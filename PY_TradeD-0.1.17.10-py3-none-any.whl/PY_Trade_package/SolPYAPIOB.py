from collections import UserDict #line:3
import decimal #line:4
from enum import Enum #line:5
import math #line:6
from pydoc_data import topics #line:7
import queue #line:8
import threading #line:9
from threading import Lock #line:10
import time #line:11
from typing import Union #line:12
from solace .messaging .messaging_service import MessagingService ,ReconnectionListener ,ReconnectionAttemptListener ,ServiceInterruptionListener ,ServiceEvent #line:14
from solace .messaging .receiver .message_receiver import MessageHandler ,InboundMessage #line:15
from solace .messaging .publisher .outbound_message import OutboundMessage #line:16
from solace .messaging .resources .topic import Topic #line:17
from solace .messaging .resources .topic_subscription import TopicSubscription #line:18
from solace .messaging .utils .cache_request_outcome import CacheRequestOutcome #line:19
from solace .messaging .resources .cached_message_subscription_request import CachedMessageSubscriptionRequest #line:20
from solace .messaging .receiver .receiver_cache_requests import ReceiverCacheRequests #line:21
from solace .messaging .receiver .inbound_message import *#line:22
from solace .messaging .utils .life_cycle_control import TerminationNotificationListener #line:23
from solace .messaging .utils .cache_request_outcome_listener import CacheRequestOutcomeListener #line:24
from solace .messaging .utils ._termination_notification_util import TerminationNotificationEvent #line:25
from solace .messaging .receiver .direct_message_receiver import DirectMessageReceiver #line:26
from solace .messaging .publisher .request_reply_message_publisher import RequestReplyMessagePublisher #line:27
from solace .messaging .publisher .publisher_health_check import PublisherReadinessListener #line:28
from datetime import datetime #line:29
import json #line:31
import os #line:32
from os .path import dirname #line:33
from decimal import Decimal #line:34
from PY_Trade_package .MarketDataMart import MarketDataMart ,SystemEvent #line:35
from PY_Trade_package .Product import ProductSnapshot ,ProductTick_Fut ,ProductTick_Stk ,TMapPrdOvs ,TMapPrdSnapshot #line:36
from PY_Trade_package .SolPYAPI_Model import *#line:38
from PY_Trade_package .SolLog import *#line:40
import logging #line:41
from time import sleep #line:42
class TStkQuoteConnStu (Enum ):#line:45
    stuUnConn =0 #line:46
    """未連線"""#line:47
    stuConnIng =10 #line:48
    """連線中"""#line:49
    stuConnected =20 #line:50
    """初次連線成功"""#line:51
    stuReConnected =21 #line:52
    """再次連線成功"""#line:53
    stuDisConnIng =30 #line:54
    """準備斷線"""#line:55
class TStkProdKind (Enum ):#line:58
    pkNone =0 #line:59
    pkNormal =10 #line:60
    """一般證券"""#line:61
    pkIndex =20 #line:62
    """指數商品(EX:加權指數)"""#line:63
class STKxFUT (Enum ):#line:66
    STK =0 #line:67
    FUT =1 #line:68
    OPT =2 #line:69
    OVSFUT =3 #line:70
class TStkQtBase ():#line:74
    fHasBAS =False #line:75
    TopicTX :str =""#line:77
    Topic5Q :str =""#line:78
    TopicHL :str =""#line:79
    fBAS =[]#line:81
    StkNo :str #line:82
    """證券代碼"""#line:83
    StkName :str #line:84
    """證券中文"""#line:85
    RefPriceOrg :str #line:86
    """參考價"""#line:87
    LimitPrice_UpOrg :str #line:88
    """漲停價"""#line:89
    LimitPrice_DownOrg :str #line:90
    """跌停價"""#line:91
    IndustryCategory :str #line:92
    "產業別"#line:93
    StockCategory :str #line:94
    "證券別"#line:95
    StockAnomalyCode :str #line:96
    "股票異常代碼"#line:97
    BoardRemark :str #line:98
    "板別註記"#line:99
    ClassRemark :str #line:100
    "類股註記"#line:101
    NonTenFaceValueIndicator :str #line:102
    "非10元面額註記"#line:103
    AbnormalRecommendationIndicator :str #line:104
    "異常推介個股註記"#line:105
    AbnormalSecuritiesIndicator :str #line:106
    "特殊異常證券註記"#line:107
    DayTradingIndicator :str #line:108
    "可現股當沖註記"#line:109
    TradingUnit :str #line:110
    "交易單位"#line:111
    def Get_TradingUnit (OOO00OOOO000O0O0O ):#line:112
        return OOO00OOOO000O0O0O .TransToInt (OOO00OOOO000O0O0O .fBAS [30 ])#line:113
    TickSizeInfo :str #line:114
    """跳動點資訊"""#line:115
    TotQtyPre :str #line:116
    """(前交易日)成交總量"""#line:117
    TotAmtPre :str #line:118
    """(前交易日)成交總額"""#line:119
    RefPPre :str #line:121
    "上一交易日參考價"#line:122
    CPPre :str #line:123
    "上一交易日收盤價"#line:124
    def __init__ (O0O0OOOOOO00OO00O ,topic :str =""):#line:126
        if topic !="":#line:127
            OOOOOOOO0O0000OOO =topic .split ("/")#line:128
            OOOOOOOO0O0000OOO [len (OOOOOOOO0O0000OOO )-1 ]="HL"#line:129
            O0O0OOOOOO00OO00O .TopicHL ="/".join (OOOOOOOO0O0000OOO )#line:130
            OOOOOOOO0O0000OOO [len (OOOOOOOO0O0000OOO )-1 ]="TX"#line:131
            O0O0OOOOOO00OO00O .TopicTX ="/".join (OOOOOOOO0O0000OOO )#line:132
            OOOOOOOO0O0000OOO [len (OOOOOOOO0O0000OOO )-1 ]="5Q"#line:133
            O0O0OOOOOO00OO00O .Topic5Q ="/".join (OOOOOOOO0O0000OOO )#line:134
    def Get_RefPrice (O0OO000O00OO0O000 )->decimal :#line:137
        return O0OO000O00OO0O000 .TransToDecimal (O0OO000O00OO0O000 .fBAS [4 ])#line:138
    def Get_LimitPrice_Up (O0O0O00O00OO0OO00 )->decimal :#line:140
        return O0O0O00O00OO0OO00 .TransToDecimal (O0O0O00O00OO0OO00 .fBAS [5 ])#line:141
    def Get_LimitPrice_Down (O00OOOOOOOO0000OO )->decimal :#line:143
        return O00OOOOOOOO0000OO .TransToDecimal (O00OOOOOOOO0000OO .fBAS [6 ])#line:144
    def Get_TotQtyPre (OOO0O0OOO00OO000O )->decimal :#line:146
        return OOO0O0OOO00OO000O .TransToDecimal (OOO0O0OOO00OO000O .fBAS [34 ])#line:147
    def Get_TotAmtPre (OOO0OOO00O000O0OO )->decimal :#line:149
        return OOO0OOO00O000O0OO .TransToDecimal (OOO0OOO00O000O0OO .fBAS [35 ])#line:150
    def Handle_BAS (O0O0O0O0O0O0OO00O ,O0000OO0OOO000OO0 :str ):#line:152
        O0O0O0O0O0O0OO00O .fBAS =O0000OO0OOO000OO0 .split ('|')#line:153
        O0O0O0O0O0O0OO00O .fHasBAS =len (O0O0O0O0O0O0OO00O .fBAS )>0 #line:154
        O0O0O0O0O0O0OO00O .StkNo =O0O0O0O0O0O0OO00O .fBAS [0 ]#line:155
        O0O0O0O0O0O0OO00O .StkName =O0O0O0O0O0O0OO00O .fBAS [1 ]#line:156
        O0O0O0O0O0O0OO00O .RefPriceOrg =O0O0O0O0O0O0OO00O .fBAS [4 ]#line:157
        O0O0O0O0O0O0OO00O .LimitPrice_UpOrg =O0O0O0O0O0O0OO00O .fBAS [5 ]#line:158
        O0O0O0O0O0O0OO00O .LimitPrice_DownOrg =O0O0O0O0O0O0OO00O .fBAS [6 ]#line:159
        O0O0O0O0O0O0OO00O .IndustryCategory =O0O0O0O0O0O0OO00O .fBAS [7 ]#line:160
        O0O0O0O0O0O0OO00O .StockCategory =O0O0O0O0O0O0OO00O .fBAS [8 ]#line:161
        O0O0O0O0O0O0OO00O .StockAnomalyCode =O0O0O0O0O0O0OO00O .fBAS [10 ]#line:162
        O0O0O0O0O0O0OO00O .BoardRemark =O0O0O0O0O0O0OO00O .fBAS [11 ]#line:163
        O0O0O0O0O0O0OO00O .ClassRemark =O0O0O0O0O0O0OO00O .fBAS [12 ]#line:164
        O0O0O0O0O0O0OO00O .NonTenFaceValueIndicator =O0O0O0O0O0O0OO00O .fBAS [13 ]#line:165
        O0O0O0O0O0O0OO00O .AbnormalRecommendationIndicator =O0O0O0O0O0O0OO00O .fBAS [14 ]#line:166
        O0O0O0O0O0O0OO00O .AbnormalSecuritiesIndicator =O0O0O0O0O0O0OO00O .fBAS [15 ]#line:167
        O0O0O0O0O0O0OO00O .DayTradingIndicator =O0O0O0O0O0O0OO00O .fBAS [16 ]#line:168
        O0O0O0O0O0O0OO00O .TradingUnit =O0O0O0O0O0O0OO00O .fBAS [30 ]#line:169
        O0O0O0O0O0O0OO00O .TickSizeInfo =O0O0O0O0O0O0OO00O .fBAS [33 ]#line:170
        O0O0O0O0O0O0OO00O .TotQtyPre =O0O0O0O0O0O0OO00O .fBAS [34 ]#line:171
        O0O0O0O0O0O0OO00O .TotAmtPre =O0O0O0O0O0O0OO00O .fBAS [35 ]#line:172
        O0O0O0O0O0O0OO00O .RefPPre =O0O0O0O0O0O0OO00O .fBAS [36 ]#line:173
        O0O0O0O0O0O0OO00O .CPPre =O0O0O0O0O0O0OO00O .fBAS [37 ]#line:174
        if O0O0O0O0O0O0OO00O .TopicTX !="":#line:175
            OOO0O00O0O0O00O0O =O0O0O0O0O0O0OO00O .TopicHL .split ("/")#line:176
            OOO0O00O0O0O00O0O [len (OOO0O00O0O0O00O0O )-2 ]=O0O0O0O0O0O0OO00O .StkNo #line:177
            O0O0O0O0O0O0OO00O .TopicHL ="/".join (OOO0O00O0O0O00O0O )#line:178
            OOO0O00O0O0O00O0O =O0O0O0O0O0O0OO00O .TopicTX .split ("/")#line:179
            OOO0O00O0O0O00O0O [len (OOO0O00O0O0O00O0O )-2 ]=O0O0O0O0O0O0OO00O .StkNo #line:180
            O0O0O0O0O0O0OO00O .TopicTX ="/".join (OOO0O00O0O0O00O0O )#line:181
            OOO0O00O0O0O00O0O =O0O0O0O0O0O0OO00O .Topic5Q .split ("/")#line:182
            OOO0O00O0O0O00O0O [len (OOO0O00O0O0O00O0O )-2 ]=O0O0O0O0O0O0OO00O .StkNo #line:183
            O0O0O0O0O0O0OO00O .Topic5Q ="/".join (OOO0O00O0O0O00O0O )#line:184
    def TransToInt (O0O0O0OOOO00000OO ,O0O000OO0O0OO0O00 :str )->int :#line:187
        try :#line:189
            return int (O0O000OO0O0OO0O00 )#line:190
        except Exception as OOO0O0O0O00OOOO00 :#line:191
            pass #line:192
        return 0 #line:194
    def TransToDecimal (OOOO0OOOO0O0O0OOO ,O0OOOOO0OO0O00OO0 :str )->decimal :#line:196
        try :#line:197
            return Decimal (O0OOOOO0OO0O00OO0 )#line:198
        except Exception as OOOO000000O0O0000 :#line:199
            print (f"Not a Decimal{OOOO000000O0O0000}")#line:200
        return 0 #line:201
class TStkQtHL ():#line:202
    HasHL =False #line:203
    fHL =[]#line:204
    TopicTX :str =""#line:205
    Topic5Q :str =""#line:206
    Market :str =""#line:208
    """市場別(TSE/OTC)"""#line:209
    StkKind :str =""#line:210
    """"證券別(S/W/Idx)"""#line:211
    Symbol :str =""#line:212
    """委託商品代碼(2330)"""#line:213
    DealTime :str =""#line:214
    """撮合時間(成交)(EX:173547.32700)"""#line:215
    DealSn :str =""#line:216
    """成交序號"""#line:217
    def Get_DealSn (O000OO0OO0O0OO000 )->int :#line:219
        return O000OO0OO0O0OO000 .TransToInt (O000OO0OO0O0OO000 .fHL [4 ])#line:220
    Sn_5Q :str =""#line:221
    """五檔序號(指數類=空字串)"""#line:222
    def Get_Sn_5Q (OO00O0OOOOO00O0OO )->int :#line:224
        return OO00O0OOOOO00O0OO .TransToInt (OO00O0OOOOO00O0OO .fHL [5 ])#line:225
    DealPriceOrg :str =""#line:226
    """成交價"""#line:227
    def Get_DealPrice (OOO00O0O0O0000O00 )->decimal :#line:229
        return OOO00O0O0O0000O00 .TransToDecimal (OOO00O0O0O0000O00 .fHL [6 ])#line:230
    DealPrice :decimal #line:233
    """成交價"""#line:234
    DealQty :str =""#line:235
    """成交單量(指數類=0)"""#line:236
    def Get_DealQty2Dec (OO00O0O00OO00O0O0 )->decimal :#line:238
        return OO00O0O00OO00O0O0 .TransToDecimal (OO00O0O00OO00O0O0 .fHL [7 ])#line:239
    def Get_DealQty2Int (OOO0O0O0000000O0O )->int :#line:241
        return OOO0O0O0000000O0O .TransToInt (OOO0O0O0000000O0O .fHL [7 ])#line:242
    HighPriceOrg :str =""#line:244
    """當日最高價"""#line:245
    def Get_HighPrice (OO00O0O0O000OO000 )->decimal :#line:247
        return OO00O0O0O000OO000 .TransToDecimal (OO00O0O0O000OO000 .fHL [8 ])#line:248
    LowPriceOrg :str =""#line:250
    """當日最低價"""#line:251
    def Get_LowPrice (OO0O00O000O0OO000 )->decimal :#line:253
        return OO0O00O000O0OO000 .TransToDecimal (OO0O00O000O0OO000 .fHL [9 ])#line:254
    TotAmt :str =""#line:256
    """成交總額(指數類=0)"""#line:257
    def Get_TotAmt2Dec (O0000O000O0O0OOOO )->decimal :#line:259
        return O0000O000O0O0OOOO .TransToDecimal (O0000O000O0O0OOOO .fHL [10 ])#line:260
    def Get_TotAmt2Int (OO00OO0O0O0OO0O00 )->int :#line:262
        return OO00OO0O0O0OO0O00 .TransToInt (OO00OO0O0O0OO0O00 .fHL [10 ])#line:263
    TotQty :str =""#line:265
    """成交總量(指數類=0)"""#line:266
    def Get_TotQty2Dec (O00000OO0000OOO0O )->decimal :#line:268
        return O00000OO0000OOO0O .TransToDecimal (O00000OO0000OOO0O .fHL [11 ])#line:269
    def Get_TotQty2Int (O00O00OO0OO00O0O0 )->int :#line:271
        return O00O00OO0OO00O0O0 .TransToInt (O00O00OO0OO00O0O0 .fHL [11 ])#line:272
    FirstDerivedBuyPrice :str =""#line:275
    "衍生委託單第一檔買進價格"#line:276
    FirstDerivedBuyQty :str =""#line:277
    "衍生委託單第一檔買進價格數量"#line:278
    FirstDerivedSellPrice :str =""#line:279
    "衍生委託單第一檔賣出價格數量"#line:280
    FirstDerivedSellQty :str =""#line:281
    "衍生委託單第一檔賣出價格數量"#line:282
    OpenPriceOrg :str =""#line:284
    """開盤價"""#line:285
    def Get_OpenPrice (OOO0OO00O0O0O00O0 )->decimal :#line:287
        return OOO0OO00O0O0O00O0 .TransToDecimal (OOO0OO00O0O0O00O0 .fHL [42 ])#line:288
    TryMark_Deal :str =""#line:290
    "成交試撮註記(試撮=1, 非試撮=0)"#line:291
    TryMark_5Q :str =""#line:292
    "五檔試撮註記(試撮=1, 非試撮=0)"#line:293
    fAryB5Q_P =[13 ,15 ,17 ,19 ,21 ]#line:296
    """買五檔價在字串中的位置"""#line:297
    fAryB5Q_Q =[14 ,16 ,18 ,20 ,22 ]#line:298
    """買五檔價在字串中的位置"""#line:299
    """買5檔的檔數"""#line:301
    B5QCountOrg :str =""#line:302
    """買5檔的檔數(指數類=0)"""#line:303
    B5QCount =0 #line:304
    """買5檔的檔數(指數類=0)"""#line:305
    def B5Q_POrg (O000OO0OO0O0OOO0O ,OO0000OOO00O0OOO0 :int )->str :#line:307
        ""#line:308
        if OO0000OOO00O0OOO0 >O000OO0OO0O0OOO0O .B5QCount :#line:309
            return ""#line:310
        else :#line:311
            return O000OO0OO0O0OOO0O .fHL [O000OO0OO0O0OOO0O .fAryB5Q_P [OO0000OOO00O0OOO0 -1 ]]#line:312
    def Get_B5Q_P (OO0O0OOOO00OO0O00 ,O0O0O000OO0O0O0O0 :int )->decimal :#line:314
        ""#line:315
        if O0O0O000OO0O0O0O0 >OO0O0OOOO00OO0O00 .B5QCount :#line:316
            return 0 #line:317
        else :#line:318
            return OO0O0OOOO00OO0O00 .TransToDecimal (OO0O0OOOO00OO0O00 .fHL [OO0O0OOOO00OO0O00 .fAryB5Q_P [O0O0O000OO0O0O0O0 -1 ]])#line:319
    def B5Q_QOrg (OOO0000OOO00OO0OO ,O0OOO000OOOO0OO00 :int )->str :#line:321
        ""#line:322
        if (O0OOO000OOOO0OO00 >OOO0000OOO00OO0OO .B5QCount ):#line:323
            return ""#line:324
        else :#line:325
            return OOO0000OOO00OO0OO .fHL [OOO0000OOO00OO0OO .fAryB5Q_Q [O0OOO000OOOO0OO00 -1 ]]#line:326
    def Get_B5Q_Q (O0OOOOO0O000OOO00 ,O00OO0OOOOO00O000 :int )->int :#line:328
        ""#line:329
        if (O00OO0OOOOO00O000 >O0OOOOO0O000OOO00 .B5QCount ):#line:330
            return 0 #line:331
        else :#line:332
            return O0OOOOO0O000OOO00 .TransToInt (O0OOOOO0O000OOO00 .fHL [O0OOOOO0O000OOO00 .fAryB5Q_Q [O00OO0OOOOO00O000 -1 ]])#line:333
    fAryS5Q_P =[24 ,26 ,28 ,30 ,32 ]#line:336
    """賣五檔價在字串中的位置"""#line:337
    fAryS5Q_Q =[25 ,27 ,29 ,31 ,33 ]#line:338
    """賣五檔價在字串中的位置"""#line:339
    S5QCountOrg :str =""#line:341
    """賣5檔的檔數(指數類=0)"""#line:342
    S5QCount :int #line:343
    def S5Q_POrg (OO0O000000O000OOO ,O000000O00OOOO0OO :int )->str :#line:345
        ""#line:346
        if O000000O00OOOO0OO >OO0O000000O000OOO .S5QCount :#line:347
            return ""#line:348
        else :#line:349
            return OO0O000000O000OOO .fHL [OO0O000000O000OOO .fAryS5Q_P [O000000O00OOOO0OO -1 ]]#line:350
    def Get_S5Q_P (OO0O0O0OOOO0OOOO0 ,O0000OO00OO0O0OOO :int )->decimal :#line:352
        ""#line:353
        if O0000OO00OO0O0OOO >OO0O0O0OOOO0OOOO0 .S5QCount :#line:354
            return 0 #line:355
        else :#line:356
            return OO0O0O0OOOO0OOOO0 .TransToDecimal (OO0O0O0OOOO0OOOO0 .fHL [OO0O0O0OOOO0OOOO0 .fAryS5Q_P [O0000OO00OO0O0OOO -1 ]])#line:357
    def S5Q_QOrg (O00O00O0OO00O00OO ,OOOO00OOO00OOOO00 :int )->str :#line:359
        ""#line:360
        if OOOO00OOO00OOOO00 >O00O00O0OO00O00OO .S5QCount :#line:361
            return ""#line:362
        else :#line:363
            return O00O00O0OO00O00OO .fHL [O00O00O0OO00O00OO .fAryS5Q_Q [OOOO00OOO00OOOO00 -1 ]]#line:364
    def Get_S5Q_Q (O0O0OOOOOO0OOO0O0 ,OO0OO0OOOO00OOOOO :int )->int :#line:366
        ""#line:367
        if OO0OO0OOOO00OOOOO >O0O0OOOOOO0OOO0O0 .fS5QCount :#line:368
            return 0 #line:369
        else :#line:370
            return O0O0OOOOOO0OOO0O0 .TransToInt (O0O0OOOOOO0OOO0O0 .fHL [O0O0OOOOOO0OOO0O0 .fAryS5Q_Q [OO0OO0OOOO00OOOOO -1 ]])#line:371
    WholeTotAmt :str #line:375
    """整體市場成交總額"""#line:376
    def Get_WholeTotAmt (OO00O0O0000OO00OO )->int :#line:378
        return OO00O0O0000OO00OO .TransToInt (OO00O0O0000OO00OO .fHL [34 ])#line:379
    WholeTotQty :str #line:381
    """整體市場成交數量"""#line:382
    def Get_WholeTotQty (OO0O0000O0O00000O )->int :#line:384
        return OO0O0000O0O00000O .TransToInt (OO0O0000O0O00000O .fHL [35 ])#line:385
    WholeDealCount :str #line:387
    """整體市場成交筆數"""#line:388
    def Get_WholeDealCount (O0O00O00O0000O00O )->int :#line:390
        return O0O00O00O0000O00O .TransToInt (O0O00O00O0000O00O .fHL [36 ])#line:391
    SumBuyOrderCount :str #line:393
    """整體市場委託買進筆數"""#line:394
    def Get_SumBuyOrderCount (OO00OO000O0O000OO )->int :#line:396
        return OO00OO000O0O000OO .TransToInt (OO00OO000O0O000OO .fHL [37 ])#line:397
    SumSellOrderCount :str #line:399
    """整體市場委託賣出筆數"""#line:400
    def Get_SumSellOrderCount (OO0000O000O0OO0O0 )->int :#line:402
        return OO0000O000O0OO0O0 .TransToInt (OO0000O000O0OO0O0 .fHL [38 ])#line:403
    SumBuyOrderQty :str #line:405
    """整體市場委託買進數量"""#line:406
    def Get_SumBuyOrderQty (OOO00OO0O0O00OOO0 )->int :#line:408
        return OOO00OO0O0O00OOO0 .TransToInt (OOO00OO0O0O00OOO0 .fHL [39 ])#line:409
    SumSellOrderQty :str #line:411
    """整體市場委託賣出數量"""#line:412
    def Get_SumSellOrderQty (O0OO00OOOO000O00O )->int :#line:414
        return O0OO00OOOO000O00O .TransToInt (O0OO00OOOO000O00O .fHL [40 ])#line:415
    def Handle_HL (O00OOO00OO000O0OO ,O000OOOO0O0O00OOO :str ):#line:418
        O00OOO00OO000O0OO .fHL =O000OOOO0O0O00OOO .split ('|')#line:419
        O00OOO00OO000O0OO .HasHL =len (O00OOO00OO000O0OO .fHL )>0 #line:420
        O00OOO00OO000O0OO .Market =O00OOO00OO000O0OO .fHL [0 ]#line:422
        O00OOO00OO000O0OO .StkKind =O00OOO00OO000O0OO .fHL [1 ]#line:423
        O00OOO00OO000O0OO .Symbol =O00OOO00OO000O0OO .fHL [2 ]#line:424
        O00OOO00OO000O0OO .DealTime =O00OOO00OO000O0OO .fHL [3 ]#line:425
        O00OOO00OO000O0OO .DealSn =O00OOO00OO000O0OO .fHL [4 ]#line:426
        O00OOO00OO000O0OO .Sn_5Q =O00OOO00OO000O0OO .fHL [5 ]#line:427
        O00OOO00OO000O0OO .DealPriceOrg =O00OOO00OO000O0OO .fHL [6 ]#line:428
        O00OOO00OO000O0OO .DealPrice =O00OOO00OO000O0OO .TransToDecimal (O00OOO00OO000O0OO .DealPriceOrg )#line:429
        O00OOO00OO000O0OO .DealQty =O00OOO00OO000O0OO .fHL [7 ]#line:430
        O00OOO00OO000O0OO .HighPriceOrg =O00OOO00OO000O0OO .fHL [8 ]#line:431
        O00OOO00OO000O0OO .LowPriceOrg =O00OOO00OO000O0OO .fHL [9 ]#line:432
        O00OOO00OO000O0OO .TotAmt =O00OOO00OO000O0OO .fHL [10 ]#line:433
        O00OOO00OO000O0OO .TotQty =O00OOO00OO000O0OO .fHL [11 ]#line:434
        O00OOO00OO000O0OO .FirstDerivedBuyPrice =O00OOO00OO000O0OO .fHL [35 ]#line:435
        O00OOO00OO000O0OO .FirstDerivedBuyQty =O00OOO00OO000O0OO .fHL [36 ]#line:436
        O00OOO00OO000O0OO .FirstDerivedSellPrice =O00OOO00OO000O0OO .fHL [37 ]#line:437
        O00OOO00OO000O0OO .FirstDerivedSellQty =O00OOO00OO000O0OO .fHL [38 ]#line:438
        O00OOO00OO000O0OO .B5QCountOrg =O00OOO00OO000O0OO .fHL [12 ]#line:440
        O00OOO00OO000O0OO .B5QCount =O00OOO00OO000O0OO .TransToInt (O00OOO00OO000O0OO .B5QCountOrg )#line:441
        O00OOO00OO000O0OO .S5QCountOrg =O00OOO00OO000O0OO .fHL [23 ]#line:442
        O00OOO00OO000O0OO .S5QCount =O00OOO00OO000O0OO .TransToInt (O00OOO00OO000O0OO .S5QCountOrg )#line:443
        O00OOO00OO000O0OO .WholeTotAmt =O00OOO00OO000O0OO .fHL [34 ]#line:444
        O00OOO00OO000O0OO .WholeTotQty =O00OOO00OO000O0OO .fHL [35 ]#line:445
        O00OOO00OO000O0OO .WholeDealCount =O00OOO00OO000O0OO .fHL [36 ]#line:446
        O00OOO00OO000O0OO .SumBuyOrderCount =O00OOO00OO000O0OO .fHL [37 ]#line:447
        O00OOO00OO000O0OO .SumSellOrderCount =O00OOO00OO000O0OO .fHL [38 ]#line:448
        O00OOO00OO000O0OO .SumBuyOrderQty =O00OOO00OO000O0OO .fHL [39 ]#line:449
        O00OOO00OO000O0OO .SumSellOrderQty =O00OOO00OO000O0OO .fHL [40 ]#line:450
        O00OOO00OO000O0OO .OpenPriceOrg =O00OOO00OO000O0OO .fHL [42 ]#line:452
        O00OOO00OO000O0OO .TryMark_Deal =O00OOO00OO000O0OO .fHL [43 ]#line:453
        O00OOO00OO000O0OO .TryMark_5Q =O00OOO00OO000O0OO .fHL [44 ]#line:454
        if O00OOO00OO000O0OO .HasHL :#line:455
            O00OOO00OO000O0OO .TopicTX =f"Quote/TWS/{O00OOO00OO000O0OO.StkKind}/{O00OOO00OO000O0OO.Market}/{O00OOO00OO000O0OO.Symbol}/TX"#line:456
            O00OOO00OO000O0OO .Topic5Q =f"Quote/TWS/{O00OOO00OO000O0OO.StkKind}/{O00OOO00OO000O0OO.Market}/{O00OOO00OO000O0OO.Symbol}/5Q"#line:457
    def TransToInt (OOO00O00OO000O0OO ,OO000O0000OO00000 :str )->int :#line:461
        try :#line:462
            return int (OO000O0000OO00000 )#line:463
        except Exception as O000000OOO0O0000O :#line:464
            return 0 #line:465
    def TransToDecimal (OOOO0OO0O0OO00O00 ,O0OOOOOOO0OOO0O00 :str )->decimal :#line:467
        try :#line:468
            return Decimal (O0OOOOOOO0OOO0O00 )#line:469
        except Exception as O000O0OOOO0O00O0O :#line:470
            return 0 #line:471
    def __init__ (OOOO0000OOOO0000O )->None :#line:474
        pass #line:475
    def __str__ (OOOOO00O00O0OOO00 )->str :#line:477
        return f"""Market:{OOOOO00O00O0OOO00.Market} StkKind:{OOOOO00O00O0OOO00.StkKind} Symbol:{OOOOO00O00O0OOO00.Symbol} DealTime:{OOOOO00O00O0OOO00.DealTime}"""+"""DealSn:{self.DealSn} Sn_5Q:{self.Sn_5Q} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty}"""+"""HighPriceOrg:{self.HighPriceOrg} LowPriceOrg:{self.LowPriceOrg} TotAmt:{self.TotAmt} TotQty:{self.TotQty}"""+"""B5QCountOrg:{self.B5QCountOrg} S5QCount:{self.S5QCount} WholeTotAmt:{self.WholeTotAmt} WholeTotQty:{self.WholeTotQty}"""+"""WholeDealCount:{self.WholeDealCount} SumBuyOrderCount:{self.SumBuyOrderCount} SumSellOrderCount:{self.SumSellOrderCount}"""+"""SumBuyOrderQty:{self.SumBuyOrderQty} SumSellOrderQty:{self.SumSellOrderQty} OpenPriceOrg:{self.OpenPriceOrg}"""#line:483
class TStkQtTX :#line:484
    fTX =[]#line:485
    HL_Sn_5Q =0 #line:486
    """來自HL回補的5檔序號(當收到即時成交行情時,若帶五檔行情,需判斷是否比HL紀錄的還大, 若比較小, 表示很久沒有成交行情, 但五檔一直在變動, 則不可使用成交行情裡的五檔資料)"""#line:487
    HL_TotAmt :decimal =0 #line:488
    """來自HL的成交總額，用於累加收到成交行情時的成交價*成交單量*交易單位"""#line:489
    BAS_TradingUnit =1 #line:490
    """來自BAS的交易單位用，用於累加收到成交行情時的成交價*成交單量*交易單位"""#line:491
    def Handle_TXRcv (O0O0O000OOO00000O ,OOOO00O00O0O0O00O :str ):#line:493
        ""#line:494
        try :#line:495
            O00000OOO0OOO0OO0 :int =0 #line:496
            OOOOOO0O0O000O0OO :int =0 #line:497
            OOO00OO00OO0O0OOO =OOOO00O00O0O0O00O .split ('|')#line:498
            if OOO00OO00OO0O0OOO [4 ]==TSolQuoteStkSet .TryMark_No :#line:500
                O0O0O000OOO00000O .fPROC_HandleData =O0O0O000OOO00000O .HandleData #line:501
                if O0O0O000OOO00000O .fTX ==None :#line:503
                    O0O0O000OOO00000O .fTX =OOO00OO00OO0O0OOO #line:504
                    O0O0O000OOO00000O .SetData ()#line:505
                else :#line:506
                    OOOOOO0O0O000O0OO =O0O0O000OOO00000O .TransToInt (OOO00OO00OO0O0OOO [3 ])#line:507
                    O00000OOO0OOO0OO0 =O0O0O000OOO00000O .Get_DealSn ()#line:508
                    if OOOOOO0O0O000O0OO >O00000OOO0OOO0OO0 :#line:509
                        O0O0O000OOO00000O .fTX =OOO00OO00OO0O0OOO #line:510
                        O0O0O000OOO00000O .SetData ()#line:511
                O0O0O000OOO00000O .fPROC_CalcHightLowPrice ()#line:513
                O0O0O000OOO00000O .CalTotalTradingAmount ()#line:514
                O00000OOO0OOO0OO0 =O0O0O000OOO00000O .Get_DealSn ()#line:517
                if O00000OOO0OOO0OO0 >=O0O0O000OOO00000O .HL_Sn_5Q :#line:518
                    O0O0O000OOO00000O .fB5QCount =O0O0O000OOO00000O .TransToInt (O0O0O000OOO00000O .B5QCountOrg )#line:520
                    O0O0O000OOO00000O .fS5QCount =O0O0O000OOO00000O .TransToInt (O0O0O000OOO00000O .S5QCountOrg )#line:522
                else :#line:523
                    O0O0O000OOO00000O .fB5QCount =0 #line:524
                    O0O0O000OOO00000O .fS5QCount =0 #line:525
            else :#line:526
                O0O0O000OOO00000O .fPROC_HandleData =O0O0O000OOO00000O .HandleData_TryMarket #line:527
                O0O0O000OOO00000O .fPROC_HandleData (OOOO00O00O0O0O00O )#line:528
        except Exception as O00O0O000OO0O0O00 :#line:529
            pass #line:530
    def Handle_TX (O0O00OO0OO00O0O0O ,OO000OO0OO00O0O0O :str ):#line:532
        ""#line:533
        O0O00OO0OO00O0O0O .fPROC_HandleData (OO000OO0OO00O0O0O )#line:534
    def HandleData_TryMarket (O0OOOO00O000O00O0 ,O0000OOOO00OOO000 :str ):#line:538
        ""#line:539
        if O0000OOOO00OOO000 .split ('|')[4 ]==TSolQuoteStkSet .TryMark_No :#line:540
            OO0OO0O0000O00O0O =O0OOOO00O000O00O0 .HandleData #line:541
            OO0OO0O0000O00O0O (O0000OOOO00OOO000 )#line:542
        else :#line:543
            O0OOOO00O000O00O0 .fTX =O0000OOOO00OOO000 .split ('|')#line:544
            O0OOOO00O000O00O0 .SetData ()#line:545
            O0OOOO00O000O00O0 .B5QCount =O0OOOO00O000O00O0 .TransToInt (O0OOOO00O000O00O0 .B5QCountOrg )#line:546
            O0OOOO00O000O00O0 .S5QCount =O0OOOO00O000O00O0 .TransToInt (O0OOOO00O000O00O0 .S5QCountOrg )#line:547
    def HandleData (OOO000O00OO00O0OO ,O00OO0OOOO00O000O :str ):#line:549
        ""#line:550
        OOO000O00OO00O0OO .fTX =O00OO0OOOO00O000O .split ('|')#line:551
        OOO000O00OO00O0OO .SetData ()#line:552
        OOO000O00OO00O0OO .fPROC_CalcHightLowPrice ()#line:553
        OOO000O00OO00O0OO .CalTotalTradingAmount ()#line:554
        OOO000O00OO00O0OO .B5QCount =OOO000O00OO00O0OO .TransToInt (OOO000O00OO00O0OO .B5QCountOrg )#line:555
        OOO000O00OO00O0OO .S5QCount =OOO000O00OO00O0OO .TransToInt (OOO000O00OO00O0OO .S5QCountOrg )#line:556
    def SetData (O0O00OOO0O0OOOO0O ):#line:558
        O0O00OOO0O0OOOO0O .SysTime =O0O00OOO0O0OOOO0O .fTX [1 ]#line:559
        O0O00OOO0O0OOOO0O .DealTime =O0O00OOO0O0OOOO0O .fTX [2 ]#line:560
        O0O00OOO0O0OOOO0O .DealSn =O0O00OOO0O0OOOO0O .fTX [3 ]#line:561
        O0O00OOO0O0OOOO0O .TryMark =O0O00OOO0O0OOOO0O .fTX [4 ]#line:562
        O0O00OOO0O0OOOO0O .Has5Q =O0O00OOO0O0OOOO0O .fTX [5 ]#line:563
        if len (O0O00OOO0O0OOOO0O .fTX )>8 :#line:564
            O0O00OOO0O0OOOO0O .IsOpenRecord =O0O00OOO0O0OOOO0O .fTX [8 ][4 ]=='1'#line:565
        if len (O0O00OOO0O0OOOO0O .fTX )>8 :#line:566
            O0O00OOO0O0OOOO0O .IsCloseRecord =O0O00OOO0O0OOOO0O .fTX [8 ][5 ]=='1'#line:567
        O0O00OOO0O0OOOO0O .TotQty =O0O00OOO0O0OOOO0O .fTX [9 ]#line:568
        O0O00OOO0O0OOOO0O .DealPriceOrg =O0O00OOO0O0OOOO0O .fTX [10 ]#line:569
        O0O00OOO0O0OOOO0O .DealQty =O0O00OOO0O0OOOO0O .fTX [11 ]#line:570
        O0O00OOO0O0OOOO0O .B5QCountOrg =O0O00OOO0O0OOOO0O .fTX [12 ]#line:571
        O0O00OOO0O0OOOO0O .S5QCountOrg =O0O00OOO0O0OOOO0O .fTX [23 ]#line:572
        O0O00OOO0O0OOOO0O .WholeTotAmt =O0O00OOO0O0OOOO0O .fTX [34 ]#line:574
        O0O00OOO0O0OOOO0O .WholeTotQty =O0O00OOO0O0OOOO0O .fTX [35 ]#line:575
        O0O00OOO0O0OOOO0O .WholeDealCount =O0O00OOO0O0OOOO0O .fTX [36 ]#line:576
        O0O00OOO0O0OOOO0O .SumBuyOrderCount =O0O00OOO0O0OOOO0O .fTX [37 ]#line:577
        O0O00OOO0O0OOOO0O .SumSellOrderCount =O0O00OOO0O0OOOO0O .fTX [38 ]#line:578
        O0O00OOO0O0OOOO0O .SumBuyOrderQty =O0O00OOO0O0OOOO0O .fTX [39 ]#line:579
        O0O00OOO0O0OOOO0O .SumSellOrderQty =O0O00OOO0O0OOOO0O .fTX [40 ]#line:580
        O0O00OOO0O0OOOO0O .IsFixedPriceTransaction =O0O00OOO0O0OOOO0O .fTX [41 ]#line:581
    fPROC_HandleData :callable =None #line:584
    """PROC_HandleData"""#line:585
    SysTime :str #line:589
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""#line:590
    DealTime :str #line:591
    """撮合時間(成交)(EX:085229.843665)"""#line:592
    DealSn :str #line:593
    """序號(成交序號、5檔序號)"""#line:594
    def Get_DealSn (O0000000O0O0000OO )->int :#line:596
        return O0000000O0O0000OO .TransToInt (O0000000O0O0000OO .fTX [3 ])#line:597
    TryMark ="1"#line:598
    """試撮註記(試撮=1, 非試撮=0)"""#line:599
    Has5Q :str #line:600
    """五檔揭示註記(揭示=1, 不揭示=0)"""#line:601
    IsOpenRecord :bool =False #line:603
    """此筆是否為開盤行情(False:僅代表此筆非開盤行情, 並不代表盤中或收盤狀態)"""#line:604
    IsCloseRecord :bool =False #line:605
    """此筆是否為收盤行情(False:僅代表此筆非收盤行情, 並不代表盤中或開盤狀態)"""#line:606
    TotQty :str #line:608
    """成交總量"""#line:609
    def Get_TotQty2Dec (O0OOO0OOOOOOO00O0 )->decimal :#line:611
        return O0OOO0OOOOOOO00O0 .TransToDecimal (O0OOO0OOOOOOO00O0 .fTX [9 ])#line:612
    def Get_TotQty2Int (OOOO0OOO0OO0OOO00 )->int :#line:614
        return OOOO0OOO0OO0OOO00 .TransToInt (OOOO0OOO0OO0OOO00 .fTX [9 ])#line:615
    DealPriceOrg :str #line:617
    """成交價"""#line:618
    def Get_DealPrice (OOOO0OOO00O0OO0O0 )->decimal :#line:620
        return OOOO0OOO00O0OO0O0 .TransToDecimal (OOOO0OOO00O0OO0O0 .fTX [10 ])#line:621
    DealQty :str #line:623
    """成交單量"""#line:624
    def Get_DealQty2Dec (OO0OOOO0O0OO0O0O0 )->decimal :#line:626
        return OO0OOOO0O0OO0O0O0 .TransToDecimal (OO0OOOO0O0OO0O0O0 .fTX [11 ])#line:627
    def Get_DealQty2Int (O0O0O0OO00O00OOO0 )->int :#line:629
        return O0O0O0OO00O00OOO0 .TransToInt (O0O0O0OO00O00OOO0 .fTX [11 ])#line:630
    fAryB5Q_P =[13 ,15 ,17 ,19 ,21 ]#line:634
    """買五檔價在字串中的位置"""#line:635
    fAryB5Q_Q =[14 ,16 ,18 ,20 ,22 ]#line:636
    """買五檔價在字串中的位置"""#line:637
    B5QCountOrg :str #line:640
    """買5檔的檔數"""#line:641
    B5QCount :int #line:642
    """買5檔的檔數"""#line:643
    def B5Q_POrg (O000O0OO0OOO000O0 ,OO00O00000OOOO00O :int )->str :#line:645
        ""#line:646
        if (OO00O00000OOOO00O >O000O0OO0OOO000O0 .B5QCount ):#line:647
            return ""#line:648
        else :#line:649
            return O000O0OO0OOO000O0 .fTX [O000O0OO0OOO000O0 .fAryB5Q_P [OO00O00000OOOO00O -1 ]]#line:650
    def Get_B5Q_P (OO00000O0O0000O00 ,O0O00OO00O000O0OO :int )->decimal :#line:652
        ""#line:653
        if (O0O00OO00O000O0OO >OO00000O0O0000O00 .B5QCount ):#line:654
            return 0 #line:655
        else :#line:656
            return OO00000O0O0000O00 .TransToDecimal (OO00000O0O0000O00 .fTX [OO00000O0O0000O00 .fAryB5Q_P [O0O00OO00O000O0OO -1 ]])#line:657
    def B5Q_QOrg (O000O0O00OOO0OO00 ,O0OOOO00OOOO000OO :int )->str :#line:659
        ""#line:660
        if (O0OOOO00OOOO000OO >O000O0O00OOO0OO00 .B5QCount ):#line:661
            return ""#line:662
        else :#line:663
            return O000O0O00OOO0OO00 .fTX [O000O0O00OOO0OO00 .fAryB5Q_Q [O0OOOO00OOOO000OO -1 ]]#line:664
    def Get_B5Q_Q (O0O0OOOOO0OO000OO ,O00OO0000OO0000O0 :int )->int :#line:666
        ""#line:667
        if (O00OO0000OO0000O0 >O0O0OOOOO0OO000OO .B5QCount ):#line:668
            return 0 #line:669
        else :#line:670
            return O0O0OOOOO0OO000OO .TransToInt (O0O0OOOOO0OO000OO .fTX [O0O0OOOOO0OO000OO .fAryB5Q_Q [O00OO0000OO0000O0 -1 ]])#line:671
    fAryS5Q_P =[24 ,26 ,28 ,30 ,32 ]#line:675
    """賣五檔價在字串中的位置"""#line:676
    fAryS5Q_Q =[25 ,27 ,29 ,31 ,33 ]#line:677
    """賣五檔價在字串中的位置"""#line:678
    S5QCountOrg :str #line:681
    """賣5檔的檔數"""#line:682
    S5QCount :int #line:683
    """賣5檔的檔數"""#line:684
    def S5Q_POrg (O00000OOOOO000OO0 ,O0O0O00O0000O000O :int )->str :#line:686
        ""#line:687
        if (O0O0O00O0000O000O >O00000OOOOO000OO0 .S5QCount ):#line:688
            return ""#line:689
        else :#line:690
            return O00000OOOOO000OO0 .fTX [O00000OOOOO000OO0 .fAryS5Q_P [O0O0O00O0000O000O -1 ]]#line:691
    def Get_S5Q_P (OO000OOOO0000O0OO ,O0O000O0O0O0O0000 :int )->decimal :#line:693
        ""#line:694
        if (O0O000O0O0O0O0000 >OO000OOOO0000O0OO .S5QCount ):#line:695
            return 0 #line:696
        else :#line:697
            return OO000OOOO0000O0OO .TransToDecimal (OO000OOOO0000O0OO .fTX [OO000OOOO0000O0OO .fAryS5Q_P [O0O000O0O0O0O0000 -1 ]])#line:698
    def S5Q_QOrg (O0OO000OO0000O000 ,O0OOOOOO00O00OOOO :int )->str :#line:700
        ""#line:701
        if (O0OOOOOO00O00OOOO >O0OO000OO0000O000 .S5QCount ):#line:702
            return ""#line:703
        else :#line:704
            return O0OO000OO0000O000 .fTX [O0OO000OO0000O000 .fAryS5Q_Q [O0OOOOOO00O00OOOO -1 ]]#line:705
    def Get_S5Q_Q (O00000000O0OOO0O0 ,O00O0OOOOOOOO0O0O :int )->int :#line:707
        ""#line:708
        if (O00O0OOOOOOOO0O0O >O00000000O0OOO0O0 .S5QCount ):#line:709
            return 0 #line:710
        else :#line:711
            return O00000000O0OOO0O0 .TransToInt (O00000000O0OOO0O0 .fTX [O00000000O0OOO0O0 .fAryS5Q_Q [O00O0OOOOOOOO0O0O -1 ]])#line:712
    fDealPrice =0 #line:716
    """成交價"""#line:717
    HighPrice =0 #line:718
    """當日最高價"""#line:719
    LowPrice =0 #line:720
    """當日最低價"""#line:721
    def CalcHightLowPrice (OOOOO0O0O0OOO0OOO ):#line:723
        ""#line:724
        try :#line:725
            O000OO00O000OO000 =OOOOO0O0O0OOO0OOO .Get_DealPrice ()#line:726
            OOOOO0O0O0OOO0OOO .HighPrice =math .Max (O000OO00O000OO000 ,OOOOO0O0O0OOO0OOO .HighPrice )#line:727
            if OOOOO0O0O0OOO0OOO .LowPrice ==0 :#line:728
                OOOOO0O0O0OOO0OOO .LowPrice =O000OO00O000OO000 #line:729
            else :#line:730
                OOOOO0O0O0OOO0OOO .LowPrice =math .Min (O000OO00O000OO000 ,OOOOO0O0O0OOO0OOO .LowPrice )#line:731
        except :#line:733
            pass #line:734
    def CalcHightLowPrice_None (O00O0OO00O0O00OOO ):#line:736
        pass #line:737
    fPROC_CalcHightLowPrice :callable =None #line:740
    """PROC_CalcHightLowPrice """#line:741
    fDealQty :int =0 #line:746
    def CalTotalTradingAmount (OO0OOOO0O0OO0OO00 ):#line:749
        ""#line:750
        try :#line:752
            OO0OOOO0O0OO0OO00 .fDealQty =OO0OOOO0O0OO0OO00 .Get_DealQty2Int ()#line:753
            OO0OOOO0O0OO0OO00 .HL_TotAmt +=OO0OOOO0O0OO0OO00 .fDealPrice *OO0OOOO0O0OO0OO00 .fDealQty *OO0OOOO0O0OO0OO00 .BAS_TradingUnit #line:756
        except Exception as OO0O000OO0OO0OO00 :#line:757
            pass #line:758
    WholeTotAmt :str #line:763
    "整體市場成交總額"#line:764
    def Get_WholeTotAmt (OO00OOO00000000OO )->int :#line:765
        return OO00OOO00000000OO .TransToInt (OO00OOO00000000OO .fTX [34 ])#line:766
    WholeTotQty :str #line:767
    "整體市場成交數量"#line:768
    def Get_WholeTotQty (O000000OO0OOO0000 )->int :#line:769
        return O000000OO0OOO0000 .TransToInt (O000000OO0OOO0000 .fTX [35 ])#line:770
    WholeDealCount :str #line:771
    "整體市場成交筆數"#line:772
    def Get_WholeDealCount (OOOOO00OO0O0O00OO )->int :#line:773
        return OOOOO00OO0O0O00OO .TransToInt (OOOOO00OO0O0O00OO .fTX [36 ])#line:774
    SumBuyOrderCount :str #line:775
    "整體市場委託買進筆數"#line:776
    def Get_SumBuyOrderCount (OOOOO0OO000000OO0 )->int :#line:777
        return OOOOO0OO000000OO0 .TransToInt (OOOOO0OO000000OO0 .fTX [37 ])#line:778
    SumSellOrderCount :str #line:779
    "整體市場委託賣出筆數"#line:780
    def Get_SumSellOrderCount (OO000OOO0OO00O00O )->int :#line:781
        return OO000OOO0OO00O00O .TransToInt (OO000OOO0OO00O00O .fTX [38 ])#line:782
    SumBuyOrderQty :str #line:783
    "整體市場委託買進數量"#line:784
    def Get_SumBuyOrderQty (OO0OO00OO00OO0000 ):#line:785
        return OO0OO00OO00OO0000 .TransToInt (OO0OO00OO00OO0000 .fTX [39 ])#line:786
    SumSellOrderQty :str #line:787
    "整體市場委託賣出數量"#line:788
    def Get_SumSellOrderQty (O000OO00O0O00O000 ):#line:789
        return O000OO00O0O00O000 .TransToInt (O000OO00O0O00O000 .fTX [40 ])#line:790
    IsFixedPriceTransaction :str #line:791
    "是否為定盤交易"#line:792
    def TransToInt (O0O0OO00000OOOOOO ,O0O0OO0O000OOO0O0 :str )->int :#line:797
        try :#line:798
            return int (O0O0OO0O000OOO0O0 )#line:799
        except Exception as O0OO0OO0OO0OO0OOO :#line:800
            return 0 #line:801
    def TransToDecimal (O0OO00O000OO00OOO ,O000OOO0O0O0OO0OO :str )->decimal :#line:803
        try :#line:804
            return Decimal (O000OOO0O0O0OO0OO )#line:805
        except Exception as OOO0000O00O0OOOO0 :#line:806
            return 0 #line:807
    def __init__ (OO0OOO000OO0O0OOO ,OOOO000OOO0O00O00 :bool )->None :#line:810
        OO0OOO000OO0O0OOO .fPROC_CalcHightLowPrice =OO0OOO000OO0O0OOO .CalcHightLowPrice_None #line:811
        if OOOO000OOO0O00O00 :#line:812
            OO0OOO000OO0O0OOO .fPROC_CalcHightLowPrice =OO0OOO000OO0O0OOO .CalcHightLowPrice #line:813
        OO0OOO000OO0O0OOO .fPROC_HandleData =OO0OOO000OO0O0OOO .HandleData_TryMarket #line:815
    def __str__ (OO0O00OO0OO0O0000 )->str :#line:817
        return f"""SysTime:{OO0O00OO0OO0O0000.SysTime} DealTime:{OO0O00OO0OO0O0000.DealTime} DealSn:{OO0O00OO0OO0O0000.DealSn} TryMark:{OO0O00OO0OO0O0000.TryMark}"""+"""Has5Q:{self.Has5Q} TotQty:{self.TotQty} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty}"""+"""B5QCountOrg:{self.B5QCountOrg} S5QCountOrg:{self.S5QCountOrg} fTX:{self.fTX}"""#line:820
class TStkQt5Q ():#line:821
    f5Q =[]#line:822
    def Handle_5Q (O0OO000O0O0O000O0 ,OO0OO000O00OOOO0O :str ):#line:824
        O0OO000O0O0O000O0 .fPROC_HandleData (OO0OO000O00OOOO0O )#line:825
    def HandleData_TryMarket (O000O0O0000O0OO00 ,O000000O00OO00O0O :str ):#line:828
        ""#line:829
        if O000000O00OO00O0O .split ('|')[4 ]==TSolQuoteStkSet .TryMark_No :#line:830
            O000O0O0000O0OO00 .fPROC_HandleData =O000O0O0000O0OO00 .HandleData #line:831
            O000O0O0000O0OO00 .fPROC_HandleData (O000000O00OO00O0O )#line:832
        else :#line:833
            O000O0O0000O0OO00 .f5Q =O000000O00OO00O0O .split ('|')#line:834
            O000O0O0000O0OO00 .SetData ()#line:835
            O000O0O0000O0OO00 .B5QCount =O000O0O0000O0OO00 .TransToInt (O000O0O0000O0OO00 .B5QCountOrg )#line:836
            O000O0O0000O0OO00 .S5QCount =O000O0O0000O0OO00 .TransToInt (O000O0O0000O0OO00 .S5QCountOrg )#line:837
    def HandleData (OOOOOOO0OOOOO0O00 ,O0000OO00000O00O0 :str ):#line:839
        OOOOOOO0OOOOO0O00 .f5Q =O0000OO00000O00O0 .split ('|')#line:840
        OOOOOOO0OOOOO0O00 .SetData ()#line:841
        OOOOOOO0OOOOO0O00 .B5QCount =OOOOOOO0OOOOO0O00 .TransToInt (OOOOOOO0OOOOO0O00 .B5QCountOrg )#line:842
        OOOOOOO0OOOOO0O00 .S5QCount =OOOOOOO0OOOOO0O00 .TransToInt (OOOOOOO0OOOOO0O00 .S5QCountOrg )#line:843
    def SetData (OO00O0OOO0O0OOOO0 ):#line:845
        OO00O0OOO0O0OOOO0 .SysTime =OO00O0OOO0O0OOOO0 .f5Q [1 ]#line:846
        OO00O0OOO0O0OOOO0 .DataTime =OO00O0OOO0O0OOOO0 .f5Q [2 ]#line:847
        OO00O0OOO0O0OOOO0 .DealSn =OO00O0OOO0O0OOOO0 .f5Q [3 ]#line:848
        if len (OO00O0OOO0O0OOOO0 .f5Q )>4 :#line:849
            OO00O0OOO0O0OOOO0 .TryMark =OO00O0OOO0O0OOOO0 .f5Q [4 ]#line:850
        if len (OO00O0OOO0O0OOOO0 .f5Q )>8 :#line:851
            OO00O0OOO0O0OOOO0 .IsOpenRecord =OO00O0OOO0O0OOOO0 .f5Q [8 ][4 ]=='1'#line:852
        if len (OO00O0OOO0O0OOOO0 .f5Q )>8 :#line:853
            OO00O0OOO0O0OOOO0 .IsCloseRecord =OO00O0OOO0O0OOOO0 .f5Q [8 ][5 ]=='1'#line:854
        OO00O0OOO0O0OOOO0 .TotQty =OO00O0OOO0O0OOOO0 .f5Q [9 ]#line:856
        OO00O0OOO0O0OOOO0 .B5QCountOrg =OO00O0OOO0O0OOOO0 .f5Q [12 ]#line:857
        OO00O0OOO0O0OOOO0 .S5QCountOrg =OO00O0OOO0O0OOOO0 .f5Q [23 ]#line:858
    fPROC_HandleData =None #line:861
    """PROC_HandleData"""#line:862
    SysTime :str #line:865
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""#line:866
    DataTime :str #line:867
    """資料時間(交易所)(EX:173547.32700)"""#line:868
    DealSn :str #line:869
    """序號(5檔序號)"""#line:870
    def Get_DealSn (O00OO00OO0000O00O )->int :#line:872
        return O00OO00OO0000O00O .TransToInt (O00OO00OO0000O00O .f5Q [3 ])#line:873
    TryMark ="1"#line:874
    """試撮註記(試撮=1, 非試撮=0)"""#line:875
    IsOpenRecord :bool =False #line:877
    """此筆是否為開盤行情(False:僅代表此筆非開盤行情, 並不代表盤中或收盤狀態)"""#line:878
    IsCloseRecord :bool =False #line:879
    """此筆是否為收盤行情(False:僅代表此筆非收盤行情, 並不代表盤中或開盤狀態)"""#line:880
    TotQty :str #line:882
    """成交總量"""#line:883
    def Get_TotQty2Dec (O0O000O00O000O0OO )->decimal :#line:885
        return O0O000O00O000O0OO .TransToDecimal (O0O000O00O000O0OO .f5Q [9 ])#line:886
    def Get_TotQty2Int (O0O0OOO0O0O00OO00 )->int :#line:888
        return O0O0OOO0O0O00OO00 .TransToInt (O0O0OOO0O0O00OO00 .f5Q [9 ])#line:889
    fAryB5Q_P =[13 ,15 ,17 ,19 ,21 ]#line:892
    """買五檔價在字串中的位置"""#line:893
    fAryB5Q_Q =[14 ,16 ,18 ,20 ,22 ]#line:894
    """買五檔價在字串中的位置"""#line:895
    B5QCountOrg :str #line:897
    """買5檔的檔數"""#line:898
    B5QCount :int #line:899
    """買5檔的檔數"""#line:900
    def B5Q_POrg (O0OO0O0OO0OO0O00O ,O0O0O000OO00O00OO :int )->str :#line:902
        ""#line:903
        if (O0O0O000OO00O00OO >O0OO0O0OO0OO0O00O .B5QCount ):#line:904
            return ""#line:905
        else :#line:906
            return O0OO0O0OO0OO0O00O .f5Q [O0OO0O0OO0OO0O00O .fAryB5Q_P [O0O0O000OO00O00OO -1 ]]#line:907
    def Get_B5Q_P (O0O0OOO000000OOOO ,OO0OOOO00OOO00O0O :int )->decimal :#line:909
        ""#line:910
        if (OO0OOOO00OOO00O0O >O0O0OOO000000OOOO .B5QCount ):#line:911
            return 0 #line:912
        else :#line:913
            return O0O0OOO000000OOOO .TransToDecimal (O0O0OOO000000OOOO .f5Q [O0O0OOO000000OOOO .fAryB5Q_P [OO0OOOO00OOO00O0O -1 ]])#line:914
    def B5Q_QOrg (OO0OOO000O00OO0O0 ,OO0O00O00O0OO0O00 :int )->str :#line:916
        ""#line:917
        if (OO0O00O00O0OO0O00 >OO0OOO000O00OO0O0 .B5QCount ):#line:918
            return ""#line:919
        else :#line:920
            return OO0OOO000O00OO0O0 .f5Q [OO0OOO000O00OO0O0 .fAryB5Q_Q [OO0O00O00O0OO0O00 -1 ]]#line:921
    def Get_B5Q_Q (O0O0OO0OOO0OO0OO0 ,O00O00O000000000O :int )->int :#line:923
        ""#line:924
        if (O00O00O000000000O >O0O0OO0OOO0OO0OO0 .B5QCount ):#line:925
            return 0 #line:926
        else :#line:927
            return O0O0OO0OOO0OO0OO0 .TransToInt (O0O0OO0OOO0OO0OO0 .f5Q [O0O0OO0OOO0OO0OO0 .fAryB5Q_Q [O00O00O000000000O -1 ]])#line:928
    fAryS5Q_P =[24 ,26 ,28 ,30 ,32 ]#line:932
    """賣五檔價在字串中的位置"""#line:933
    fAryS5Q_Q =[25 ,27 ,29 ,31 ,33 ]#line:934
    """賣五檔價在字串中的位置"""#line:935
    S5QCountOrg :str #line:937
    """賣5檔的檔數"""#line:938
    S5QCount :int #line:939
    """賣5檔的檔數"""#line:940
    def S5Q_POrg (OO0O000OO00OO0OOO ,OOO0OO0O00O00OO00 :int )->str :#line:942
        ""#line:943
        if (OOO0OO0O00O00OO00 >OO0O000OO00OO0OOO .S5QCount ):#line:944
            return ""#line:945
        else :#line:946
            return OO0O000OO00OO0OOO .f5Q [OO0O000OO00OO0OOO .fAryS5Q_P [OOO0OO0O00O00OO00 -1 ]]#line:947
    def Get_S5Q_P (OO00000O0O0OO0O0O ,OOOOO0OO00O00OOO0 :int )->decimal :#line:949
        ""#line:950
        if (OOOOO0OO00O00OOO0 >OO00000O0O0OO0O0O .S5QCount ):#line:951
            return 0 #line:952
        else :#line:953
            return OO00000O0O0OO0O0O .TransToDecimal (OO00000O0O0OO0O0O .f5Q [OO00000O0O0OO0O0O .fAryS5Q_P [OOOOO0OO00O00OOO0 -1 ]])#line:954
    def S5Q_QOrg (O0OOOOOO000000OOO ,OOOO0OOO00OOO0O00 :int )->str :#line:956
        ""#line:957
        if (OOOO0OOO00OOO0O00 >O0OOOOOO000000OOO .S5QCount ):#line:958
            return ""#line:959
        else :#line:960
            return O0OOOOOO000000OOO .f5Q [O0OOOOOO000000OOO .fAryS5Q_Q [OOOO0OOO00OOO0O00 -1 ]]#line:961
    def Get_S5Q_Q (O00000OO00OO0O00O ,OOO0OOO00O0000O0O :int )->int :#line:963
        ""#line:964
        if (OOO0OOO00O0000O0O >O00000OO00OO0O00O .S5QCount ):#line:965
            return 0 #line:966
        else :#line:967
            return O00000OO00OO0O00O .TransToInt (O00000OO00OO0O00O .f5Q [O00000OO00OO0O00O .fAryS5Q_Q [OOO0OOO00O0000O0O -1 ]])#line:968
    def TransToInt (O00O0000OOO000OOO ,OO0OO0000000OO0OO :str )->int :#line:972
        try :#line:973
            return int (OO0OO0000000OO0OO )#line:974
        except Exception as O0O0OO0OOOOOO00O0 :#line:975
            return 0 #line:976
    def TransToDecimal (O000OOO0OOO0OOOO0 ,OO0000O000O00OO00 :str )->decimal :#line:978
        try :#line:979
            return Decimal (OO0000O000O00OO00 )#line:980
        except Exception as OO00O00OOO0O0OOOO :#line:981
            return 0 #line:982
    def __init__ (O00O0000OO000OO00 )->None :#line:985
        O00O0000OO000OO00 .fPROC_HandleData =O00O0000OO000OO00 .HandleData_TryMarket #line:987
    def __str__ (O0O0O00O0OOOOO000 )->str :#line:989
        return f"""SysTime:{O0O0O00O0OOOOO000.SysTime} DataTime:{O0O0O00O0OOOOO000.DataTime} DealSn:{O0O0O00O0OOOOO000.DealSn} TryMark:{O0O0O00O0OOOOO000.TryMark}"""+"""TotQty:{self.TotQty} B5QCountOrg:{self.B5QCountOrg} S5QCountOrg:{self.S5QCountOrg} f5Q:{self.f5Q}"""#line:991
class TStkQtIDX ():#line:992
    fIDX =[]#line:993
    def Handle_IDXRcv (OO0O00OO0O0O0OO00 ,O0OOO0OO0OOOO00OO :str ):#line:995
        ""#line:996
        try :#line:997
            OO0000OO0OO0O00O0 :int =0 #line:998
            O0000OO0OO00OOO0O :int =0 #line:999
            OO0OOO00O00OOO00O =O0OOO0OO0OOOO00OO .split ('|')#line:1000
            if OO0O00OO0O0O0OO00 .fIDX ==None :#line:1001
                OO0O00OO0O0O0OO00 .fIDX =OO0OOO00O00OOO00O #line:1002
            else :#line:1003
                O0000OO0OO00OOO0O =OO0O00OO0O0O0OO00 .TransToInt (OO0OOO00O00OOO00O [3 ])#line:1004
                OO0000OO0OO0O00O0 =OO0O00OO0O0O0OO00 .Get_DealSn ()#line:1005
                if O0000OO0OO00OOO0O >OO0000OO0OO0O00O0 :#line:1006
                    OO0O00OO0O0O0OO00 .fIDX =OO0OOO00O00OOO00O #line:1007
                    OO0O00OO0O0O0OO00 .SetData ()#line:1008
                OO0O00OO0O0O0OO00 .fPROC_CalcHightLowPrice ()#line:1010
        except Exception as O000OOO0OOO0OOO0O :#line:1012
            pass #line:1013
    def Handle_IDX (O000OO0000O00OO0O ,OOO00OO00OO00OOOO :str ):#line:1015
        ""#line:1016
        O000OO0000O00OO0O .fIDX =OOO00OO00OO00OOOO .split ('|')#line:1017
        O000OO0000O00OO0O .SetData ()#line:1018
        O000OO0000O00OO0O .fPROC_CalcHightLowPrice ()#line:1019
    def SetData (OOO000OOO0OO0O00O ):#line:1021
        OOO000OOO0OO0O00O .SysTime =OOO000OOO0OO0O00O .fIDX [1 ]#line:1022
        OOO000OOO0OO0O00O .DealTime =OOO000OOO0OO0O00O .fIDX [2 ]#line:1023
        OOO000OOO0OO0O00O .DealSn =OOO000OOO0OO0O00O .fIDX [3 ]#line:1024
        OOO000OOO0OO0O00O .DealPriceOrg =OOO000OOO0OO0O00O .fIDX [10 ]#line:1026
        OOO000OOO0OO0O00O .WholeTotAmt =OOO000OOO0OO0O00O .fIDX [34 ]#line:1027
        OOO000OOO0OO0O00O .TotQty =OOO000OOO0OO0O00O .fIDX [35 ]#line:1029
        OOO000OOO0OO0O00O .WholeTotQty =OOO000OOO0OO0O00O .fIDX [35 ]#line:1030
        OOO000OOO0OO0O00O .WholeDealCount =OOO000OOO0OO0O00O .fIDX [36 ]#line:1031
        OOO000OOO0OO0O00O .SumBuyOrderCount =OOO000OOO0OO0O00O .fIDX [37 ]#line:1032
        OOO000OOO0OO0O00O .SumSellOrderCount =OOO000OOO0OO0O00O .fIDX [38 ]#line:1033
        OOO000OOO0OO0O00O .SumBuyOrderQty =OOO000OOO0OO0O00O .fIDX [39 ]#line:1034
        OOO000OOO0OO0O00O .SumSellOrderQty =OOO000OOO0OO0O00O .fIDX [40 ]#line:1035
    SysTime :str #line:1038
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""#line:1039
    DealTime :str #line:1040
    """撮合時間(成交)(EX:085229.843665)"""#line:1041
    DealSn :str #line:1042
    """序號"""#line:1043
    def Get_DealSn (O0O0000OO0O0OO0OO )->int :#line:1045
        return O0O0000OO0O0OO0OO .TransToInt (O0O0000OO0O0OO0OO .fIDX [3 ])#line:1046
    TotQty :str #line:1047
    """成交總量"""#line:1048
    def Get_TotQty2Dec (OOO0O00OO00000OOO )->decimal :#line:1050
        return OOO0O00OO00000OOO .TransToDecimal (OOO0O00OO00000OOO .fIDX [35 ])#line:1051
    def Get_TotQty2Int (OO0OOO0O0000O0O0O )->int :#line:1053
        return OO0OOO0O0000O0O0O .TransToInt (OO0OOO0O0000O0O0O .fIDX [35 ])#line:1054
    DealPriceOrg :str #line:1055
    """成交價"""#line:1056
    def Get_DealPrice (OO0000O000OO00O0O )->decimal :#line:1058
        return OO0000O000OO00O0O .TransToDecimal (OO0000O000OO00O0O .fIDX [10 ])#line:1059
    fDealPrice =0 #line:1062
    """成交價"""#line:1063
    HighPrice =0 #line:1064
    """當日最高價"""#line:1065
    LowPrice =0 #line:1066
    """當日最低價"""#line:1067
    def CalcHightLowPrice (O0OOO0000OOO0O00O ):#line:1069
        ""#line:1070
        try :#line:1071
            O0OOO0000OOO0O00O .fDealPrice =O0OOO0000OOO0O00O .Get_DealPrice ()#line:1072
            O0OOO0000OOO0O00O .HighPrice =math .Max (O0OOO0000OOO0O00O .fDealPrice ,O0OOO0000OOO0O00O .HighPrice )#line:1074
            if O0OOO0000OOO0O00O .LowPrice ==0 :#line:1075
                O0OOO0000OOO0O00O .LowPrice =O0OOO0000OOO0O00O .fDealPrice #line:1076
            else :#line:1077
                O0OOO0000OOO0O00O .LowPrice =math .Min (O0OOO0000OOO0O00O .fDealPrice ,O0OOO0000OOO0O00O .LowPrice )#line:1078
        except Exception as O00OOO00OOO0O0OO0 :#line:1079
            pass #line:1080
    def CalcHightLowPrice_None (OOO0000O0O0OOOO0O ):#line:1082
        pass #line:1083
    fPROC_CalcHightLowPrice =None #line:1086
    """PROC_CalcHightLowPrice"""#line:1087
    HasWholeMarketData :bool #line:1092
    WholeTotAmt :str #line:1094
    """整體市場成交總額"""#line:1095
    def Get_WholeTotAmt (O00O0OOOO000O00O0 )->int :#line:1097
        if (O00O0OOOO000O00O0 .HasWholeMarketData ):#line:1098
            return O00O0OOOO000O00O0 .TransToInt (O00O0OOOO000O00O0 .fIDX [34 ])#line:1099
    def Get_WholeTotAmt (OOO000OOO0OOO0O0O )->decimal :#line:1101
        if (OOO000OOO0OOO0O0O .HasWholeMarketData ):#line:1102
            return OOO000OOO0OOO0O0O .TransToDecimal (OOO000OOO0OOO0O0O .fIDX [34 ])#line:1103
        else :#line:1104
            return 0 #line:1105
    WholeTotQty :str #line:1107
    """整體市場成交數量"""#line:1108
    def Get_WholeTotQty (O00O0OO0O0OO0OOO0 )->int :#line:1110
        if (O00O0OO0O0OO0OOO0 .HasWholeMarketData ):#line:1111
            return O00O0OO0O0OO0OOO0 .TransToInt (O00O0OO0O0OO0OOO0 .fIDX [35 ])#line:1112
        else :#line:1113
            return 0 #line:1114
    WholeDealCount :str #line:1115
    """整體市場成交筆數"""#line:1116
    def Get_WholeDealCount (O0OOO0O000O00OO0O )->int :#line:1118
        if O0OOO0O000O00OO0O .HasWholeMarketData :#line:1119
            return O0OOO0O000O00OO0O .TransToInt (O0OOO0O000O00OO0O .fIDX [36 ])#line:1120
        else :#line:1121
            return 0 #line:1122
    SumBuyOrderCount :str #line:1124
    """整體市場委託買進筆數"""#line:1125
    def Get_SumBuyOrderCount (O0O0OO0OO0OO000O0 )->int :#line:1127
        if O0O0OO0OO0OO000O0 .HasWholeMarketData :#line:1128
            return O0O0OO0OO0OO000O0 .TransToInt (O0O0OO0OO0OO000O0 .fIDX [37 ])#line:1129
        else :#line:1130
            return 0 #line:1131
    SumSellOrderCount :str #line:1132
    """整體市場委託賣出筆數"""#line:1133
    def Get_SumSellOrderCount (O000000O00O00OOO0 )->int :#line:1135
        if O000000O00O00OOO0 .HasWholeMarketData :#line:1136
            return O000000O00O00OOO0 .TransToInt (O000000O00O00OOO0 .fIDX [38 ])#line:1137
        else :#line:1138
            return 0 #line:1139
    SumBuyOrderQty :str #line:1140
    """整體市場委託買進數量"""#line:1141
    def Get_SumBuyOrderQty (OO0O0O0OOO0000O00 )->int :#line:1143
        if OO0O0O0OOO0000O00 .HasWholeMarketData :#line:1144
            return OO0O0O0OOO0000O00 .TransToInt (OO0O0O0OOO0000O00 .fIDX [39 ])#line:1145
        else :#line:1146
            return 0 #line:1147
    SumSellOrderQty :str #line:1148
    """整體市場委託賣出數量"""#line:1149
    def Get_SumSellOrderQty (O000O0OO0OOOO00OO )->int :#line:1151
        if O000O0OO0OOOO00OO .HasWholeMarketData :#line:1152
            return O000O0OO0OOOO00OO .TransToInt (O000O0OO0OOOO00OO .fIDX [40 ])#line:1153
        else :#line:1154
            return 0 #line:1155
    def TransToInt (OO00O0000OOO00OOO ,OO00000OO0O0O000O :str )->int :#line:1159
        try :#line:1160
            return int (OO00000OO0O0O000O )#line:1161
        except Exception as OOOOOO00O0O0000OO :#line:1162
            return 0 #line:1163
    def TransToDecimal (OO000000O0O000OO0 ,OOO0O0OOO00OOO0O0 :str )->decimal :#line:1165
        try :#line:1166
            return Decimal (OOO0O0OOO00OOO0O0 )#line:1167
        except Exception as O0OOO000000O0O0OO :#line:1168
            return 0 #line:1169
    def __init__ (O000000O0OOO0O0O0 ,O00OO000O0OO0OOOO :bool )->None :#line:1172
        ""#line:1173
        O000000O0OOO0O0O0 .fPROC_CalcHightLowPrice =O000000O0OOO0O0O0 .CalcHightLowPrice_None #line:1175
        if (O00OO000O0OO0OOOO ):#line:1176
            O000000O0OOO0O0O0 .fPROC_CalcHightLowPrice =O000000O0OOO0O0O0 .CalcHightLowPrice #line:1177
class TStkQuoteData :#line:1178
    BAS :TStkQtBase =None #line:1180
    HL :TStkQtHL =None #line:1181
    QtTX :TStkQtTX =None #line:1182
    Qt5Q :TStkQt5Q =None #line:1183
    QtIDX :TStkQtIDX =None #line:1184
    def __init__ (O0O0OOO0O0OOO0O0O ,OOOO0O0OOO0000O00 :TStkProdKind ,OOO00O00OOOOOOO0O :str ,OO000O0O0OO0O000O :bool )->None :#line:1186
        ""#line:1187
        O0O0OOO0O0OOO0O0O .SolIce =OOO00O00OOOOOOO0O #line:1188
        O0O0OOO0O0OOO0O0O .ProdKind :TStkProdKind =OOOO0O0OOO0000O00 #line:1189
        O0O0OOO0O0OOO0O0O ._lock =Lock ()#line:1190
        O0O0OOO0O0OOO0O0O .UpdateBAS =True #line:1191
        O0O0OOO0O0OOO0O0O .UpdateHL =False #line:1192
        if OOOO0O0OOO0000O00 ==TStkProdKind .pkNormal :#line:1193
            O0O0OOO0O0OOO0O0O .BAS =TStkQtBase ()#line:1194
            O0O0OOO0O0OOO0O0O .HL =TStkQtHL ()#line:1195
            O0O0OOO0O0OOO0O0O .QtTX =TStkQtTX (OO000O0O0OO0O000O )#line:1196
            O0O0OOO0O0OOO0O0O .Qt5Q =TStkQt5Q ()#line:1197
        elif OOOO0O0OOO0000O00 ==TStkProdKind .pkIndex :#line:1198
            O0O0OOO0O0OOO0O0O .BAS =TStkQtBase ()#line:1199
            O0O0OOO0O0OOO0O0O .HL =TStkQtHL ()#line:1200
            O0O0OOO0O0OOO0O0O .QtIDX =TStkQtIDX (OO000O0O0OO0O000O )#line:1201
    def SetDataInit (OO0000OO00O00O000 ):#line:1228
        ""#line:1229
        if OO0000OO00O00O000 .ProdKind ==TStkProdKind .pkNormal :#line:1230
            OO0000OO00O00O000 .QtTX .HighPrice =OO0000OO00O00O000 .HL .Get_HighPrice ()#line:1232
            OO0000OO00O00O000 .QtTX .LowPrice =OO0000OO00O00O000 .HL .Get_LowPrice ()#line:1233
            OO0000OO00O00O000 .QtTX .HL_Sn_5Q =OO0000OO00O00O000 .HL .Get_Sn_5Q ()#line:1235
            OO0000OO00O00O000 .QtTX .BAS_TradingUnit =OO0000OO00O00O000 .BAS .Get_TradingUnit ()#line:1237
            OO0000OO00O00O000 .QtTX .HL_TotAmt =OO0000OO00O00O000 .HL .Get_TotAmt2Int ()#line:1239
        elif OO0000OO00O00O000 .ProdKind ==TStkProdKind .pkIndex :#line:1240
            OO0000OO00O00O000 .QtIDX .HighPrice =OO0000OO00O00O000 .HL .Get_HighPrice ()#line:1242
            OO0000OO00O00O000 .QtIDX .LowPrice =OO0000OO00O00O000 .HL .Get_LowPrice ()#line:1243
class TObjStkQuoteMap (UserDict ):#line:1258
    ""#line:1260
    """各商品拆解行情proc(EX:2330的TX與5Q, 行情拆解,是不同Proc)
        Dictionary<string, PROC_Handle_StkRTQuote> MapQtProc = new Dictionary<string, PROC_Handle_StkRTQuote>();"""#line:1263
    DefProc_TX :callable =None #line:1268
    DefProc_5Q :callable =None #line:1269
    DefProc_Idx :callable =None #line:1270
    def __init__ (O00O0OO00O0OOOOOO ,mapping =None ,**O0000O0O0O0O0O0O0 ):#line:1271
        if mapping is not None :#line:1272
            mapping ={str (O00O0OO0OOOO0OO00 ).upper ():OO0O00O00000OOOO0 for O00O0OO0OOOO0OO00 ,OO0O00O00000OOOO0 in mapping .items ()}#line:1275
        else :#line:1276
            mapping ={}#line:1277
        if O0000O0O0O0O0O0O0 :#line:1278
            mapping .update ({str (OOO000000000O0OOO ).upper ():OO000OO0OO0OO00O0 for OOO000000000O0OOO ,OO000OO0OO0OO00O0 in O0000O0O0O0O0O0O0 .items ()})#line:1281
        O00O0OO00O0OOOOOO .MapQtProc ={}#line:1282
        super ().__init__ (mapping )#line:1283
    def __setitem__ (O00O0O00O00O0O00O ,OO0OO000O00O00O00 ,OO0O00000OO00O0OO ):#line:1285
        super ().__setitem__ (OO0OO000O00O00O00 ,OO0O00000OO00O0OO )#line:1286
    def AddRcvData (OO0O00OO0O0000O0O ,OO00O0OO0OO0OO00O :TStkProdKind ,O00O00O0O0O00O0OO :str ,O0O0O0OOOO0OO000O :str ,OO0O00O0O000000OO :bool ):#line:1288
        ""#line:1293
        O00OOOO0O00O0000O =""#line:1294
        OO0O0O00OOO00OOOO :TStkQuoteData =None #line:1295
        try :#line:1296
            O0O0OO0O0OOO00OO0 =json .loads (O0O0O0OOOO0OO000O )#line:1299
            if "status"in O0O0OO0O0OOO00OO0 and len (O0O0OO0O0OOO00OO0 ["status"])>0 :#line:1300
                if O0O0OO0O0OOO00OO0 ["status"][0 ]=="error":#line:1301
                    O00OOOO0O00O0000O =f"[證][AddRcvData](aSolIce={O00O00O0O0O00O0OO}, aData={O0O0O0OOOO0OO000O})行情回補資料有誤!"#line:1302
                    return False ,OO0O0O00OOO00OOOO ,O00OOOO0O00O0000O #line:1303
            if "BAS"in O0O0OO0O0OOO00OO0 and len (O0O0OO0O0OOO00OO0 ["BAS"])==0 :#line:1304
                O00OOOO0O00O0000O =f"[證][AddRcvData](aSolIce={O00O00O0O0O00O0OO}, aData={O0O0O0OOOO0OO000O})沒有BAS資料!"#line:1305
                return False ,OO0O0O00OOO00OOOO ,O00OOOO0O00O0000O #line:1306
            if "HL"in O0O0OO0O0OOO00OO0 and len (O0O0OO0O0OOO00OO0 ["HL"])==0 :#line:1307
                O00OOOO0O00O0000O =f"[證][AddRcvData](aSolIce={O00O00O0O0O00O0OO}, aData={O0O0O0OOOO0OO000O})沒有HL資料!"#line:1308
                return False ,OO0O0O00OOO00OOOO ,O00OOOO0O00O0000O #line:1309
            if OO0O00OO0O0000O0O .data .get (O00O00O0O0O00O0OO )is None :#line:1312
                O00OO0O00O00OO0OO =TStkQuoteData (OO00O0OO0OO0OO00O ,O00O00O0O0O00O0OO ,OO0O00O0O000000OO )#line:1313
                O00OO0O00O00OO0OO .BAS .Handle_BAS (O0O0OO0O0OOO00OO0 ["BAS"][0 ])#line:1314
                O00OO0O00O00OO0OO .HL .Handle_HL (O0O0OO0O0OOO00OO0 ["HL"][0 ])#line:1315
                O00OO0O00O00OO0OO .SetDataInit ()#line:1316
                OO0O0O00OOO00OOOO =O00OO0O00O00OO0OO #line:1317
                OO0O00OO0O0000O0O [O00O00O0O0O00O0OO ]=O00OO0O00O00OO0OO #line:1318
                return True ,OO0O0O00OOO00OOOO ,""#line:1319
            else :#line:1320
                O00OO0O00O00OO0OO :TStkQuoteData =OO0O00OO0O0000O0O [O00O00O0O0O00O0OO ]#line:1321
                with O00OO0O00O00OO0OO ._lock :#line:1322
                    O00OO0O00O00OO0OO .BAS .Handle_BAS (O0O0OO0O0OOO00OO0 ["BAS"][0 ])#line:1323
                    O00OO0O00O00OO0OO .HL .Handle_HL (O0O0OO0O0OOO00OO0 ["HL"][0 ])#line:1324
                    O00OO0O00O00OO0OO .SetDataInit ()#line:1325
                    OO0O0O00OOO00OOOO =O00OO0O00O00OO0OO #line:1326
                return True ,OO0O0O00OOO00OOOO ,""#line:1327
        except Exception as OO00O00000OO00OOO :#line:1328
            O00OOOO0O00O0000O =f"[證][AddRcvData](aSolIce={O00O00O0O0O00O0OO}, aData={O0O0O0OOOO0OO000O}){OO00O00000OO00OOO}"#line:1329
            return False ,OO0O0O00OOO00OOOO ,O00OOOO0O00O0000O #line:1330
    def AddDataBySolIce (O0OOO0OO00OO00000 ,O0OOO0O000OOOOOO0 :bool ,O0OO0O0OOOO000OO0 :str ,O00O0O0OOO0000000 ,O0OO0OO0OO000O00O :bool ,topic :str =""):#line:1332
        ""#line:1340
        try :#line:1341
            OO0OOOO0OO0O00O0O :str =""#line:1342
            OO0O00OOOOO00O000 :TObjStkQuoteMap =TObjStkQuoteMap ()#line:1343
            if O00O0O0OOO0000000 .get ("BAS")is not None :#line:1345
                for O00O0O0O00OOO0O0O in O00O0O0OOO0000000 ["BAS"]:#line:1346
                    O00000OOOO00000O0 :TStkQtBase =TStkQtBase (topic )#line:1347
                    O00000OOOO00000O0 .Handle_BAS (O00O0O0O00OOO0O0O )#line:1348
                    if OO0O00OOOOO00O000 .data .get (O00000OOOO00000O0 .StkNo )is None :#line:1349
                        O000O0000OOO0O00O :TStkQuoteData =TStkQuoteData (TStkProdKind .pkNormal ,O00000OOOO00000O0 .StkNo ,O0OO0OO0OO000O00O )#line:1350
                        O000O0000OOO0O00O .BAS =O00000OOOO00000O0 #line:1351
                        O000O0000OOO0O00O .UpdateHL =False #line:1352
                        O000O0000OOO0O00O .QtTX .BAS_TradingUnit =O00000OOOO00000O0 .Get_TradingUnit ()#line:1354
                        OO0O00OOOOO00O000 [O00000OOOO00000O0 .StkNo ]=O000O0000OOO0O00O #line:1355
                    if topic !="":#line:1356
                        OOO0O000OOOO0OOO0 :str =O00000OOOO00000O0 .TopicTX #line:1357
                        OOO0O000O0OOO0OO0 :str =O00000OOOO00000O0 .Topic5Q #line:1358
                        O0OOO0OO00OO00000 [OOO0O000OOOO0OOO0 ]=O000O0000OOO0O00O #line:1359
                        O0OOO0OO00OO00000 [OOO0O000O0OOO0OO0 ]=O000O0000OOO0O00O #line:1360
                        if O0OOO0OO00OO00000 .MapQtProc .get (OOO0O000OOOO0OOO0 )is None :#line:1361
                            O0OOO0OO00OO00000 .MapQtProc [OOO0O000OOOO0OOO0 ]=O0OOO0OO00OO00000 .DefProc_TX #line:1362
                        if O0OOO0OO00OO00000 .MapQtProc .get (OOO0O000O0OOO0OO0 )is None :#line:1363
                            O0OOO0OO00OO00000 .MapQtProc [OOO0O000O0OOO0OO0 ]=O0OOO0OO00OO00000 .DefProc_5Q #line:1364
            if O00O0O0OOO0000000 .get ("HL")is not None :#line:1367
                for O0O00000OO00O0000 in O00O0O0OOO0000000 ["HL"]:#line:1368
                    OOOOO0O0OO00O0O00 =TStkQtHL ()#line:1369
                    OOOOO0O0OO00O0O00 .Handle_HL (O0O00000OO00O0000 )#line:1370
                    if OO0O00OOOOO00O000 .data .get (OOOOO0O0OO00O0O00 .Symbol ):#line:1371
                        O000O0000OOO0O00O =OO0O00OOOOO00O000 [OOOOO0O0OO00O0O00 .Symbol ]#line:1372
                        O000O0000OOO0O00O .UpdateHL =True #line:1373
                        O000O0000OOO0O00O .HL =OOOOO0O0OO00O0O00 #line:1374
                        O000O0000OOO0O00O .SetDataInit ()#line:1375
                    if topic =="":#line:1376
                        OOO0O000OOOO0OOO0 :str =OOOOO0O0OO00O0O00 .TopicTX #line:1377
                        OOO0O000O0OOO0OO0 :str =OOOOO0O0OO00O0O00 .Topic5Q #line:1378
                        O0OOO0OO00OO00000 [OOO0O000OOOO0OOO0 ]=O000O0000OOO0O00O #line:1379
                        O0OOO0OO00OO00000 [OOO0O000O0OOO0OO0 ]=O000O0000OOO0O00O #line:1380
                        if O0OOO0OO00OO00000 .MapQtProc .get (OOO0O000OOOO0OOO0 )is None :#line:1381
                            O0OOO0OO00OO00000 .MapQtProc [OOO0O000OOOO0OOO0 ]=O0OOO0OO00OO00000 .DefProc_TX #line:1382
                        if O0OOO0OO00OO00000 .MapQtProc .get (OOO0O000O0OOO0OO0 )is None :#line:1383
                            O0OOO0OO00OO00000 .MapQtProc [OOO0O000O0OOO0OO0 ]=O0OOO0OO00OO00000 .DefProc_5Q #line:1384
            return len (OO0O00OOOOO00O000 )>0 ,OO0O00OOOOO00O000 ,OO0OOOO0OO0O00O0O #line:1386
        except Exception as OO000OOOO0000OOOO :#line:1387
            OO0OOOO0OO0O00O0O =f"[證][AddDataBySolIce](aIsCat={O0OOO0O000OOOOOO0}, aSolIce={O0OO0O0OOOO000OO0}){OO000OOOO0000OOOO}"#line:1388
        return False ,OO0O00OOOOO00O000 ,OO0OOOO0OO0O00O0O #line:1389
    def AddIdxDataBySolIce (O000000OOOOOO0OOO ,O0O0OOO0O0O00OOO0 :bool ,OOO00O0OO00O00O00 :str ,OOO00OO0OOOO00OO0 ,OOO0O0OO0000OOOOO :bool ):#line:1391
        ""#line:1398
        try :#line:1399
            OOOOO0OO00O0O00OO =""#line:1400
            O000O0O0O00O00O00 :TObjStkQuoteMap =TObjStkQuoteMap ()#line:1401
            for OO0OOO0O000OO0OO0 in OOO00OO0OOOO00OO0 ["BAS"]:#line:1403
                OO0OO000O0OO0O000 :TStkQtBase =TStkQtBase ()#line:1404
                OO0OO000O0OO0O000 .Handle_BAS (OO0OOO0O000OO0OO0 )#line:1405
                if O000O0O0O00O00O00 .data .get (OO0OO000O0OO0O000 .StkNo )is None :#line:1406
                    O0O0000O0000O0O00 :TStkQuoteData =TStkQuoteData (TStkProdKind .pkIndex ,OO0OO000O0OO0O000 .StkNo ,OOO0O0OO0000OOOOO )#line:1407
                    O0O0000O0000O0O00 .BAS =OO0OO000O0OO0O000 #line:1408
                    O000O0O0O00O00O00 [OO0OO000O0OO0O000 .StkNo ]=O0O0000O0000O0O00 #line:1409
            for OO0OOO0O000OO0OO0 in OOO00OO0OOOO00OO0 ["HL"]:#line:1412
                OOOO000OO0O00OO0O =TStkQtHL ()#line:1413
                OOOO000OO0O00OO0O .Handle_HL (OO0OOO0O000OO0OO0 )#line:1414
                if O000O0O0O00O00O00 .data .get (OOOO000OO0O00OO0O .Symbol ):#line:1415
                    O0O0000O0000O0O00 =O000O0O0O00O00O00 [OOOO000OO0O00OO0O .Symbol ]#line:1416
                    O0O0000O0000O0O00 .HL =OOOO000OO0O00OO0O #line:1417
                    O0O0000O0000O0O00 .SetDataInit ()#line:1418
                    O0O0O00000O000O00 :OO0OOO0O000OO0OO0 =O0O0000O0000O0O00 .HL .TopicTX #line:1420
                    O000000OOOOOO0OOO [O0O0O00000O000O00 ]=O0O0000O0000O0O00 #line:1422
                    if O000000OOOOOO0OOO .MapQtProc .get (O0O0O00000O000O00 )is None :#line:1424
                        O000000OOOOOO0OOO .MapQtProc [O0O0O00000O000O00 ]=O000000OOOOOO0OOO .DefProc_Idx #line:1425
            return len (O000O0O0O00O00O00 )>0 ,O000O0O0O00O00O00 ,OOOOO0OO00O0O00OO #line:1427
        except Exception as O0OO0O00O0OOO00OO :#line:1428
            OOOOO0OO00O0O00OO =f"[證][AddIdxDataBySolIce](aIsCat={O0O0OOO0O0O00OOO0}, aSolIce={OOO00O0OO00O00O00}){O0OO0O00O0OOO00OO}"#line:1429
        return False ,O000O0O0O00O00O00 ,OOOOO0OO00O0O00OO #line:1430
    def GetItem_BySolIce (O0000OOOO0O0OOO00 ,O0O0O000OOOO0OOO0 :str ):#line:1433
        ""#line:1438
        try :#line:1439
            O0000000O00OO000O =[]#line:1440
            for OO00OOOOO0OOO0000 ,OO0000O00000OO0O0 in O0000OOOO0O0OOO00 .items ():#line:1441
                OO00O00OOOOO0000O :TStkQuoteData #line:1442
                OO00O00OOOOO0000O =OO0000O00000OO0O0 #line:1443
                if OO00O00OOOOO0000O .SolIce ==O0O0O000OOOO0OOO0 :#line:1444
                    O0000000O00OO000O .append (OO00OOOOO0OOO0000 )#line:1445
            if O0000000O00OO000O is None or len (O0000000O00OO000O )==0 :#line:1446
                return False ,[],f"[證][GetItem_BySolIce](aSolIce={O0O0O000OOOO0OOO0})商品已不存存!"#line:1447
            else :#line:1448
                return True ,O0000000O00OO000O ,""#line:1449
        except Exception as OOOO0OO0O00O0O000 :#line:1450
            return False ,[],f"[證][GetItem_BySolIce](aSolIce={O0O0O000OOOO0OOO0}){OOOO0OO0O00O0O000}"#line:1451
    def GetItem_ByCategory (O0OOOO0O0OO0OOOO0 ,OOO0O00OOO0O0OOO0 :str ):#line:1452
        ""#line:1455
        try :#line:1457
            O0OOO0OOO0O0000OO =[]#line:1458
            for O00OO0O0O0000OOOO ,O0O0O000O0O0O0000 in O0OOOO0O0OO0OOOO0 .items ():#line:1459
                OOO0OO0O0O00O0OOO :TStkQuoteData =O0O0O000O0O0O0000 #line:1460
                O000O0O00O00O0OOO =O00OO0O0O0000OOOO .split ('/')#line:1461
                if O000O0O00O00O0OOO [2 ]==OOO0O00OOO0O0OOO0 :#line:1462
                    O0OOO0OOO0O0000OO .append (O00OO0O0O0000OOOO )#line:1463
            if O0OOO0OOO0O0000OO is None or len (O0OOO0OOO0O0000OO )==0 :#line:1465
                return False ,[],f"[證][GetItem_ByCategory](aCat={OOO0O00OOO0O0OOO0})商品已不存存!"#line:1466
            else :#line:1467
                return True ,O0OOO0OOO0O0000OO ,""#line:1468
        except Exception as OOOOOOO00O00OO00O :#line:1470
            return False ,[],f"[證][GetItem_ByCategory](aCat={OOO0O00OOO0O0OOO0}){OOOOOOO00O00OO00O}"#line:1471
class TQryStkProdMap (UserDict ):#line:1475
    def __init__ (OOOO0OOO000OO00O0 ,mapping =None ,**O0O000OO00000O00O ):#line:1476
        if mapping is not None :#line:1477
            mapping ={str (OOOO000OO0O0O0OO0 ).upper ():OOO00000000O0000O for OOOO000OO0O0O0OO0 ,OOO00000000O0000O in mapping .items ()}#line:1480
        else :#line:1481
            mapping ={}#line:1482
        if O0O000OO00000O00O :#line:1483
            mapping .update ({str (OOO0O000O000000O0 ).upper ():O0OOOOO0OO00O0000 for OOO0O000O000000O0 ,O0OOOOO0OO00O0000 in O0O000OO00000O00O .items ()})#line:1486
        super ().__init__ (mapping )#line:1487
    """Dictionary<string, TQryStkProdRec>"""#line:1488
    def __setitem__ (O0O0O000000O00O00 ,OO0OOO0O000OOO000 ,OO0000O0O0000OO0O ):#line:1490
        super ().__setitem__ (OO0OOO0O000OOO000 ,OO0000O0O0000OO0O )#line:1491
class TQryStkProdRec ():#line:1494
    tmpBase :TStkQtBase =None #line:1495
    tmpHL :TStkQtHL =None #line:1496
    def SetDataInit (O00OOO0O0OOO0OOO0 ):#line:1498
        pass #line:1499
class TFutQtBase :#line:1505
    fHasBAS :bool =False #line:1507
    TopicTX :str =""#line:1508
    Topic5Q :str =""#line:1509
    TopicHL :str =""#line:1510
    Topic5QTOT :str =""#line:1511
    TopicBAS :str =""#line:1512
    fBAS =[]#line:1514
    DECIMAL_LOCATOR_Org :int =0 #line:1516
    """價格欄位小數位數"""#line:1517
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:1518
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""#line:1519
    OrdProdID :str #line:1520
    """商品委託代碼(EX:CDFC3)"""#line:1521
    RefPriceOrg :str #line:1522
    """參考價"""#line:1523
    def Get_RefPrice2Str (OO0O00OOOO0000OOO )->str :#line:1525
        return OO0O00OOOO0000OOO .TransPrice2Str (OO0O00OOOO0000OOO .fBAS [4 ])#line:1526
    def Get_RefPrice2Dec (OOOO0O0000OO0000O )->decimal :#line:1528
        return OOOO0O0000OO0000O .TransPrice2Dec (OOOO0O0000OO0000O .fBAS [4 ])#line:1529
    LimitPrice_UpOrg :str #line:1531
    """漲停價"""#line:1532
    def Get_LimitPrice_Up2Str (O0O0OO0OO000OO000 )->str :#line:1534
        return O0O0OO0OO000OO000 .TransPrice2Str (O0O0OO0OO000OO000 .fBAS [5 ])#line:1535
    def Get_LimitPrice_Up2Dec (OO00O0O00O00OO0OO )->decimal :#line:1537
        return OO00O0O00O00OO0OO .TransPrice2Dec (OO00O0O00O00OO0OO .fBAS [5 ])#line:1538
    LimitPrice_DownOrg :str #line:1540
    """跌停價"""#line:1541
    ProdKind :str #line:1543
    """契約種類"""#line:1544
    def Get_LimitPrice_Down2Str (O0O0O0O0O000O0OOO )->str :#line:1546
        return O0O0O0O0O000O0OOO .TransPrice2Str (O0O0O0O0O000O0OOO .fBAS [6 ])#line:1547
    def Get_LimitPrice_Down2Dec (OOOO0OO00O00OOOOO )->decimal :#line:1549
        return OOOO0OO00O00OOOOO .TransPrice2Dec (OOOO0OO00O00OOOOO .fBAS [6 ])#line:1550
    IdxDgtOrg :str #line:1552
    """指數小數位數"""#line:1553
    def Get_IdxDgtOrg (O0000000OO00000OO )->int :#line:1555
        return O0000000OO00000OO .TransToInt (O0000000OO00000OO .fBAS [8 ])#line:1556
    StrikePriceDecimalLocator :str #line:1558
    "選擇權商品代號之履約價小數位數"#line:1559
    BeginDate :str #line:1561
    "上市日期"#line:1562
    EndDate :str #line:1563
    "下市日期"#line:1564
    FlowGroup :str #line:1565
    "流程群組"#line:1566
    DeliveryDate :str #line:1567
    "最後結算日"#line:1568
    DynamicBanding :str #line:1569
    "適用動態價格穩定"#line:1570
    ProdID :str #line:1572
    """契約代號 (EX:CDF)"""#line:1573
    FutName :str #line:1574
    """期貨契約中文(EX:小型環球晶)"""#line:1575
    StkNo :str #line:1576
    """現股代碼(EX:2330)"""#line:1577
    ValuePerUnitOrg :str #line:1578
    """契約乘數"""#line:1579
    def Get_ValuePerUnit (OOO00OO0OO00OO0O0 )->decimal :#line:1581
        return OOO00OO0OO00OO0O0 .TransToDecimal (OOO00OO0OO00OO0O0 .fBAS [18 ])#line:1582
    StatusCode :str #line:1584
    "狀態碼"#line:1585
    Currency :str #line:1586
    "幣別"#line:1587
    AcceptQuoteFlag :str #line:1588
    "是否可報價"#line:1589
    BlockTradeFlag :str #line:1590
    "是否可鉅額交易"#line:1591
    ExpiryType :str #line:1592
    "到期別"#line:1593
    UnderlyingType :str #line:1594
    "現貨類別"#line:1595
    MarketCloseGroup :str #line:1596
    "商品收盤時間群組"#line:1597
    EndSession :str #line:1598
    MktType :str #line:1600
    """早午盤識別(早盤:0, 午盤:1)"""#line:1601
    SettleMth :str #line:1602
    """交割月"""#line:1603
    CallPutType :str #line:1604
    """C/P"""#line:1605
    StrikeP :str #line:1606
    """履約價"""#line:1607
    PreTotalMatchQty :str #line:1609
    """昨日成交總量"""#line:1610
    PreOpenInterest :str #line:1611
    """昨日未平倉合約數"""#line:1612
    PreTodayRefPrice :str #line:1613
    """昨日參考價"""#line:1614
    def Get_PreTodayRefPrice2Str (O0OO0OOO00OOO000O ):#line:1615
        return O0OO0OOO00OOO000O .TransPrice2Dec (O0OO0OOO00OOO000O .fBAS [31 ])#line:1616
    def Get_PreTodayRefPrice2Dec (O00000O00O000OO0O ):#line:1617
        return O00000O00O000OO0O .TransPrice2Dec (O00000O00O000OO0O .fBAS [31 ])#line:1618
    PreClosePrice :str #line:1620
    """昨日收盤價"""#line:1621
    def Get_PreClosePrice2Str (OO0OOO0OOOO00OO00 ):#line:1622
        return OO0OOO0OOOO00OO00 .TransPrice2Str (OO0OOO0OOOO00OO00 .fBAS [32 ])#line:1623
    def Get_PreClosePrice2Dec (O00O0O0O0OOOO00OO ):#line:1624
        return O00O0O0O0OOOO00OO .TransPrice2Dec (O00O0O0O0OOOO00OO .fBAS [32 ])#line:1625
    PreSettlePrice :str #line:1627
    """昨日結算價"""#line:1628
    def Get_PreSettlePrice2Str (OOOOO00OO0OO00O00 ):#line:1629
        return OOOOO00OO0OO00O00 .TransPrice2Str (OOOOO00OO0OO00O00 .fBAS [33 ])#line:1630
    def Get_PreSettlePrice2Dec (OOOOOO0OO0O000000 ):#line:1631
        return OOOOOO0OO0O000000 .TransPrice2Dec (OOOOOO0OO0O000000 .fBAS [33 ])#line:1632
    TickSizeInfo :str #line:1634
    """跳動點資訊"""#line:1635
    def Handle_BAS (O00O000OOO0O0OO00 ,O000OO0OOO0O0OOOO :str ):#line:1638
        O00O000OOO0O0OO00 .fBAS =O000OO0OOO0O0OOOO .split ("|")#line:1639
        O00O000OOO0O0OO00 .fHasBAS =len (O00O000OOO0O0OO00 .fBAS )>0 #line:1640
        O00O000OOO0O0OO00 .OrdProdID =O00O000OOO0O0OO00 .fBAS [0 ]#line:1641
        O00O000OOO0O0OO00 .RefPriceOrg =O00O000OOO0O0OO00 .fBAS [4 ]#line:1642
        O00O000OOO0O0OO00 .LimitPrice_UpOrg =O00O000OOO0O0OO00 .fBAS [5 ]#line:1643
        O00O000OOO0O0OO00 .LimitPrice_DownOrg =O00O000OOO0O0OO00 .fBAS [6 ]#line:1644
        O00O000OOO0O0OO00 .ProdKind =O00O000OOO0O0OO00 .fBAS [7 ]#line:1645
        O00O000OOO0O0OO00 .IdxDgtOrg =O00O000OOO0O0OO00 .fBAS [8 ]#line:1646
        O00O000OOO0O0OO00 .StrikePriceDecimalLocator =O00O000OOO0O0OO00 .fBAS [9 ]#line:1647
        O00O000OOO0O0OO00 .BeginDate =O00O000OOO0O0OO00 .fBAS [10 ]#line:1648
        O00O000OOO0O0OO00 .EndDate =O00O000OOO0O0OO00 .fBAS [11 ]#line:1649
        O00O000OOO0O0OO00 .FlowGroup =O00O000OOO0O0OO00 .fBAS [12 ]#line:1650
        O00O000OOO0O0OO00 .DeliveryDate =O00O000OOO0O0OO00 .fBAS [13 ]#line:1651
        O00O000OOO0O0OO00 .DynamicBanding =O00O000OOO0O0OO00 .fBAS [14 ]#line:1652
        O00O000OOO0O0OO00 .ProdID =O00O000OOO0O0OO00 .fBAS [15 ]#line:1653
        O00O000OOO0O0OO00 .FutName =O00O000OOO0O0OO00 .fBAS [16 ]#line:1654
        O00O000OOO0O0OO00 .StkNo =O00O000OOO0O0OO00 .fBAS [17 ]#line:1655
        O00O000OOO0O0OO00 .ValuePerUnitOrg =O00O000OOO0O0OO00 .fBAS [18 ]#line:1656
        O00O000OOO0O0OO00 .StatusCode =O00O000OOO0O0OO00 .fBAS [19 ]#line:1657
        O00O000OOO0O0OO00 .Currency =O00O000OOO0O0OO00 .fBAS [20 ]#line:1658
        O00O000OOO0O0OO00 .AcceptQuoteFlag =O00O000OOO0O0OO00 .fBAS [21 ]#line:1659
        O00O000OOO0O0OO00 .BlockTradeFlag =O00O000OOO0O0OO00 .fBAS [22 ]#line:1660
        O00O000OOO0O0OO00 .ExpiryType =O00O000OOO0O0OO00 .fBAS [23 ]#line:1661
        O00O000OOO0O0OO00 .UnderlyingType =O00O000OOO0O0OO00 .fBAS [24 ]#line:1662
        O00O000OOO0O0OO00 .MarketCloseGroup =O00O000OOO0O0OO00 .fBAS [25 ]#line:1663
        O00O000OOO0O0OO00 .EndSession =O00O000OOO0O0OO00 .fBAS [26 ]#line:1664
        O00O000OOO0O0OO00 .MktType =O00O000OOO0O0OO00 .fBAS [27 ]#line:1665
        if len (O00O000OOO0O0OO00 .fBAS [28 ])==0 or O00O000OOO0O0OO00 .fBAS [28 ]is None or O00O000OOO0O0OO00 .fBAS [28 ].isspace ():#line:1666
            O00O000OOO0O0OO00 .SettleMth =""#line:1667
        else :#line:1668
            O00O000OOO0O0OO00 .SettleMth =O00O000OOO0O0OO00 .fBAS [28 ].split (".")[1 ]#line:1669
        O00O000OOO0O0OO00 .CallPutType =""#line:1671
        if len (O00O000OOO0O0OO00 .fBAS [28 ])==0 or O00O000OOO0O0OO00 .fBAS [28 ]is None or O00O000OOO0O0OO00 .fBAS [28 ].isspace ():#line:1672
            O00O000OOO0O0OO00 .CallPutType =""#line:1673
        if "C"in O00O000OOO0O0OO00 .fBAS [28 ]:#line:1674
            O00O000OOO0O0OO00 .CallPutType ="C"#line:1675
        if "P"in O00O000OOO0O0OO00 .fBAS [28 ]:#line:1676
            O00O000OOO0O0OO00 .CallPutType ="P"#line:1677
        O00O000OOO0O0OO00 .StrikeP =""#line:1679
        if len (O00O000OOO0O0OO00 .fBAS [28 ])==0 or O00O000OOO0O0OO00 .fBAS [28 ]is None or O00O000OOO0O0OO00 .fBAS [28 ].isspace ():#line:1680
            O00O000OOO0O0OO00 .StrikeP =""#line:1681
        if "C"in O00O000OOO0O0OO00 .fBAS [28 ]:#line:1682
            O00O000OOO0O0OO00 .StrikeP =O00O000OOO0O0OO00 .fBAS [28 ].split (".")[1 ]#line:1683
        if "P"in O00O000OOO0O0OO00 .fBAS [28 ]:#line:1684
            O00O000OOO0O0OO00 .StrikeP =O00O000OOO0O0OO00 .fBAS [28 ].split (".")[1 ]#line:1685
        O00O000OOO0O0OO00 .PreTotalMatchQty =O00O000OOO0O0OO00 .fBAS [29 ]#line:1687
        O00O000OOO0O0OO00 .PreOpenInterest =O00O000OOO0O0OO00 .fBAS [30 ]#line:1688
        O00O000OOO0O0OO00 .PreTodayRefPrice =O00O000OOO0O0OO00 .fBAS [31 ]#line:1689
        O00O000OOO0O0OO00 .PreClosePrice =O00O000OOO0O0OO00 .fBAS [32 ]#line:1690
        O00O000OOO0O0OO00 .PreSettlePrice =O00O000OOO0O0OO00 .fBAS [33 ]#line:1691
        O00O000OOO0O0OO00 .TickSizeInfo =O00O000OOO0O0OO00 .fBAS [36 ]#line:1693
        if O00O000OOO0O0OO00 .fHasBAS :#line:1694
            O00O000OOO0O0OO00 .DECIMAL_LOCATOR_Org =O00O000OOO0O0OO00 .Get_IdxDgtOrg ()#line:1696
            if O00O000OOO0O0OO00 .DECIMAL_LOCATOR_Org ==0 :#line:1697
                O00O000OOO0O0OO00 .DECIMAL_LOCATOR_Dgt =1 #line:1698
            else :#line:1699
                O00O000OOO0O0OO00 .DECIMAL_LOCATOR_Dgt =1 /Decimal ("1".ljust (O00O000OOO0O0OO00 .DECIMAL_LOCATOR_Org +1 ,'0'))#line:1701
        if O00O000OOO0O0OO00 .TopicTX !="":#line:1703
            OOO0O00O0O0OO00OO =O00O000OOO0O0OO00 .TopicTX .split ("/")#line:1704
            OOO0O00O0O0OO00OO [len (OOO0O00O0O0OO00OO )-2 ]=O00O000OOO0O0OO00 .OrdProdID #line:1705
            O00O000OOO0O0OO00 .TopicTX ="/".join (OOO0O00O0O0OO00OO )#line:1706
            OOO0O00O0O0OO00OO =O00O000OOO0O0OO00 .Topic5Q .split ("/")#line:1707
            OOO0O00O0O0OO00OO [len (OOO0O00O0O0OO00OO )-2 ]=O00O000OOO0O0OO00 .OrdProdID #line:1708
            O00O000OOO0O0OO00 .Topic5Q ="/".join (OOO0O00O0O0OO00OO )#line:1709
            OOO0O00O0O0OO00OO =O00O000OOO0O0OO00 .TopicHL .split ("/")#line:1710
            OOO0O00O0O0OO00OO [len (OOO0O00O0O0OO00OO )-2 ]=O00O000OOO0O0OO00 .OrdProdID #line:1711
            O00O000OOO0O0OO00 .TopicHL ="/".join (OOO0O00O0O0OO00OO )#line:1712
            OOO0O00O0O0OO00OO =O00O000OOO0O0OO00 .Topic5QTOT .split ("/")#line:1713
            OOO0O00O0O0OO00OO [len (OOO0O00O0O0OO00OO )-2 ]=O00O000OOO0O0OO00 .OrdProdID #line:1714
            O00O000OOO0O0OO00 .Topic5QTOT ="/".join (OOO0O00O0O0OO00OO )#line:1715
            OOO0O00O0O0OO00OO =O00O000OOO0O0OO00 .TopicBAS .split ("/")#line:1716
            OOO0O00O0O0OO00OO [len (OOO0O00O0O0OO00OO )-2 ]=O00O000OOO0O0OO00 .OrdProdID #line:1717
            O00O000OOO0O0OO00 .TopicBAS ="/".join (OOO0O00O0O0OO00OO )#line:1718
    def Handle_BAS_ChangeMktType (O0OOOO00O0OO0O0OO ,OO0000O00000OOOOO :str )->bool :#line:1720
        ""#line:1721
        try :#line:1722
            if O0OOOO00O0OO0O0OO .fBAS is not None and len (O0OOOO00O0OO0O0OO .fBAS )>28 :#line:1723
                OOOO000OOOOOOOO00 =OO0000O00000OOOOO .split ("|")#line:1724
                if len (OOOO000OOOOOOOO00 )>28 :#line:1725
                    if OOOO000OOOOOOOO00 [27 ]!=O0OOOO00O0OO0O0OO .fBAS [27 ]:#line:1726
                        O0OOOO00O0OO0O0OO .Handle_BAS (OO0000O00000OOOOO )#line:1727
                        return True #line:1728
        except Exception as OOO0O0OO00000OO00 :#line:1729
            return False #line:1730
    def TransPrice2Dec (O0O0OO0OO00O0000O ,OOO00OO0OO0O00000 :str )->decimal :#line:1733
        try :#line:1734
            O0OO00O000O00O0OO =Decimal (OOO00OO0OO0O00000 )#line:1735
            O0OO00O000O00O0OO =O0OO00O000O00O0OO *O0O0OO0OO00O0000O .DECIMAL_LOCATOR_Dgt #line:1736
            return O0OO00O000O00O0OO #line:1737
        except Exception as O0000O0OOO00O00O0 :#line:1738
            print (f"Not a Decimal{O0000O0OOO00O00O0}")#line:1739
            return 0 #line:1740
    def TransPrice2Str (O00OOOO0OO000OOO0 ,O00OOO0OOOOO000O0 :str )->str :#line:1742
        if O00OOOO0OO000OOO0 .DECIMAL_LOCATOR_Dgt ==1 :#line:1743
            return O00OOO0OOOOO000O0 #line:1744
        if O00OOO0OOOOO000O0 =="0":#line:1745
            return ""#line:1746
        if len (O00OOO0OOOOO000O0 )<O00OOOO0OO000OOO0 .DECIMAL_LOCATOR_Org :#line:1747
            return O00OOO0OOOOO000O0 #line:1748
        if not O00OOO0OOOOO000O0 or O00OOO0OOOOO000O0 .isspace ():#line:1749
            return ""#line:1750
        try :#line:1751
            O0000O0O00OOOOOO0 =len (O00OOO0OOOOO000O0 )#line:1752
            return O00OOO0OOOOO000O0 [:O0000O0O00OOOOOO0 -O00OOOO0OO000OOO0 .DECIMAL_LOCATOR_Org ]+'.'+O00OOO0OOOOO000O0 [O0000O0O00OOOOOO0 -O00OOOO0OO000OOO0 .DECIMAL_LOCATOR_Org :]#line:1753
        except Exception as O00OOOO00O0OO0O00 :#line:1754
            return ""#line:1755
    def TransToInt (OOOOO00O0O0OO0O00 ,OOOO0OO00O0O00000 :str )->int :#line:1757
        try :#line:1758
            return int (OOOO0OO00O0O00000 )#line:1759
        except Exception as O0000O00OOO00OO00 :#line:1760
            pass #line:1762
        return 0 #line:1763
    def TransToDecimal (OO0O0OO00OOO0OOOO ,OO00O0OOO000OO000 :str )->decimal :#line:1765
        try :#line:1766
            return Decimal (OO00O0OOO000OO000 )#line:1767
        except Exception as OO0000000O000OOO0 :#line:1768
            print (f"Not a Decimal{OO0000000O000OOO0}")#line:1769
        return 0 #line:1770
    def __init__ (OOOOOOO000O000OOO ,topic :str ="")->None :#line:1773
        if topic !="":#line:1774
            OO0000OO0OOO000OO =topic .split ("/")#line:1775
            OO0000OO0OOO000OO [len (OO0000OO0OOO000OO )-1 ]="HL"#line:1776
            OOOOOOO000O000OOO .TopicHL ="/".join (OO0000OO0OOO000OO )#line:1777
            OO0000OO0OOO000OO [len (OO0000OO0OOO000OO )-1 ]="TX"#line:1778
            OOOOOOO000O000OOO .TopicTX ="/".join (OO0000OO0OOO000OO )#line:1779
            OO0000OO0OOO000OO [len (OO0000OO0OOO000OO )-1 ]="5Q"#line:1780
            OOOOOOO000O000OOO .Topic5Q ="/".join (OO0000OO0OOO000OO )#line:1781
            OO0000OO0OOO000OO [len (OO0000OO0OOO000OO )-1 ]="5QTOT"#line:1782
            OOOOOOO000O000OOO .Topic5QTOT ="/".join (OO0000OO0OOO000OO )#line:1783
            OO0000OO0OOO000OO [len (OO0000OO0OOO000OO )-1 ]="BAS"#line:1784
            OOOOOOO000O000OOO .TopicBAS ="/".join (OO0000OO0OOO000OO )#line:1785
    def __str__ (O00000O0O00O0O0OO )->str :#line:1787
        return f"""OrdProdID:{O00000O0O00O0O0OO.OrdProdID} RefPriceOrg:{O00000O0O00O0O0OO.RefPriceOrg} LimitPrice_UpOrg:{O00000O0O00O0O0OO.LimitPrice_UpOrg} LimitPrice_DownOrg:{O00000O0O00O0O0OO.LimitPrice_DownOrg}"""+"""IdxDgtOrg:{self.IdxDgtOrg} ProdID:{self.ProdID} FutName:{self.FutName} StkNo:{self.StkNo} ValuePerUnitOrg:{self.ValuePerUnitOrg}"""+"""MktType:{self.MktType} SettleMth:{self.SettleMth} CallPutType:{self.CallPutType} StrikeP:{self.StrikeP} TickSizeInfo:{self.TickSizeInfo} """#line:1790
class TFutQtHL :#line:1791
    HasHL :bool =False #line:1793
    fHL =[]#line:1794
    TopicTX =""#line:1795
    Topic5Q =""#line:1796
    Topic5QTOT =""#line:1797
    TopicBAS =""#line:1798
    DECIMAL_LOCATOR_Org :int =0 #line:1800
    """價格欄位小數位數"""#line:1801
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:1802
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""#line:1803
    Exchange :str =""#line:1804
    "市場別(TWS/TWF)"#line:1805
    Market :str =""#line:1806
    """商品別(FUT/OPT)"""#line:1807
    Symbol :str =""#line:1808
    """委託商品代碼(TXFA2)"""#line:1809
    TryMark_Deal :str =""#line:1810
    """成交試撮註記(試撮=1, 非試撮=0"""#line:1811
    TryMark :str =""#line:1812
    """試撮註記(試撮=1, 非試撮=0)"""#line:1813
    DealTime :str =""#line:1814
    """撮合時間(成交)(EX:173547.32700)"""#line:1815
    DealSn :str =""#line:1816
    """成交序號"""#line:1817
    def Get_DealSn (OO0O0O0000000OO00 )->int :#line:1819
        return OO0O0O0000000OO00 .TransToInt (OO0O0O0000000OO00 .fHL [7 ])#line:1820
    Sn_5Q :str =""#line:1821
    """五檔序號"""#line:1822
    def Get_Sn_5Q (O000O000O0O000OO0 )->int :#line:1824
        return O000O000O0O000OO0 .TransToInt (O000O000O0O000OO0 .fHL [8 ])#line:1825
    DealPriceOrg :str =""#line:1826
    """成交價"""#line:1827
    def Get_DealPrice2Str (OOOOO00000OOOOOO0 )->str :#line:1828
        return OOOOO00000OOOOOO0 .TransPrice2Str (OOOOO00000OOOOOO0 .fHL [9 ])#line:1829
    def Get_DealPrice2Dec (OOOO00O0O0O0O0000 )->decimal :#line:1830
        return OOOO00O0O0O0O0000 .TransPrice2Dec (OOOO00O0O0O0O0000 .fHL [9 ])#line:1831
    fDealPrice :decimal =0 #line:1833
    """成交價"""#line:1834
    def DealPrice (OO0000OO0OOOOOOOO )->decimal :#line:1836
        return OO0000OO0OOOOOOOO .fDealPrice #line:1837
    DealQty :str =""#line:1838
    """成交單量"""#line:1839
    def Get_DealQty2Dec (OO0O000OO0O0OO000 )->decimal :#line:1841
        return OO0O000OO0O0OO000 .TransToDecimal (OO0O000OO0O0OO000 .fHL [10 ])#line:1842
    def Get_DealQty2Int (OO0O0OO0OOO00O00O )->int :#line:1844
        return OO0O0OO0OOO00O00O .TransToInt (OO0O0OO0OOO00O00O .fHL [10 ])#line:1845
    HighPriceOrg :str =""#line:1846
    """當日最高價"""#line:1847
    def Get_HighPrice2Str (O0O00O00O0O0OO0OO )->str :#line:1849
        return O0O00O00O0O0OO0OO .TransPrice2Str (O0O00O00O0O0OO0OO .fHL [11 ])#line:1850
    def Get_HighPrice2Dec (O000O0000O0OO0OOO )->decimal :#line:1852
        return O000O0000O0OO0OOO .TransPrice2Dec (O000O0000O0OO0OOO .fHL [11 ])#line:1853
    LowPriceOrg :str =""#line:1854
    """當日最低價"""#line:1855
    def Get_LowPrice2Str (OOOOOO0O00O0000O0 )->str :#line:1857
        return OOOOOO0O00O0000O0 .TransPrice2Str (OOOOOO0O00O0000O0 .fHL [12 ])#line:1858
    def Get_LowPrice2Dec (O00OOO000OO0O00OO )->decimal :#line:1860
        return O00OOO000OO0O00OO .TransPrice2Dec (O00OOO000OO0O00OO .fHL [12 ])#line:1861
    TotAmt :str =""#line:1862
    """成交總額"""#line:1863
    TotQty :str =""#line:1864
    """成交總量"""#line:1865
    def Get_TotQty2Dec (O00O0O00O00OO00OO )->decimal :#line:1867
        return O00O0O00O00OO00OO .TransToDecimal (O00O0O00O00OO00OO .fHL [14 ])#line:1868
    def Get_TotQty2Int (O0OO0O0OOO0OO00OO )->int :#line:1870
        return O0OO0O0OOO0OO00OO .TransToInt (O0OO0O0OOO0OO00OO .fHL [14 ])#line:1871
    FirstDerivedBuyPriceOrg :str #line:1873
    "衍生委託單第一檔買進價格"#line:1874
    def Get_FirstDerivedBuyPrice (O0000OO0OO0OOO0O0 ):#line:1875
        return O0000OO0OO0OOO0O0 .TransPrice2Str (O0000OO0OO0OOO0O0 .fHL [35 ])#line:1876
    FirstDerivedBuyQty :str #line:1877
    "衍生委託單第一檔買進價格數量"#line:1878
    FirstDerivedSellPriceOrg :str #line:1879
    "衍生委託單第一檔賣出價格數量"#line:1880
    def Get_FirstDerivedSellPrice (OO0O00OOO0OOOOOO0 ):#line:1881
        return OO0O00OOO0OOOOOO0 .TransPrice2Str (OO0O00OOO0OOOOOO0 .fHL [37 ])#line:1882
    FirstDerivedSellQty :str #line:1883
    "衍生委託單第一檔賣出價格數量"#line:1884
    OpenPriceOrg :str =""#line:1886
    """開盤價"""#line:1887
    def Get_OpenPrice2Str (OOO0OOOO0O00OOOOO ):#line:1888
        return OOO0OOOO0O00OOOOO .TransPrice2Str (OOO0OOOO0O00OOOOO .fHL [39 ])#line:1889
    def Get_OpenPrice2Dec (O0O000OOOOOOOOO00 ):#line:1890
        return O0O000OOOOOOOOO00 .TransPrice2Dec (O0O000OOOOOOOOO00 .fHL [39 ])#line:1891
    def Get_OpenPrice2Str (OOOO0O00O0OOOO000 )->str :#line:1893
        return OOOO0O00O0OOOO000 .TransPrice2Str (OOOO0O00O0OOOO000 .fHL [39 ])#line:1894
    def Get_OpenPrice2Dec (O0OOO0000OOOOO0O0 )->decimal :#line:1896
        return O0OOO0000OOOOO0O0 .TransPrice2Dec (O0OOO0000OOOOO0O0 .fHL [39 ])#line:1897
    TryMark_5Q :str =""#line:1899
    "五檔試撮註記(試撮=1, 非試撮=0)"#line:1900
    ClosePrice :str =""#line:1901
    "收盤價"#line:1902
    def Get_ClosePrice (O000OOOOO000OO0OO ):#line:1903
        return O000OOOOO000OO0OO .TransPrice2Str (O000OOOOO000OO0OO .fHL [41 ])#line:1904
    SettlePrice :str =""#line:1905
    "結算價<"#line:1906
    def Get_SettlePrice (O0OOOOO00OOO00O00 ):#line:1907
        return O0OOOOO00OOO00O00 .TransPrice2Str (O0OOOOO00OOO00O00 .fHL [42 ])#line:1908
    OpenInterest :str =""#line:1909
    "未平倉合約數"#line:1910
    fAryB5Q_P =[15 ,17 ,19 ,21 ,23 ]#line:1914
    """買五檔價在字串中的位置"""#line:1915
    fAryB5Q_Q =[16 ,18 ,20 ,22 ,24 ]#line:1916
    """買五檔價在字串中的位置"""#line:1917
    fB5QCount :int =5 #line:1918
    """買5檔的檔數"""#line:1919
    def B5Q_POrg (O00O000OOO00000OO ,OO00O000000OO0OO0 :int )->str :#line:1921
        ""#line:1922
        if OO00O000000OO0OO0 >O00O000OOO00000OO .fB5QCount :#line:1923
            return ""#line:1924
        else :#line:1925
            return O00O000OOO00000OO .fHL [O00O000OOO00000OO .fAryB5Q_P [OO00O000000OO0OO0 -1 ]]#line:1926
    def Get_B5Q_P2Dec (O00OOO0OOO0OOO0O0 ,OO0O00O0OO000OOOO :int )->decimal :#line:1928
        ""#line:1929
        if OO0O00O0OO000OOOO >O00OOO0OOO0OOO0O0 .fB5QCount :#line:1930
            return 0 #line:1931
        else :#line:1932
            return O00OOO0OOO0OOO0O0 .TransPrice2Dec (O00OOO0OOO0OOO0O0 .fHL [O00OOO0OOO0OOO0O0 .fAryB5Q_P [OO0O00O0OO000OOOO -1 ]])#line:1933
    def Get_B5Q_P2Str (OO00O0OOO00000O00 ,OO0OO00000O0OO000 :int )->str :#line:1935
        ""#line:1936
        if OO0OO00000O0OO000 >OO00O0OOO00000O00 .fB5QCount :#line:1937
            return ""#line:1938
        else :#line:1939
            return OO00O0OOO00000O00 .TransPrice2Str (OO00O0OOO00000O00 .fHL [OO00O0OOO00000O00 .fAryB5Q_P [OO0OO00000O0OO000 -1 ]])#line:1940
    def B5Q_QOrg (O0OOOOO00O0OO0O0O ,O000O0O00000O0OO0 :int )->str :#line:1942
        ""#line:1943
        if O000O0O00000O0OO0 >O0OOOOO00O0OO0O0O .fB5QCount :#line:1944
            return ""#line:1945
        else :#line:1946
            return O0OOOOO00O0OO0O0O .fHL [O0OOOOO00O0OO0O0O .fAryB5Q_Q [O000O0O00000O0OO0 -1 ]]#line:1947
    def Get_B5Q_Q (OO0O0O0O000000000 ,OO0O000000O000000 :int )->int :#line:1949
        ""#line:1950
        if OO0O000000O000000 >OO0O0O0O000000000 .fB5QCount :#line:1951
            return 0 #line:1952
        else :#line:1953
            return OO0O0O0O000000000 .TransToInt (OO0O0O0O000000000 .fHL [OO0O0O0O000000000 .fAryB5Q_Q [OO0O000000O000000 -1 ]])#line:1954
    fAryS5Q_P =[25 ,27 ,29 ,31 ,33 ]#line:1958
    """買五檔價在字串中的位置"""#line:1959
    fAryS5Q_Q =[26 ,28 ,30 ,32 ,34 ]#line:1960
    """買五檔價在字串中的位置"""#line:1961
    fS5QCount :int =5 #line:1962
    """賣5檔的檔數"""#line:1963
    def S5Q_POrg (O0OO00OO000OO000O ,OO0O000O0O0OOO000 :int )->str :#line:1965
        ""#line:1966
        if OO0O000O0O0OOO000 >O0OO00OO000OO000O .fS5QCount :#line:1967
            return ""#line:1968
        else :#line:1969
            return O0OO00OO000OO000O .fHL [O0OO00OO000OO000O .fAryS5Q_P [OO0O000O0O0OOO000 -1 ]]#line:1970
    def Get_S5Q_P2Dec (OO000OOOOOOO0000O ,OO00O000O000O0OO0 :int )->decimal :#line:1972
        ""#line:1973
        if OO00O000O000O0OO0 >OO000OOOOOOO0000O .fS5QCount :#line:1974
            return 0 #line:1975
        else :#line:1976
            return OO000OOOOOOO0000O .TransPrice2Dec (OO000OOOOOOO0000O .fHL [OO000OOOOOOO0000O .fAryS5Q_P [OO00O000O000O0OO0 -1 ]])#line:1977
    def Get_S5Q_P2Str (O00O0000OO0O00O00 ,O00OO000O0000O000 :int )->str :#line:1979
        ""#line:1980
        if O00OO000O0000O000 >O00O0000OO0O00O00 .fS5QCount :#line:1981
            return ""#line:1982
        else :#line:1983
            return O00O0000OO0O00O00 .TransPrice2Str (O00O0000OO0O00O00 .fHL [O00O0000OO0O00O00 .fAryS5Q_P [O00OO000O0000O000 -1 ]])#line:1984
    def S5Q_QOrg (O0OO000OO0O0OO00O ,O00OO00OO00000000 :int )->str :#line:1986
        ""#line:1987
        if O00OO00OO00000000 >O0OO000OO0O0OO00O .fS5QCount :#line:1988
            return ""#line:1989
        else :#line:1990
            return O0OO000OO0O0OO00O .fHL [O0OO000OO0O0OO00O .fAryS5Q_Q [O00OO00OO00000000 -1 ]]#line:1991
    def Get_S5Q_Q (OO0OO0000O0O00O00 ,OO00O000OOOO00O0O :int )->int :#line:1993
        ""#line:1994
        if OO00O000OOOO00O0O >OO0OO0000O0O00O00 .fS5QCount :#line:1995
            return 0 #line:1996
        else :#line:1997
            return OO0OO0000O0O00O00 .TransToInt (OO0OO0000O0O00O00 .fHL [OO0OO0000O0O00O00 .fAryS5Q_Q [OO00O000OOOO00O0O -1 ]])#line:1998
    def Handle_HL (O00OO0O0OOO0OO000 ,O0O00000O0O000OOO :str ):#line:2001
        O00OO0O0OOO0OO000 .fHL =O0O00000O0O000OOO .split ('|')#line:2002
        O00OO0O0OOO0OO000 .HasHL =len (O00OO0O0OOO0OO000 .fHL )>0 #line:2003
        O00OO0O0OOO0OO000 .Exchange =O00OO0O0OOO0OO000 .fHL [0 ]#line:2004
        O00OO0O0OOO0OO000 .Market =O00OO0O0OOO0OO000 .fHL [1 ]#line:2005
        O00OO0O0OOO0OO000 .Symbol =O00OO0O0OOO0OO000 .fHL [3 ]#line:2006
        O00OO0O0OOO0OO000 .TryMark_Deal =O00OO0O0OOO0OO000 .fHL [4 ]#line:2007
        O00OO0O0OOO0OO000 .TryMark =O00OO0O0OOO0OO000 .fHL [5 ]#line:2008
        O00OO0O0OOO0OO000 .DealTime =O00OO0O0OOO0OO000 .fHL [6 ]#line:2009
        O00OO0O0OOO0OO000 .DealSn =O00OO0O0OOO0OO000 .fHL [7 ]#line:2010
        O00OO0O0OOO0OO000 .Sn_5Q =O00OO0O0OOO0OO000 .fHL [8 ]#line:2011
        O00OO0O0OOO0OO000 .DealPriceOrg =O00OO0O0OOO0OO000 .fHL [9 ]#line:2012
        O00OO0O0OOO0OO000 .DealQty =O00OO0O0OOO0OO000 .fHL [10 ]#line:2013
        O00OO0O0OOO0OO000 .HighPriceOrg =O00OO0O0OOO0OO000 .fHL [11 ]#line:2014
        O00OO0O0OOO0OO000 .LowPriceOrg =O00OO0O0OOO0OO000 .fHL [12 ]#line:2015
        O00OO0O0OOO0OO000 .TotAmt =O00OO0O0OOO0OO000 .fHL [13 ]#line:2016
        O00OO0O0OOO0OO000 .TotQty =O00OO0O0OOO0OO000 .fHL [14 ]#line:2017
        O00OO0O0OOO0OO000 .FirstDerivedBuyPriceOrg =O00OO0O0OOO0OO000 .fHL [35 ]#line:2018
        O00OO0O0OOO0OO000 .FirstDerivedBuyQty =O00OO0O0OOO0OO000 .fHL [36 ]#line:2019
        O00OO0O0OOO0OO000 .FirstDerivedSellPriceOrg =O00OO0O0OOO0OO000 .fHL [37 ]#line:2020
        O00OO0O0OOO0OO000 .FirstDerivedSellQty =O00OO0O0OOO0OO000 .fHL [38 ]#line:2021
        O00OO0O0OOO0OO000 .OpenPriceOrg =O00OO0O0OOO0OO000 .fHL [39 ]#line:2022
        O00OO0O0OOO0OO000 .TryMark_5Q =O00OO0O0OOO0OO000 .fHL [40 ]#line:2023
        O00OO0O0OOO0OO000 .ClosePrice =O00OO0O0OOO0OO000 .fHL [41 ]#line:2024
        O00OO0O0OOO0OO000 .SettlePrice =O00OO0O0OOO0OO000 .fHL [42 ]#line:2025
        O00OO0O0OOO0OO000 .OpenInterest =O00OO0O0OOO0OO000 .fHL [43 ]#line:2026
        if O00OO0O0OOO0OO000 .HasHL :#line:2027
            O00OO0O0OOO0OO000 .TopicTX =f"Quote/TWF/{O00OO0O0OOO0OO000.Market}/{O00OO0O0OOO0OO000.Symbol}/TX"#line:2028
            O00OO0O0OOO0OO000 .Topic5Q =f"Quote/TWF/{O00OO0O0OOO0OO000.Market}/{O00OO0O0OOO0OO000.Symbol}/5Q"#line:2029
            O00OO0O0OOO0OO000 .Topic5QTOT =f"Quote/TWF/{O00OO0O0OOO0OO000.Market}/{O00OO0O0OOO0OO000.Symbol}/5QTOT"#line:2030
            O00OO0O0OOO0OO000 .TopicBAS =f"Quote/TWF/{O00OO0O0OOO0OO000.Market}/{O00OO0O0OOO0OO000.Symbol}/BAS"#line:2031
        O00OO0O0OOO0OO000 .fDealPrice =O00OO0O0OOO0OO000 .TransPrice2Dec (O00OO0O0OOO0OO000 .DealPriceOrg )#line:2033
    def TransPrice2Dec (OOO00O00OO0O0O0OO ,O00000000O00O0OOO :str )->decimal :#line:2036
        try :#line:2037
            OO0OO00O00O00O000 =Decimal (O00000000O00O0OOO )#line:2038
            OO0OO00O00O00O000 =OO0OO00O00O00O000 *OOO00O00OO0O0O0OO .DECIMAL_LOCATOR_Dgt #line:2039
            return OO0OO00O00O00O000 #line:2040
        except Exception as OO0OOO0OOOOOOO0OO :#line:2041
            return 0 #line:2042
    def TransPrice2Str (OOOOOO00OOO00O00O ,OOO0O00OOO0OO0OOO :str )->str :#line:2044
        if OOOOOO00OOO00O00O .DECIMAL_LOCATOR_Dgt ==1 :#line:2045
            return OOO0O00OOO0OO0OOO #line:2046
        if OOO0O00OOO0OO0OOO =="0":#line:2047
            return ""#line:2048
        if len (OOO0O00OOO0OO0OOO )<OOOOOO00OOO00O00O .DECIMAL_LOCATOR_Org :#line:2049
            return OOO0O00OOO0OO0OOO #line:2050
        if not OOO0O00OOO0OO0OOO or OOO0O00OOO0OO0OOO .isspace ():#line:2051
            return ""#line:2052
        try :#line:2053
            OO000O0000O0OOO0O =len (OOO0O00OOO0OO0OOO )#line:2054
            return OOO0O00OOO0OO0OOO [:OO000O0000O0OOO0O -OOOOOO00OOO00O00O .DECIMAL_LOCATOR_Org ]+'.'+OOO0O00OOO0OO0OOO [OO000O0000O0OOO0O -OOOOOO00OOO00O00O .DECIMAL_LOCATOR_Org :]#line:2055
        except Exception as OO0OO00OOOOOOOOOO :#line:2056
            return ""#line:2057
    def TransToInt (OO0O000O00O0O0OOO ,OOOOO00O0O0OOO00O :str )->int :#line:2059
        try :#line:2060
            return int (OOOOO00O0O0OOO00O )#line:2061
        except Exception as O00O00OOOOO00OOOO :#line:2062
            pass #line:2064
        return 0 #line:2065
    def TransToDecimal (OOOOOOOOO0O00O00O ,OO00OO0O0O0OOOOOO :str )->decimal :#line:2067
        try :#line:2068
            return Decimal (OO00OO0O0O0OOOOOO )#line:2069
        except Exception as OOOO00O0000O0O00O :#line:2070
            print (f"Not a Decimal{OOOO00O0000O0O00O}")#line:2071
        return 0 #line:2072
    def __init__ (OO0OO0000OO000OOO )->None :#line:2075
        pass #line:2076
    def __str__ (OO00OO00O000000OO )->str :#line:2078
        return f"""Market:{OO00OO00O000000OO.Market} Symbol:{OO00OO00O000000OO.Symbol} TryMark:{OO00OO00O000000OO.TryMark} DealTime:{OO00OO00O000000OO.DealTime} DealSn:{OO00OO00O000000OO.DealSn}"""+"""Sn_5Q:{self.Sn_5Q} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} HighPriceOrg:{self.HighPriceOrg} LowPriceOrg:{self.LowPriceOrg}"""+"""TotQty:{self.TotQty} OpenPriceOrg:{self.OpenPriceOrg}"""#line:2081
class TFutQtTX :#line:2082
    DECIMAL_LOCATOR_Org :int =0 #line:2084
    """價格欄位小數位數"""#line:2085
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:2086
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""#line:2087
    fTX =[]#line:2088
    SystemTime :str #line:2090
    """系統時間(Epoch & Unix Timestamp(us))"""#line:2091
    DataTime :str #line:2092
    """資料時間(交易所給的)(EX:173547.32700)"""#line:2093
    DealSn :str #line:2094
    """成交序號"""#line:2095
    TryMark :str #line:2096
    """試撮註記(試撮=1, 非試撮=0)"""#line:2097
    DealTime :str #line:2098
    """撮合時間(成交)(EX:173547.32700)"""#line:2099
    DealShowMark :str #line:2100
    """成交資料揭示項目註記(*結算價此欄為空)"""#line:2101
    def Get_SystemTime (O0OO0O0O0OO0O000O )->int :#line:2102
        return O0OO0O0O0OO0O000O .TransToInt (O0OO0O0O0OO0O000O .fTX [1 ])#line:2103
    def Get_DealSn (OO000OO0OOOOOOOO0 )->int :#line:2105
        return OO000OO0OOOOOOOO0 .TransToInt (OO000OO0OOOOOOOO0 .fTX [3 ])#line:2106
    TotQty :str #line:2107
    """成交總量"""#line:2108
    def Get_TotQty2Dec (OOOO0OO00OOO0O00O )->decimal :#line:2110
        return OOOO0OO00OOO0O00O .TransToDecimal (OOOO0OO00OOO0O00O .fTX [7 ])#line:2111
    def Get_TotQty2Int (O000OO0O0OO0O0OOO )->int :#line:2113
        return O000OO0O0OO0O0OOO .TransToInt (O000OO0O0OO0O0OOO .fTX [7 ])#line:2114
    SumBuyDealCount :str #line:2115
    """累計買進成交筆數"""#line:2116
    def Get_SumBuyDealCount (O0000OO00OO0O0000 )->int :#line:2118
        return O0000OO00OO0O0000 .TransToInt (O0000OO00OO0O0000 .fTX [8 ])#line:2119
    SumSellDealCount :str #line:2120
    """累計賣出成交筆數"""#line:2121
    def Get_SumSellDealCount (OOO000OOO000000O0 )->int :#line:2123
        return OOO000OOO000000O0 .TransToInt (OOO000OOO000000O0 .fTX [9 ])#line:2124
    DealCount :str #line:2125
    """成交價量檔數"""#line:2126
    def Get_DealCount (O00O0OO0O0O0O000O )->int :#line:2128
        return O00O0OO0O0O0O000O .TransToInt (O00O0OO0O0O0O000O .fTX [11 ])#line:2129
    DealPriceOrg :str #line:2130
    """成交價"""#line:2131
    def Get_DealPrice2Dec (OOOO00OO0000OOO0O )->decimal :#line:2133
        return OOOO00OO0000OOO0O .TransPrice2Dec (OOOO00OO0000OOO0O .fTX [12 ])#line:2134
    def Get_DealPrice2Str (OO0O00000O0OO0O00 )->str :#line:2136
        return OO0O00000O0OO0O00 .TransPrice2Str (OO0O00000O0OO0O00 .fTX [12 ])#line:2137
    def Get_DealPrice2IdxVal (OOO00O000O0000O0O ,O0O000O0OO0OO0000 :int )->decimal :#line:2139
        return OOO00O000O0000O0O .TransPrice2Dec (OOO00O000O0000O0O .fTX [12 +(O0O000O0OO0OO0000 *2 )])#line:2140
    DealQty :str #line:2142
    """成交單量"""#line:2143
    def Get_DealQty2Dec (OOOO0000O00O00OOO )->decimal :#line:2145
        return OOOO0000O00O00OOO .TransToDecimal (OOOO0000O00O00OOO .fTX [13 ])#line:2146
    def Get_DealQty2Int (O00OOOOOO0OO0O00O )->int :#line:2148
        return O00OOOOOO0OO0O00O .TransToInt (O00OOOOOO0OO0O00O .fTX [13 ])#line:2149
    def Get_DealQty2IdxVal (OOO0OO0O000OOOO0O ,OO0O00000OOO0OO00 :int )->int :#line:2150
        return OOO0OO0O000OOOO0O .TransToInt (OOO0OO0O000OOOO0O .fTX [13 +(OO0O00000OOO0OO00 *2 )])#line:2151
    fDealPrice :decimal =0 #line:2155
    "成交價"#line:2156
    HighPrice :decimal =0 #line:2157
    "當日最高價"#line:2158
    LowPrice :decimal =0 #line:2159
    "當日最低價"#line:2160
    def CalcHightLowPrice (O0O0O00O00OO0O0OO ):#line:2162
        ""#line:2163
        try :#line:2164
            O0O0O00O00OO0O0OO .fDealPrice =O0O0O00O00OO0O0OO .Get_DealPrice ()#line:2165
            O0O0O00O00OO0O0OO .HighPrice =math .Max (O0O0O00O00OO0O0OO .fDealPrice ,O0O0O00O00OO0O0OO .HighPrice )#line:2166
            O0O0O00O00OO0O0OO .LowPrice =O0O0O00O00OO0O0OO .fDealPrice if O0O0O00O00OO0O0OO .LowPrice ==0 else math .Min (O0O0O00O00OO0O0OO .fDealPrice ,O0O0O00O00OO0O0OO .LowPrice )#line:2168
        except Exception as O0O00000O0000O0OO :#line:2169
            pass #line:2170
    def CalcHightLowPrice_None (O0O00OOOOOOO00OO0 ):#line:2172
        pass #line:2173
    fPROC_CalcHightLowPrice :callable =None #line:2175
    "PROC_CalcHightLowPrice"#line:2176
    def SetData (O0000000OO000O000 ):#line:2179
        O0000000OO000O000 .SystemTime =O0000000OO000O000 .fTX [1 ]#line:2180
        O0000000OO000O000 .DataTime =O0000000OO000O000 .fTX [2 ]#line:2181
        O0000000OO000O000 .DealSn =O0000000OO000O000 .fTX [3 ]#line:2182
        O0000000OO000O000 .TryMark ="1"if O0000000OO000O000 .fTX [4 ]is None else O0000000OO000O000 .fTX [4 ]#line:2183
        O0000000OO000O000 .DealTime =O0000000OO000O000 .fTX [5 ]#line:2184
        O0000000OO000O000 .DealShowMark =O0000000OO000O000 .fTX [6 ]#line:2185
        O0000000OO000O000 .TotQty =O0000000OO000O000 .fTX [7 ]#line:2186
        O0000000OO000O000 .SumBuyDealCount =O0000000OO000O000 .fTX [8 ]#line:2187
        O0000000OO000O000 .SumSellDealCount =O0000000OO000O000 .fTX [9 ]#line:2188
        O0000000OO000O000 .DealCount =O0000000OO000O000 .fTX [11 ]#line:2189
        O0000000OO000O000 .DealPriceOrg =O0000000OO000O000 .fTX [12 ]#line:2190
        O0000000OO000O000 .DealQty =O0000000OO000O000 .fTX [13 ]#line:2191
    def Handle_TXRcv (OO00000O0O000O00O ,O0000000OO000OOO0 :str ):#line:2193
        try :#line:2194
            OOO0000000OOOO0O0 :int =0 #line:2195
            OO0O00000O0OOOO00 :int =0 #line:2196
            OO0OOOO0OO00000O0 =O0000000OO000OOO0 .split ('|')#line:2197
            if OO0OOOO0OO00000O0 [4 ]==TSolQuoteFutSet .TryMark_No :#line:2199
                OO00000O0O000O00O .fPROC_HandleData =OO00000O0O000O00O .HandleData #line:2200
                if OO00000O0O000O00O .fTX ==None :#line:2202
                    OO00000O0O000O00O .fTX =OO0OOOO0OO00000O0 #line:2203
                    OO00000O0O000O00O .SetData ()#line:2204
                else :#line:2205
                    OO0O00000O0OOOO00 =OO00000O0O000O00O .TransToInt (OO0OOOO0OO00000O0 [3 ])#line:2206
                    OOO0000000OOOO0O0 =OO00000O0O000O00O .Get_DealSn ()#line:2207
                    if OO0O00000O0OOOO00 >OOO0000000OOOO0O0 :#line:2208
                        OO00000O0O000O00O .fTX =OO0OOOO0OO00000O0 #line:2209
                        OO00000O0O000O00O .SetData ()#line:2210
                OO00000O0O000O00O .fPROC_CalcHightLowPrice ()#line:2211
            else :#line:2212
                OO00000O0O000O00O .fPROC_HandleData =OO00000O0O000O00O .HandleData_TryMarket #line:2213
                OO00000O0O000O00O .fPROC_HandleData (O0000000OO000OOO0 )#line:2214
        except Exception as OO00OO0OOO000O0OO :#line:2216
            pass #line:2217
    def Handle_TX (OO00O0O00OO0OO00O ,OOO0O0OO0O00OOO00 :str ):#line:2219
        OO00O0O00OO0OO00O .fPROC_HandleData (OOO0O0OO0O00OOO00 )#line:2220
    def HandleData_TryMarket (OOOO0000O00O0OOO0 ,OO00O0000O0OO000O :str ):#line:2223
        ""#line:2224
        if OO00O0000O0OO000O .split ('|')[4 ]==TSolQuoteFutSet .TryMark_No :#line:2225
            OOOO0000O00O0OOO0 .fPROC_HandleData =OOOO0000O00O0OOO0 .HandleData #line:2226
            OOOO0000O00O0OOO0 .fPROC_HandleData (OO00O0000O0OO000O )#line:2227
        else :#line:2228
            OOOO0000O00O0OOO0 .fTX =OO00O0000O0OO000O .split ('|')#line:2229
            OOOO0000O00O0OOO0 .SetData ()#line:2230
    def HandleData (O0O0OO0OOO000OO0O ,OO0O0OOO0OOOO0000 :str ):#line:2232
        ""#line:2233
        O0O0OO0OOO000OO0O .fTX =OO0O0OOO0OOOO0000 .split ('|')#line:2234
        O0O0OO0OOO000OO0O .SetData ()#line:2235
        O0O0OO0OOO000OO0O .fPROC_CalcHightLowPrice ()#line:2236
    fPROC_HandleData :callable =None #line:2238
    "PROC_HandleData"#line:2239
    def TransPrice2Dec (O000O0OOOO00O0O0O ,O00O00000OO0000OO :str )->decimal :#line:2243
        try :#line:2244
            OO0OO00000OO000OO =Decimal (O00O00000OO0000OO )#line:2245
            OO0OO00000OO000OO =OO0OO00000OO000OO *O000O0OOOO00O0O0O .DECIMAL_LOCATOR_Dgt #line:2246
            return OO0OO00000OO000OO #line:2247
        except Exception as O0000000O0000OO00 :#line:2248
            return 0 #line:2249
    def TransPrice2Str (O0O0O00O0O0O00O00 ,OOO0O00OO00O0OOO0 :str )->str :#line:2251
        if O0O0O00O0O0O00O00 .DECIMAL_LOCATOR_Dgt ==1 :#line:2252
            return OOO0O00OO00O0OOO0 #line:2253
        if OOO0O00OO00O0OOO0 =="0":#line:2254
            return ""#line:2255
        if len (OOO0O00OO00O0OOO0 )<O0O0O00O0O0O00O00 .DECIMAL_LOCATOR_Org :#line:2256
            return OOO0O00OO00O0OOO0 #line:2257
        if not OOO0O00OO00O0OOO0 or OOO0O00OO00O0OOO0 .isspace ():#line:2258
            return ""#line:2259
        try :#line:2260
            O0000OOOO000OOOO0 =len (OOO0O00OO00O0OOO0 )#line:2261
            return OOO0O00OO00O0OOO0 [:O0000OOOO000OOOO0 -O0O0O00O0O0O00O00 .DECIMAL_LOCATOR_Org ]+'.'+OOO0O00OO00O0OOO0 [O0000OOOO000OOOO0 -O0O0O00O0O0O00O00 .DECIMAL_LOCATOR_Org :]#line:2262
        except Exception as O0OO0OO00000O00O0 :#line:2263
            return ""#line:2264
    def TransToInt (OO0O0O00000O00OOO ,O00OOOO0OOOO0O0O0 :str )->int :#line:2266
        try :#line:2267
            return int (O00OOOO0OOOO0O0O0 )#line:2268
        except Exception as O0O00OOO0OOO00000 :#line:2269
            pass #line:2271
        return 0 #line:2272
    def TransToDecimal (O0OO0OO0OO0O000OO ,OOO00OO000OO0OO00 :str )->decimal :#line:2274
        try :#line:2275
            return Decimal (OOO00OO000OO0OO00 )#line:2276
        except Exception as OOOO0OOO0OOO0O0O0 :#line:2277
            print (f"Not a Decimal{OOOO0OOO0OOO0O0O0}")#line:2278
        return 0 #line:2279
    def __init__ (O000000000OO0000O ,OOOOO00OOO00OO000 :bool )->None :#line:2282
        O000000000OO0000O .fPROC_CalcHightLowPrice =O000000000OO0000O .CalcHightLowPrice_None #line:2284
        if OOOOO00OOO00OO000 :#line:2285
            O000000000OO0000O .fPROC_CalcHightLowPrice =O000000000OO0000O .CalcHightLowPrice #line:2286
        O000000000OO0000O .fPROC_HandleData =O000000000OO0000O .HandleData_TryMarket #line:2288
    def __str__ (OOO00000000000000 ):#line:2290
        return f"""DataTime:{OOO00000000000000.DataTime} TryMark:{OOO00000000000000.TryMark} DealTime:{OOO00000000000000.DealTime} DealSn:{OOO00000000000000.DealSn}"""+"""TotQty:{self.TotQty} SumBuyDealCount:{self.SumBuyDealCount} SumSellDealCount:{self.SumSellDealCount}"""+"""DealCount:{self.DealCount} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} fDealPrice:{self.fDealPrice}"""+"""HighPrice:{self.HighPrice} LowPrice:{self.LowPrice} \n"""#line:2294
class TFutQt5Q :#line:2295
    DECIMAL_LOCATOR_Org :int =0 #line:2297
    "價格欄位小數位數"#line:2298
    DECIMAL_LOCATOR_Dgt :decimal =1 #line:2299
    "價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"#line:2300
    f5Q =[]#line:2301
    SystemTime :str #line:2303
    """系統時間(Epoch & Unix Timestamp(us))"""#line:2304
    DataTime :str #line:2305
    "資料時間(交易所給的)(EX:173547.32700)"#line:2306
    Sn :str #line:2307
    "序號"#line:2308
    def Get_SystemTime (OOOO00O000O0OOOOO )->int :#line:2309
        return OOOO00O000O0OOOOO .TransToInt (OOOO00O000O0OOOOO .f5Q [1 ])#line:2310
    def Get_Sn (OO000O000O0O0O00O )->int :#line:2311
        return OO000O000O0O0O00O .TransToInt (OO000O000O0O0O00O .f5Q [3 ])#line:2312
    TryMark :str #line:2313
    "試撮註記(試撮=1, 非試撮=0)"#line:2314
    FirstDerivedBuyPriceOrg :str #line:2316
    "衍生委託單第一檔買進價格"#line:2317
    def Get_FirstDerivedBuyPrice (OOOO00O0OOO0OOOO0 ):#line:2318
        return OOOO00O0OOO0OOOO0 .TransPrice2Dec (OOOO00O0OOO0OOOO0 .f5Q [25 ])#line:2319
    FirstDerivedBuyQty :str #line:2320
    "衍生委託單第一檔買進價格數量"#line:2321
    FirstDerivedSellPriceOrg :str #line:2322
    "衍生委託單第一檔賣出價格數量"#line:2323
    def Get_FirstDerivedSellPrice (OOO0O00OOO000O000 ):#line:2324
        return OOO0O00OOO000O000 .TransPrice2Str (OOO0O00OOO000O000 .f5Q [27 ])#line:2325
    FirstDerivedSellQty :str #line:2326
    "衍生委託單第一檔賣出價格數量"#line:2327
    def Handle_5Q (O00O000OO0OOOOOOO ,O000OO00OO0O00000 :str ):#line:2328
        O00O000OO0OOOOOOO .fPROC_HandleData (O000OO00OO0O00000 )#line:2329
    def HandleData_TryMarket (OOO00OO0OO00OO00O ,OOOO00O000O000O00 :str ):#line:2332
        ""#line:2333
        if OOOO00O000O000O00 .split ('|')[4 ]==TSolQuoteFutSet .TryMark_No :#line:2334
            OOO00OO0OO00OO00O .fPROC_HandleData =OOO00OO0OO00OO00O .HandleData #line:2335
            OOO00OO0OO00OO00O .fPROC_HandleData (OOOO00O000O000O00 )#line:2336
        else :#line:2337
            OOO00OO0OO00OO00O .f5Q =OOOO00O000O000O00 .split ('|')#line:2338
            OOO00OO0OO00OO00O .SetData ()#line:2339
    def HandleData (OO0OOO00OO000OOOO ,OO0000OO0000OOO0O :str ):#line:2341
        ""#line:2342
        OO0OOO00OO000OOOO .f5Q =OO0000OO0000OOO0O .split ('|')#line:2343
        OO0OOO00OO000OOOO .SetData ()#line:2344
    def SetData (OO0OO00O0O0000O00 ):#line:2346
        OO0OO00O0O0000O00 .DataTime =OO0OO00O0O0000O00 .f5Q [2 ]#line:2347
        OO0OO00O0O0000O00 .Sn =OO0OO00O0O0000O00 .f5Q [3 ]#line:2348
        OO0OO00O0O0000O00 .TryMark ="1"if OO0OO00O0O0000O00 .f5Q is None else OO0OO00O0O0000O00 .f5Q [4 ]#line:2349
        OO0OO00O0O0000O00 .FirstDerivedBuyPriceOrg =OO0OO00O0O0000O00 .f5Q [25 ]#line:2350
        OO0OO00O0O0000O00 .FirstDerivedBuyQty =OO0OO00O0O0000O00 .f5Q [26 ]#line:2351
        OO0OO00O0O0000O00 .FirstDerivedSellPriceOrg =OO0OO00O0O0000O00 .f5Q [27 ]#line:2352
        OO0OO00O0O0000O00 .FirstDerivedSellQty =OO0OO00O0O0000O00 .f5Q [28 ]#line:2353
    fPROC_HandleData :callable =None #line:2355
    "PROC_HandleData"#line:2356
    fAryB5Q_P =[5 ,7 ,9 ,11 ,13 ]#line:2360
    "買五檔價在字串中的位置"#line:2361
    fAryB5Q_Q =[6 ,8 ,10 ,12 ,14 ]#line:2362
    "買五檔價在字串中的位置"#line:2363
    fB5QCount :int =5 #line:2364
    "買5檔的檔數"#line:2365
    def B5Q_POrg (OO00000O000O0OO00 ,O000OO00OO00O0O00 :int )->str :#line:2367
        ""#line:2368
        if O000OO00OO00O0O00 >OO00000O000O0OO00 .fB5QCount :#line:2369
            return ""#line:2370
        elif OO00000O000O0OO00 .f5Q is None :#line:2371
            return ""#line:2372
        else :#line:2373
            return OO00000O000O0OO00 .f5Q [OO00000O000O0OO00 .fAryB5Q_P [O000OO00OO00O0O00 -1 ]]#line:2374
    def Get_B5Q_P2Dec (O0000OO00O0O00O00 ,OOOO00O000OO00O0O :int )->decimal :#line:2376
        ""#line:2377
        if OOOO00O000OO00O0O >O0000OO00O0O00O00 .fB5QCount :#line:2378
            return 0 #line:2379
        elif O0000OO00O0O00O00 .f5Q is None :#line:2380
            return 0 #line:2381
        else :#line:2382
            return O0000OO00O0O00O00 .TransPrice2Dec (O0000OO00O0O00O00 .f5Q [O0000OO00O0O00O00 .fAryB5Q_P [OOOO00O000OO00O0O -1 ]])#line:2383
    def Get_B5Q_P2Str (OO0OOOOOO00OOO0OO ,O0000OOOOOO0O0O00 :int )->str :#line:2385
        ""#line:2386
        if O0000OOOOOO0O0O00 >OO0OOOOOO00OOO0OO .fB5QCount :#line:2387
            return ""#line:2388
        elif OO0OOOOOO00OOO0OO .f5Q is None :#line:2389
            return ""#line:2390
        else :#line:2391
            return OO0OOOOOO00OOO0OO .TransPrice2Str (OO0OOOOOO00OOO0OO .f5Q [OO0OOOOOO00OOO0OO .fAryB5Q_P [O0000OOOOOO0O0O00 -1 ]])#line:2392
    def B5Q_QOrg (OO0O00000O0O0000O ,O0O0OOOO0O0O0O00O :int )->str :#line:2394
        ""#line:2395
        if O0O0OOOO0O0O0O00O >OO0O00000O0O0000O .fB5QCount :#line:2397
            return ""#line:2398
        elif OO0O00000O0O0000O .f5Q is None :#line:2399
            return ""#line:2400
        else :#line:2401
            return OO0O00000O0O0000O .f5Q [OO0O00000O0O0000O .fAryB5Q_Q [O0O0OOOO0O0O0O00O -1 ]]#line:2402
    def Get_B5Q_Q (OOOO00O00O0O0O000 ,O0O00O0O000O00OO0 :int )->int :#line:2404
        ""#line:2405
        if O0O00O0O000O00OO0 >OOOO00O00O0O0O000 .fB5QCount :#line:2406
            return 0 #line:2407
        elif OOOO00O00O0O0O000 .f5Q is None :#line:2408
            return 0 #line:2409
        else :#line:2410
            return OOOO00O00O0O0O000 .TransToInt (OOOO00O00O0O0O000 .f5Q [OOOO00O00O0O0O000 .fAryB5Q_Q [O0O00O0O000O00OO0 -1 ]])#line:2411
    fAryS5Q_P =[15 ,17 ,19 ,21 ,23 ]#line:2416
    "買五檔價在字串中的位置"#line:2417
    fAryS5Q_Q =[16 ,18 ,20 ,22 ,24 ]#line:2418
    "買五檔價在字串中的位置"#line:2419
    fS5QCount :int =5 #line:2420
    "賣5檔的檔數"#line:2421
    def S5Q_POrg (OO000O00O00OOOOOO ,OO0OO0OOO0OOOO0OO :int )->str :#line:2423
        ""#line:2424
        if OO0OO0OOO0OOOO0OO >OO000O00O00OOOOOO .fS5QCount :#line:2425
            return ""#line:2426
        elif OO000O00O00OOOOOO .f5Q is None :#line:2427
            return ""#line:2428
        else :#line:2429
            return OO000O00O00OOOOOO .f5Q [OO000O00O00OOOOOO .fAryS5Q_P [OO0OO0OOO0OOOO0OO -1 ]]#line:2430
    def Get_S5Q_P2Dec (O0OOO0OOO000OO00O ,O0OO0000000OO00O0 :int )->decimal :#line:2432
        ""#line:2433
        if O0OO0000000OO00O0 >O0OOO0OOO000OO00O .fS5QCount :#line:2434
            return 0 #line:2435
        elif O0OOO0OOO000OO00O .f5Q is None :#line:2436
            return 0 #line:2437
        else :#line:2438
            return O0OOO0OOO000OO00O .TransPrice2Dec (O0OOO0OOO000OO00O .f5Q [O0OOO0OOO000OO00O .fAryS5Q_P [O0OO0000000OO00O0 -1 ]])#line:2439
    def Get_S5Q_P2Str (OOO0O00000OOOOO0O ,OOO0O00O00OO00O0O :int )->str :#line:2441
        ""#line:2442
        if OOO0O00O00OO00O0O >OOO0O00000OOOOO0O .fS5QCount :#line:2443
            return ""#line:2444
        elif OOO0O00000OOOOO0O .f5Q is None :#line:2445
            return ""#line:2446
        else :#line:2447
            return OOO0O00000OOOOO0O .TransPrice2Str (OOO0O00000OOOOO0O .f5Q [OOO0O00000OOOOO0O .fAryS5Q_P [OOO0O00O00OO00O0O -1 ]])#line:2448
    def S5Q_QOrg (O00O00OOO0O000000 ,O0000OO0O00O0OO00 :int )->str :#line:2450
        ""#line:2451
        if O0000OO0O00O0OO00 >O00O00OOO0O000000 .fS5QCount :#line:2452
            return ""#line:2453
        elif O00O00OOO0O000000 .f5Q is None :#line:2454
            return ""#line:2455
        else :#line:2456
            return O00O00OOO0O000000 .f5Q [O00O00OOO0O000000 .fAryS5Q_Q [O0000OO0O00O0OO00 -1 ]]#line:2457
    def Get_S5Q_Q (OOO0000OOO0000OOO ,O00OO0OOOOOO0O00O :int )->int :#line:2459
        ""#line:2460
        if O00OO0OOOOOO0O00O >OOO0000OOO0000OOO .fS5QCount :#line:2461
            return 0 #line:2462
        elif OOO0000OOO0000OOO .f5Q is None :#line:2463
            return 0 #line:2464
        else :#line:2465
            return OOO0000OOO0000OOO .TransToInt (OOO0000OOO0000OOO .f5Q [OOO0000OOO0000OOO .fAryS5Q_Q [O00OO0OOOOOO0O00O -1 ]])#line:2466
    def TransPrice2Dec (OOOO0O000OO000000 ,O00OOOOOO00OOO000 :str )->decimal :#line:2471
        try :#line:2472
            OOOOO0O0000O0O00O =Decimal (O00OOOOOO00OOO000 )#line:2473
            OOOOO0O0000O0O00O =OOOOO0O0000O0O00O *OOOO0O000OO000000 .DECIMAL_LOCATOR_Dgt #line:2474
            return OOOOO0O0000O0O00O #line:2475
        except Exception as OOOO0OO0OO0000OOO :#line:2476
            return 0 #line:2477
    def TransPrice2Str (O00OOOOOOO00O0O00 ,O0O0OOOO00OO00OO0 :str )->str :#line:2479
        if O00OOOOOOO00O0O00 .DECIMAL_LOCATOR_Dgt ==1 :#line:2480
            return O0O0OOOO00OO00OO0 #line:2481
        if O0O0OOOO00OO00OO0 =="0":#line:2482
            return ""#line:2483
        if len (O0O0OOOO00OO00OO0 )<O00OOOOOOO00O0O00 .DECIMAL_LOCATOR_Org :#line:2484
            return O0O0OOOO00OO00OO0 #line:2485
        if not O0O0OOOO00OO00OO0 or O0O0OOOO00OO00OO0 .isspace ():#line:2486
            return ""#line:2487
        try :#line:2488
            OO00O0O0OOO00O00O =len (O0O0OOOO00OO00OO0 )#line:2489
            return O0O0OOOO00OO00OO0 [:OO00O0O0OOO00O00O -O00OOOOOOO00O0O00 .DECIMAL_LOCATOR_Org ]+'.'+O0O0OOOO00OO00OO0 [OO00O0O0OOO00O00O -O00OOOOOOO00O0O00 .DECIMAL_LOCATOR_Org :]#line:2490
        except Exception as OOO00OO00OOO000OO :#line:2491
            return ""#line:2492
    def TransToInt (OO000OOO00OOOO0OO ,OO00O0O0000OOO000 :str )->int :#line:2494
        try :#line:2495
            return int (OO00O0O0000OOO000 )#line:2496
        except Exception as O00OO00000O0O00O0 :#line:2497
            pass #line:2499
        return 0 #line:2500
    def TransToDecimal (OOO00OOOOO00O00OO ,O0000OO000000OO00 :str )->decimal :#line:2502
        try :#line:2503
            return Decimal (O0000OO000000OO00 )#line:2504
        except Exception as OO0OOO00OOO000000 :#line:2505
            print (f"Not a Decimal{OO0OOO00OOO000000}")#line:2506
        return 0 #line:2507
    def __init__ (OO000000O00000OO0 )->None :#line:2510
        OO000000O00000OO0 .fPROC_HandleData =OO000000O00000OO0 .HandleData_TryMarket #line:2512
    def __str__ (OO00OOO0000O00000 ):#line:2514
        return f"""DataTime:{OO00OOO0000O00000.DataTime} Sn:{OO00OOO0000O00000.Sn} TryMark:{OO00OOO0000O00000.TryMark} f5Q:{OO00OOO0000O00000.f5Q}"""#line:2515
class TFutQt5QTOT :#line:2516
    f5QTOT =[]#line:2517
    DataTime :str #line:2519
    "資料時間(交易所給的)(EX:173547.32700)"#line:2520
    Sn :str #line:2521
    "序號"#line:2522
    def Get_Sn (OO00O0000OO0OO00O )->int :#line:2524
        return OO00O0000OO0OO00O .TransToInt (OO00O0000OO0OO00O .f5QTOT [3 ])#line:2525
    SumBuyOrderCount :str #line:2526
    "買進累計委託筆數"#line:2527
    def Get_SumBuyOrderCount (O0OOOOOOO0O0OOO0O )->int :#line:2529
        return O0OOOOOOO0O0OOO0O .TransToInt (O0OOOOOOO0O0OOO0O .f5QTOT [4 ])#line:2530
    SumBuyOrderQty :str #line:2531
    "買進累計委託合約數"#line:2532
    def Get_SumBuyOrderQty (OOO0OO0OOOO0OO00O )->int :#line:2534
        return OOO0OO0OOOO0OO00O .TransToInt (OOO0OO0OOOO0OO00O .f5QTOT [5 ])#line:2535
    SumSellOrderCount :str #line:2536
    "賣出累計委託筆數"#line:2537
    def Get_SumSellOrderCount (O00000O00OOO00000 )->int :#line:2539
        return O00000O00OOO00000 .TransToInt (O00000O00OOO00000 .f5QTOT [6 ])#line:2540
    SumSellOrderQty :str #line:2541
    "賣出累計委託合約數"#line:2542
    def Get_SumSellOrderQty (OO000000OOOOO0000 )->int :#line:2544
        return OO000000OOOOO0000 .TransToInt (OO000000OOOOO0000 .f5QTOT [7 ])#line:2545
    def Handle_5QTOT (OOOOO0OOO0OO00OOO ,OOOOO000000OOOOOO :str ):#line:2547
        OOOOO0OOO0OO00OOO .f5QTOT =OOOOO000000OOOOOO .split ('|')#line:2548
        OOOOO0OOO0OO00OOO .DataTime =OOOOO0OOO0OO00OOO .f5QTOT [2 ]#line:2550
        OOOOO0OOO0OO00OOO .Sn =OOOOO0OOO0OO00OOO .f5QTOT [3 ]#line:2551
        OOOOO0OOO0OO00OOO .SumBuyOrderCount =OOOOO0OOO0OO00OOO .f5QTOT [4 ]#line:2552
        OOOOO0OOO0OO00OOO .SumBuyOrderQty =OOOOO0OOO0OO00OOO .f5QTOT [5 ]#line:2553
        OOOOO0OOO0OO00OOO .SumSellOrderCount =OOOOO0OOO0OO00OOO .f5QTOT [6 ]#line:2554
        OOOOO0OOO0OO00OOO .SumSellOrderQty =OOOOO0OOO0OO00OOO .f5QTOT [7 ]#line:2555
    def TransToInt (OOO0O0O0O0O00O0O0 ,O0O000OO0O0O000OO :str )->int :#line:2558
        try :#line:2559
            return int (O0O000OO0O0O000OO )#line:2560
        except Exception as OO000OO000OO0000O :#line:2561
            return 0 #line:2562
    def TransToDecimal (O000O0O0OOO0000OO ,O0OOO00OOOO00O0O0 :str )->decimal :#line:2564
        try :#line:2565
            return Decimal (O0OOO00OOOO00O0O0 )#line:2566
        except Exception as O0OO0000OOOOOOOO0 :#line:2567
            return 0 #line:2568
    def __init__ (O0OO0OO0OO0O000O0 )->None :#line:2571
        pass #line:2572
    def __str__ (OO00OO00O0O00O00O )->str :#line:2574
        return f"""DataTime:{OO00OO00O0O00O00O.DataTime} Sn:{OO00OO00O0O00O00O.Sn} SumBuyOrderCount:{OO00OO00O0O00O00O.SumBuyOrderCount} SumBuyOrderQty:{OO00OO00O0O00O00O.SumBuyOrderQty}"""+"""SumSellOrderCount:{self.SumSellOrderCount} SumSellOrderQty:{self.SumSellOrderQty}"""#line:2576
class TFutQtIDX :#line:2577
    fIsGotDgtVal :bool =False #line:2578
    fDECIMAL_LOCATOR_Org :int =0 #line:2579
    "指數小數位數"#line:2580
    fDECIMAL_LOCATOR_Dgt :decimal =1 #line:2581
    "指數小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"#line:2582
    fIdx =[]#line:2583
    DataTime :str #line:2586
    "資料時間(交易所給的)(EX:173547.32700)"#line:2587
    Sn :str #line:2588
    "序號"#line:2589
    def Get_Sn (OO0O000O00O0OOOOO )->int :#line:2591
        return OO0O000O00O0OOOOO .TransToInt (OO0O000O00O0OOOOO .fIdx [3 ])#line:2592
    TryMark :str #line:2593
    "試撮註記(試撮=1, 非試撮=0)"#line:2594
    DealTime :str #line:2595
    "指數編篡時間(EX:173547.32700)"#line:2596
    IdxDgtOrg :str #line:2597
    "指數小數位數"#line:2598
    def Get_IdxDgtOrg (OO00O0000O000O00O )->int :#line:2600
        return OO00O0000O000O00O .TransToInt (OO00O0000O000O00O .fIdx [7 ])#line:2601
    IdxValueOrg :str #line:2602
    "指數"#line:2603
    def Get_IdxValue2Dec (O00OOO00000000O0O )->decimal :#line:2605
        return O00OOO00000000O0O .TransPrice2Dec (O00OOO00000000O0O .fIdx [6 ])#line:2606
    def Get_IdxValue2Str (OOO0OOO0O0O0OOO0O )->str :#line:2608
        return OOO0OOO0O0O0OOO0O .TransPrice2Str (OOO0OOO0O0O0OOO0O .fIdx [6 ])#line:2609
    HighIdxValueOrg :str #line:2610
    "當日最高指數"#line:2611
    def Get_HighIdxValue2Dec (O00OOO0O0OOOOOO0O )->decimal :#line:2613
        return O00OOO0O0OOOOOO0O .TransPrice2Dec (O00OOO0O0OOOOOO0O .fIdx [8 ])#line:2614
    def Get_HighIdxValue2Str (OO00OOOO0O0OOO000 )->str :#line:2616
        return OO00OOOO0O0OOO000 .TransPrice2Str (OO00OOOO0O0OOO000 .fIdx [8 ])#line:2617
    LowIdxValueOrg :str #line:2619
    "當日最低指數"#line:2620
    def Get_LowIdxValue2Dec (OO00O00OOO0OOO0O0 )->decimal :#line:2622
        return OO00O00OOO0OOO0O0 .TransPrice2Dec (OO00O00OOO0OOO0O0 .fIdx [9 ])#line:2623
    def Get_LowIdxValue2Str (OOO0O000O0OO0OOOO )->str :#line:2625
        return OOO0O000O0OO0OOOO .TransPrice2Str (OOO0O000O0OO0OOOO .fIdx [9 ])#line:2626
    OpenIdxValueOrg :str #line:2628
    "開盤指數"#line:2629
    def Get_OpenIdxValue2Dec (O00OOO0OO0OO00O00 )->decimal :#line:2631
        return O00OOO0OO0OO00O00 .TransPrice2Dec (O00OOO0OO0OO00O00 .fIdx [10 ])#line:2632
    def Get_OpenIdxValue2Str (OO0O00O00OO000O0O )->str :#line:2634
        return OO0O00O00OO000O0O .TransPrice2Str (OO0O00O00OO000O0O .fIdx [10 ])#line:2635
    def Handle_IDX (OO00OOOOOOOOOOO0O ,O00OOO000OO00O000 :str ):#line:2638
        OO00OOOOOOOOOOO0O .fIdx =O00OOO000OO00O000 .split ('|')#line:2639
        OO00OOOOOOOOOOO0O .DataTime =OO00OOOOOOOOOOO0O .fIdx [2 ]#line:2641
        OO00OOOOOOOOOOO0O .Sn =OO00OOOOOOOOOOO0O .fIdx [3 ]#line:2642
        OO00OOOOOOOOOOO0O .TryMark =OO00OOOOOOOOOOO0O .fIdx [4 ]#line:2643
        OO00OOOOOOOOOOO0O .DealTime =OO00OOOOOOOOOOO0O .fIdx [5 ]#line:2644
        OO00OOOOOOOOOOO0O .IdxValueOrg =OO00OOOOOOOOOOO0O .fIdx [6 ]#line:2645
        OO00OOOOOOOOOOO0O .IdxDgtOrg =OO00OOOOOOOOOOO0O .fIdx [7 ]#line:2646
        OO00OOOOOOOOOOO0O .HighIdxValueOrg =OO00OOOOOOOOOOO0O .fIdx [8 ]#line:2647
        OO00OOOOOOOOOOO0O .LowIdxValueOrg =OO00OOOOOOOOOOO0O .fIdx [9 ]#line:2648
        OO00OOOOOOOOOOO0O .OpenIdxValueOrg =OO00OOOOOOOOOOO0O .fIdx [10 ]#line:2649
        if OO00OOOOOOOOOOO0O .fIsGotDgtVal ==False :#line:2652
            OO00OOOOOOOOOOO0O .fDECIMAL_LOCATOR_Org =OO00OOOOOOOOOOO0O .Get_IdxDgtOrg ()#line:2654
            if OO00OOOOOOOOOOO0O .fDECIMAL_LOCATOR_Org ==0 :#line:2655
                OO00OOOOOOOOOOO0O .fDECIMAL_LOCATOR_Dgt =1 #line:2656
            else :#line:2657
                OO00OOOOOOOOOOO0O .fDECIMAL_LOCATOR_Dgt =1 /Decimal ("1".ljust (OO00OOOOOOOOOOO0O .fDECIMAL_LOCATOR_Dgt +1 ,'0'))#line:2659
            OO00OOOOOOOOOOO0O .fIsGotDgtVal =True #line:2661
    def TransPrice2Dec (O0000O0O0O00OOOO0 ,OOOO00O0O00OOOO0O :str )->decimal :#line:2664
        try :#line:2665
            OOO00O0OOOO000000 =Decimal (OOOO00O0O00OOOO0O )#line:2666
            OOO00O0OOOO000000 =OOO00O0OOOO000000 *O0000O0O0O00OOOO0 .DECIMAL_LOCATOR_Dgt #line:2667
            return OOO00O0OOOO000000 #line:2668
        except Exception as OO00OO0OOO00O0O0O :#line:2669
            print (f"Not a Decimal{OO00OO0OOO00O0O0O}")#line:2670
            return 0 #line:2671
    def TransPrice2Str (OO0O00O0OOOOO0OOO ,O0O00O0000000OOOO :str )->str :#line:2673
        if OO0O00O0OOOOO0OOO .DECIMAL_LOCATOR_Dgt ==1 :#line:2674
            return O0O00O0000000OOOO #line:2675
        if O0O00O0000000OOOO =="0":#line:2676
            return ""#line:2677
        if len (O0O00O0000000OOOO )<OO0O00O0OOOOO0OOO .DECIMAL_LOCATOR_Org :#line:2678
            return O0O00O0000000OOOO #line:2679
        if not O0O00O0000000OOOO or O0O00O0000000OOOO .isspace ():#line:2680
            return ""#line:2681
        try :#line:2682
            OOOO000000000000O =len (O0O00O0000000OOOO )#line:2683
            return O0O00O0000000OOOO [:OOOO000000000000O -OO0O00O0OOOOO0OOO .DECIMAL_LOCATOR_Org ]+'.'+O0O00O0000000OOOO [OOOO000000000000O -OO0O00O0OOOOO0OOO .DECIMAL_LOCATOR_Org :]#line:2684
        except Exception as O0OO0O00OO0000OOO :#line:2685
            return ""#line:2686
    def TransToInt (OO0O00O000OOOO00O ,O0O00O0000O00O0OO :str )->int :#line:2688
        try :#line:2689
            return int (O0O00O0000O00O0OO )#line:2690
        except Exception as OO000OO00O000O00O :#line:2691
            pass #line:2693
        return 0 #line:2694
    def TransToDecimal (OO0O0O0OO0O0O0OOO ,O0OOO0000O000O0O0 :str )->decimal :#line:2696
        try :#line:2697
            return Decimal (O0OOO0000O000O0O0 )#line:2698
        except Exception as O0O0000000OOO00O0 :#line:2699
            print (f"Not a Decimal{O0O0000000OOO00O0}")#line:2700
        return 0 #line:2701
    def __init__ (O0OOO0O000OO0O0OO )->None :#line:2704
        pass #line:2705
    def __str__ (O000OO00O0O0000O0 )->str :#line:2707
        return f"""DataTime:{O000OO00O0O0000O0.DataTime} Sn:{O000OO00O0O0000O0.Sn} TryMark:{O000OO00O0O0000O0.TryMark} DealTime:{O000OO00O0O0000O0.DealTime} IdxValueOrg:{O000OO00O0O0000O0.IdxValueOrg}"""+"""IdxDgtOrg:{self.IdxDgtOrg} HighIdxValueOrg:{self.HighIdxValueOrg} LowIdxValueOrg:{self.LowIdxValueOrg} OpenIdxValueOrg:{self.OpenIdxValueOrg}"""#line:2709
class TFutQuoteData :#line:2710
    SolIce =""#line:2711
    ProdKind :TFutProdKind =TFutProdKind .pkNone #line:2712
    BAS :TFutQtBase =None #line:2713
    HL :TFutQtHL =None #line:2714
    QtTX :TFutQtTX =None #line:2715
    Qt5Q :TFutQt5Q =None #line:2716
    Qt5QTOT :TFutQt5QTOT =None #line:2717
    QtIDX :TFutQtIDX =None #line:2718
    def __init__ (O000000O0O0OO00O0 ,OO00O0O0O000000O0 :TFutProdKind ,O0OOOOO0OOO00O000 :str ,O000O0OOO0000O0O0 :bool ):#line:2720
        ""#line:2721
        O000000O0O0OO00O0 .SolIce =O0OOOOO0OOO00O000 #line:2723
        O000000O0O0OO00O0 .ProdKind =OO00O0O0O000000O0 #line:2724
        O000000O0O0OO00O0 ._lock =Lock ()#line:2725
        O000000O0O0OO00O0 .UpdateBAS =True #line:2726
        O000000O0O0OO00O0 .UpdateHL =False #line:2727
        if OO00O0O0O000000O0 ==TFutProdKind .pkNormal :#line:2728
            O000000O0O0OO00O0 .BAS =TFutQtBase ()#line:2729
            O000000O0O0OO00O0 .HL =TFutQtHL ()#line:2730
            O000000O0O0OO00O0 .QtTX =TFutQtTX (O000O0OOO0000O0O0 )#line:2731
            O000000O0O0OO00O0 .Qt5Q =TFutQt5Q ()#line:2732
            O000000O0O0OO00O0 .Qt5QTOT =TFutQt5QTOT ()#line:2733
        elif OO00O0O0O000000O0 ==TFutProdKind .pkIndex :#line:2735
            O000000O0O0OO00O0 .QtIDX =TFutQtIDX ()#line:2736
    def SetDataInit (OOOO0OO000O0OO00O ,type :str =""):#line:2738
        ""#line:2739
        if OOOO0OO000O0OO00O .ProdKind ==TFutProdKind .pkNormal :#line:2740
            if type =="BAS"or type =="":#line:2741
                OOOO0OO000O0OO00O .HL .DECIMAL_LOCATOR_Dgt =OOOO0OO000O0OO00O .BAS .DECIMAL_LOCATOR_Dgt #line:2742
                OOOO0OO000O0OO00O .QtTX .DECIMAL_LOCATOR_Dgt =OOOO0OO000O0OO00O .BAS .DECIMAL_LOCATOR_Dgt #line:2743
                OOOO0OO000O0OO00O .Qt5Q .DECIMAL_LOCATOR_Dgt =OOOO0OO000O0OO00O .BAS .DECIMAL_LOCATOR_Dgt #line:2744
                OOOO0OO000O0OO00O .HL .DECIMAL_LOCATOR_Org =OOOO0OO000O0OO00O .BAS .DECIMAL_LOCATOR_Org #line:2746
                OOOO0OO000O0OO00O .QtTX .DECIMAL_LOCATOR_Org =OOOO0OO000O0OO00O .BAS .DECIMAL_LOCATOR_Org #line:2747
                OOOO0OO000O0OO00O .Qt5Q .DECIMAL_LOCATOR_Org =OOOO0OO000O0OO00O .BAS .DECIMAL_LOCATOR_Org #line:2748
            if type =="HL"or type =="":#line:2749
                OOOO0OO000O0OO00O .QtTX .HighPrice =OOOO0OO000O0OO00O .HL .Get_HighPrice2Dec ()#line:2750
                OOOO0OO000O0OO00O .QtTX .LowPrice =OOOO0OO000O0OO00O .HL .Get_LowPrice2Dec ()#line:2751
class TObjFutQuoteMap (UserDict ):#line:2753
    ""#line:2755
    DefProc_TX :callable =None #line:2759
    DefProc_5Q :callable =None #line:2760
    DefProc_Idx :callable =None #line:2761
    DefProc_5QTOT :callable =None #line:2762
    DefProc_BAS :callable =None #line:2763
    def __init__ (OO00000000000O0O0 ,mapping =None ,**OO0O0OOOOOOO0OO0O ):#line:2764
        if mapping is not None :#line:2765
            mapping ={str (O00OO00O00O000O00 ).upper ():OOO0OOO0O00O0OO0O for O00OO00O00O000O00 ,OOO0OOO0O00O0OO0O in mapping .items ()}#line:2768
        else :#line:2769
            mapping ={}#line:2770
        if OO0O0OOOOOOO0OO0O :#line:2771
            mapping .update ({str (OO0O0OO000O0O0O0O ).upper ():OO0O0O00O000O00OO for OO0O0OO000O0O0O0O ,OO0O0O00O000O00OO in OO0O0OOOOOOO0OO0O .items ()})#line:2774
        OO00000000000O0O0 .MapQtProc ={}#line:2776
        "各商品拆解行情proc(EX:TXF的TX與5Q, 行情拆解,是不同Proc)"#line:2777
        super ().__init__ (mapping )#line:2778
    def __setitem__ (O0OOOOOO000OO0OOO ,OO00OO0O00OO0O000 ,OOOOOOO00O0O0OOO0 ):#line:2780
        super ().__setitem__ (OO00OO0O00OO0O000 ,OOOOOOO00O0O0OOO0 )#line:2781
    def AddRcvData (OO0OO00OO00OOOO00 ,O00000O00O0OO0000 :str ,O0000O00OO00O0O00 :str ,OO00O0OOO000OO0O0 :bool ):#line:2783
        ""#line:2787
        O0O00O00OO0O0OO00 =""#line:2788
        O0O0000OOO0OO0O0O :TFutQuoteData =None #line:2789
        try :#line:2790
            O00O0OO0OOOOO0O00 =json .loads (O0000O00OO00O0O00 )#line:2791
            if "status"in O00O0OO0OOOOO0O00 and len (O00O0OO0OOOOO0O00 ["status"])>0 :#line:2793
                if O00O0OO0OOOOO0O00 ["status"][0 ]=="error":#line:2794
                    O0O00O00OO0O0OO00 =f"[期][AddRcvData](aSolIce={O00000O00O0OO0000}, aData={O0000O00OO00O0O00})行情回補資料有誤!"#line:2795
                    return False ,O0O0000OOO0OO0O0O ,O0O00O00OO0O0OO00 #line:2796
            if "BAS"in O00O0OO0OOOOO0O00 and len (O00O0OO0OOOOO0O00 ["BAS"])==0 :#line:2797
                O0O00O00OO0O0OO00 =f"[期][AddRcvData](aSolIce={O00000O00O0OO0000}, aData={O0000O00OO00O0O00})沒有BAS資料!"#line:2798
                return False ,O0O0000OOO0OO0O0O ,O0O00O00OO0O0OO00 #line:2799
            if "HL"in O00O0OO0OOOOO0O00 and len (O00O0OO0OOOOO0O00 ["HL"])==0 :#line:2800
                O0O00O00OO0O0OO00 =f"[期][AddRcvData](aSolIce={O00000O00O0OO0000}, aData={O0000O00OO00O0O00})沒有HL資料!"#line:2801
                return False ,O0O0000OOO0OO0O0O ,O0O00O00OO0O0OO00 #line:2802
            if OO0OO00OO00OOOO00 .data .get (O00000O00O0OO0000 )is None :#line:2805
                OOO00OOO0O0O0OO00 =TFutQuoteData (TFutProdKind .pkNormal ,O00000O00O0OO0000 ,OO00O0OOO000OO0O0 )#line:2807
                OOO00OOO0O0O0OO00 .BAS .Handle_BAS (O00O0OO0OOOOO0O00 ["BAS"][0 ])#line:2808
                OOO00OOO0O0O0OO00 .HL .Handle_HL (O00O0OO0OOOOO0O00 ["HL"][0 ])#line:2809
                OOO00OOO0O0O0OO00 .SetDataInit ()#line:2810
                O0O0000OOO0OO0O0O =OOO00OOO0O0O0OO00 #line:2811
                OO0OO00OO00OOOO00 [O00000O00O0OO0000 ]=OOO00OOO0O0O0OO00 #line:2812
                return True ,O0O0000OOO0OO0O0O ,""#line:2813
            else :#line:2814
                OOO00OOO0O0O0OO00 :TFutQuoteData =OO0OO00OO00OOOO00 [O00000O00O0OO0000 ]#line:2815
                with OOO00OOO0O0O0OO00 ._lock :#line:2816
                    OOO00OOO0O0O0OO00 .BAS .Handle_BAS (O00O0OO0OOOOO0O00 ["BAS"][0 ])#line:2817
                    OOO00OOO0O0O0OO00 .HL .Handle_HL (O00O0OO0OOOOO0O00 ["HL"][0 ])#line:2818
                    OOO00OOO0O0O0OO00 .SetDataInit ()#line:2819
                    O0O0000OOO0OO0O0O =OOO00OOO0O0O0OO00 #line:2820
                return True ,O0O0000OOO0OO0O0O ,""#line:2821
        except Exception as OO0O0OO00O0OOO0O0 :#line:2822
            O0O00O00OO0O0OO00 =f"[期][AddRcvData](aSolIce={O00000O00O0OO0000}, aData={O0000O00OO00O0O00}){OO0O0OO00O0OOO0O0}"#line:2823
        return False ,O0O0000OOO0OO0O0O ,O0O00O00OO0O0OO00 #line:2824
    def AddData (O00OOO00OOO00O0O0 ,O0O0O000O0O0O0OOO :TFutProdKind ,O0OOOOO000O000000 :str ,OO0OO0OOOO00O0OO0 :bool ,OO0000000000OOOO0 :str ,OOOOO0000OO00OOOO :callable ):#line:2826
        ""#line:2829
        try :#line:2830
            if O00OOO00OOO00O0O0 .data .get (O0OOOOO000O000000 )is None :#line:2831
                O0O0O0OOO0O0O0000 =TFutQuoteData (O0O0O000O0O0O0OOO ,O0OOOOO000O000000 ,OO0OO0OOOO00O0OO0 )#line:2832
                O00OOO00OOO00O0O0 [OO0000000000OOOO0 ]=O0O0O0OOO0O0O0000 #line:2833
                if O00OOO00OOO00O0O0 .MapQtProc .get (OO0000000000OOOO0 )is None :#line:2835
                    O00OOO00OOO00O0O0 .MapQtProc [OO0000000000OOOO0 ]=OOOOO0000OO00OOOO #line:2836
                return True #line:2838
            else :#line:2839
                return True #line:2840
        except Exception as OOO000O0OOO000O0O :#line:2841
            pass #line:2842
        return False #line:2843
    def AddDataBySolIce (O0OO000OO0000OOO0 ,O00O000OOO0O00000 :bool ,OO00OO000OOOO0000 :str ,OOOOO00O00OOOO000 ,O0O0OO00000O0OOOO :bool ,topic :str =""):#line:2845
        ""#line:2851
        OO000O0O0000O00OO =""#line:2852
        try :#line:2853
            O00O0OOOO000O0000 :TObjFutQuoteMap =TObjFutQuoteMap ()#line:2855
            if OOOOO00O00OOOO000 .get ("BAS")is not None :#line:2856
                for OO0OO00O0O0O0OO00 in OOOOO00O00OOOO000 ["BAS"]:#line:2857
                    O000O00O00O0OO000 :TFutQtBase =TFutQtBase (topic )#line:2858
                    O000O00O00O0OO000 .Handle_BAS (OO0OO00O0O0O0OO00 )#line:2859
                    if O00O0OOOO000O0000 .data .get (O000O00O00O0OO000 .OrdProdID )is None :#line:2860
                        OO00000OO0O000000 =TFutQuoteData (TFutProdKind .pkNormal ,O000O00O00O0OO000 .OrdProdID ,O0O0OO00000O0OOOO )#line:2861
                        OO00000OO0O000000 .BAS =O000O00O00O0OO000 #line:2862
                        OO00000OO0O000000 .UpdateHL =False #line:2863
                        OO00000OO0O000000 .SetDataInit ("BAS")#line:2864
                        O00O0OOOO000O0000 [O000O00O00O0OO000 .OrdProdID ]=OO00000OO0O000000 #line:2865
                    if topic !="":#line:2866
                        OOOOOOOO0OO000000 :OOO0O00O00O0OOO00 =OO00000OO0O000000 .BAS .TopicTX #line:2867
                        OO000OOOOO00O0OO0 :OOO0O00O00O0OOO00 =OO00000OO0O000000 .BAS .Topic5Q #line:2868
                        OO0O0OO000OO00O00 :OOO0O00O00O0OOO00 =OO00000OO0O000000 .BAS .Topic5QTOT #line:2869
                        O0O0O0OOOOOOOOOO0 :OOO0O00O00O0OOO00 =OO00000OO0O000000 .BAS .TopicBAS #line:2870
                        O0OO000OO0000OOO0 [OOOOOOOO0OO000000 ]=OO00000OO0O000000 #line:2871
                        O0OO000OO0000OOO0 [OO000OOOOO00O0OO0 ]=OO00000OO0O000000 #line:2872
                        O0OO000OO0000OOO0 [OO0O0OO000OO00O00 ]=OO00000OO0O000000 #line:2873
                        O0OO000OO0000OOO0 [O0O0O0OOOOOOOOOO0 ]=OO00000OO0O000000 #line:2874
                        if O0OO000OO0000OOO0 .MapQtProc .get (OOOOOOOO0OO000000 )is None :#line:2875
                            O0OO000OO0000OOO0 .MapQtProc [OOOOOOOO0OO000000 ]=O0OO000OO0000OOO0 .DefProc_TX #line:2876
                        if O0OO000OO0000OOO0 .MapQtProc .get (OO000OOOOO00O0OO0 )is None :#line:2877
                            O0OO000OO0000OOO0 .MapQtProc [OO000OOOOO00O0OO0 ]=O0OO000OO0000OOO0 .DefProc_5Q #line:2878
                        if O0OO000OO0000OOO0 .MapQtProc .get (OO0O0OO000OO00O00 )is None :#line:2879
                            O0OO000OO0000OOO0 .MapQtProc [OO0O0OO000OO00O00 ]=O0OO000OO0000OOO0 .DefProc_5QTOT #line:2880
                        if O0OO000OO0000OOO0 .MapQtProc .get (O0O0O0OOOOOOOOOO0 )is None :#line:2881
                            O0OO000OO0000OOO0 .MapQtProc [O0O0O0OOOOOOOOOO0 ]=O0OO000OO0000OOO0 .DefProc_BAS #line:2882
            if OOOOO00O00OOOO000 .get ("HL")is not None :#line:2885
                for OOO0O00O00O0OOO00 in OOOOO00O00OOOO000 ["HL"]:#line:2886
                    O0O0O00O00OOO00OO =TFutQtHL ()#line:2887
                    O0O0O00O00OOO00OO .Handle_HL (OOO0O00O00O0OOO00 )#line:2888
                    if O00O0OOOO000O0000 .data .get (O0O0O00O00OOO00OO .Symbol ):#line:2889
                        OO00000OO0O000000 :TFutQuoteData =O00O0OOOO000O0000 [O0O0O00O00OOO00OO .Symbol ]#line:2890
                        OO00000OO0O000000 .UpdateHL =True #line:2891
                        OO00000OO0O000000 .HL =O0O0O00O00OOO00OO #line:2892
                        OO00000OO0O000000 .SetDataInit ()#line:2893
                    if topic =="":#line:2894
                        OOOOOOOO0OO000000 :OOO0O00O00O0OOO00 =O0O0O00O00OOO00OO .TopicTX #line:2895
                        OO000OOOOO00O0OO0 :OOO0O00O00O0OOO00 =O0O0O00O00OOO00OO .Topic5Q #line:2896
                        OO0O0OO000OO00O00 :OOO0O00O00O0OOO00 =O0O0O00O00OOO00OO .Topic5QTOT #line:2897
                        O0O0O0OOOOOOOOOO0 :OOO0O00O00O0OOO00 =O0O0O00O00OOO00OO .TopicBAS #line:2898
                        O0OO000OO0000OOO0 [OOOOOOOO0OO000000 ]=OO00000OO0O000000 #line:2899
                        O0OO000OO0000OOO0 [OO000OOOOO00O0OO0 ]=OO00000OO0O000000 #line:2900
                        O0OO000OO0000OOO0 [OO0O0OO000OO00O00 ]=OO00000OO0O000000 #line:2901
                        O0OO000OO0000OOO0 [O0O0O0OOOOOOOOOO0 ]=OO00000OO0O000000 #line:2902
                        if O0OO000OO0000OOO0 .MapQtProc .get (OOOOOOOO0OO000000 )is None :#line:2903
                            O0OO000OO0000OOO0 .MapQtProc [OOOOOOOO0OO000000 ]=O0OO000OO0000OOO0 .DefProc_TX #line:2904
                        if O0OO000OO0000OOO0 .MapQtProc .get (OO000OOOOO00O0OO0 )is None :#line:2905
                            O0OO000OO0000OOO0 .MapQtProc [OO000OOOOO00O0OO0 ]=O0OO000OO0000OOO0 .DefProc_5Q #line:2906
                        if O0OO000OO0000OOO0 .MapQtProc .get (OO0O0OO000OO00O00 )is None :#line:2907
                            O0OO000OO0000OOO0 .MapQtProc [OO0O0OO000OO00O00 ]=O0OO000OO0000OOO0 .DefProc_5QTOT #line:2908
                        if O0OO000OO0000OOO0 .MapQtProc .get (O0O0O0OOOOOOOOOO0 )is None :#line:2909
                            O0OO000OO0000OOO0 .MapQtProc [O0O0O0OOOOOOOOOO0 ]=O0OO000OO0000OOO0 .DefProc_BAS #line:2910
            return len (O00O0OOOO000O0000 )>0 ,O00O0OOOO000O0000 ,OO000O0O0000O00OO #line:2913
        except Exception as O000O00O0O00OOO00 :#line:2914
            OO000O0O0000O00OO =f"[期][AddDataBySolIce](aIsCat={O00O000OOO0O00000}, aSolIce={OO00OO000OOOO0000}){O000O00O0O00OOO00}"#line:2915
        return False ,O00O0OOOO000O0000 ,OO000O0O0000O00OO #line:2916
    def GetItem_BySolIce (OOOOOO000OO000O00 ,OO000O00O0O0000OO :str ):#line:2919
        ""#line:2922
        O0O0OO00O0O0OO0OO =""#line:2923
        OOOOO00O00OOOOO0O =None #line:2924
        try :#line:2925
            O0O00OO0000OOO00O =[]#line:2926
            for OO00O00000000O0O0 ,O0O0OOO00O000000O in OOOOOO000OO000O00 .items ():#line:2927
                OOO0OO0000OOO00O0 :TFutQuoteData #line:2928
                OOO0OO0000OOO00O0 =O0O0OOO00O000000O #line:2929
                if (OOO0OO0000OOO00O0 .SolIce ==OO000O00O0O0000OO ):#line:2930
                    O0O00OO0000OOO00O .append (OO00O00000000O0O0 )#line:2931
            OOOOO00O00OOOOO0O =O0O00OO0000OOO00O #line:2932
            if OOOOO00O00OOOOO0O is None or len (OOOOO00O00OOOOO0O )==0 :#line:2933
                O0O0OO00O0O0OO0OO =f"[期][GetItem_BySolIce](aSolIce={OO000O00O0O0000OO})商品已不存存!"#line:2934
                return False ,OOOOO00O00OOOOO0O ,O0O0OO00O0O0OO0OO #line:2935
            else :#line:2936
                return True ,OOOOO00O00OOOOO0O ,""#line:2937
        except Exception as O0OO0O0O000OOOOOO :#line:2938
            O0O0OO00O0O0OO0OO =f"[期][GetItem_BySolIce](aSolIce={OO000O00O0O0000OO}){O0OO0O0O000OOOOOO}"#line:2939
        return False ,OOOOO00O00OOOOO0O ,O0O0OO00O0O0OO0OO #line:2940
    def GetItem_ByCategory (O000O0O0000OO000O ,O0O0000OO000OO0O0 :str ):#line:2942
        ""#line:2945
        O0O000O00OO00OO0O :str =""#line:2946
        OOOOOO000000OOO00 =None #line:2947
        try :#line:2948
            O0O000O0O000OOO00 =[]#line:2949
            for O00OO0000OOOO0OOO ,OO0OOOOO0O0OO00O0 in O000O0O0000OO000O .items ():#line:2950
                O00O0000O0O0OOO00 :TFutQuoteData =OO0OOOOO0O0OO00O0 #line:2951
                OO0OO0OOO0OOOO00O =O00OO0000OOOO0OOO .split ('/')#line:2952
                if OO0OO0OOO0OOOO00O [2 ]==O0O0000OO000OO0O0 :#line:2953
                    O0O000O0O000OOO00 .append (O00OO0000OOOO0OOO )#line:2954
            OOOOOO000000OOO00 =O0O000O0O000OOO00 #line:2955
            if OOOOOO000000OOO00 is None or len (OOOOOO000000OOO00 )==0 :#line:2956
                O0O000O00OO00OO0O =f"期][GetItem_ByCategory](aCat={O0O0000OO000OO0O0})商品已不存存!"#line:2957
                return False ,OOOOOO000000OOO00 ,O0O000O00OO00OO0O #line:2958
            else :#line:2959
                return True ,OOOOOO000000OOO00 ,""#line:2960
        except Exception as O0O000OO0OOO0OOOO :#line:2961
            O0O000O00OO00OO0O =f"[期][GetItem_ByCategory](aCat={O0O0000OO000OO0O0}){O0O000OO0OOO0OOOO}"#line:2962
        return False ,OOOOOO000000OOO00 ,O0O000O00OO00OO0O #line:2963
class TObjBaseFutMap (UserDict ):#line:2966
    ""#line:2968
    def __init__ (O0OOOOO0000OOOOOO ,mapping =None ,**OOO000OOOOO00OO00 ):#line:2971
        if mapping is not None :#line:2972
            mapping ={str (OO0O000000OO0OO0O ).upper ():OOO0000OOO0OO0OO0 for OO0O000000OO0OO0O ,OOO0000OOO0OO0OO0 in mapping .items ()}#line:2975
        else :#line:2976
            mapping ={}#line:2977
        if OOO000OOOOO00OO00 :#line:2978
            mapping .update ({str (O0OOO0O0OOO00OOOO ).upper ():O0O0OO0OO0OO00O00 for O0OOO0O0OOO00OOOO ,O0O0OO0OO0OO00O00 in OOO000OOOOO00OO00 .items ()})#line:2981
        O0OOOOO0000OOOOOO .fSortMap ={}#line:2983
        "<ProdID, <交割月, TFutQtBase>>"#line:2984
        super ().__init__ (mapping )#line:2985
    def __setitem__ (O0O00OO00O00OO0O0 ,O0OOO0O000O0O00O0 ,OO000O0OO00O00OO0 ):#line:2987
        super ().__setitem__ (O0OOO0O000O0O00O0 ,OO000O0OO00O00OO0 )#line:2988
    def AddItem_ByStkNo (OOO0O000OO00O0OO0 ,O00O0OO000O00OO0O :TFutQtBase ):#line:2990
        try :#line:2991
            if OOO0O000OO00O0OO0 .fSortMap .get (O00O0OO000O00OO0O .StkNo )is None :#line:2992
                O00O00000O0OO0OOO ={O00O0OO000O00OO0O .SettleMth :O00O0OO000O00OO0O }#line:2993
                OOO0O000OO00O0OO0 .fSortMap [O00O0OO000O00OO0O .StkNo ]=O00O00000O0OO0OOO #line:2994
            else :#line:2995
                OO00OOOO000OO0OO0 =OOO0O000OO00O0OO0 .fSortMap [O00O0OO000O00OO0O .StkNo ]#line:2996
                OO00OOOO000OO0OO0 [O00O0OO000O00OO0O .SettleMth ]=O00O0OO000O00OO0O #line:2997
                OO0O0OO00OOO0OOO0 =sorted (OO00OOOO000OO0OO0 .items ())#line:2998
                OOO00O0O00OO000O0 =dict (OO0O0OO00OOO0OOO0 )#line:2999
                OOO0O000OO00O0OO0 .fSortMap [O00O0OO000O00OO0O .StkNo ]=OOO00O0O00OO000O0 #line:3000
        except Exception as O000OOO0O0O0O0O0O :#line:3001
            pass #line:3002
    def AddItem_ByProdID (OOOO0O000O0O0OOOO ,O00O0OOOO000OO00O :TFutQtBase ):#line:3004
        try :#line:3005
            if OOOO0O000O0O0OOOO .fSortMap .get (O00O0OOOO000OO00O .ProdID )is None :#line:3006
                O00OOO00O000000O0 ={O00O0OOOO000OO00O .SettleMth :O00O0OOOO000OO00O }#line:3007
                OOOO0O000O0O0OOOO .fSortMap [O00O0OOOO000OO00O .ProdID ]=O00OOO00O000000O0 #line:3008
            else :#line:3009
                OOO0O00O0O0O00OOO =OOOO0O000O0O0OOOO .fSortMap [O00O0OOOO000OO00O .ProdID ]#line:3010
                OOO0O00O0O0O00OOO [O00O0OOOO000OO00O .SettleMth ]=O00O0OOOO000OO00O #line:3011
                O0000OO0O00000O00 =sorted (OOO0O00O0O0O00OOO .items ())#line:3012
                O0OOO0OO0OO0O0O00 =dict (O0000OO0O00000O00 )#line:3013
                OOOO0O000O0O0OOOO .fSortMap [O00O0OOOO000OO00O .ProdID ]=O0OOO0OO0OO0O0O00 #line:3014
        except Exception as OO000O000O0O0OO00 :#line:3015
            pass #line:3016
    def ReAddAll (OOO00O0O0000OOO0O ):#line:3018
        if OOO00O0O0000OOO0O .fSortMap .keys ()is None :#line:3019
            return #line:3020
        for O0O0OOO00O0OOO000 in OOO00O0O0000OOO0O .fSortMap .keys ():#line:3022
            O0OO0O00O0O0OO0O0 =TObjBaseFutList ()#line:3023
            [O0OO0O00O0O0OO0O0 .append (OOO00O0O0000OOO0O .fSortMap [O0O0OOO00O0OOO000 ][O0O0O00000OOOO00O ])for O0O0O00000OOOO00O in OOO00O0O0000OOO0O .fSortMap [O0O0OOO00O0OOO000 ]]#line:3024
            OOO00O0O0000OOO0O [O0O0OOO00O0OOO000 ]=O0OO0O00O0O0OO0O0 #line:3025
class TObjBaseFutList (list ):#line:3027
    ""#line:3028
    pass #line:3029
class TObjFutComList (UserDict ):#line:3030
    ""#line:3032
    def __init__ (OOO00O000OOO0O00O ,mapping =None ,**O0OO0OOOOOOO00000 ):#line:3034
        if mapping is not None :#line:3035
            mapping ={str (O0O0000OO00000OOO ).upper ():O0OOOOOOO00O0OOOO for O0O0000OO00000OOO ,O0OOOOOOO00O0OOOO in mapping .items ()}#line:3038
        else :#line:3039
            mapping ={}#line:3040
        if O0OO0OOOOOOO00000 :#line:3041
            mapping .update ({str (O00O00O0O00OOOO00 ).upper ():OOO00OO0O0O000OOO for O00O00O0O00OOOO00 ,OOO00OO0O0O000OOO in O0OO0OOOOOOO00000 .items ()})#line:3044
        super ().__init__ (mapping )#line:3045
    def __setitem__ (OOOOOOO00OOO0000O ,OO0OO00O0O0O000OO ,O000O00O00OOO0OO0 ):#line:3047
        super ().__setitem__ (OO0OO00O0O0O000OO ,O000O00O00OOO0OO0 )#line:3048
    def AddItem (OOO0O0OOO0O000O00 ,OO000O000OOOO00O0 :str ):#line:3050
        try :#line:3051
            OOO0O0O0OOOOO0O00 =TFutCom ()#line:3052
            OOO0O0O0OOOOO0O00 .SolIce =OO000O000OOOO00O0 #line:3053
            OOO0O0O0OOOOO0O00 .Leg1_SolIce =OO000O000OOOO00O0 .split ('^')[0 ]#line:3054
            OOO0O0O0OOOOO0O00 .Leg2_SolIce =OOO0O0O0OOOOO0O00 .Leg1_SolIce [:len (OOO0O0O0OOOOO0O00 .Leg1_SolIce )-2 ]+OO000O000OOOO00O0 .split ('^')[1 ]#line:3056
            OOO0O0OOO0O000O00 [OO000O000OOOO00O0 ]=OOO0O0O0OOOOO0O00 #line:3057
            OOO0O0OOO0O000O00 .data =dict (sorted (OOO0O0OOO0O000O00 .data .items ()))#line:3058
        except Exception as OOO0O0O0O0O0O0OO0 :#line:3059
            pass #line:3060
class TFutCom :#line:3062
    SolIce :str #line:3063
    "CDFL2^C3"#line:3064
    Leg1_SolIce :str #line:3065
    "CDFL2"#line:3066
    Leg2_SolIce :str #line:3067
    "CDFC3"#line:3068
class TObjBaseOptMap (UserDict ):#line:3073
    ""#line:3075
    def __init__ (O0000000OOOO000OO ,mapping =None ,**OO0O000OO0O0000OO ):#line:3077
        if mapping is not None :#line:3078
            mapping ={str (O0000OO0OO0O0OO0O ).upper ():OO0O000O00O0O0O00 for O0000OO0OO0O0OO0O ,OO0O000O00O0O0O00 in mapping .items ()}#line:3081
        else :#line:3082
            mapping ={}#line:3083
        if OO0O000OO0O0000OO :#line:3084
            mapping .update ({str (OOOO0O0OOOOOOOOO0 ).upper ():O0OO0O00000000000 for OOOO0O0OOOOOOOOO0 ,O0OO0O00000000000 in OO0O000OO0O0000OO .items ()})#line:3087
        super ().__init__ (mapping )#line:3088
    def __setitem__ (O00O0O00O0OOO0O00 ,O00OOO0OO00O00OOO ,OO0O0OO0OOOO0OO00 ):#line:3090
        super ().__setitem__ (O00OOO0OO00O00OOO ,OO0O0OO0OOOO0OO00 )#line:3091
    def AddItem_ByProdID (OOOOOO00OO0OOO0O0 ,OOO000OOO00O0O0OO :TFutQtBase ):#line:3093
        try :#line:3094
            if OOOOOO00OO0OOO0O0 .data .get (OOO000OOO00O0O0OO .ProdID )is None :#line:3095
                O0OO00OOOOOOO000O =TObjBaseOptMthList ()#line:3096
                O0OO00OOOOOOO000O .NewItem (OOO000OOO00O0O0OO )#line:3097
                OOOOOO00OO0OOO0O0 [OOO000OOO00O0O0OO .ProdID ]=O0OO00OOOOOOO000O #line:3098
            else :#line:3099
                O0OO00OOOOOOO000O :TObjBaseOptMthList =OOOOOO00OO0OOO0O0 [OOO000OOO00O0O0OO .ProdID ]#line:3100
                O0OO00OOOOOOO000O .NewItem (OOO000OOO00O0O0OO )#line:3101
        except Exception as O0000OO00O000OOO0 :#line:3102
            pass #line:3103
class TObjBaseOptMthList (UserDict ):#line:3104
    ""#line:3106
    ProdName :str =""#line:3107
    def __init__ (OO0O00O0O000000O0 ,mapping =None ,**OOOO00O0OO00O0O0O ):#line:3109
        if mapping is not None :#line:3110
            mapping ={str (O00O0OO000O00OO00 ).upper ():OOOO0OO00000O00O0 for O00O0OO000O00OO00 ,OOOO0OO00000O00O0 in mapping .items ()}#line:3113
        else :#line:3114
            mapping ={}#line:3115
        if OOOO00O0OO00O0O0O :#line:3116
            mapping .update ({str (O00OO00OOO0O00O0O ).upper ():OO0O0O0O00000000O for O00OO00OOO0O00O0O ,OO0O0O0O00000000O in OOOO00O0OO00O0O0O .items ()})#line:3119
        super ().__init__ (mapping )#line:3120
    def __setitem__ (OO0O000O0O0O0000O ,O0OOO000OOO0O00OO ,OO0O0O00O0000O000 ):#line:3122
        super ().__setitem__ (O0OOO000OOO0O00OO ,OO0O0O00O0000O000 )#line:3123
    def NewItem (O00O0O0OOO0O0000O ,O00OO000OO000OOOO :TFutQtBase ):#line:3125
        OO00OO0O00O0O00OO =O00OO000OO000OOOO .SettleMth #line:3126
        if O00O0O0OOO0O0000O .data .get (OO00OO0O00O0O00OO )is None :#line:3128
            O0OOOO0O0O00OOO00 =O00OO000OO000OOOO .FutName #line:3129
            O0O00000000O00000 =TObjBaseOptCallPutList ()#line:3130
            O0O00000000O00000 .NewItem (O00OO000OO000OOOO )#line:3131
            O00O0O0OOO0O0000O [OO00OO0O00O0O00OO ]=O0O00000000O00000 #line:3132
        else :#line:3133
            O0O00000000O00000 :TObjBaseOptCallPutList =O00O0O0OOO0O0000O [OO00OO0O00O0O00OO ]#line:3134
            O0O00000000O00000 .NewItem (O00OO000OO000OOOO )#line:3135
        OOOOO0OO00O0000O0 =O00O0O0OOO0O0000O .data #line:3137
        O0OOOO0O0OOOOO0O0 =sorted (OOOOO0OO00O0000O0 .items ())#line:3138
        OO0O0O000O0OO0O0O =dict (O0OOOO0O0OOOOO0O0 )#line:3139
        O00O0O0OOO0O0000O .data =OO0O0O000O0OO0O0O #line:3140
class TObjBaseOptCallPutList (UserDict ):#line:3141
    ""#line:3143
    def __init__ (OO0OO0OO00O0OOOOO ,mapping =None ,**O00000000O0OO0OOO ):#line:3145
        if mapping is not None :#line:3146
            mapping ={str (OOOOOOO0OOO0O0OO0 ).upper ():OO0O00000OOOO0O0O for OOOOOOO0OOO0O0OO0 ,OO0O00000OOOO0O0O in mapping .items ()}#line:3149
        else :#line:3150
            mapping ={}#line:3151
        if O00000000O0OO0OOO :#line:3152
            mapping .update ({str (O00OOOO0O00OO000O ).upper ():O0OOOOO0O00O000OO for O00OOOO0O00OO000O ,O0OOOOO0O00O000OO in O00000000O0OO0OOO .items ()})#line:3155
        super ().__init__ (mapping )#line:3156
    def __setitem__ (OO000O0OOOO00OO0O ,O00O00O0OOO00OO00 ,OOOO0000000O0OO00 ):#line:3158
        super ().__setitem__ (O00O00O0OOO00OO00 ,OOOO0000000O0OO00 )#line:3159
    def NewItem (OOO00OOO00OO00000 ,OOO000O000O0OOO0O :TFutQtBase ):#line:3161
        O0000OOO00OOO000O =OOO000O000O0OOO0O .CallPutType #line:3162
        if OOO00OOO00OO00000 .data .get (O0000OOO00OOO000O )is None :#line:3164
            O00O00000OO00000O =TObjBaseOptList ()#line:3165
            O00O00000OO00000O .append (OOO000O000O0OOO0O )#line:3166
            OOO00OOO00OO00000 [O0000OOO00OOO000O ]=O00O00000OO00000O #line:3167
        else :#line:3168
            OO00O00O0OO0O0O00 :TObjBaseOptList =OOO00OOO00OO00000 [O0000OOO00OOO000O ]#line:3169
            OO00O00O0OO0O0O00 .append (OOO000O000O0OOO0O )#line:3170
        O0OO000OOO0OO00OO =OOO00OOO00OO00000 .data #line:3172
        OOOOOO000O00OOO00 =sorted (O0OO000OOO0OO00OO .items ())#line:3173
        OO000000OO0O0000O =dict (OOOOOO000O00OOO00 )#line:3174
        OOO00OOO00OO00000 .data =OO000000OO0O0000O #line:3175
class TObjBaseOptList (list ):#line:3176
    ""#line:3177
    pass #line:3178
class TQryFutProdMap (UserDict ):#line:3182
    ""#line:3184
    def __init__ (OOOO00O00O0O0OOO0 ,mapping =None ,**OOOOO0O000OO0O0OO ):#line:3186
        if mapping is not None :#line:3187
            mapping ={str (O000O00O0OOOO00O0 ).upper ():O00O0OOOOO00000OO for O000O00O0OOOO00O0 ,O00O0OOOOO00000OO in mapping .items ()}#line:3190
        else :#line:3191
            mapping ={}#line:3192
        if OOOOO0O000OO0O0OO :#line:3193
            mapping .update ({str (O0OOOO0OOOOOO0000 ).upper ():O000OOOO0OO0OOOOO for O0OOOO0OOOOOO0000 ,O000OOOO0OO0OOOOO in OOOOO0O000OO0O0OO .items ()})#line:3196
        super ().__init__ (mapping )#line:3197
    def __setitem__ (OO0OO00O0000OO000 ,O00O00O00OOOOO00O ,OOOO00OO000OOO0O0 ):#line:3199
        super ().__setitem__ (O00O00O00OOOOO00O ,OOOO00OO000OOO0O0 )#line:3200
class TQryFutProdRec :#line:3202
    tmpBase :TFutQtBase =None #line:3204
    tmpHL :TFutQtHL =None #line:3205
    def SetDataInit (O000OOOOOO0O0000O ):#line:3207
        O000OOOOOO0O0000O .tmpHL .DECIMAL_LOCATOR_Dgt =O000OOOOOO0O0000O .tmpBase .DECIMAL_LOCATOR_Dgt #line:3208
        O000OOOOOO0O0000O .tmpHL .DECIMAL_LOCATOR_Org =O000OOOOOO0O0000O .tmpBase .DECIMAL_LOCATOR_Org #line:3209
class TOvsFutQtDef :#line:3214
    DecimalMultiply :decimal =1 #line:3215
    "DecimalMultiply(一個契約含多少Shares)"#line:3216
    Price_Denominator :decimal =1 #line:3217
    "分母價格(為1者, 不是分子分母報價方式)"#line:3218
    def TransPrice2Dec (OOOOO000OO0O0O00O ,OOO00O000O000O00O :str ):#line:3221
        try :#line:3222
            return Decimal (OOO00O000O000O00O )#line:3223
        except Exception as OOOOOOO0OO00O0O0O :#line:3224
            return 0 #line:3225
    def TransPrice2Str (O00OO0OOOO0OO00O0 ,OOOO0O0O0O0O0000O :decimal ,aDg_tPrice :str =""):#line:3228
        if O00OO0OOOO0OO00O0 .Price_Denominator ==1 :#line:3229
            if O00OO0OOOO0OO00O0 .DecimalMultiply ==1 :#line:3230
                if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice .isspace ():#line:3231
                    return str (OOOO0O0O0O0O0000O )#line:3232
                else :#line:3233
                    return aDg_tPrice .format (OOOO0O0O0O0O0000O )#line:3234
            if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice .isspace ():#line:3235
                return "{:.8f}".format (OOOO0O0O0O0O0000O *O00OO0OOOO0OO00O0 .DecimalMultiply )#line:3236
            else :#line:3237
                return aDg_tPrice .format (OOOO0O0O0O0O0000O *O00OO0OOOO0OO00O0 .DecimalMultiply )#line:3238
        else :#line:3240
            O0O000O00OO00OOOO :decimal =math .trunc (OOOO0O0O0O0O0000O )#line:3242
            O000O000O0O00OO00 :decimal =OOOO0O0O0O0O0000O -O0O000O00OO00OOOO #line:3243
            if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice .isspace ():#line:3244
                return "{0} {1:.8f}/{2}".format (O0O000O00OO00OOOO ,(O000O000O0O00OO00 *O00OO0OOOO0OO00O0 .Price_Denominator ),O00OO0OOOO0OO00O0 .Price_Denominator )#line:3245
            else :#line:3246
                return "{0} {1:.8f}/{2}".format (O0O000O00OO00OOOO ,aDg_tPrice .format (O000O000O0O00OO00 *O00OO0OOOO0OO00O0 .Price_Denominator ),O00OO0OOOO0OO00O0 .Price_Denominator )#line:3247
    def TransToInt (O0000OOOO000000O0 ,O0O0OOO0O0O0O000O :str ):#line:3249
        try :#line:3250
            return int (O0O0OOO0O0O0O000O )#line:3251
        except Exception as O0O0O0O0O0OO00O00 :#line:3252
            return 0 #line:3253
    def TransToDecimal (O000000OOO0O000OO ,OO0O0OO0OO000000O :str ):#line:3255
        try :#line:3256
            return Decimal (OO0O0OO0OO000000O )#line:3257
        except Exception as OO0000O00OO0000O0 :#line:3258
            return 0 #line:3259
    def __init__ (O00O00O000O0OO00O )->None :#line:3262
        pass #line:3263
class TOvsFutQtBase (TOvsFutQtDef ):#line:3265
    fHasBAS :bool =False #line:3266
    fBAS =[]#line:3267
    SolICE :str #line:3269
    "台新行情代碼(NQ.202212)"#line:3270
    SysTime :str #line:3271
    "系統時間"#line:3272
    RefPriceOrg :str #line:3273
    "參考價"#line:3274
    def Get_RefPrice (O0O00OOO00OO0OO00 ):#line:3276
        return O0O00OOO00OO0OO00 .TransPrice2Dec (O0O00OOO00OO0OO00 .RefPriceOrg )#line:3277
    def GetDply_RefPrice (OO0OO0OO000O0O0OO ,aDg_tPrice :str =""):#line:3279
        if (OO0OO0OO000O0O0OO .fBAS ==None ):#line:3280
            return ""#line:3281
        OOO00O0O0OOOO0OO0 :decimal =0 #line:3282
        OOO00O0O0OOOO0OO0 =OO0OO0OO000O0O0OO .TransPrice2Dec (OO0OO0OO000O0O0OO .RefPriceOrg )#line:3283
        return OO0OO0OO000O0O0OO .TransPrice2Str (OOO00O0O0OOOO0OO0 ,aDg_tPrice )#line:3284
    ProdID :str #line:3285
    "台新商品代碼 (EX:NQ)"#line:3286
    FutName :str #line:3287
    "商品中文名稱(EX:小型環球晶)"#line:3288
    OrdProdId :str #line:3289
    "台新商品委託代碼(EX:NQ)"#line:3290
    ICEProdId :str #line:3291
    "台新行情代碼(EX:NQ, 艾揚的為ICE開頭)"#line:3292
    MktStr :str #line:3293
    "台新市場別(FUT/OPT)"#line:3294
    Market :str #line:3295
    "台新市場別(4=FUT/5=OPT)"#line:3296
    BaseUnit :str #line:3297
    "基本跳動點(選擇權商品為TickSizeList, 如:0=0.05;5=0.25)"#line:3298
    def Get_BaseUnit (O0O000O000O000O00 ):#line:3300
        OOOO0OOO000000OOO :decimal =1 #line:3301
        OOOO0OOO000000OOO =O0O000O000O000O00 .TransToDecimal (O0O000O000O000O00 .BaseUnit )#line:3302
        if OOOO0OOO000000OOO ==0 :#line:3303
            OOOO0OOO000000OOO =1 #line:3304
        return OOOO0OOO000000OOO #line:3305
    ValuePerUnitOrg :str #line:3307
    "每點價值"#line:3308
    def Get_ValuePerUnit (O0OOOO0OO0O00OOO0 ):#line:3310
        return O0OOOO0OO0O00OOO0 .TransToDecimal (O0OOOO0OO0O00OOO0 .ValuePerUnitOrg )#line:3311
    DecimalMultiplyOrg :str #line:3312
    "DecimalMultiply(一個契約含多少Shares)"#line:3313
    def Get_DecimalMultiply (O0OO0O000O0OO00O0 ):#line:3315
        return O0OO0O000O0OO00O0 .TransToDecimal (O0OO0O000O0OO00O0 .DecimalMultiplyOrg )#line:3316
    Exchange :str #line:3317
    "台新交易所代碼"#line:3318
    ExchangeName :str #line:3319
    "台新商品代碼 (EX:NQ)"#line:3320
    Price_DenominatorOrg :str #line:3321
    "分母價格(為1者, 不是分子分母報價方式)"#line:3322
    def Get_Price_Denominator (OO000000OO0000OO0 ):#line:3324
        return OO000000OO0000OO0 .TransToDecimal (OO000000OO0000OO0 .Price_DenominatorOrg )#line:3325
    Display :str #line:3326
    "是否可交易(Y/N)"#line:3327
    SettleMth :str #line:3328
    "交割月"#line:3329
    CP :str #line:3330
    "C/P(非選擇權者為空字串)"#line:3331
    StrikeP :str #line:3332
    "履約價(非選擇權者為空字串)"#line:3333
    PreSettlePriceOrg :str #line:3334
    "昨日結算價"#line:3335
    def Get_PreSettlePrice (O000OO0000OOO0OO0 ):#line:3337
        if O000OO0000OOO0OO0 .fBAS is None :#line:3338
            return 0 #line:3339
        O0O00O00OO0OOOOO0 :decimal =0 #line:3340
        O0O00O00OO0OOOOO0 =O000OO0000OOO0OO0 .TransPrice2Dec (O000OO0000OOO0OO0 .PreSettlePriceOrg )#line:3341
        return O0O00O00OO0OOOOO0 #line:3342
    def GetDply_PreSettlePrice (O000000O0O000O000 ,aDg_tPrice :str =""):#line:3344
        if O000000O0O000O000 .fBAS ==None :#line:3345
            return ""#line:3346
        OO0OOOO00000O0OO0 :decimal =0 #line:3347
        OO0OOOO00000O0OO0 =O000000O0O000O000 .TransPrice2Dec (O000000O0O000O000 .PreSettlePriceOrg )#line:3348
        return O000000O0O000O000 .TransPrice2Str (OO0OOOO00000O0OO0 ,aDg_tPrice )#line:3349
    PreClosePriceOrg :str #line:3350
    def Get_PreClosePrice (OO00O0O00O0O000OO ):#line:3352
        if OO00O0O00O0O000OO .fBAS ==None :#line:3353
            return 0 #line:3354
        OO0O0000O0O0OO000 :decimal =0 #line:3355
        OO0O0000O0O0OO000 =OO00O0O00O0O000OO .TransPrice2Dec (OO00O0O00O0O000OO .PreClosePriceOrg )#line:3356
        return OO0O0000O0O0OO000 #line:3357
    def GetDply_PreClosePrice (O00O0OOOOO0O0O00O ,aDg_tPrice :str =""):#line:3359
        if O00O0OOOOO0O0O00O .fBAS ==None :#line:3360
            return ""#line:3361
        O0O00000OOOOOO0O0 :decimal =0 #line:3362
        O0O00000OOOOOO0O0 =O00O0OOOOO0O0O00O .TransPrice2Str (O00O0OOOOO0O0O00O .PreClosePriceOrg )#line:3363
        return O00O0OOOOO0O0O00O .TransPrice2Str (O0O00000OOOOOO0O0 ,aDg_tPrice )#line:3364
    LastTxDate :str #line:3366
    "最後交易日"#line:3367
    TickSizeList :str #line:3368
    "TickSizeList(僅選擇權有值, 如:0=0.05;5=0.25)"#line:3369
    def Get_OptTickSizeList (OO0O00OO0OOOOO0O0 ):#line:3371
        ""#line:3373
        OOOOO000OOO0O00O0 ={}#line:3375
        try :#line:3376
            if OO0O00OO0OOOOO0O0 .MktStr =="FUT":#line:3377
                return OOOOO000OOO0O00O0 #line:3378
            if OO0O00OO0OOOOO0O0 .TickSizeList is None or not OO0O00OO0OOOOO0O0 .TickSizeList or OO0O00OO0OOOOO0O0 .TickSizeList .isspace :#line:3379
                return OOOOO000OOO0O00O0 #line:3380
            O0OO0O0000000OO0O =OO0O00OO0OOOOO0O0 .TickSizeList .split (';')#line:3383
            for OOO00OOO0OOOOOO00 in O0OO0O0000000OO0O :#line:3384
                OOOOO000OOO0O00O0 [Decimal (OOO00OOO0OOOOOO00 .split ('=')[0 ])]=Decimal (OOO00OOO0OOOOOO00 .split ('=')[1 ])#line:3386
            OOOOO000OOO0O00O0 =dict (sorted (OOOOO000OOO0O00O0 .items ()))#line:3387
        except Exception as OO0OO0O000O0OO0OO :#line:3388
            pass #line:3389
        return OOOOO000OOO0O00O0 #line:3390
    def GetFavorStr (O0O0OO0O0OOOO0000 )->str :#line:3392
        ""#line:3393
        return "|{0}|{1}|{2}|{3}|".format (O0O0OO0O0OOOO0000 .Exchange ,O0O0OO0O0OOOO0000 .ProdID ,O0O0OO0O0OOOO0000 .SettleMth ,O0O0OO0O0OOOO0000 .SolICE )#line:3394
    def Handle_BAS (OO0OOOOO0OOOOOOOO ,OOO0OO0000O000O00 :str ):#line:3396
        OO0OOOOO0OOOOOOOO .fBAS =OOO0OO0000O000O00 .split ('|')#line:3397
        OO0OOOOO0OOOOOOOO .fHasBAS =len (OO0OOOOO0OOOOOOOO .fBAS )>0 #line:3398
        OO0OOOOO0OOOOOOOO .Set_Data ()#line:3399
        if OO0OOOOO0OOOOOOOO .fHasBAS :#line:3400
            OO0OOOOO0OOOOOOOO .DecimalMultiply =OO0OOOOO0OOOOOOOO .Get_DecimalMultiply ()#line:3401
            OO0OOOOO0OOOOOOOO .Price_Denominator =OO0OOOOO0OOOOOOOO .Get_Price_Denominator ()#line:3402
    def Set_Data (O0O0000O0O0O0OOOO ):#line:3404
        O0O0000O0O0O0OOOO .SolICE =O0O0000O0O0O0OOOO .fBAS [0 ]#line:3405
        O0O0000O0O0O0OOOO .SysTime =O0O0000O0O0O0OOOO .fBAS [1 ]#line:3406
        O0O0000O0O0O0OOOO .RefPriceOrg =O0O0000O0O0O0OOOO .fBAS [2 ]#line:3407
        O0O0000O0O0O0OOOO .ProdID =O0O0000O0O0O0OOOO .fBAS [3 ]#line:3408
        O0O0000O0O0O0OOOO .FutName =O0O0000O0O0O0OOOO .fBAS [4 ]#line:3409
        O0O0000O0O0O0OOOO .OrdProdId =O0O0000O0O0O0OOOO .fBAS [5 ]#line:3410
        O0O0000O0O0O0OOOO .ICEProdId =O0O0000O0O0O0OOOO .fBAS [6 ]#line:3411
        O0O0000O0O0O0OOOO .MktStr =O0O0000O0O0O0OOOO .fBAS [7 ]#line:3412
        O0O0000O0O0O0OOOO .Market ="4"if O0O0000O0O0O0OOOO .fBAS [7 ]=="FUT"else "5"#line:3413
        O0O0000O0O0O0OOOO .BaseUnit =O0O0000O0O0O0OOOO .fBAS [8 ]#line:3414
        O0O0000O0O0O0OOOO .ValuePerUnitOrg =O0O0000O0O0O0OOOO .fBAS [9 ]#line:3415
        O0O0000O0O0O0OOOO .DecimalMultiplyOrg =O0O0000O0O0O0OOOO .fBAS [10 ]#line:3416
        O0O0000O0O0O0OOOO .Exchange =O0O0000O0O0O0OOOO .fBAS [11 ]#line:3417
        O0O0000O0O0O0OOOO .ExchangeName =O0O0000O0O0O0OOOO .fBAS [12 ]#line:3418
        O0O0000O0O0O0OOOO .Price_DenominatorOrg =O0O0000O0O0O0OOOO .fBAS [13 ]#line:3419
        O0O0000O0O0O0OOOO .Display =O0O0000O0O0O0OOOO .fBAS [14 ]#line:3420
        O0O0000O0O0O0OOOO .SettleMth =O0O0000O0O0O0OOOO .fBAS [15 ]#line:3421
        O0O0000O0O0O0OOOO .CP =O0O0000O0O0O0OOOO .fBAS [16 ]#line:3422
        O0O0000O0O0O0OOOO .StrikeP =O0O0000O0O0O0OOOO .fBAS [17 ]#line:3423
        O0O0000O0O0O0OOOO .PreSettlePriceOrg =O0O0000O0O0O0OOOO .fBAS [18 ]#line:3424
        O0O0000O0O0O0OOOO .PreClosePriceOrg =O0O0000O0O0O0OOOO .fBAS [19 ]#line:3425
        O0O0000O0O0O0OOOO .LastTxDate =O0O0000O0O0O0OOOO .fBAS [20 ]#line:3426
        O0O0000O0O0O0OOOO .TickSizeList =O0O0000O0O0O0OOOO .fBAS [21 ]#line:3427
    def IsSameBAS (O0O0OOOOO0O00O000 ,OOOOOOOOOO0O000O0 :str ,O0O00OO0OO0O0OOOO :str ):#line:3429
        return OOOOOOOOOO0O000O0 ==O0O0OOOOO0O00O000 .ProdID and O0O0OOOOO0O00O000 .SettleMth ==O0O00OO0OO0O0OOOO #line:3430
class TOvsFutQtTX (TOvsFutQtDef ):#line:3431
    fTX =[]#line:3432
    SolICE :str #line:3435
    "台新行情代碼(NQ.202212)"#line:3436
    SysTime :str #line:3437
    "系統時間(EX:143211.693)"#line:3438
    DataTime :str #line:3439
    "資料時間(交易所給的)(EX:14:32:11.752025)"#line:3440
    QtSrc :str #line:3441
    "行情來源(EX:PATS.NQ/CQG.NQ)"#line:3442
    DealTime :str #line:3443
    "成交時間(EX:14:32:11.752025)"#line:3444
    DealShowMark :str #line:3445
    "成交資料揭示項目註記(0:請略過,1:成交行情,空字串:收盤/結算)"#line:3446
    TotQty :str #line:3447
    "成交總量"#line:3448
    def Get_TotQty2Dec (OO0OO00O00OO00OOO ):#line:3450
        return OO0OO00O00OO00OOO .TransToDecimal (OO0OO00O00OO00OOO .TotQty )#line:3451
    def Get_TotQty2Int (O00OOO0O000OOO0OO ):#line:3453
        return O00OOO0O000OOO0OO .TransToInt (O00OOO0O000OOO0OO .TotQty )#line:3454
    SumBuyDealCount :str #line:3455
    "累計買進成交筆數"#line:3456
    def Get_SumBuyDealCount (O00O00OOO00OO0OO0 ):#line:3458
        return O00O00OOO00OO0OO0 .TransToInt (O00O00OOO00OO0OO0 .SumBuyDealCount )#line:3459
    SumSellDealCount :str #line:3460
    "累計賣出成交筆數"#line:3461
    def Get_SumSellDealCount (O00OOOOO0OO00OO00 ):#line:3463
        return O00OOOOO0OO00OO00 .TransToInt (O00OOOOO0OO00OO00 .SumSellDealCount )#line:3464
    DealCount :str #line:3465
    "成交價量檔數(目前海期都給1)"#line:3466
    def Get_DealCount (O00O0000OOO0O0000 ):#line:3468
        return O00O0000OOO0O0000 .TransToInt (O00O0000OOO0O0000 .DealCount )#line:3469
    DealPriceOrg :str #line:3470
    "成交價"#line:3471
    def Get_DealPrice (O0OOOO0OO0O00OO00 ):#line:3473
        if O0OOOO0OO0O00OO00 .fTX is None :#line:3474
            return 0 #line:3475
        OO0OO0O000OO00000 :decimal =0 #line:3476
        OO0OO0O000OO00000 =O0OOOO0OO0O00OO00 .TransPrice2Dec (O0OOOO0OO0O00OO00 .DealPriceOrg )#line:3477
        return OO0OO0O000OO00000 #line:3478
    def GetDply_DealPrice (OOO000OO000O0OOO0 ,aDg_tPrice :str =""):#line:3480
        if OOO000OO000O0OOO0 .fTX ==None :#line:3481
            return ""#line:3482
        O0OO0O00OOO0O00OO :decimal =0 #line:3483
        O0OO0O00OOO0O00OO =OOO000OO000O0OOO0 .TransPrice2Dec (OOO000OO000O0OOO0 .DealPriceOrg )#line:3484
        return OOO000OO000O0OOO0 .TransPrice2Str (O0OO0O00OOO0O00OO ,aDg_tPrice )#line:3485
    DealQty :str #line:3486
    "成交單量"#line:3487
    def Get_DealQty2Dec (OOO0O0O0000OOO0OO ):#line:3489
        return OOO0O0O0000OOO0OO .TransPrice2Dec (OOO0O0O0000OOO0OO .DealQty )#line:3490
    def GetDealQty2Int (O0000O0OOOO000O00 ):#line:3492
        return O0000O0OOOO000O00 .TransToInt (O0000O0OOOO000O00 .DealQty )#line:3493
    DayHighOrg :str #line:3494
    "最高價"#line:3495
    def Get_DayHigh (O0O0O0O0OO0OOOO0O ):#line:3497
        if O0O0O0O0OO0OOOO0O .fTX is None :#line:3498
            return 0 #line:3499
        O0OOO0O0O00O00O0O :decimal =0 #line:3500
        O0OOO0O0O00O00O0O =O0O0O0O0OO0OOOO0O .TransPrice2Dec (O0O0O0O0OO0OOOO0O .DayHighOrg )#line:3501
        return O0OOO0O0O00O00O0O #line:3502
    def GetDply_DayHigh (O0O00OO0OOO0OO00O ,aDg_tPrice :str =""):#line:3504
        if O0O00OO0OOO0OO00O .fTX ==None :#line:3505
            return ""#line:3506
        O0OO0OO0O000O0OO0 :decimal =0 #line:3507
        O0OO0OO0O000O0OO0 =O0O00OO0OOO0OO00O .TransPrice2Dec (O0O00OO0OOO0OO00O .DayHighOrg )#line:3508
        return O0O00OO0OOO0OO00O .TransPrice2Str (O0OO0OO0O000O0OO0 ,aDg_tPrice )#line:3509
    DayLowOrg :str #line:3510
    "最低價"#line:3511
    def Get_DayLow (OOO0O00OOOO00OO0O ):#line:3513
        if OOO0O00OOOO00OO0O .fTX ==None :#line:3514
            return 0 #line:3515
        OOOO0OOOOO00OOOOO :decimal =0 #line:3516
        OOOO0OOOOO00OOOOO =OOO0O00OOOO00OO0O .TransPrice2Dec (OOO0O00OOOO00OO0O .DayLowOrg )#line:3517
        return OOOO0OOOOO00OOOOO #line:3518
    def GetDply_DayLow (OO0OO0OOO0000OO00 ,aDg_tPrice :str =""):#line:3520
        if OO0OO0OOO0000OO00 .fTX ==None :#line:3521
            return ""#line:3522
        OO000O00OO0O000OO :decimal =0 #line:3523
        OO000O00OO0O000OO =OO0OO0OOO0000OO00 .TransPrice2Dec (OO0OO0OOO0000OO00 .DayLowOrg )#line:3524
        return OO0OO0OOO0000OO00 .TransPrice2Str (OO000O00OO0O000OO ,aDg_tPrice )#line:3525
    OpenPriceOrg :str #line:3526
    "開盤價"#line:3527
    def Get_OpenPrice (OOO0000O0000O0OOO ):#line:3529
        if OOO0000O0000O0OOO .fTX ==None :#line:3530
            return 0 #line:3531
        OO0OO0000O0O00OOO :decimal =0 #line:3532
        OO0OO0000O0O00OOO =OOO0000O0000O0OOO .TransPrice2Dec (OOO0000O0000O0OOO .OpenPriceOrg )#line:3533
        return OO0OO0000O0O00OOO #line:3534
    def GetDply_OpenPrice (O0OOOO00OO0000000 ,aDg_tPrice :str =""):#line:3536
        if O0OOOO00OO0000000 .fTX ==None :#line:3537
            return ""#line:3538
        O0OOO0O0O0OOOO0O0 :decimal =0 #line:3539
        O0OOO0O0O0OOOO0O0 =O0OOOO00OO0000000 .TransPrice2Dec (O0OOOO00OO0000000 .OpenPriceOrg )#line:3540
        return O0OOOO00OO0000000 .TransPrice2Dec (O0OOO0O0O0OOOO0O0 ,aDg_tPrice )#line:3541
    ClosePriceOrg :str #line:3542
    "收盤價"#line:3543
    def Get_ClosePrice (OO0O00OO0000OOO00 ):#line:3545
        if OO0O00OO0000OOO00 .fTX ==None :#line:3546
            return 0 #line:3547
        OO0O00OOO000O0000 :decimal =0 #line:3548
        OO0O00OOO000O0000 =OO0O00OO0000OOO00 .TransPrice2Dec (OO0O00OO0000OOO00 .ClosePriceOrg )#line:3549
        return OO0O00OOO000O0000 #line:3550
    def GetDply_ClosePrice (O0000OO0OOOO0O00O ,aDg_tPrice :str =""):#line:3552
        if O0000OO0OOOO0O00O .fTX ==None :#line:3554
            return ""#line:3555
        OOO0O0O0OO0O00000 :decimal =0 #line:3556
        OOO0O0O0OO0O00000 =O0000OO0OOOO0O00O .TransPrice2Dec (O0000OO0OOOO0O00O .ClosePriceOrg )#line:3557
        return O0000OO0OOOO0O00O .TransPrice2Str (OOO0O0O0OO0O00000 ,aDg_tPrice )#line:3558
    SettlePriceOrg :str #line:3560
    "結算價"#line:3561
    def Get_SettlePrice (OO00OO000OOO00OOO ):#line:3563
        if OO00OO000OOO00OOO .fTX ==None :#line:3564
            return 0 #line:3565
        OO0O0O000000OOOO0 :decimal =0 #line:3566
        OO0O0O000000OOOO0 =OO00OO000OOO00OOO .TransPrice2Dec (OO00OO000OOO00OOO .SettlePriceOrg )#line:3567
        return OO0O0O000000OOOO0 #line:3568
    def GetDply_SettlePrice (OOOO0O00O0OO0O0OO ,aDg_tPrice :str =""):#line:3570
        if OOOO0O00O0OO0O0OO .fTX ==None :#line:3571
            return ""#line:3572
        O0O000OO0O000O000 :decimal =0 #line:3573
        O0O000OO0O000O000 =OOOO0O00O0OO0O0OO .TransPrice2Dec (OOOO0O00O0OO0O0OO .SettlePriceOrg )#line:3574
        return OOOO0O00O0OO0O0OO .TransPrice2Str (O0O000OO0O000O000 ,aDg_tPrice )#line:3575
    fDealPrice :decimal =0 #line:3578
    "成交價"#line:3579
    HighPrice :decimal =0 #line:3580
    "當日最高價"#line:3581
    LowPrice :decimal =0 #line:3582
    "當日最低價"#line:3583
    def CalcHightLowPrice (OO00O0OOOO0OOO0O0 ):#line:3585
        ""#line:3586
        try :#line:3587
            OO00O0OOOO0OOO0O0 .fDealPrice =OO00O0OOOO0OOO0O0 .Get_DealPrice ()#line:3588
            OO00O0OOOO0OOO0O0 .HighPrice =math .Max (OO00O0OOOO0OOO0O0 .fDealPrice ,OO00O0OOOO0OOO0O0 .HighPrice )#line:3590
            if OO00O0OOOO0OOO0O0 .LowPrice ==0 :#line:3591
                OO00O0OOOO0OOO0O0 .LowPrice =OO00O0OOOO0OOO0O0 .fDealPrice #line:3592
            else :#line:3593
                OO00O0OOOO0OOO0O0 .LowPrice =min (OO00O0OOOO0OOO0O0 .fDealPrice ,OO00O0OOOO0OOO0O0 .LowPrice )#line:3594
        except Exception as OO000OOOOO00OOOO0 :#line:3595
            pass #line:3596
    def CalcHightLowPrice_None (O00O0O00OOO0OOOOO ):#line:3598
        pass #line:3599
    fPROC_CalcHightLowPrice :callable =None #line:3600
    "PROC_CalcHightLowPrice"#line:3601
    def Set_Data (OO0OO0000O00O00O0 ):#line:3604
        OO0OO0000O00O00O0 .SolICE =OO0OO0000O00O00O0 .fTX [0 ]#line:3605
        OO0OO0000O00O00O0 .SysTime =OO0OO0000O00O00O0 .fTX [1 ]#line:3606
        OO0OO0000O00O00O0 .DataTime =OO0OO0000O00O00O0 .fTX [2 ]#line:3607
        OO0OO0000O00O00O0 .QtSrc =OO0OO0000O00O00O0 .fTX [3 ]#line:3608
        OO0OO0000O00O00O0 .DealTime =OO0OO0000O00O00O0 .fTX [4 ]#line:3609
        OO0OO0000O00O00O0 .DealShowMark =OO0OO0000O00O00O0 .fTX [5 ]#line:3610
        OO0OO0000O00O00O0 .TotQty =OO0OO0000O00O00O0 .fTX [6 ]#line:3611
        OO0OO0000O00O00O0 .SumBuyDealCount =OO0OO0000O00O00O0 .fTX [7 ]#line:3612
        OO0OO0000O00O00O0 .SumSellDealCount =OO0OO0000O00O00O0 .fTX [8 ]#line:3613
        OO0OO0000O00O00O0 .DealCount =OO0OO0000O00O00O0 .fTX [9 ]#line:3614
        OO0OO0000O00O00O0 .DealPriceOrg =OO0OO0000O00O00O0 .fTX [10 ]#line:3615
        OO0OO0000O00O00O0 .DealQty =OO0OO0000O00O00O0 .fTX [11 ]#line:3616
        OO0OO0000O00O00O0 .DayHighOrg =OO0OO0000O00O00O0 .fTX [12 ]#line:3617
        OO0OO0000O00O00O0 .DayLowOrg =OO0OO0000O00O00O0 .fTX [13 ]#line:3618
        OO0OO0000O00O00O0 .OpenPriceOrg =OO0OO0000O00O00O0 .fTX [14 ]#line:3619
        OO0OO0000O00O00O0 .ClosePriceOrg =OO0OO0000O00O00O0 .fTX [15 ]#line:3620
        OO0OO0000O00O00O0 .SettlePriceOrg =OO0OO0000O00O00O0 .fTX [16 ]#line:3621
    def Handle_TX (O0O000O00OOO00OO0 ,O0O0OOOOO0OO00000 :str ):#line:3623
        ""#line:3624
        O0O000O00OOO00OO0 .fTX =O0O0OOOOO0OO00000 .split ('|')#line:3625
        O0O000O00OOO00OO0 .Set_Data ()#line:3626
        O0O000O00OOO00OO0 .fPROC_CalcHightLowPrice ()#line:3628
    def __init__ (O0OOO0OOOO0OO00O0 ,OO00O0O0000O0O0OO :bool )->None :#line:3630
        O0OOO0OOOO0OO00O0 .fPROC_CalcHightLowPrice =O0OOO0OOOO0OO00O0 .CalcHightLowPrice_None #line:3632
        if OO00O0O0000O0O0OO :#line:3633
            O0OOO0OOOO0OO00O0 .fPROC_CalcHightLowPrice =O0OOO0OOOO0OO00O0 .CalcHightLowPrice #line:3634
        super ().__init__ ()#line:3635
    def __str__ (OO00OO0OOOOOO0O00 )->str :#line:3637
        return f"""SolICE:{OO00OO0OOOOOO0O00.SolICE} SysTime:{OO00OO0OOOOOO0O00.SysTime} DataTime:{OO00OO0OOOOOO0O00.DataTime} QtSrc:{OO00OO0OOOOOO0O00.QtSrc} DealTime:{OO00OO0OOOOOO0O00.DealTime}"""+"""DealShowMark:{self.DealShowMark} TotQty:{self.TotQty} SumBuyDealCount:{self.SumBuyDealCount} SumSellDealCount:{self.SumSellDealCount}"""+"""DealCount:{self.DealCount} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} DayHighOrg:{self.DayHighOrg}"""+"""DayLowOrg:{self.DayLowOrg} OpenPriceOrg:{self.OpenPriceOrg} ClosePriceOrg:{self.ClosePriceOrg} SettlePriceOrg:{self.SettlePriceOrg}"""+"""fDealPrice:{self.fDealPrice} HighPrice:{self.HighPrice} LowPrice:{self.LowPrice}"""#line:3642
class TOvsFutQt5Q (TOvsFutQtDef ):#line:3643
    f5Q =[]#line:3644
    SolICE :str #line:3646
    "台新行情代碼(NQ.202212)"#line:3647
    DataTime :str #line:3648
    "資料時間(交易所給的)(EX:14:32:19.676684)"#line:3649
    QtSrc :str #line:3650
    "行情來源(EX:PATS.NQ/CQG.NQ)"#line:3651
    fAryB5Q_P =[4 ,6 ,8 ,10 ,12 ,24 ,26 ,28 ,30 ,32 ]#line:3653
    "買五檔價在字串中的位置"#line:3654
    fAryB5Q_Q =[5 ,7 ,9 ,11 ,13 ,25 ,27 ,29 ,31 ,33 ]#line:3655
    "買五檔價在字串中的位置"#line:3656
    fB5QCount :int =10 #line:3657
    "買5檔的檔數"#line:3658
    def B5Q_POrg (OO00OOO000OO0OO00 ,OOO000O0OOOOO00O0 :int ):#line:3660
        ""#line:3661
        if OOO000O0OOOOO00O0 >OO00OOO000OO0OO00 .fB5QCount :#line:3662
            return ""#line:3663
        elif OO00OOO000OO0OO00 .f5Q ==None :#line:3664
            return ""#line:3665
        else :#line:3666
            return OO00OOO000OO0OO00 .f5Q [OO00OOO000OO0OO00 .fAryB5Q_P [OOO000O0OOOOO00O0 -1 ]]#line:3667
    def Set_B5Q_P (OO0O0000O0000OOOO ,OOO000O000OO0O0O0 :int ):#line:3669
        ""#line:3670
        if OOO000O000OO0O0O0 >OO0O0000O0000OOOO .fB5QCount :#line:3671
            return 0 #line:3672
        elif OO0O0000O0000OOOO .f5Q ==None :#line:3673
            return 0 #line:3674
        else :#line:3675
            return OO0O0000O0000OOOO .TransPrice2Dec (OO0O0000O0000OOOO .f5Q [OO0O0000O0000OOOO .fAryB5Q_P [OOO000O000OO0O0O0 -1 ]])#line:3676
    def Get_B5Q_P (O0O0OO0OOO0O00OO0 ,OO00O0OOOOOO000O0 :int ):#line:3678
        if O0O0OO0OOO0O00OO0 .f5Q ==None :#line:3679
            return 0 #line:3680
        O000O000000OOOO00 :decimal =0 #line:3681
        O000O000000OOOO00 =O0O0OO0OOO0O00OO0 .TransPrice2Dec (O0O0OO0OOO0O00OO0 .f5Q [O0O0OO0OOO0O00OO0 .fAryB5Q_P [OO00O0OOOOOO000O0 -1 ]])#line:3682
        return O000O000000OOOO00 #line:3683
    def GetDply_B5Q_P (O00O000O000000OO0 ,OO000O0000000OOO0 :int ,aDg_tPrice :str =""):#line:3685
        if OO000O0000000OOO0 >O00O000O000000OO0 .fB5QCount :#line:3686
            return ""#line:3687
        elif O00O000O000000OO0 .f5Q ==None :#line:3688
            return ""#line:3689
        else :#line:3690
            O0OO000O0O00O0OO0 :decimal =0 #line:3691
            O0OO000O0O00O0OO0 =O00O000O000000OO0 .TransPrice2Dec (O00O000O000000OO0 .f5Q [O00O000O000000OO0 .fAryB5Q_P [OO000O0000000OOO0 -1 ]])#line:3692
            return O00O000O000000OO0 .TransPrice2Str (O0OO000O0O00O0OO0 ,aDg_tPrice )#line:3693
    def B5Q_QOrg (O00O0OOOOOOO00O0O ,O000OOO0O0O0O00OO :int ):#line:3695
        ""#line:3696
        if O000OOO0O0O0O00OO >O00O0OOOOOOO00O0O .fB5QCount :#line:3697
            return ""#line:3698
        elif O00O0OOOOOOO00O0O .f5Q ==None :#line:3699
            return ""#line:3700
        else :#line:3701
            return O00O0OOOOOOO00O0O .f5Q [O00O0OOOOOOO00O0O .fAryB5Q_Q [O000OOO0O0O0O00OO -1 ]]#line:3702
    def Set_B5Q_Q (O00000O0OO0000000 ,O0O00000O00000O0O :int ):#line:3704
        ""#line:3705
        if O0O00000O00000O0O >O00000O0OO0000000 .fB5QCount :#line:3707
            return 0 #line:3708
        elif O00000O0OO0000000 .f5Q ==None :#line:3709
            return 0 #line:3710
        else :#line:3711
            return O00000O0OO0000000 .TransToInt (O00000O0OO0000000 .f5Q [O00000O0OO0000000 .fAryB5Q_Q [O0O00000O00000O0O -1 ]])#line:3712
    def Get_B5Q_Q (O0OOO00O000OO0OO0 ,OO00OO0O00OO0O0OO :int ):#line:3714
        OO000O000O00OOOOO :int =0 #line:3716
        OO000O000O00OOOOO =O0OOO00O000OO0OO0 .Set_B5Q_Q (OO00OO0O00OO0O0OO )#line:3717
        return str (OO000O000O00OOOOO )#line:3718
    fAryS5Q_P =[14 ,16 ,18 ,20 ,22 ,34 ,36 ,38 ,40 ,42 ]#line:3721
    "買五檔價在字串中的位置"#line:3722
    fAryS5Q_Q =[15 ,17 ,19 ,21 ,23 ,35 ,37 ,39 ,41 ,43 ]#line:3723
    "買五檔價在字串中的位置"#line:3724
    fS5QCount :int =10 #line:3725
    "賣5檔的檔數"#line:3726
    def S5Q_POrg (O0O00O0OOO00OOOO0 ,O0O0000000OO000OO :int ):#line:3728
        ""#line:3729
        if O0O0000000OO000OO >O0O00O0OOO00OOOO0 .fS5QCount :#line:3730
            return ""#line:3731
        elif O0O00O0OOO00OOOO0 .f5Q ==None :#line:3732
            return ""#line:3733
        else :#line:3734
            return O0O00O0OOO00OOOO0 .f5Q [O0O00O0OOO00OOOO0 .fAryS5Q_P [O0O0000000OO000OO -1 ]]#line:3735
    def Set_S5Q_P (O00O0O000O000OO0O ,O00O00OOO0OOO000O :int ):#line:3737
        ""#line:3738
        if O00O00OOO0OOO000O >O00O0O000O000OO0O .fS5QCount :#line:3739
            return 0 #line:3740
        elif O00O0O000O000OO0O .f5Q ==None :#line:3741
            return 0 #line:3742
        else :#line:3743
            return O00O0O000O000OO0O .TransPrice2Dec (O00O0O000O000OO0O .f5Q [O00O0O000O000OO0O .fAryS5Q_P [O00O00OOO0OOO000O -1 ]])#line:3744
    def Get_S5Q_P (O00O000OO000O0O0O ,O0O000OOOO0O0OOOO :int ):#line:3746
        if O00O000OO000O0O0O .f5Q ==None :#line:3747
            return 0 #line:3748
        O00OOOOOOO0O00OO0 :decimal =0 #line:3749
        O00OOOOOOO0O00OO0 =O00O000OO000O0O0O .TransPrice2Dec (O00O000OO000O0O0O .f5Q [O00O000OO000O0O0O .fAryS5Q_P [O0O000OOOO0O0OOOO -1 ]])#line:3750
        return O00OOOOOOO0O00OO0 #line:3751
    def GetDply_S5Q_P (O0OOOOO00000OO00O ,O0OOO000OOOOOO0O0 :int ,aDg_tPrice :str =""):#line:3753
        if O0OOO000OOOOOO0O0 >O0OOOOO00000OO00O .fS5QCount :#line:3754
            return ""#line:3755
        elif O0OOOOO00000OO00O .f5Q ==None :#line:3756
            return ""#line:3757
        else :#line:3758
            OO0OOOO000OO00O00 :decimal =0 #line:3759
            OO0OOOO000OO00O00 =O0OOOOO00000OO00O .TransPrice2Dec (O0OOOOO00000OO00O .f5Q [O0OOOOO00000OO00O .fAryS5Q_P [O0OOO000OOOOOO0O0 -1 ]])#line:3760
            return O0OOOOO00000OO00O .TransPrice2Str (OO0OOOO000OO00O00 ,aDg_tPrice )#line:3761
    def S5Q_QOrg (OO000OO0O000OO0OO ,OO0OOO000OOOOOO00 :int ):#line:3763
        ""#line:3764
        if OO0OOO000OOOOOO00 >OO000OO0O000OO0OO .fS5QCount :#line:3765
            return ""#line:3766
        elif OO000OO0O000OO0OO .f5Q ==None :#line:3767
            return ""#line:3768
        else :#line:3769
            return OO000OO0O000OO0OO .f5Q [OO000OO0O000OO0OO .fAryS5Q_Q [OO0OOO000OOOOOO00 -1 ]]#line:3770
    def Set_S5Q_Q (OOOOOO000OOO0OOOO ,OO000000O0OO00O00 :int ):#line:3772
        ""#line:3773
        if OO000000O0OO00O00 >OOOOOO000OOO0OOOO .fS5QCount :#line:3774
            return 0 #line:3775
        elif OOOOOO000OOO0OOOO .f5Q ==None :#line:3776
            return 0 #line:3777
        else :#line:3778
            return OOOOOO000OOO0OOOO .TransToInt (OOOOOO000OOO0OOOO .f5Q [OOOOOO000OOO0OOOO .fAryS5Q_Q [OO000000O0OO00O00 -1 ]])#line:3779
    def Get_S5Q_Q (O0OOOO00O0OOO00OO ,OOO00O0OOO0OOOO00 :int ):#line:3781
        O0O000OO0O00OOO00 :int =0 #line:3782
        O0O000OO0O00OOO00 =O0OOOO00O0OOO00OO .Set_S5Q_Q (OOO00O0OOO0OOOO00 )#line:3783
        return str (O0O000OO0O00OOO00 )#line:3784
    def Handle_5Q (O0O0O00000O00O0OO ,OOO0OO000O00O00O0 :str ):#line:3787
        O0O0O00000O00O0OO .f5Q =OOO0OO000O00O00O0 .split ('|')#line:3788
        O0O0O00000O00O0OO .SetData ()#line:3789
    def SetData (O0O000O0OO0000OOO ):#line:3791
        O0O000O0OO0000OOO .SolICE =O0O000O0OO0000OOO .f5Q [0 ]#line:3792
        O0O000O0OO0000OOO .DataTime =O0O000O0OO0000OOO .f5Q [2 ]#line:3793
        O0O000O0OO0000OOO .QtSrc =O0O000O0OO0000OOO .f5Q [3 ]#line:3794
    def __init__ (OOO0OO0O00O0O00OO )->None :#line:3796
        pass #line:3797
    def __str__ (OOOO000OOO0OOO000 )->str :#line:3799
        return f"SolICE:{OOOO000OOO0OOO000.SolICE} DataTime:{OOOO000OOO0OOO000.DataTime} QtSrc:{OOOO000OOO0OOO000.QtSrc} f5Q:{OOOO000OOO0OOO000.f5Q}"#line:3800
class TOvsFutQuoteData :#line:3801
    SolIce :str =""#line:3802
    ProdKind :TOvsFutProdKind =TOvsFutProdKind .pkNone #line:3804
    BAS :TOvsFutQtBase =None #line:3806
    QtTX :TOvsFutQtTX =None #line:3807
    Qt5Q :TOvsFutQt5Q =None #line:3808
    def __init__ (OO0O0000O00OOO0O0 ,OOO0OO0OOO0OO00O0 :TOvsFutProdKind ,OOO00OO0OOOO00O0O :str ,O00OO000O000O0000 :bool ):#line:3810
        ""#line:3811
        OO0O0000O00OOO0O0 .SolIce =OOO00OO0OOOO00O0O #line:3812
        OO0O0000O00OOO0O0 .ProdKind =OOO0OO0OOO0OO00O0 #line:3813
        OO0O0000O00OOO0O0 ._lock =Lock ()#line:3814
        if OOO0OO0OOO0OO00O0 ==TOvsFutProdKind .pkNormal :#line:3815
            OO0O0000O00OOO0O0 .BAS =TOvsFutQtBase ()#line:3816
            OO0O0000O00OOO0O0 .QtTX =TOvsFutQtTX (O00OO000O000O0000 )#line:3817
            OO0O0000O00OOO0O0 .Qt5Q =TOvsFutQt5Q ()#line:3818
        elif OOO0OO0OOO0OO00O0 ==TOvsFutProdKind .pkIndex :#line:3819
            pass #line:3820
    def SetDataInit (OOO0OO00OO00O00OO ):#line:3822
        ""#line:3823
        if OOO0OO00OO00O00OO .ProdKind ==TOvsFutProdKind .pkNormal :#line:3824
            OOO0OO00OO00O00OO .QtTX .DecimalMultiply =OOO0OO00OO00O00OO .BAS .DecimalMultiply #line:3825
            OOO0OO00OO00O00OO .Qt5Q .DecimalMultiply =OOO0OO00OO00O00OO .BAS .DecimalMultiply #line:3826
            OOO0OO00OO00O00OO .QtTX .Price_Denominator =OOO0OO00OO00O00OO .BAS .Price_Denominator #line:3827
            OOO0OO00OO00O00OO .Qt5Q .Price_Denominator =OOO0OO00OO00O00OO .BAS .Price_Denominator #line:3828
class TMapOvsFutQuoteData (UserDict ):#line:3830
    ""#line:3831
    def __init__ (OOO0O000000O000O0 ,mapping =None ,**O000000OOOO0OOOOO ):#line:3832
        if mapping is not None :#line:3833
            mapping ={str (O0O00000OOO0OO00O ).upper ():OO000OOOOO0O0O0O0 for O0O00000OOO0OO00O ,OO000OOOOO0O0O0O0 in mapping .items ()}#line:3836
        else :#line:3837
            mapping ={}#line:3838
        if O000000OOOO0OOOOO :#line:3839
            mapping .update ({str (O000O0O0O00OOOO0O ).upper ():O00OO0OO00OO0O0O0 for O000O0O0O00OOOO0O ,O00OO0OO00OO0O0O0 in O000000OOOO0OOOOO .items ()})#line:3842
        OOO0O000000O000O0 .MapQtProc ={}#line:3843
        super ().__init__ (mapping )#line:3844
    def __setitem__ (OO00O0000O000O0O0 ,O00O00OOOO0O0O00O ,OOOO000OOOO00O0OO ):#line:3846
        super ().__setitem__ (O00O00OOOO0O0O00O ,OOOO000OOOO00O0OO )#line:3847
class TObjOvsFutQuoteMap (UserDict ):#line:3849
    DefProc_TX :callable =None #line:3851
    "成交行情解析proc"#line:3852
    DefProc_5Q :callable =None #line:3853
    "五檔行情解析proc"#line:3854
    def __init__ (O0OOOO00000000OOO ,mapping =None ,**O0OOOO0OOOO00OO0O ):#line:3856
        if mapping is not None :#line:3857
            mapping ={str (OO00OOO00O00O0O00 ).upper ():OO0OO00O000OO0O0O for OO00OOO00O00O0O00 ,OO0OO00O000OO0O0O in mapping .items ()}#line:3860
        else :#line:3861
            mapping ={}#line:3862
        if O0OOOO0OOOO00OO0O :#line:3863
            mapping .update ({str (O0000000OOOOOOO00 ).upper ():OO0O00O0O0OO0O00O for O0000000OOOOOOO00 ,OO0O00O0O0OO0O00O in O0OOOO0OOOO00OO0O .items ()})#line:3866
        O0OOOO00000000OOO .MapQtProc ={}#line:3869
        "各商品拆解行情proc(EX:NQ的TX與5Q, 行情拆解,是不同Proc)"#line:3870
        super ().__init__ (mapping )#line:3871
    def __setitem__ (OOO0O0OO00O0O000O ,OOOO000OOO00OO00O ,O0OO0O0O000OO0O0O ):#line:3873
        super ().__setitem__ (OOOO000OOO00OO00O ,O0OO0O0O000OO0O0O )#line:3874
    def AddRcvData (OO00000O000O0O00O ,O0000OO0O0O0O0O0O :str ,OOO0OO0O00OO0OO0O :str ,O00O0O00O0OO0OOOO :bool ):#line:3876
        ""#line:3880
        O0O00O0O0O0OO0OO0 =""#line:3882
        OO000OO0O00O000O0 :TOvsFutQuoteData =None #line:3883
        try :#line:3884
            OO0OOO00O00OOO0O0 =json .loads (OOO0OO0O00OO0OO0O )#line:3885
            if "status"in OO0OOO00O00OOO0O0 and len (OO0OOO00O00OOO0O0 ["status"])>0 :#line:3887
                if OO0OOO00O00OOO0O0 ["status"][0 ]=="error":#line:3888
                    O0O00O0O0O0OO0OO0 =f"[海期][AddRcvData](aSolIce={O0000OO0O0O0O0O0O}, aData={OOO0OO0O00OO0OO0O})行情回補資料有誤!"#line:3889
                    return False ,OO000OO0O00O000O0 ,O0O00O0O0O0OO0OO0 #line:3890
            if "BAS"in OO0OOO00O00OOO0O0 and len (OO0OOO00O00OOO0O0 ["BAS"])==0 :#line:3891
                O0O00O0O0O0OO0OO0 =f"[海期][AddRcvData](aSolIce={O0000OO0O0O0O0O0O}, aData={OOO0OO0O00OO0OO0O})沒有BAS資料!"#line:3892
                return False ,OO000OO0O00O000O0 ,O0O00O0O0O0OO0OO0 #line:3893
            if OO00000O000O0O00O .data .get (O0000OO0O0O0O0O0O )is None :#line:3896
                OO0OOO0OO0O00OO00 =TOvsFutQuoteData (TOvsFutProdKind .pkNormal ,O0000OO0O0O0O0O0O ,O00O0O00O0OO0OOOO )#line:3898
                OO0OOO0OO0O00OO00 .BAS .Handle_BAS (OO0OOO00O00OOO0O0 ["BAS"][0 ])#line:3899
                OO0OOO0OO0O00OO00 .SetDataInit ()#line:3901
                OO000OO0O00O000O0 =OO0OOO0OO0O00OO00 #line:3902
                OO00000O000O0O00O [O0000OO0O0O0O0O0O ]=OO0OOO0OO0O00OO00 #line:3903
                return True ,OO000OO0O00O000O0 ,""#line:3904
            else :#line:3905
                OO0OOO0OO0O00OO00 :TOvsFutQuoteData =OO00000O000O0O00O [O0000OO0O0O0O0O0O ]#line:3906
                with OO0OOO0OO0O00OO00 ._lock :#line:3907
                    OO0OOO0OO0O00OO00 .BAS .Handle_BAS (OO0OOO00O00OOO0O0 ["BAS"][0 ])#line:3908
                    OO0OOO0OO0O00OO00 .SetDataInit ()#line:3910
                    OO000OO0O00O000O0 =OO0OOO0OO0O00OO00 #line:3911
                return True ,OO000OO0O00O000O0 ,""#line:3912
        except Exception as OO0O0O0O0OO00000O :#line:3913
            O0O00O0O0O0OO0OO0 =f"[海期][AddRcvData](aSolIce={O0000OO0O0O0O0O0O}, aData={OOO0OO0O00OO0OO0O}){OO0O0O0O0OO00000O}"#line:3914
        return False ,OO000OO0O00O000O0 ,O0O00O0O0O0OO0OO0 #line:3915
    def AddData (O00000OO00000OOOO ,O0OOO0OOO000OOO00 :TOvsFutProdKind ,O0O00OOO00O00000O :str ,O00OOOOO0OOOO0O0O :bool ,OOO0OOOO000000OO0 :str ,O00000OOO0OOOOO00 :callable ):#line:3917
        ""#line:3921
        try :#line:3922
            if O00000OO00000OOOO .data .get (O0O00OOO00O00000O )is None :#line:3923
                O00O0000OOOOO000O =TOvsFutQuoteData (O0OOO0OOO000OOO00 ,O0O00OOO00O00000O ,O00OOOOO0OOOO0O0O )#line:3924
                O00000OO00000OOOO [OOO0OOOO000000OO0 ]=O00O0000OOOOO000O #line:3925
                if O00000OO00000OOOO .MapQtProc .get (OOO0OOOO000000OO0 )is None :#line:3927
                    O00000OO00000OOOO .MapQtProc [OOO0OOOO000000OO0 ]=O00000OOO0OOOOO00 #line:3928
                return True #line:3930
            else :#line:3931
                return True #line:3932
        except Exception as O000OOOO00O00OO0O :#line:3933
            pass #line:3934
        return False #line:3935
    def AddDataBySolIce (OO0O0OOO00OO0OOO0 ,OO0OOOOOOO0O0OOOO :bool ,O0OO0O00OOOO0000O :str ,OOOOO000O0000OO0O ,O00000OOOO0OOOOOO :bool ):#line:3937
        ""#line:3945
        OO0OO0OO0O00O0O0O =""#line:3946
        OOO00OOOOO0O0000O :TOvsFutQuoteData =None #line:3947
        try :#line:3948
            OOO00OOOOO0O0000O =TMapOvsFutQuoteData ()#line:3950
            for OO0OOOO0O0O0O0OO0 in OOOOO000O0000OO0O ["BAS"]:#line:3951
                O00OOOO0000OOO000 =TOvsFutQtBase ()#line:3952
                O00OOOO0000OOO000 .Handle_BAS (OO0OOOO0O0O0O0OO0 )#line:3953
                if OOO00OOOOO0O0000O .data .get (O00OOOO0000OOO000 .Symbol ):#line:3955
                    O0000OO0OOO0O0000 =TOvsFutQuoteData (TOvsFutProdKind .pkNormal ,O00OOOO0000OOO000 .Symbol ,O00000OOOO0OOOOOO )#line:3956
                    O0000OO0OOO0O0000 .BAS =O00OOOO0000OOO000 #line:3957
                    O0000OO0OOO0O0000 .SetDataInit ()#line:3958
                    O00O000OOO00O000O :OO0OOOO0O0O0O0OO0 =O0000OO0OOO0O0000 .BAS .TopicTX #line:3960
                    OOOO0OO00000OOOOO :OO0OOOO0O0O0O0OO0 =O0000OO0OOO0O0000 .BAS .Topic5Q #line:3961
                    OO0O0OOO00OO0OOO0 [O00O000OOO00O000O ]=O0000OO0OOO0O0000 #line:3963
                    OO0O0OOO00OO0OOO0 [OOOO0OO00000OOOOO ]=O0000OO0OOO0O0000 #line:3964
                    if OO0O0OOO00OO0OOO0 .MapQtProc .get (O00O000OOO00O000O )is None :#line:3966
                        OO0O0OOO00OO0OOO0 .MapQtProc [O00O000OOO00O000O ]=OO0O0OOO00OO0OOO0 .DefProc_TX #line:3967
                    if OO0O0OOO00OO0OOO0 .MapQtProc .get (OOOO0OO00000OOOOO )is None :#line:3968
                        OO0O0OOO00OO0OOO0 .MapQtProc [OOOO0OO00000OOOOO ]=OO0O0OOO00OO0OOO0 .DefProc_5Q #line:3969
                    OOO00OOOOO0O0000O .Add (O00OOOO0000OOO000 .Symbol ,O0000OO0OOO0O0000 )#line:3971
            return len (OOO00OOOOO0O0000O )>0 ,OOO00OOOOO0O0000O ,OO0OO0OO0O00O0O0O #line:3972
        except Exception as O0OOOO0OO0OO00000 :#line:3974
            OO0OO0OO0O00O0O0O =f"[海期][AddDataBySolIce](aIsCat={OO0OOOOOOO0O0OOOO}, aSolIce={O0OO0O00OOOO0000O}){O0OOOO0OO0OO00000}"#line:3975
        return False ,OOO00OOOOO0O0000O ,OO0OO0OO0O00O0O0O #line:3976
    def GetItem_BySolIce (OOO0O0OOO0O0OO0O0 ,O0OOO00000OOOO0O0 :str ):#line:3978
        ""#line:3981
        O0OOO0O00O0O00000 :str =""#line:3983
        OOOO000O0O00O000O =None #line:3984
        try :#line:3985
            O00OO0OOOO0O00O00 =[]#line:3986
            for O0OOOO00OO00O0OOO ,O0O0O0O00OO0O000O in OOO0O0OOO0O0OO0O0 .items ():#line:3987
                O000O0O0O00O0OO0O :TOvsFutQuoteData =O0O0O0O00OO0O000O #line:3988
                if O000O0O0O00O0OO0O .SolIce ==O0OOO00000OOOO0O0 :#line:3989
                    O00OO0OOOO0O00O00 .append (O0OOOO00OO00O0OOO )#line:3990
            OOOO000O0O00O000O =O00OO0OOOO0O00O00 #line:3992
            if OOOO000O0O00O000O is None or len (OOOO000O0O00O000O )==0 :#line:3993
                O0OOO0O00O0O00000 =f"[海期][GetItem_BySolIce](aSolIce={O0OOO00000OOOO0O0})商品已不存存!"#line:3994
                return False ,OOOO000O0O00O000O ,O0OOO0O00O0O00000 #line:3995
            return True ,OOOO000O0O00O000O ,O0OOO0O00O0O00000 #line:3996
        except Exception as O0O0OO0OO0OO00O0O :#line:3997
            O0OOO0O00O0O00000 =f"[海期][GetItem_BySolIce](aSolIce={O0OOO00000OOOO0O0}){O0O0OO0OO0OO00O0O}"#line:3998
        return False ,OOOO000O0O00O000O ,O0OOO0O00O0O00000 #line:3999
    def GetItem_ByExchange (OO0OO0OOO00O0000O ,OO0OOO0OO00O00O00 :str ):#line:4000
        ""#line:4001
        OO0OOO0O0000O00OO =""#line:4002
        OO0O000OO0000O00O =None #line:4003
        try :#line:4004
            OO000OOO0OO0OOO00 =[]#line:4005
            for OO000OOOO00OO0OOO ,O0OOOOOOO0O0O00OO in OO0OO0OOO00O0000O .items ():#line:4006
                OO000OO000O0O0000 :TOvsFutQuoteData =O0OOOOOOO0O0O00OO #line:4007
                if OO000OO000O0O0000 .BAS .Exchange ==OO0OOO0OO00O00O00 :#line:4008
                    OO000OOO0OO0OOO00 .append (OO000OOOO00OO0OOO )#line:4009
                OO0O000OO0000O00O =OO000OOO0OO0OOO00 #line:4010
            if OO0O000OO0000O00O is None or len (OO0O000OO0000O00O )==0 :#line:4011
                OO0OOO0O0000O00OO =f"[海期][GetItem_ByExchange](aExchange={OO0OOO0OO00O00O00})商品已不存存!"#line:4012
                return False ,OO0O000OO0000O00O ,OO0OOO0O0000O00OO #line:4013
            return True ,OO0O000OO0000O00O ,OO0OOO0O0000O00OO #line:4015
        except Exception as O000OOO0000OO0OOO :#line:4017
            OO0OOO0O0000O00OO =f"[海期][GetItem_ByExchange](aExchange={OO0OOO0OO00O00O00}){O000OOO0000OO0OOO}"#line:4018
        return False ,OO0O000OO0000O00O ,OO0OOO0O0000O00OO #line:4019
class TObjOvsFutProdMthMap (UserDict ):#line:4024
    ""#line:4026
    def __init__ (OO00OOO000O0O00O0 ,OOOO0O0O0O0O0OOOO :str ,OOO0OOOO00OO0O0OO :str ):#line:4028
        OO00OOO000O0O00O0 .Exchange =OOOO0O0O0O0O0OOOO #line:4029
        OO00OOO000O0O00O0 .ExchangeName =OOO0OOOO00OO0O0OO #line:4030
        O00O00OO000O0OOO0 ={}#line:4031
        super ().__init__ (O00O00OO000O0OOO0 )#line:4032
    def __setitem__ (OOO0O00O00000OOO0 ,O0O0000OOOOO0OOOO ,O000O0OOOO0OO0O00 ):#line:4034
        super ().__setitem__ (O0O0000OOOOO0OOOO ,O000O0OOOO0OO0O00 )#line:4035
    def AddItem (O0O0O0OOO000OO0O0 ,OO0O0000O0O0O0OO0 :TOvsFutQtBase ):#line:4037
        if O0O0O0OOO000OO0O0 .data .get (OO0O0000O0O0O0OO0 .ProdID )is None :#line:4038
            O000000OOO0OO0000 =TObjOvsFutMthList (OO0O0000O0O0O0OO0 .ProdID ,OO0O0000O0O0O0OO0 .FutName )#line:4039
            O000000OOO0OO0000 .AddItem (OO0O0000O0O0O0OO0 )#line:4040
            O0O0O0OOO000OO0O0 [OO0O0000O0O0O0OO0 .ProdID ]=O000000OOO0OO0000 #line:4041
        else :#line:4042
            O000000OOO0OO0000 :TObjOvsFutMthList =O0O0O0OOO000OO0O0 [OO0O0000O0O0O0OO0 .ProdID ]#line:4043
            O000000OOO0OO0000 .AddItem (OO0O0000O0O0O0OO0 )#line:4044
class TObjOvsFutMthList (UserDict ):#line:4046
    ""#line:4048
    def __init__ (O000O0OOOOO0OO000 ,OOO000000000O0OO0 :str ,OOO0O00O0OOOO0OO0 :str ):#line:4050
        O000O0OOOOO0OO000 .ProdID =OOO000000000O0OO0 #line:4051
        O000O0OOOOO0OO000 .ProdName =OOO0O00O0OOOO0OO0 #line:4052
        OOO0O0O000OO00O00 ={}#line:4053
        super ().__init__ (OOO0O0O000OO00O00 )#line:4054
    def __setitem__ (OOOO00OOO0O00OO0O ,O0000O0O00O00O000 ,O0OOOO000OO0O0O0O ):#line:4056
        super ().__setitem__ (O0000O0O00O00O000 ,O0OOOO000OO0O0O0O )#line:4057
    def AddItem (OOOO0OOO0OOOOOO00 ,O0O0OOO0OO0O0O00O :TOvsFutQtBase ):#line:4059
        if OOOO0OOO0OOOOOO00 .data .get (O0O0OOO0OO0O0O00O .SettleMth )is None :#line:4060
            OOO0O00000O000OO0 :TObjOvsFutBasMap =TObjOvsFutBasMap (O0O0OOO0OO0O0O00O .SettleMth )#line:4061
            OOO0O00000O000OO0 .AddItem (O0O0OOO0OO0O0O00O )#line:4062
            OOOO0OOO0OOOOOO00 [O0O0OOO0OO0O0O00O .SettleMth ]=OOO0O00000O000OO0 #line:4063
        else :#line:4064
            OOO0O00000O000OO0 :TObjOvsFutBasMap =OOOO0OOO0OOOOOO00 [O0O0OOO0OO0O0O00O .SettleMth ]#line:4065
            OOO0O00000O000OO0 .AddItem (O0O0OOO0OO0O0O00O )#line:4066
        OOOO0OOO0OOOOOO00 .data =dict (sorted (OOOO0OOO0OOOOOO00 .data .items ()))#line:4067
class TObjOvsFutBasMap (UserDict ):#line:4069
    ""#line:4070
    def __init__ (OO000O0O0O0OO000O ,OO00O0O00OOOO0000 :str ):#line:4072
        OO000O0O0O0OO000O .SettleMth =OO00O0O00OOOO0000 #line:4073
        O0O0OOOO0O0O00O0O ={}#line:4074
        super ().__init__ (O0O0OOOO0O0O00O0O )#line:4075
    def __setitem__ (O00OOO00OO00O0OO0 ,O0O0OO00O0OO00OOO ,O00OO0000OOOOO0O0 ):#line:4077
        super ().__setitem__ (O0O0OO00O0OO00OOO ,O00OO0000OOOOO0O0 )#line:4078
    def AddItem (OO00OOOO0O000OO0O ,O00O0OOO00O0O0OOO :TOvsFutQtBase ):#line:4080
        if OO00OOOO0O000OO0O .data .get (O00O0OOO00O0O0OOO .SolICE )is None :#line:4081
            OO00OOOO0O000OO0O [O00O0OOO00O0O0OOO .SolICE ]=O00O0OOO00O0O0OOO #line:4082
class TObjBaseOvsFutExchageTree (UserDict ):#line:4084
    ""#line:4086
    fProdMthList :TObjOvsFutProdMthMap =TObjOvsFutProdMthMap ("","")#line:4087
    "Key=ProdID, Values=可交易月份們"#line:4088
    fMapSolICE ={}#line:4090
    "Key=SolICE Dictionary<string, TOvsFutQtBase>()"#line:4091
    def __init__ (OO0O000O0OOOO0000 ):#line:4093
        OOO000OOOOOOO00OO ={}#line:4094
        super ().__init__ (OOO000OOOOOOO00OO )#line:4095
    def __setitem__ (O0O000O00OOOO00OO ,OO000000O0OOOOO0O ,O0OOOO0O0OO0O00O0 ):#line:4097
        super ().__setitem__ (OO000000O0OOOOO0O ,O0OOOO0O0OO0O00O0 )#line:4098
    def AddItem (OOOO000OO0OOOOOOO ,OOO0O00O0O0O00O00 :TOvsFutQtBase ):#line:4100
        if OOOO000OO0OOOOOOO .data .get (OOO0O00O0O0O00O00 .Exchange )is None :#line:4101
            O000OO0OO0OOOOO00 =TObjOvsFutProdMthMap (OOO0O00O0O0O00O00 .Exchange ,OOO0O00O0O0O00O00 .ExchangeName )#line:4103
            OOOO000OO0OOOOOOO [OOO0O00O0O0O00O00 .Exchange ]=O000OO0OO0OOOOO00 #line:4104
        else :#line:4105
            O000OO0OO0OOOOO00 :TObjOvsFutMthList =OOOO000OO0OOOOOOO [OOO0O00O0O0O00O00 .Exchange ]#line:4106
            O000OO0OO0OOOOO00 .AddItem (OOO0O00O0O0O00O00 )#line:4107
    def SetInit (O0O0OO0OOOOO0O00O ):#line:4109
        try :#line:4110
            for OOOOO0O0O0O00O0OO in O0O0OO0OOOOO0O00O .values ():#line:4112
                O0O0O0000O0O0OOOO :TObjOvsFutProdMthMap #line:4113
                O0O0O0000O0O0OOOO =OOOOO0O0O0O00O0OO #line:4114
                O0O00O00O0O00OO00 :TObjOvsFutMthList =next (iter (O0O0O0000O0O0OOOO .values ()),None )#line:4117
                if O0O00O00O0O00OO00 .ProdID in O0O0OO0OOOOO0O00O .fProdMthList :#line:4119
                    continue #line:4120
                O0O0OO0OOOOO0O00O .fProdMthList [O0O00O00O0O00OO00 .ProdID ]=O0O00O00O0O00OO00 #line:4123
                for OOO0000OO0OO0O00O in O0O00O00O0O00OO00 .values ():#line:4125
                    for OO0O00O0O00OO000O in OOO0000OO0OO0O00O .values ():#line:4126
                        O0O0OO0OOOOO0O00O .fMapSolICE [OO0O00O0O00OO000O .SolICE ]=OO0O00O0O00OO000O #line:4127
        except Exception as OO000OOO000OOO000 :#line:4128
            pass #line:4129
    def GetItem_BySolICE (O00O0O0OOOOOO0OO0 ,O0OOOO00OO00O0O0O :str ):#line:4131
        ""#line:4133
        O00OO0O0OO0OOOO0O =None #line:4134
        try :#line:4135
            if O00O0O0OOOOOO0OO0 .fMapSolICE .get (O0OOOO00OO00O0O0O )is not None :#line:4136
                O00OO0O0OO0OOOO0O =O00O0O0OOOOOO0OO0 .fMapSolICE [O0OOOO00OO00O0O0O ]#line:4137
                return True ,O00OO0O0OO0OOOO0O #line:4138
        except Exception as OO0OOO00OOO0O0OO0 :#line:4139
            pass #line:4140
        return False ,O00OO0O0OO0OOOO0O #line:4141
    def IsExists (OO0000OOO000O0OO0 ,OOO0OOO00O00OO000 :str ,OO0OO0O00OO0OO0OO :str ):#line:4143
        try :#line:4144
            if OO0000OOO000O0OO0 .fProdMthList .get (OOO0OOO00O00OO000 )is not None :#line:4145
                if OO0OO0O00OO0OO0OO in OO0000OOO000O0OO0 .fProdMthList [OOO0OOO00O00OO000 ]:#line:4146
                    return True #line:4147
        except Exception as OO0000OOO00OO00O0 :#line:4148
            pass #line:4149
        return False #line:4150
    def GetExchangeAndProdList (O000O0O000O00OOOO ):#line:4152
        ""#line:4155
        OOOO0O000O0O0O00O ={}#line:4156
        O0OO00O000OOO0OO0 ={}#line:4157
        try :#line:4158
            for OO00O0O00OOO00OO0 in O000O0O000O00OOOO .values ():#line:4160
                OOOO0O000O0O0O00O [OO00O0O00OOO00OO0 .Exchange ]=OO00O0O00OOO00OO0 .ExchangeName #line:4161
                for OOOO00000OO0OO0O0 in OO00O0O00OOO00OO0 .Values :#line:4162
                    O0OO00O000OOO0OO0 [OOOO00000OO0OO0O0 .ProdName ]=OOOO00000OO0OO0O0 #line:4163
            return True ,OOOO0O000O0O0O00O ,O0OO00O000OOO0OO0 #line:4164
        except Exception as O00OOO00O0O000O0O :#line:4166
            pass #line:4167
        return False ,OOOO0O000O0O0O00O ,O0OO00O000OOO0OO0 #line:4168
class ITQtRcvEventData :#line:4171
    SolIce :str #line:4172
    IsOK :bool #line:4173
    tmpRcvKind :TOvsFutQtRcvKind #line:4174
    tmpQt :TOvsFutQuoteData #line:4175
class TQtRcvEventData (ITQtRcvEventData ):#line:4177
    def __init__ (O000OO00OOOO00OOO )->None :#line:4178
        O000OO00OOOO00OOO .SolIce =""#line:4179
        O000OO00OOOO00OOO .IsOK =False #line:4180
        O000OO00OOOO00OOO .tmpQt =None #line:4181
        super ().__init__ ()#line:4182
    def SetRcvBAS_Succ (OOO0OOOOO0000O0OO ,O0O0O0000O0000OO0 :str ,OO000000000OOO0O0 :TOvsFutQuoteData ):#line:4184
        OOO0OOOOO0000O0OO .IsOK =True #line:4185
        OOO0OOOOO0000O0OO .SolIce =O0O0O0000O0000OO0 #line:4186
        OOO0OOOOO0000O0OO .tmpRcvKind =TOvsFutQtRcvKind .pkQtRcv_BAS #line:4187
        OOO0OOOOO0000O0OO .tmpQt =OO000000000OOO0O0 #line:4188
    def SetRcvBAS_Fail (OOOO0000OOO0000O0 ,O0OO000O0OOOOOOO0 :str ):#line:4190
        OOOO0000OOO0000O0 .IsOK =False #line:4191
        OOOO0000OOO0000O0 .SolIce =O0OO000O0OOOOOOO0 #line:4192
        OOOO0000OOO0000O0 .tmpRcvKind =TOvsFutQtRcvKind .pkQtRcv_BAS #line:4193
class ServiceEventHandler (ReconnectionListener ,ReconnectionAttemptListener ,ServiceInterruptionListener ):#line:4198
    def __init__ (O0O000000OOOOO00O ,O000OO0OOOO0OOOO0 :callable )->None :#line:4199
        O0O000000OOOOO00O ._callbackInterrupt =O000OO0OOOO0OOOO0 #line:4200
        super ().__init__ ()#line:4201
    def on_reconnected (O00O0O0O00O00OO00 ,OO0OO0O00000OOOOO :ServiceEvent ):#line:4203
        print ("\non_reconnected")#line:4204
        print (f"Error cause: {OO0OO0O00000OOOOO.get_cause()}")#line:4205
        print (f"Message: {OO0OO0O00000OOOOO.get_message()}")#line:4206
    def on_reconnecting (O00OOOOOO0O00O0O0 ,O00O00000OOOOO0OO :"ServiceEvent"):#line:4208
        print ("\non_reconnecting")#line:4209
        print (f"Error cause: {O00O00000OOOOO0OO.get_cause()}")#line:4210
        print (f"Message: {O00O00000OOOOO0OO.get_message()}")#line:4211
    def on_service_interrupted (OOO0OO0OO0O00OOOO ,O00O00O000OOO0O0O :"ServiceEvent"):#line:4213
        OOO0OO0OO0O00OOOO ._callbackInterrupt (f"Error cause: {O00O00O000OOO0O0O.get_cause()} Message: {O00O00O000OOO0O0O.get_message()}")#line:4217
class TerminationNotificationHandler (TerminationNotificationListener ):#line:4219
    def __init__ (O0000O0OOO000OO0O ,OO0OOO00O0000O000 :callable )->None :#line:4220
        O0000O0OOO000OO0O ._callbackfunc =OO0OOO00O0000O000 #line:4221
        super ().__init__ ()#line:4222
    def on_termination (O0000OO000O0O0OOO ,O0O00O0OOO00O0O00 :'TerminationNotificationEvent'):#line:4223
        O0000OO000O0O0OOO ._callbackfunc (f"Error cause:{O0O00O0OOO00O0O00.cause()} Message:{O0O00O0OOO00O0O00.message}")#line:4225
class TCacheJobMap (UserDict ):#line:4227
    ""#line:4228
    _Lock =Lock ()#line:4229
    def __init__ (OOOO00OOOOO00O0OO ,mapping =None ,**O00O00OO0OOOOOO0O ):#line:4230
        if mapping is not None :#line:4231
            mapping ={str (OO000OO00OO00000O ).upper ():OOOOOO0O00OO0OO00 for OO000OO00OO00000O ,OOOOOO0O00OO0OO00 in mapping .items ()}#line:4234
        else :#line:4235
            mapping ={}#line:4236
        if O00O00OO0OOOOOO0O :#line:4237
            mapping .update ({str (O000OOO0OO0OO000O ).upper ():OOO00000O00OO00O0 for O000OOO0OO0OO000O ,OOO00000O00OO00O0 in O00O00OO0OOOOOO0O .items ()})#line:4240
        super ().__init__ (mapping )#line:4241
    def __setitem__ (OOOO00OOO0OO0OO00 ,OOOOO0OO0O000OOO0 ,O00000O000O00O0O0 ):#line:4243
        super ().__setitem__ (OOOOO0OO0O000OOO0 ,O00000O000O00O0O0 )#line:4244
    def IsExists (OOOO0O000O00OOOO0 ,OO0OOOO00O0O0O00O )->bool :#line:4247
        with OOOO0O000O00OOOO0 ._Lock :#line:4248
            if OOOO0O000O00OOOO0 .data .get (OO0OOOO00O0O0O00O )is None :#line:4249
                return False #line:4250
            else :#line:4251
                return True #line:4252
    def AddRcvData (O0OOOOOO00O0OO0OO ,OO000OO0000O00O0O :'InboundMessage')->bool :#line:4254
        with O0OOOOOO00O0OO0OO ._Lock :#line:4256
            if O0OOOOOO00O0OO0OO .data .get (OO000OO0000O00O0O .get_cache_request_id ())is None :#line:4257
                return False #line:4258
            else :#line:4259
                O0OOOOOO00O0OO0OO .data [OO000OO0000O00O0O .get_cache_request_id ()]=OO000OO0000O00O0O #line:4260
                return True #line:4261
    def DeleteJob (OOO0O00OOOO00OOO0 ,OO000000OOOOOOOOO )->bool :#line:4263
        ""#line:4264
        OO00OOOO00O0O0000 =None #line:4265
        with OOO0O00OOOO00OOO0 ._Lock :#line:4266
            if OOO0O00OOOO00OOO0 .data .get (OO000000OOOOOOOOO )is None :#line:4267
                return False ,None #line:4268
            else :#line:4269
                OO00OOOO00O0O0000 =OOO0O00OOOO00OOO0 .data .pop (OO000000OOOOOOOOO )#line:4270
                return True ,OO00OOOO00O0O0000 #line:4271
class TCacheJob :#line:4273
    def __init__ (OO0OO0O00OOOO0O00 )->None :#line:4275
        OO0OO0O00OOOO0O00 .RequestID :int =0 #line:4276
        OO0OO0O00OOOO0O00 .prod :str =""#line:4277
        OO0OO0O00OOOO0O00 .oneProd :bool =True #line:4278
        OO0OO0O00OOOO0O00 .TopicBAS :str =""#line:4279
        OO0OO0O00OOOO0O00 .TopicHL :str =""#line:4280
        OO0OO0O00OOOO0O00 .TopicTX :str =""#line:4281
        OO0OO0O00OOOO0O00 .HandleProc :callable =None #line:4282
        OO0OO0O00OOOO0O00 .CacheData :dict ={}#line:4283
        OO0OO0O00OOOO0O00 .Params :dict ={}#line:4284
        OO0OO0O00OOOO0O00 .fTotCnt =10 #line:4286
        OO0OO0O00OOOO0O00 .fCurCnt =0 #line:4287
    def ReSet (OO000OOOO0OOO0OO0 )->bool :#line:4289
        ""#line:4290
        O0O0O0O0O00O0OOOO =""#line:4291
        if OO000OOOO0OOO0OO0 .fCurCnt >=OO000OOOO0OOO0OO0 .fTotCnt :#line:4292
            O0O0O0O0O00O0OOOO =f"已超過總執行次數:{OO000OOOO0OOO0OO0.fTotCnt}"#line:4293
            return False ,O0O0O0O0O00O0OOOO #line:4294
        OO000OOOO0OOO0OO0 .fCurCnt +=1 #line:4296
        return True ,""#line:4299
class SolAPI :#line:4302
    __O00OOOO000OO000OO ='solacelink.json'#line:4304
    __O0OOO0O00OO0OOOO0 ='solaceProperties'#line:4306
    __OOOOO00O000O00O00 =os .path .join (dirname (__file__ ),__O00OOOO000OO000OO )#line:4308
    _fPrdSnapshotMap :TMapPrdSnapshot =TMapPrdSnapshot ()#line:4312
    _fPrdOvsMap :TMapPrdOvs =TMapPrdOvs ()#line:4313
    _fMapQuoteSTK :TObjStkQuoteMap =TObjStkQuoteMap ()#line:4315
    _fMapQuoteFUT :TObjFutQuoteMap =TObjFutQuoteMap ()#line:4316
    _fMapQuoteOvsFUT :TObjOvsFutQuoteMap =TObjOvsFutQuoteMap ()#line:4317
    def __init__ (OO0OOOOO0OO0O0O0O ,__OOO0O0O00OOOO00O0 :MarketDataMart ,O00OO0OOOO000OO00 :str ,aRcvUseList :bool =False ,loglv =logging .INFO ,conlv =logging .INFO ):#line:4319
        ""#line:4320
        OO0OOOOO0OO0O0O0O .__O000OOO000000O0O0 =None #line:4323
        OO0OOOOO0OO0O0O0O .__O0OO00O000000OOOO =None #line:4324
        OO0OOOOO0OO0O0O0O .__O0O00000OOO0O000O =None #line:4325
        OO0OOOOO0OO0O0O0O .__O0OOOOO0OOOO0000O =None #line:4326
        OO0OOOOO0OO0O0O0O .__O0O000O000O0O00OO =aRcvUseList #line:4327
        OO0OOOOO0OO0O0O0O .__OOO0O0O00OOOO00O0 :MarketDataMart =__OOO0O0O00OOOO00O0 #line:4328
        OO0OOOOO0OO0O0O0O ._pypath =O00OO0OOOO000OO00 #line:4329
        OO0OOOOO0OO0O0O0O ._is_connected =False #line:4330
        OO0OOOOO0OO0O0O0O ._lock =Lock ()#line:4331
        OO0OOOOO0OO0O0O0O ._lockQtTX_Stk =Lock ()#line:4332
        OO0OOOOO0OO0O0O0O ._lockQtTX_Fut =Lock ()#line:4333
        OO0OOOOO0OO0O0O0O ._lockQtIDX_Stk =Lock ()#line:4334
        OO0OOOOO0OO0O0O0O ._lockQtIDX_Fut =Lock ()#line:4335
        OO0OOOOO0OO0O0O0O ._fMapQuoteSTK .DefProc_TX =OO0OOOOO0OO0O0O0O .__OO0OOOO0OO0O0OOOO #line:4338
        OO0OOOOO0OO0O0O0O ._fMapQuoteSTK .DefProc_5Q =OO0OOOOO0OO0O0O0O .__OOO00O0O00OOOO000 #line:4339
        OO0OOOOO0OO0O0O0O ._fMapQuoteSTK .DefProc_Idx =OO0OOOOO0OO0O0O0O .__OOO000O0O00000OO0 #line:4340
        OO0OOOOO0OO0O0O0O .__OOO0OOO000OO00000 =OO0OOOOO0OO0O0O0O .__OO0O000000000O00O #line:4341
        OO0OOOOO0OO0O0O0O .__OO0O00O000O0O0O0O =OO0OOOOO0OO0O0O0O .__OO0OOO000OOOOO0O0 #line:4342
        OO0OOOOO0OO0O0O0O .__O0O00OOO0000O000O =OO0OOOOO0OO0O0O0O .__OOO00O000000O00OO #line:4343
        OO0OOOOO0OO0O0O0O .__O0O000O0O0O0OOO00 =OO0OOOOO0OO0O0O0O .__OO0OOOO0O00O0O0O0 #line:4344
        OO0OOOOO0OO0O0O0O .__OO00OO0OO0O0O000O =OO0OOOOO0OO0O0O0O .__O0OO0000O0OO00OO0 #line:4345
        OO0OOOOO0OO0O0O0O ._fMapCacheJob =TCacheJobMap ()#line:4348
        OO0OOOOO0OO0O0O0O ._last_ReqID =0 #line:4349
        OO0OOOOO0OO0O0O0O ._lock_ReqID =Lock ()#line:4350
        OO0OOOOO0OO0O0O0O ._fMapQuoteFUT .DefProc_TX =OO0OOOOO0OO0O0O0O .__OOO0OO0O0O00O00OO #line:4351
        OO0OOOOO0OO0O0O0O ._fMapQuoteFUT .DefProc_5Q =OO0OOOOO0OO0O0O0O .__OOO000O000000000O #line:4352
        OO0OOOOO0OO0O0O0O ._fMapQuoteFUT .DefProc_5QTOT =OO0OOOOO0OO0O0O0O .__O0O0O0O00O00OO0O0 #line:4353
        OO0OOOOO0OO0O0O0O ._fMapQuoteFUT .DefProc_BAS =OO0OOOOO0OO0O0O0O .__OOO00OOO0OOO00O00 #line:4354
        OO0OOOOO0OO0O0O0O .__O00000000O0OO0O0O =OO0OOOOO0OO0O0O0O .__O0OOO000000OO000O #line:4355
        OO0OOOOO0OO0O0O0O .__O00000OOOOO0OO000 =OO0OOOOO0OO0O0O0O .__OO00000000O00O00O #line:4356
        OO0OOOOO0OO0O0O0O .__OOO00O00O0O0OOOOO =OO0OOOOO0OO0O0O0O .__O0O0O0000OO00O000 #line:4357
        OO0OOOOO0OO0O0O0O .__OO000OO0OOO0O0OO0 =OO0OOOOO0OO0O0O0O .__O0OOOOO0O0OOOO0O0 #line:4358
        OO0OOOOO0OO0O0O0O .__O0000000OO00O00OO =OO0OOOOO0OO0O0O0O .__O000O00000OOOO0OO #line:4359
        OO0OOOOO0OO0O0O0O .__O000O0OOO00O0O0OO =OO0OOOOO0OO0O0O0O .__O000O0000O0O0OOOO #line:4360
        OO0OOOOO0OO0O0O0O ._fMapQuoteOvsFUT .DefProc_TX =OO0OOOOO0OO0O0O0O .__OOO00O0OOOO0OOOOO #line:4362
        OO0OOOOO0OO0O0O0O ._fMapQuoteOvsFUT .DefProc_5Q =OO0OOOOO0OO0O0O0O .__OO0O00O0O0000OO00 #line:4363
        OO0OOOOO0OO0O0O0O .__O000000O0OO00OO0O =OO0OOOOO0OO0O0O0O .__O0O0O00OO000OO00O #line:4364
        OO0OOOOO0OO0O0O0O .__O0OOO00O000OO0OOO =OO0OOOOO0OO0O0O0O .__O000OOOOOOO0OO00O #line:4365
        OO0OOOOO0OO0O0O0O .__OOO0O0OOOO0O00O0O =OO0OOOOO0OO0O0O0O .__O0000000OO0000OO0 #line:4366
        OO0OOOOO0OO0O0O0O ._message_service :MessagingService #line:4368
        OO0OOOOO0OO0O0O0O ._message_receiver :DirectMessageReceiver #line:4369
        OO0OOOOO0OO0O0O0O ._message_requester :RequestReplyMessagePublisher #line:4371
        OO0OOOOO0OO0O0O0O ._loglv =loglv #line:4372
        OO0OOOOO0OO0O0O0O ._conlv =conlv #line:4373
        OO0OOOOO0OO0O0O0O ._log =SolaceLog (OO0OOOOO0OO0O0O0O ._pypath ,loglv ,conlv )#line:4374
        OO0OOOOO0OO0O0O0O ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"pypath:{O00OO0OOOO000OO00}, aRcvUseList:{aRcvUseList}, loglv:{loglv} conlv:{conlv}")#line:4375
        OO0OOOOO0OO0O0O0O ._reply_timeout =120000 #line:4381
        OO0OOOOO0OO0O0O0O ._vRcvTopic_Stk ="Quote_TWS_RECOVER"#line:4382
        "證券回補TOPIC"#line:4383
        OO0OOOOO0OO0O0O0O ._vRcvTopic_Stk_Req ="Quote_TWS_REQ"#line:4384
        "收到證券回補TOPIC"#line:4385
        OO0OOOOO0OO0O0O0O ._vRcvTopic_Fut ="Quote_TWF_RECOVER"#line:4386
        "期貨回補TOPIC"#line:4387
        OO0OOOOO0OO0O0O0O ._vRcvTopic_Fut_Req ="Quote_TWF_REQ"#line:4388
        "收到期貨回補TOPIC"#line:4389
        OO0OOOOO0OO0O0O0O ._vRcvTopic_OvsFut ="QuoteOvs_RECOVER"#line:4390
        "海期貨回補TOPIC"#line:4391
        OO0OOOOO0OO0O0O0O ._vRcvTopic_OvsFut_Req ="QuoteOvs_REQ"#line:4392
        "收到海期貨回補TOPIC"#line:4393
        OO0OOOOO0OO0O0O0O ._vExchange =""#line:4394
        OO0OOOOO0OO0O0O0O .__OOOOOO0OOO000OO0O ="Idx"#line:4395
        OO0OOOOO0OO0O0O0O ._vQuote_FUT ="Quote/TWF/"#line:4396
        OO0OOOOO0OO0O0O0O ._vQuote_STK ="Quote/TWS/"#line:4397
        OO0OOOOO0OO0O0O0O ._vQuote_OvsFUT ="QuoteOvs/"#line:4398
        OO0OOOOO0OO0O0O0O ._vQuote_BAS ="/BAS"#line:4399
        OO0OOOOO0OO0O0O0O ._vQuote_HL ="/HL"#line:4400
    def GetRequestID (O00000OOOO000OO00 ):#line:4402
        try :#line:4403
            with O00000OOOO000OO00 ._lock_ReqID :#line:4404
                O0000OO0O000OOOO0 =int (datetime .now ().strftime ("%y%m%d%H%M%S%f"))#line:4405
                if O0000OO0O000OOOO0 <=O00000OOOO000OO00 ._last_ReqID :#line:4406
                    O0000OO0O000OOOO0 =O00000OOOO000OO00 ._last_ReqID +1 #line:4407
                O00000OOOO000OO00 ._last_ReqID =O0000OO0O000OOOO0 #line:4408
                return O0000OO0O000OOOO0 #line:4409
        except Exception as O0O000OO0O0OOOOOO :#line:4410
            O00000OOOO000OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Error GetRequestID: {O0O000OO0O0OOOOOO}")#line:4411
    def __OO0O00O00O00O0OO0 ():#line:4413
        try :#line:4414
            with open (SolAPI .__OOOOO00O000O00O00 ,'r')as O00OOOOOO0OOOOOOO :#line:4415
                OOO0O000OO0O0000O =O00OOOOOO0OOOOOOO .read ()#line:4416
            return json .loads (OOO0O000OO0O0000O )#line:4418
        except Exception as OOO00O000O0OOOOOO :#line:4419
            raise Exception (f"Unable to read JSON in file: {SolAPI.__external_file_full_path}. Exception: {OOO00O000O0OOOOOO}")#line:4420
    def __O0O0O0O0O0OO00OO0 (O0OOO00OOOO0O0O0O :dict ):#line:4422
        if SolAPI .__O0OOO0O00OO0OOOO0 not in O0OOO00OOOO0O0O0O :#line:4423
            print (f'Solbroker details in [{SolAPI.__properties_from_external_file_name}] is unavailable, unable to find KEY: [{SolAPI.__solbroker_properties_key}]. Refer README...')#line:4424
        OO0O00OO0O0O000OO =O0OOO00OOOO0O0O0O [SolAPI .__O0OOO0O00OO0OOOO0 ]#line:4426
        return OO0O00OO0O0O000OO #line:4428
    __OOO0OOO000OO00000 :callable =None #line:4433
    __O00000000O0OO0O0O :callable =None #line:4434
    __O000000O0OO00OO0O :callable =None #line:4435
    def __O000O00O0000OOOO0 (OO0O0O00O0OO00O00 ,OOO0O00O0OO00O00O :STKxFUT ,OO0O00O0O00O0OO0O ):#line:4437
        ""#line:4439
        if OOO0O00O0OO00O00O ==STKxFUT .STK :#line:4440
            if OO0O0O00O0OO00O00 .__OOO0OOO000OO00000 ==None :#line:4441
                return #line:4442
            O0OO00O0OO00O0O0O :TObjStkQuoteMap =OO0O00O0O00O0OO0O #line:4443
            OO0O0O00O0OO00O00 .__OOO0OOO000OO00000 ("STK",True ,O0OO00O0OO00O0O0O )#line:4444
        elif OOO0O00O0OO00O00O ==STKxFUT .FUT :#line:4445
            if OO0O0O00O0OO00O00 .__O00000000O0OO0O0O ==None :#line:4446
                return #line:4447
            O0OO00O0OO00O0O0O :TObjFutQuoteMap =OO0O00O0O00O0OO0O #line:4448
            OO0O0O00O0OO00O00 .__O00000000O0OO0O0O ("FUT",True ,O0OO00O0OO00O0O0O )#line:4449
        elif OOO0O00O0OO00O00O ==STKxFUT .OVSFUT :#line:4450
            if OO0O0O00O0OO00O00 .__O000000O0OO00OO0O ==None :#line:4451
                return #line:4452
            O0OO00O0OO00O0O0O :TQtRcvEventData =OO0O00O0O00O0OO0O #line:4453
            if O0OO00O0OO00O0O0O .IsOK :#line:4454
                OO0O0O00O0OO00O00 .__O000000O0OO00OO0O (OO0O0O00O0OO00O00 ,O0OO00O0OO00O0O0O .SolIce ,O0OO00O0OO00O0O0O .IsOK ,O0OO00O0OO00O0O0O .tmpRcvKind ,O0OO00O0OO00O0O0O .tmpQt )#line:4456
            else :#line:4457
                OO0O0O00O0OO00O00 .__O000000O0OO00OO0O (OO0O0O00O0OO00O00 ,O0OO00O0OO00O0O0O .SolIce ,O0OO00O0OO00O0O0O .IsOK ,O0OO00O0OO00O0O0O .tmpRcvKind ,None )#line:4459
    def __O000OO0000OO00O00 (OOO0OOOO0OOO00000 ,OOO00O00O00O0OO0O :STKxFUT ,OOO0OO00O00000000 :str ):#line:4461
        if OOO00O00O00O0OO0O ==STKxFUT .STK :#line:4462
            if OOO0OOOO0OOO00000 .__OOO0OOO000OO00000 ==None :#line:4463
                return #line:4464
            OOO0OOOO0OOO00000 .__OOO0OOO000OO00000 (OOO0OO00O00000000 ,False ,None )#line:4465
        elif OOO00O00O00O0OO0O ==STKxFUT .FUT :#line:4466
            if OOO0OOOO0OOO00000 .__O00000000O0OO0O0O ==None :#line:4467
                return #line:4468
            OOO0OOOO0OOO00000 .__O00000000O0OO0O0O (OOO0OO00O00000000 ,False ,None )#line:4469
        elif OOO00O00O00O0OO0O ==STKxFUT .OVSFUT :#line:4470
            if OOO0OOOO0OOO00000 .__O000000O0OO00OO0O ==None :#line:4471
                return #line:4472
            pass #line:4473
    __OO0O00O000O0O0O0O :callable =None #line:4476
    def Set_OnQtIdxRcvEventSTK (O00OOOOO0OOOO000O ,O00O0OO00000O0OO0 :callable ):#line:4478
        O00OOOOO0OOOO000O .__OO0O00O000O0O0O0O =O00O0OO00000O0OO0 #line:4479
    def __O0OO0OOOO0OO0OOOO (OO00OOO00OOOOOO0O ,OO00OO0O0OO0OO000 :TObjStkQuoteMap ):#line:4481
        if OO00OOO00OOOOOO0O .__OO0O00O000O0O0O0O ==None :#line:4482
            return #line:4483
        OO00OOO00OOOOOO0O .__OO0O00O000O0O0O0O ("STKIdx",True ,OO00OO0O0OO0OO000 )#line:4484
    def __O000OOO00OOO0OOOO (O0OOO00O00O0OOOO0 ,O00O00O00OOO0OOOO :str ):#line:4486
        if O0OOO00O00O0OOOO0 .OnQtIdxRcvEvent ==None :#line:4487
            return #line:4488
        O0OOO00O00O0OOOO0 .OnQtIdxRcvEvent (O0OOO00O00O0OOOO0 ,O00O00O00OOO0OOOO ,False ,None )#line:4489
    __O0O00OOO0000O000O :callable =None #line:4493
    """QtTXEventHandler"""#line:4494
    def Set_OnQtTXEventSTK (OO0O0O0O0O0OO00O0 ,OO00O000O00OOOOOO :callable ):#line:4496
        OO0O0O0O0O0OO00O0 .__O0O00OOO0000O000O =OO00O000O00OOOOOO #line:4497
    def __OO000OO0O0O0OOOO0 (O0OOOOOO00O0O0O0O ,OO0OO0O00OOO0000O :str ,O0O00OOO0OO0O00O0 :TStkQtTX ):#line:4499
        if O0OOOOOO00O0O0O0O .__O0O00OOO0000O000O ==None :#line:4500
            return #line:4501
        O0OOOOOO00O0O0O0O .__O0O00OOO0000O000O (OO0OO0O00OOO0000O ,O0O00OOO0OO0O00O0 )#line:4502
    def __O0OOO000000OO000O (O0O0OO0O0000O0OOO ,O0O000O00OOOOOO00 :str ,O0O000OO0OO0000O0 :bool ,O0000OO0O000O0O0O :TObjFutQuoteMap ):#line:4504
        ""#line:4505
        if O0O000OO0OO0000O0 ==False :#line:4507
            O0O0OO0O0000O0OOO ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[期貨行情回補]{O0O000O00OOOOOO00}回補失敗!")#line:4508
            return #line:4509
        try :#line:4510
            for OOO0OO0O00O00O0O0 ,O0O0000OO0000O000 in O0000OO0O000O0O0O .items ():#line:4511
                O000O00OO0O0O00OO :TFutQuoteData =O0O0000OO0000O000 #line:4512
                O0OOO0O0000OOO0O0 =O000O00OO0O0O00OO .BAS .OrdProdID #line:4513
                if O0O0OO0O0000O0OOO ._fPrdSnapshotMap .NewItemFut (O0OOO0O0000OOO0O0 ,O000O00OO0O0O00OO ):#line:4514
                    O0O0O00OOOO00OO00 :ProductSnapshot =O0O0OO0O0000O0OOO ._fPrdSnapshotMap [O0OOO0O0000OOO0O0 ]#line:4516
                    if O000O00OO0O0O00OO .UpdateBAS :#line:4517
                        O0O0OO0O0000O0OOO .__OOO0O0O00OOOO00O0 .Fire_OnUpdateBasic (O0O0O00OOOO00OO00 .BasicData )#line:4518
                        O000O00OO0O0O00OO .UpdateBAS =False #line:4519
                    if O000O00OO0O0O00OO .UpdateHL :#line:4520
                        O0O0O00OOOO00OO00 .TickData =ProductTick_Fut (O000O00OO0O0O00OO )#line:4521
                        O0O0OO0O0000O0OOO .__OOO0O0O00OOOO00O0 .Fire_OnUpdateLastSnapshot (O0O0OO0O0000O0OOO ._fPrdSnapshotMap [O0OOO0O0000OOO0O0 ])#line:4522
                        O000O00OO0O0O00OO .UpdateHL =False #line:4523
        except Exception as OO0O0O0O00O00OOO0 :#line:4528
            O0O0OO0O0000O0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQtRcvEvent]aMsg={O0O000O00OOOOOO00}, aIsOK={O0O000OO0OO0000O0}, ex:{OO0O0O0O00O00OOO0}")#line:4529
    def __OO00000000O00O00O (OO0OO0OOO00OO00OO ,O0000OOOOOOO0OOOO :str ,O0OOOO00OO0OO0OOO :TFutQtTX ):#line:4531
        ""#line:4532
        try :#line:4533
            O0OO00O00O0O00000 :ProductSnapshot =None #line:4534
            O00000O0OOO0O00O0 ,O0OO00O00O0O00000 =OO0OO0OOO00OO00OO ._fPrdSnapshotMap .GetItem (O0000OOOOOOO0OOOO )#line:4536
            if O00000O0OOO0O00O0 :#line:4537
                O0O0OOO0OO0O00OOO :ProductTick_Fut =O0OO00O00O0O00000 .TickData #line:4539
                if O0O0OOO0OO0O00OOO .Upt_TX (O0OOOO00OO0OO0OOO ):#line:4541
                    OO0OO0OOO00OO00OO .__OOO0O0O00OOOO00O0 .Fire_OnMatch (OO0OO0OOO00OO00OO ._fPrdSnapshotMap [O0000OOOOOOO0OOOO ].TickData )#line:4542
        except Exception as O00O0OO00O0OO0O0O :#line:4544
            OO0OO0OOO00OO00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQtTXEvent]ProdID={O0000OOOOOOO0OOOO}, ex:{O00O0OO00O0OO0O0O}")#line:4545
    def __O0O0O0000OO00O000 (O00OO0OO00000O0OO ,OOOOO0OOOOOO0OOO0 :str ,OO0O0O0OOOO0O000O :TFutQt5Q ):#line:4547
        ""#line:4548
        try :#line:4549
            O0OOO000O0O00O00O :ProductSnapshot =None #line:4550
            OO00OOO0O0O0000O0 ,O0OOO000O0O00O00O =O00OO0OO00000O0OO ._fPrdSnapshotMap .GetItem (OOOOO0OOOOOO0OOO0 )#line:4552
            if OO00OOO0O0O0000O0 :#line:4553
                OO0OOOO00OO0O00O0 :ProductTick_Fut =O0OOO000O0O00O00O .TickData #line:4554
                if OO0OOOO00OO0O00O0 .Upt_5Q (OO0O0O0OOOO0O000O ):#line:4556
                    O00OO0OO00000O0OO .__OOO0O0O00OOOO00O0 .Fire_OnOrderBook (O00OO0OO00000O0OO ._fPrdSnapshotMap [OOOOO0OOOOOO0OOO0 ].TickData )#line:4557
        except Exception as OO0OO00000O00O0O0 :#line:4559
         O00OO0OO00000O0OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQt5QEvent]ProdID={OOOOO0OOOOOO0OOO0}, ex:{OO0OO00000O00O0O0}")#line:4560
    def __O0OOOOO0O0OOOO0O0 (O00OOO0O00O0OOO0O ,O00O0O000OOOO000O :str ,O00O000OO0OO0OO0O :TFutQt5QTOT ):#line:4562
        ""#line:4563
        try :#line:4564
            O0OO0O0O0OOOO00O0 :ProductSnapshot =None #line:4565
            O000O0O0OOOO0O00O ,O0OO0O0O0OOOO00O0 =O00OOO0O00O0OOO0O ._fPrdSnapshotMap .GetItem (O00O0O000OOOO000O )#line:4567
            if O000O0O0OOOO0O00O :#line:4568
                OO0O0000OOOOO0O00 :ProductTick_Fut =O0OO0O0O0OOOO00O0 .TickData #line:4569
                if OO0O0000OOOOO0O00 .Upt_5QTOT (O00O000OO0OO0OO0O ):#line:4571
                    O00OOO0O00O0OOO0O .__OOO0O0O00OOOO00O0 .Fire_OnUpdateTotalOrderQty (O00OOO0O00O0OOO0O ._fPrdSnapshotMap [O00O0O000OOOO000O ].TickData )#line:4572
        except Exception as O0OOO0000OOO0OOOO :#line:4574
            O00OOO0O00O0OOO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQt5QTOTEvent]ProdID={O00O0O000OOOO000O}, ex:{O0OOO0000OOO0OOOO}")#line:4575
    def __O000O00000OOOO0OO (OOO0000OOOOO0OO0O ,O0OOOO0OOO0O0O00O :str ,OO00O0000OO00OOOO :TFutQtIDX ):#line:4576
        try :#line:4577
            pass #line:4578
        except Exception as OO000000OOO0O0OO0 :#line:4584
            OOO0000OOOOO0OO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteFutApi_OnQtIDXEvent]ProdID={O0OOOO0OOO0O0O00O}, ex:{OO000000OOO0O0OO0}")#line:4585
    def __O000O0000O0O0OOOO (O00OO0O00O0OO0000 ,OOO0OO0OOO0O0O0OO :str ,O0OOOO00O00OOO000 :TFutQtBase ):#line:4586
        ""#line:4587
        try :#line:4588
            pass #line:4589
        except Exception as O00O0OO0O0000O0O0 :#line:4606
            pass #line:4607
    def __O0O0O00OO000OO00O (O00OO0OO000OO0OO0 ,O000OO0O000OOO0O0 :ITQtRcvEventData ):#line:4609
        if O000OO0O000OOO0O0 ==None :#line:4610
            O00OO0OO000OO0OO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[海期行情回補] 回補失敗!")#line:4611
            return #line:4612
        if O000OO0O000OOO0O0 .IsOK ==False :#line:4613
            O00OO0OO000OO0OO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[海期行情回補]{O000OO0O000OOO0O0.SolIce}回補失敗!")#line:4614
            return #line:4615
        try :#line:4616
            if O00OO0OO000OO0OO0 ._fPrdOvsMap .NewItem (O000OO0O000OOO0O0 .QtMap ):#line:4617
                O00OO0OO000OO0OO0 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateOvsBasic (O000OO0O000OOO0O0 .QtMap )#line:4618
        except Exception as OO0OO00O0000OOOO0 :#line:4620
            O00OO0OO000OO0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteOvsFutAPI_OnQtRcvEvent]aSolIce={O000OO0O000OOO0O0.SolIce}, aIsOK={O000OO0O000OOO0O0.IsOK}, ex:{OO0OO00O0000OOOO0}")#line:4621
    def __O000OOOOOOO0OO00O (OO0OO0OOO0O0OO00O ,O0000O000OO0000O0 :str ,OOOO00OO0O0O00OOO :TOvsFutQtTX ):#line:4622
        try :#line:4623
            O0O000O0000000000 :TOvsFutQuoteData =None #line:4624
            OO00OO0O0OOOO0OOO ,O0O000O0000000000 =OO0OO0OOO0O0OO00O ._fPrdOvsMap .GetItem (O0000O000OO0000O0 )#line:4626
            if OO00OO0O0OOOO0OOO :#line:4627
                O0O000O0000000000 .QtTX =OOOO00OO0O0O00OOO #line:4628
                OO0OO0OOO0O0OO00O .__OOO0O0O00OOOO00O0 .Fire_OnUpdateOvsMatch (O0O000O0000000000 )#line:4629
        except Exception as O0O0OOO0OOOO0O0OO :#line:4630
            OO0OO0OOO0O0OO00O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteOvsFutAPI_OnQtTXEvent]ProdID={O0000O000OO0000O0}, ex:{O0O0OOO0OOOO0O0OO}")#line:4631
    def __O0000000OO0000OO0 (OO0O0OO000O000O00 ,OO0OO00OOO000OO00 :str ,OOO0OO0OO0O00O00O :TOvsFutQt5Q ):#line:4632
        try :#line:4633
            O0OOOOOOO00OOOOO0 :TOvsFutQuoteData =None #line:4634
            O000OOOO0O00000OO ,O0OOOOOOO00OOOOO0 =OO0O0OO000O000O00 ._fPrdOvsMap .GetItem (OO0OO00OOO000OO00 )#line:4636
            if O000OOOO0O00000OO :#line:4637
                O0OOOOOOO00OOOOO0 .Qt5Q =OOO0OO0OO0O00O00O #line:4638
                OO0O0OO000O000O00 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateOvsOrderBook (O0OOOOOOO00OOOOO0 )#line:4639
        except Exception as OO0O0OO0O0O000000 :#line:4640
            OO0O0OO000O000O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQt5QEvent]ProdID={OO0OO00OOO000OO00}, ex:{OO0O0OO0O0O000000}")#line:4641
    __O00000OOOOO0OO000 :callable =None #line:4645
    def Set_OnQtTXEventFUT (OO0O0O0000O00OO0O ,OOO00O000000OO0OO :callable ):#line:4647
        OO0O0O0000O00OO0O .__O00000OOOOO0OO000 =OOO00O000000OO0OO #line:4648
    def __O000O000O000000O0 (OO0O0000OO0O0OO00 ,OOOO00O00OO00OO0O :str ,OO0000OOOOO0OOOOO :TFutQtTX ):#line:4650
        if OO0O0000OO0O0OO00 .__O00000OOOOO0OO000 ==None :#line:4651
            return #line:4652
        OO0O0000OO0O0OO00 .__O00000OOOOO0OO000 (OOOO00O00OO00OO0O ,OO0000OOOOO0OOOOO )#line:4654
    __O0OOO00O000OO0OOO :callable =None #line:4657
    def Set_OnQtTXEventOvsFUT (O0O0OOO0O0OO00O0O ,OOOO0OO0000OO000O :callable ):#line:4659
        O0O0OOO0O0OO00O0O .__O0OOO00O000OO0OOO =OOOO0OO0000OO000O #line:4660
    def __OOO0OO00OOO0OOO0O (OOOOO00O000OOO0OO ,O0OO0OOOOO0O0O0OO :str ,OO000O000OO0O0O0O :TOvsFutQtTX ):#line:4662
        if OOOOO00O000OOO0OO .__O0OOO00O000OO0OOO ==None :#line:4663
            return #line:4664
        OOOOO00O000OOO0OO .__O0OOO00O000OO0OOO (O0OO0OOOOO0O0O0OO ,OO000O000OO0O0O0O )#line:4665
    __O0O000O0O0O0OOO00 :callable =None #line:4669
    """Qt5QEventHandler"""#line:4670
    def Set_OnQt5QEventSTK (OOOO00OO0000OOO00 ,O0O00000OO0OOOO0O :callable ):#line:4672
        OOOO00OO0000OOO00 .__O0O000O0O0O0OOO00 =O0O00000OO0OOOO0O #line:4673
    def __O0OOOO00OOO00O00O (O000OO00000OOO0O0 ,O0O0O00OOOOOO0OOO :str ,OOO00O00O00O000O0 :TStkQt5Q ):#line:4675
        if O000OO00000OOO0O0 .__O0O000O0O0O0OOO00 ==None :#line:4676
            return #line:4677
        O000OO00000OOO0O0 .__O0O000O0O0O0OOO00 (O0O0O00OOOOOO0OOO ,OOO00O00O00O000O0 )#line:4678
    __OOO00O00O0O0OOOOO :callable =None #line:4681
    def Set_OnQt5QEventFUT (O000OOO0OO0OOO000 ,OO000000000000O00 :callable ):#line:4683
        O000OOO0OO0OOO000 .__OOO00O00O0O0OOOOO =OO000000000000O00 #line:4684
    def __O0OOO0OO0O00O0O0O (OOOO0O00000000O00 ,OOO0O0000OO0O0O00 :str ,O0OOO00OOOOO000O0 :TFutQt5Q ):#line:4686
        if OOOO0O00000000O00 .__OOO00O00O0O0OOOOO ==None :#line:4687
            return #line:4688
        OOOO0O00000000O00 .__OOO00O00O0O0OOOOO (OOO0O0000OO0O0O00 ,O0OOO00OOOOO000O0 )#line:4690
    __OOO0O0OOOO0O00O0O :callable =None #line:4693
    def Set_OnQt5QEventOvsFUT (O00O00O000O0000O0 ,OO0O00O00000OO000 :callable ):#line:4695
        O00O00O000O0000O0 .__OOO0O0OOOO0O00O0O =OO0O00O00000OO000 #line:4696
    def __OO0O00OOO0000OOOO (O0000O00O0O000O00 ,O000OOOOOOOOO0OOO :str ,O0O00O00000O0OOO0 :TOvsFutQt5Q ):#line:4698
        if O0000O00O0O000O00 .__OOO0O0OOOO0O00O0O ==None :#line:4699
            return #line:4700
        O0000O00O0O000O00 .__OOO0O0OOOO0O00O0O (O0000O00O0O000O00 ,O000OOOOOOOOO0OOO ,O0O00O00000O0OOO0 )#line:4701
    __OO000OO0OOO0O0OO0 :callable =None #line:4704
    def Set_OnQt5QTOTEventFUT (OOO000OO0OO0OOOOO ,OOO0000OO0OO0000O :callable ):#line:4706
        OOO000OO0OO0OOOOO .__OO000OO0OOO0O0OO0 =OOO0000OO0OO0000O #line:4707
    def __O0O0O000O0OO000O0 (OOO0O0000OOO0O00O ,OO00000O0O0OOO0O0 :str ,OO0000OO0000OO000 :TFutQt5QTOT ):#line:4709
        if OOO0O0000OOO0O00O .__OO000OO0OOO0O0OO0 ==None :#line:4710
            return #line:4711
        OOO0O0000OOO0O00O .__OO000OO0OOO0O0OO0 (OO00000O0O0OOO0O0 ,OO0000OO0000OO000 )#line:4712
    __O000O0OOO00O0O0OO :callable =None #line:4715
    def Set_OnChangeMktStuEventFUT (O00O0O00O00OO00O0 ,OO00O00OOOO0000OO :callable ):#line:4717
        O00O0O00O00OO00O0 .__O000O0OOO00O0O0OO =OO00O00OOOO0000OO #line:4718
    def __O0O00O0000O0O0000 (OO00OO0OOOO0O0000 ,O0O0000O00OO0000O :str ,OO000OOO0OO000O0O :TFutQtBase ):#line:4720
        if OO00OO0OOOO0O0000 .__O000O0OOO00O0O0OO ==None :#line:4721
            return #line:4722
        OO00OO0OOOO0O0000 .__O000O0OOO00O0O0OO (O0O0000O00OO0000O ,OO000OOO0OO000O0O )#line:4723
    __OO00OO0OO0O0O000O :callable =None #line:4726
    def Set_OnQtIDXEventSTK (OOO000O00O00OO0OO ,O0O000OOO0O0O0O00 :callable ):#line:4728
        OOO000O00O00OO0OO .__OO00OO0OO0O0O000O =O0O000OOO0O0O0O00 #line:4729
    def __OO0OO000O0OOOOOO0 (O0O0OO0O0000OOO0O ,OOOOOO000O0000OO0 :str ,OOO0O0O0OO00OOO00 :TStkQtIDX ):#line:4731
        if O0O0OO0O0000OOO0O .__OO00OO0OO0O0O000O ==None :#line:4732
            return #line:4733
        O0O0OO0O0000OOO0O .__OO00OO0OO0O0O000O (OOOOOO000O0000OO0 ,OOO0O0O0OO00OOO00 )#line:4734
    __O0000000OO00O00OO :callable =None #line:4735
    def Set_OnQtIDXEventFUT (O00OO00OOO0OO00O0 ,OO0OO0000OO00000O :callable ):#line:4737
        O00OO00OOO0OO00O0 .__O0000000OO00O00OO =OO0OO0000OO00000O #line:4738
    def __O00OO0O000OOO0O00 (OO000O0OO0OO00OO0 ,O0O0OO00OOOO0O0OO :str ,O0OOO0OO0OOO0OO00 :TFutQtIDX ):#line:4740
        if OO000O0OO0OO00OO0 .__O0000000OO00O00OO ==None :#line:4741
            return #line:4742
        OO000O0OO0OO00OO0 .__O0000000OO00O00OO (O0O0OO00OOOO0O0OO ,O0OOO0OO0OOO0OO00 )#line:4743
    __OOOOOOOO000O00O0O :callable =None #line:4746
    """OtherMessageEventHandler"""#line:4747
    def Set_OnOtherMessageEvent (OOO00O0OOOOOO00O0 ,O0OO00000O0000OOO :callable ):#line:4749
        OOO00O0OOOOOO00O0 .__OOOOOOOO000O00O0O =O0OO00000O0000OOO #line:4750
    def __OOOOO0000O00OO000 (O000O0O00OO0OO00O ,O0000O00OO00OO0OO :str ):#line:4752
        if O000O0O00OO0OO00O .__OOOOOOOO000O00O0O ==None :#line:4753
            return #line:4754
        O000O0O00OO0OO00O .__OOOOOOOO000O00O0O (O0000O00OO00OO0OO )#line:4755
    __O00O0O0O0O0O0000O :callable =None #line:4758
    """LogEventHandler"""#line:4759
    __OOOOOO000O0000OOO :callable =None #line:4760
    __OOOO000O00OO0O000 :callable =None #line:4761
    def Set_OnLogEvent (O00OO000O0000O0OO ,O0OO00O000000OOOO :callable ):#line:4763
        O00OO000O0000O0OO .__O00O0O0O0O0O0000O =O0OO00O000000OOOO #line:4764
    def __OO0OO0O00OOOO00O0 (OO0O0OOO000OOO000 ,O00O000O0OO0O0OOO :str ):#line:4766
        if OO0O0OOO000OOO000 .__O00O0O0O0O0O0000O ==None :#line:4767
            return #line:4768
        OO0O0OOO000OOO000 .__O00O0O0O0O0O0000O (O00O000O0OO0O0OOO )#line:4769
    def Set_OnInterruptEvent (OO000000OO000O0OO ,O0OO0O00O0OO0O0OO :callable ):#line:4772
        OO000000OO000O0OO .__OOOOOO000O0000OOO =O0OO0O00O0OO0O0OO #line:4773
    def __O0OOOOOOOOOO0OO0O (OO0OO0OO000OO00OO ,OOO0000O000O0OO0O :str ):#line:4775
        if OO0OO0OO000OO00OO .__OOOOOO000O0000OOO ==None :#line:4776
            return #line:4777
        OO0OO0OO000OO00OO .__OOOOOO000O0000OOO (OOO0000O000O0OO0O )#line:4778
    def Set_OnTerminationEvent (OO00O00O00O0000OO ,OOOO0OOOOOOOO0000 :callable ):#line:4780
        OO00O00O00O0000OO .__OOOO000O00OO0O000 =OOOO0OOOOOOOO0000 #line:4781
    def __O00O0OOOO0O0OOO00 (OO000O000O0OOOOO0 ,O00O0OO000OOO0O00 :str ):#line:4783
        if OO000O000O0OOOOO0 .__OOOO000O00OO0O000 ==None :#line:4784
            return #line:4785
        OO000O000O0OOOOO0 .__OOOO000O00OO0O000 (O00O0OO000OOO0O00 )#line:4786
    def __O0O000O00OO0OO0OO (O0O00OOO0O0O000O0 ,OOOO00OOOOOOO000O :TSolClientConnData )->RCode :#line:4789
        try :#line:4790
            if O0O00OOO0O0O000O0 ._is_connected :#line:4791
                return RCode .OK #line:4792
            if O0O00OOO0O0O000O0 ._log ._run ==False :#line:4793
                O0O00OOO0O0O000O0 ._log =SolaceLog (O0O00OOO0O0O000O0 ._pypath ,O0O00OOO0O0O000O0 ._loglv ,O0O00OOO0O0O000O0 ._conlve )#line:4794
            O0O00OOO0O0O000O0 ._log .Add (arg1 =SolLogType .Info ,arg2 ="DoSolaceConn")#line:4795
            O0O00OOO0O0O000O0 .__O00OO0O00OOO00OO0 ()#line:4796
            O0O00OOO0O0O000O0 ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"host:{OOOO00OOOOOOO000O.Host} vpn:{OOOO00OOOOOOO000O.MessageVPN} username:{OOOO00OOOOOOO000O.Username} pwd:{OOOO00OOOOOOO000O.Password} cmplv:{OOOO00OOOOOOO000O.CompressLevel}")#line:4797
            O0OO00000O00OO0O0 :dict ={}#line:4798
            O0OO00000O00OO0O0 ["solace.messaging.transport.host"]=OOOO00OOOOOOO000O .Host #line:4799
            O0OO00000O00OO0O0 ["solace.messaging.service.vpn-name"]=OOOO00OOOOOOO000O .MessageVPN #line:4800
            O0OO00000O00OO0O0 ["solace.messaging.authentication.basic.username"]=OOOO00OOOOOOO000O .Username #line:4801
            O0OO00000O00OO0O0 ["solace.messaging.authentication.basic.password"]=OOOO00OOOOOOO000O .Password #line:4802
            O0OO00000O00OO0O0 ["solace.messaging.transport.compression-level"]=OOOO00OOOOOOO000O .CompressLevel #line:4803
            O0OO00000O00OO0O0 ['solace.messaging.transport.connection-retries']=3 #line:4805
            O0OO00000O00OO0O0 ['solace.messaging.transport.connection.retries-per-host']=4 #line:4806
            O0OO00000O00OO0O0 ['solace.messaging.transport.connection-attempts-timeout']=30000 #line:4807
            O0OO00000O00OO0O0 ['solace.messaging.transport.reconnection-attempts']=10 #line:4809
            O0OO00000O00OO0O0 ['solace.messaging.transport.reconnection-attempts-wait-interval']=1000 #line:4810
            O0O00OOO0O0O000O0 ._cacheReqOutListener =CacheReqOutListener (O0O00OOO0O0O000O0 ,O0O00OOO0O0O000O0 .__O000OOO000000O0O0 ,O0O00OOO0O0O000O0 ._log )#line:4813
            O0O00OOO0O0O000O0 ._message_service =MessagingService .builder ().from_properties (O0OO00000O00OO0O0 ).build ()#line:4814
            O0O00OOO0O0O000O0 ._message_service .connect ()#line:4815
            O0O00OOO0O0O000O0 ._service_handler =ServiceEventHandler (O0O00OOO0O0O000O0 .__O0OOOOOOOOOO0OO0O )#line:4816
            O0O00OOO0O0O000O0 ._message_service .add_service_interruption_listener (O0O00OOO0O0O000O0 ._service_handler )#line:4817
            O0O00OOO0O0O000O0 ._termination_handler =TerminationNotificationHandler (O0O00OOO0O0O000O0 .__O00O0OOOO0O0OOO00 )#line:4818
            O0O00OOO0O0O000O0 ._message_receiver =O0O00OOO0O0O000O0 ._message_service .create_direct_message_receiver_builder ().build ()#line:4820
            O0O00OOO0O0O000O0 ._message_receiver .start ()#line:4821
            O0O00OOO0O0O000O0 ._message_receiver .receive_async (O0O00OOO0O0O000O0 .__O000OOO000000O0O0 )#line:4822
            O0O00OOO0O0O000O0 ._message_receiver .set_termination_notification_listener (O0O00OOO0O0O000O0 ._termination_handler )#line:4823
            O0O00OOO0O0O000O0 ._direct_publish_service =O0O00OOO0O0O000O0 ._message_service .create_direct_message_publisher_builder ().build ()#line:4825
            O0O00OOO0O0O000O0 ._message_requester =O0O00OOO0O0O000O0 ._message_service .request_reply ().create_request_reply_message_publisher_builder ().build ().start ()#line:4827
            O0O00OOO0O0O000O0 ._is_connected =O0O00OOO0O0O000O0 ._message_service .is_connected #line:4828
            if O0O00OOO0O0O000O0 ._is_connected :#line:4830
                return RCode .OK #line:4831
            else :#line:4832
                return RCode .FAIL #line:4833
        except Exception as O00O0O00OO0OO0000 :#line:4834
            O0O00OOO0O0O000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSolaceConn error: {O00O0O00OO0OO0000}")#line:4836
            return RCode .FAIL #line:4837
    def Connect (O0OOOO0000OO0O0OO ,OOOOO0000000OO0OO :str ,O0OO00OOO000O00O0 :str ,O0O000OO0OO00O0OO :str ,O0O00O0O00000000O :str ,aCompressLevel :int =0 ):#line:4839
        O0OO00O0OO0000O0O :TSolClientConnData =TSolClientConnData ()#line:4840
        O0OO00O0OO0000O0O .Host =OOOOO0000000OO0OO #line:4841
        O0OO00O0OO0000O0O .MessageVPN =O0OO00OOO000O00O0 #line:4842
        O0OO00O0OO0000O0O .Username =O0O000OO0OO00O0OO #line:4843
        O0OO00O0OO0000O0O .Password =O0O00O0O00000000O #line:4844
        O0OO00O0OO0000O0O .CompressLevel =aCompressLevel #line:4845
        return O0OOOO0000OO0O0OO .__O0O000O00OO0OO0OO (O0OO00O0OO0000O0O )#line:4847
    def DisConnect (OOOO0000O0OOOOOO0 )->RCode :#line:4849
        if OOOO0000O0OOOOOO0 ._is_connected :#line:4851
            OOO00OOOOOO0O0000 =time .time ()#line:4852
            while (True ):#line:4853
                O00O0000O0O0000O0 =OOOO0000O0OOOOOO0 .__O0O00000OOO0O000O ._queue .empty ()#line:4854
                OOOOOOOO000000OO0 =OOOO0000O0OOOOOO0 .__O0OOOOO0OOOO0000O ._queue .empty ()#line:4855
                if O00O0000O0O0000O0 and OOOOOOOO000000OO0 :#line:4856
                    sleep (2 )#line:4857
                    with OOOO0000O0OOOOOO0 ._lock :#line:4858
                        if hasattr (OOOO0000O0OOOOOO0 ,'_message_service')and OOOO0000O0OOOOOO0 ._is_connected :#line:4859
                            OOOO0000O0OOOOOO0 ._message_receiver .terminate ()#line:4860
                            OOOO0000O0OOOOOO0 ._message_requester .terminate ()#line:4861
                            OOOO0000O0OOOOOO0 ._message_service .disconnect ()#line:4862
                        OOOO0000O0OOOOOO0 ._is_connected =False #line:4863
                    break #line:4864
                O0OO00OOOOO00O000 =time .time ()#line:4865
                O0OO0O000OOOO00OO =O0OO00OOOOO00O000 -OOO00OOOOOO0O0000 #line:4866
                if O0OO0O000OOOO00OO >30 :#line:4867
                    with OOOO0000O0OOOOOO0 ._lock :#line:4868
                        if hasattr (OOOO0000O0OOOOOO0 ,'_message_service')and OOOO0000O0OOOOOO0 ._is_connected :#line:4869
                            OOOO0000O0OOOOOO0 ._message_receiver .terminate ()#line:4870
                            OOOO0000O0OOOOOO0 ._message_requester .terminate ()#line:4871
                            OOOO0000O0OOOOOO0 ._message_service .disconnect ()#line:4872
                        OOOO0000O0OOOOOO0 ._is_connected =False #line:4873
                    break #line:4874
        OOOO0000O0OOOOOO0 .__O00O000OO00OO0OOO ()#line:4876
        if OOOO0000O0OOOOOO0 ._log ._run :#line:4877
            OOOO0000O0OOOOOO0 ._log .Wrtie_log (SolLogType .Info ,"DisConnect")#line:4878
            OOOO0000O0OOOOOO0 ._log ._run =False #line:4879
        return RCode .OK #line:4880
    def __OO0OOOOO0OO00O0OO (O0O0OOO00OOOO0000 ,O0O0O00OO0OO000OO ):#line:4884
        ""#line:4885
        OO0OO0000OOO00O00 :str =""#line:4886
        try :#line:4887
            if isinstance (O0O0O00OO0OO000OO ,int ):#line:4889
                O00OO0O00OOO0O00O :int =O0O0O00OO0OO000OO #line:4890
                OO00000O0O0OOOOO0 =O0O0OOO00OOOO0000 ._fMapCacheJob .get (O00OO0O00OOO0O00O )#line:4891
                if OO00000O0O0OOOOO0 is None :#line:4892
                    O0O0OOO00OOOO0000 .__OO0OO0O00OOOO00O0 (f"[handle cache job data 回補結束]reqID={O0O0O00OO0OO000OO}")#line:4893
                    O0O0OOO00OOOO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[handle cache job data 回補結束]reqID={O0O0O00OO0OO000OO}")#line:4894
                else :#line:4895
                    OO0000O00OOO0O00O ,OOOOO00OOOO00OOOO =O0O0OOO00OOOO0000 ._fMapCacheJob .DeleteJob (O00OO0O00OOO0O00O )#line:4896
                    if OO0000O00OOO0O00O :#line:4897
                        OOOOO00OOOO00OOOO .HandleProc (OOOOO00OOOO00OOOO )#line:4898
                return #line:4899
            O0OOO0000000O000O =O0O0O00OO0OO000OO .get_cache_status ()#line:4901
            OO0OO0000OOO00O00 =O0O0O00OO0OO000OO .get_payload_as_bytes ().decode ('utf-8')#line:4902
            if len (OO0OO0000OOO00O00 )==0 :#line:4903
                return #line:4904
            O0OOOO0OO0000O0OO :str =O0O0O00OO0OO000OO .get_destination_name ()#line:4905
            if O0OOO0000000O000O .value ==O0OOO0000000O000O .CACHED .value :#line:4907
                OOOOO00OOOO00OOOO :TCacheJob =O0O0OOO00OOOO0000 ._fMapCacheJob [O0O0O00OO0OO000OO .get_cache_request_id ()]#line:4908
                if OOOOO00OOOO00OOOO is not None :#line:4909
                    if OOOOO00OOOO00OOOO .oneProd :#line:4910
                        OO00OOO00O0OO0OOO =O0OOOO0OO0000O0OO .split ("/")#line:4911
                        if O0OOOO0OO0000O0OO .endswith (O0O0OOO00OOOO0000 ._vQuote_BAS ):#line:4912
                            OOOOO00OOOO00OOOO .TopicBAS =O0OOOO0OO0000O0OO #line:4913
                            OO00OOO00O0OO0OOO [len (OO00OOO00O0OO0OOO )-1 ]="HL"#line:4914
                            OOOOO00OOOO00OOOO .TopicHL ="/".join (OO00OOO00O0OO0OOO )#line:4915
                            OO00OOO00O0OO0OOO [len (OO00OOO00O0OO0OOO )-1 ]="TX"#line:4916
                            OOOOO00OOOO00OOOO .TopicTX ="/".join (OO00OOO00O0OO0OOO )#line:4917
                            OOOOO00OOOO00OOOO .CacheData [O0OOOO0OO0000O0OO ]=O0O0O00OO0OO000OO #line:4918
                            O0O0OOO00OOOO0000 ._fMapCacheJob [O0O0O00OO0OO000OO .get_cache_request_id ()]=OOOOO00OOOO00OOOO #line:4919
                            if OOOOO00OOOO00OOOO .CacheData .get (OOOOO00OOOO00OOOO .TopicHL )is None :#line:4921
                                OO0OO0OOO00OOO0O0 =TCacheJob ()#line:4922
                                OO0OO0OOO00OOO0O0 .prod =OO00OOO00O0OO0OOO [len (OO00OOO00O0OO0OOO )-2 ]#line:4923
                                OO0OO0OOO00OOO0O0 .TopicBAS =OOOOO00OOOO00OOOO .TopicBAS #line:4924
                                OO0OO0OOO00OOO0O0 .TopicHL =OOOOO00OOOO00OOOO .TopicHL #line:4925
                                OO0OO0OOO00OOO0O0 .TopicTX =OOOOO00OOOO00OOOO .TopicTX #line:4926
                                OO0OO0OOO00OOO0O0 .RequestID =O0O0OOO00OOOO0000 .GetRequestID ()#line:4927
                                if O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_STK ):#line:4928
                                    OO0OO0OOO00OOO0O0 .HandleProc =O0O0OOO00OOOO0000 .__OO00OO00OO0O0OOOO #line:4929
                                elif O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_FUT ):#line:4930
                                    OO0OO0OOO00OOO0O0 .HandleProc =O0O0OOO00OOOO0000 .__O0OOOO0O0OO0OOOOO #line:4931
                                O0O0OOO00OOOO0000 ._fMapCacheJob [OO0OO0OOO00OOO0O0 .RequestID ]=OO0OO0OOO00OOO0O0 #line:4932
                                O0O0OOO00OOOO0000 .__O0OOOOO0O000OO00O (OO0OO0OOO00OOO0O0 .RequestID ,OO0OO0OOO00OOO0O0 .TopicHL )#line:4933
                        elif O0OOOO0OO0000O0OO .endswith (O0O0OOO00OOOO0000 ._vQuote_HL ):#line:4934
                            OOOOO00OOOO00OOOO .CacheData [O0OOOO0OO0000O0OO ]=O0O0O00OO0OO000OO #line:4935
                            O0O0OOO00OOOO0000 ._fMapCacheJob [O0O0O00OO0OO000OO .get_cache_request_id ()]=OOOOO00OOOO00OOOO #line:4936
                        O0O0OOO00OOOO0000 .__O000OOO000000O0O0 .Add (O0O0O00OO0OO000OO .get_cache_request_id ())#line:4937
                    else :#line:4938
                        OO00OOO00O0OO0OOO :list =O0OOOO0OO0000O0OO .split ('/')#line:4939
                        O0000O00OO0OO0OO0 =OO00OOO00O0OO0OOO [len (OO00OOO00O0OO0OOO )-2 ]#line:4940
                        if O0OOOO0OO0000O0OO .endswith (O0O0OOO00OOOO0000 ._vQuote_BAS ):#line:4941
                            OO00000O0O0OOOOO0 =TCacheJob ()#line:4942
                            OO00000O0O0OOOOO0 .prod =O0000O00OO0OO0OO0 #line:4943
                            OO00000O0O0OOOOO0 .TopicBAS =O0OOOO0OO0000O0OO #line:4945
                            OO00000O0O0OOOOO0 .RequestID =O0O0OOO00OOOO0000 .GetRequestID ()#line:4946
                            if O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_STK ):#line:4947
                                OO00000O0O0OOOOO0 .HandleProc =O0O0OOO00OOOO0000 .__OO000OOOO0O0O00OO #line:4948
                            elif O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_FUT ):#line:4949
                                OO00000O0O0OOOOO0 .HandleProc =O0O0OOO00OOOO0000 .__OOOO0OO00O0O0000O #line:4950
                            OO00000O0O0OOOOO0 .CacheData [O0OOOO0OO0000O0OO ]=O0O0O00OO0OO000OO #line:4951
                            O0O0OOO00OOOO0000 ._fMapCacheJob [OO00000O0O0OOOOO0 .RequestID ]=OO00000O0O0OOOOO0 #line:4952
                            O0O0OOO00OOOO0000 .__O000OOO000000O0O0 .Add (OO00000O0O0OOOOO0 .RequestID )#line:4953
                        elif O0OOOO0OO0000O0OO .endswith (O0O0OOO00OOOO0000 ._vQuote_HL ):#line:4954
                            OO00000O0O0OOOOO0 =TCacheJob ()#line:4955
                            OO00000O0O0OOOOO0 .prod =O0000O00OO0OO0OO0 #line:4956
                            OO00OOO00O0OO0OOO [len (OO00OOO00O0OO0OOO )-1 ]="TX"#line:4958
                            OO00000O0O0OOOOO0 .TopicTX ="/".join (OO00OOO00O0OO0OOO )#line:4959
                            OO00000O0O0OOOOO0 .TopicHL =O0OOOO0OO0000O0OO #line:4960
                            OO00000O0O0OOOOO0 .RequestID =O0O0OOO00OOOO0000 .GetRequestID ()#line:4961
                            if O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_STK ):#line:4962
                                OO00000O0O0OOOOO0 .HandleProc =O0O0OOO00OOOO0000 .__OO00OO00OO0O0OOOO #line:4963
                            elif O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_FUT ):#line:4964
                                OO00000O0O0OOOOO0 .HandleProc =O0O0OOO00OOOO0000 .__O0OOOO0O0OO0OOOOO #line:4965
                            OO00000O0O0OOOOO0 .CacheData [O0OOOO0OO0000O0OO ]=O0O0O00OO0OO000OO #line:4966
                            O0O0OOO00OOOO0000 ._fMapCacheJob [OO00000O0O0OOOOO0 .RequestID ]=OO00000O0O0OOOOO0 #line:4967
                            O0O0OOO00OOOO0000 .__O000OOO000000O0O0 .Add (OO00000O0O0OOOOO0 .RequestID )#line:4968
                else :#line:4969
                    O0O0OOO00OOOO0000 .__OO0OO0O00OOOO00O0 (f"[cache job is none]dest={O0OOOO0OO0000O0OO}")#line:4970
                    O0O0OOO00OOOO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[cache job is none]dest={O0OOOO0OO0000O0OO}")#line:4971
                return #line:4972
            if O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_STK ):#line:4974
                O0000OO0O00O0O0O0 =O0O0OOO00OOOO0000 ._fMapQuoteSTK .get (O0OOOO0OO0000O0OO )#line:4975
                if O0000OO0O00O0O0O0 :#line:4976
                    O0O0OOO00OOOO0000 ._fMapQuoteSTK .MapQtProc [O0OOOO0OO0000O0OO ](O0000OO0O00O0O0O0 ,OO0OO0000OOO00O00 ,O0O0O00OO0OO000OO )#line:4977
            elif O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_FUT ):#line:4978
                O0000OO0O00O0O0O0 =O0O0OOO00OOOO0000 ._fMapQuoteFUT .get (O0OOOO0OO0000O0OO )#line:4979
                if O0000OO0O00O0O0O0 :#line:4980
                    O0O0OOO00OOOO0000 ._fMapQuoteFUT .MapQtProc [O0OOOO0OO0000O0OO ](O0000OO0O00O0O0O0 ,OO0OO0000OOO00O00 ,O0O0O00OO0OO000OO )#line:4981
            elif O0OOOO0OO0000O0OO .startswith (O0O0OOO00OOOO0000 ._vQuote_OvsFUT ):#line:4982
                O0000OO0O00O0O0O0 =O0O0OOO00OOOO0000 ._fMapQuoteOvsFUT .get (O0OOOO0OO0000O0OO )#line:4983
                if O0000OO0O00O0O0O0 :#line:4984
                    O0O0OOO00OOOO0000 ._fMapQuoteOvsFUT .MapQtProc [O0OOOO0OO0000O0OO ](O0000OO0O00O0O0O0 ,OO0OO0000OOO00O00 ,O0O0O00OO0OO000OO )#line:4985
        except Exception as O0O00O0O0O0O0O0O0 :#line:4986
            if isinstance (O0O0O00OO0OO000OO ,int ):#line:4987
                O0O0OOO00OOOO0000 .__OO0OO0O00OOOO00O0 (f"[證][Solace_ReceiveSolaceTopic]aTopic={O0O0O00OO0OO000OO}, except={O0O00O0O0O0O0O0O0}")#line:4989
                O0O0OOO00OOOO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[證][Solace_ReceiveSolaceTopic]aTopic={O0O0O00OO0OO000OO}, except={O0O00O0O0O0O0O0O0}")#line:4991
            else :#line:4992
                O0O0OOO00OOOO0000 .__OO0OO0O00OOOO00O0 (f"[證][Solace_ReceiveSolaceTopic]aTopic={O0O0O00OO0OO000OO.get_destination_name()}, aData={OO0OO0000OOO00O00}, except={O0O00O0O0O0O0O0O0}")#line:4994
                O0O0OOO00OOOO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[證][Solace_ReceiveSolaceTopic]aTopic={O0O0O00OO0OO000OO.get_destination_name()}, aData={OO0OO0000OOO00O00}, except={O0O00O0O0O0O0O0O0}")#line:4996
    def __OO0OOOO0OO0O0OOOO (O0O0OO0O00O000OO0 ,OOO00O0OOO00O00OO :TStkQuoteData ,O0O000OO0O0OO00OO :str ,OO0O000OOOOO000O0 :'InboundMessage'):#line:4998
        ""#line:4999
        try :#line:5001
            with OOO00O0OOO00O00OO ._lock :#line:5002
                OOO00O0OOO00O00OO .QtTX .Handle_TX (O0O000OO0O0OO00OO )#line:5004
            O0O0OO0O00O000OO0 .__OO000OO0O0O0OOOO0 (OOO00O0OOO00O00OO .SolIce ,OOO00O0OOO00O00OO .QtTX )#line:5007
        except Exception as OO0O00O00O00OO000 :#line:5008
            O0O0OO0O00O000OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_TXSTK:{OO0O00O00O00OO000}")#line:5010
    def __OOO0OO0O0O00O00OO (OOOO00O0OO00OOO00 ,O0O000OOO0000O000 :TFutQuoteData ,OO0O0OOOOO0O000O0 :str ,OOO0OOO0000OO0O00 :'InboundMessage'):#line:5012
        ""#line:5013
        try :#line:5014
            with O0O000OOO0000O000 ._lock :#line:5015
                O0O000OOO0000O000 .QtTX .Handle_TX (OO0O0OOOOO0O000O0 )#line:5017
            OOOO00O0OO00OOO00 .__O000O000O000000O0 (O0O000OOO0000O000 .SolIce ,O0O000OOO0000O000 .QtTX )#line:5020
        except Exception as O000000000O00OOO0 :#line:5021
            OOOO00O0OO00OOO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_TXFUT:{O000000000O00OOO0}")#line:5023
    def __OOO00O0OOOO0OOOOO (O0O00OOO0O00OO000 ,OO0OOOO00O0OO00O0 :TOvsFutQuoteData ,O0OOOO00O00OO00O0 :str ,O00OOOO0OOO0O0OOO :'InboundMessage'):#line:5025
        ""#line:5026
        try :#line:5027
            with OO0OOOO00O0OO00O0 ._lock :#line:5028
                OO0OOOO00O0OO00O0 .QtTX .Handle_TX (O0OOOO00O00OO00O0 )#line:5029
            O0O00OOO0O00OO000 .__OOO0OO00OOO0OOO0O (OO0OOOO00O0OO00O0 .SolIce ,OO0OOOO00O0OO00O0 .QtTX )#line:5031
        except Exception as O0OOO0OO0000O0OOO :#line:5032
            O0O00OOO0O00OO000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_TXOvsFUT:{O0OOO0OO0000O0OOO}")#line:5034
    def __OOO00O0O00OOOO000 (OO0000OOO0OOO0OOO ,O0000O000000OOOOO :TStkQuoteData ,OOO0OO0000000O000 :str ,OOOO0OOOO00OOO0O0 :'InboundMessage'):#line:5036
        ""#line:5037
        try :#line:5038
            with O0000O000000OOOOO ._lock :#line:5039
                O0000O000000OOOOO .Qt5Q .Handle_5Q (OOO0OO0000000O000 )#line:5040
            OO0000OOO0OOO0OOO .__O0OOOO00OOO00O00O (O0000O000000OOOOO .SolIce ,O0000O000000OOOOO .Qt5Q )#line:5041
        except Exception as O000O00000O00O00O :#line:5042
            OO0000OOO0OOO0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QSTK:{O000O00000O00O00O}")#line:5044
    def __OOO000O000000000O (O00O0O0OOO00O0O00 ,OOO0O0OO0OO00O000 :TFutQuoteData ,O0O0OO0OOO00O00O0 :str ,OOOO0O00O0O0O0000 :'InboundMessage'):#line:5046
        ""#line:5047
        try :#line:5048
            with OOO0O0OO0OO00O000 ._lock :#line:5049
                OOO0O0OO0OO00O000 .Qt5Q .Handle_5Q (O0O0OO0OOO00O00O0 )#line:5050
            O00O0O0OOO00O0O00 .__O0OOO0OO0O00O0O0O (OOO0O0OO0OO00O000 .SolIce ,OOO0O0OO0OO00O000 .Qt5Q )#line:5051
        except Exception as O0O000OOOOOOO00OO :#line:5052
            O00O0O0OOO00O0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QFUT:{O0O000OOOOOOO00OO}")#line:5054
    def __OO0O00O0O0000OO00 (OO0OOO0O0000OOO0O ,O00O00OO0O0OOO0O0 :TOvsFutQuoteData ,O0O0O0OOO0000O0OO :str ,O000O0O0000O0OO0O :'InboundMessage'):#line:5056
        try :#line:5057
            with O00O00OO0O0OOO0O0 ._lock :#line:5058
                O00O00OO0O0OOO0O0 .Qt5Q .Handle_5Q (O0O0O0OOO0000O0OO )#line:5059
            OO0OOO0O0000OOO0O .__OO0O00OOO0000OOOO (O00O00OO0O0OOO0O0 .SolIce ,O00O00OO0O0OOO0O0 .Qt5Q )#line:5060
        except Exception as O00O00OO00OOO0O00 :#line:5061
            OO0OOO0O0000OOO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QOvsFUT:{O00O00OO00OOO0O00}")#line:5063
    def __OOO000O0O00000OO0 (OO00OO0O0O000OO00 ,OO0O000OOO00OO0OO :TStkQuoteData ,O000O0000O00O0000 :str ,OO00O0OO0O00000OO :'InboundMessage'):#line:5065
        ""#line:5066
        try :#line:5067
            with OO0O000OOO00OO0OO ._lock :#line:5068
                OO0O000OOO00OO0OO .QtIDX .Handle_IDX (O000O0000O00O0000 )#line:5070
            OO00OO0O0O000OO00 .__OO0OO000O0OOOOOO0 (OO0O000OOO00OO0OO .SolIce ,OO0O000OOO00OO0OO .QtIDX )#line:5073
        except Exception as OO00OOO000O0O00OO :#line:5074
            OO00OO0O0O000OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_IDXSTK:{OO00OOO000O0O00OO}")#line:5076
    def __O0O00O0OOO000OOOO (OO00O0O000OOO0O00 ,OOO000O0OO0OOO00O :TFutQuoteData ,O00OO0O0OO000O0O0 :str ,OO0000OO00O0000OO :'InboundMessage'):#line:5078
        ""#line:5079
        try :#line:5080
            with OOO000O0OO0OOO00O ._lock :#line:5081
                OOO000O0OO0OOO00O .QtIDX .Handle_IDX (O00OO0O0OO000O0O0 )#line:5082
            OO00O0O000OOO0O00 .__O00OO0O000OOO0O00 (OOO000O0OO0OOO00O .SolIce ,OOO000O0OO0OOO00O .QtIDX )#line:5083
        except Exception as OO0OOO00OOOOO00O0 :#line:5084
            OO00O0O000OOO0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_IDXFUT:{OO0OOO00OOOOO00O0}")#line:5086
    def __O0O0O0O00O00OO0O0 (O00O0OOO0O000000O ,O0O0O00OOO0O000O0 :TFutQuoteData ,OOO000O0OO0OOOO0O :str ,OOOO00O0000000O0O :'InboundMessage'):#line:5088
        ""#line:5089
        try :#line:5090
            with O0O0O00OOO0O000O0 ._lock :#line:5091
                O0O0O00OOO0O000O0 .Qt5QTOT .Handle_5QTOT (OOO000O0OO0OOOO0O )#line:5092
            O00O0OOO0O000000O .__O0O0O000O0OO000O0 (O0O0O00OOO0O000O0 .SolIce ,O0O0O00OOO0O000O0 .Qt5QTOT )#line:5093
        except Exception as OO00OO00000OO0OO0 :#line:5094
            O00O0OOO0O000000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_5QTOT:{OO00OO00000OO0OO0}")#line:5096
    def __OOO00OOO0OOO00O00 (O0O0000OO00O000O0 ,O0OOO000OO0OOO0OO :TFutQuoteData ,O0OOO00OOOO0O00OO :str ,OOO0OO0O00O00000O :'InboundMessage'):#line:5098
        ""#line:5099
        try :#line:5100
            OO00O0O0O0OO0O0O0 :bool =False #line:5101
            with O0OOO000OO0OOO0OO ._lock :#line:5102
                OO00O0O0O0OO0O0O0 =O0OOO000OO0OOO0OO .BAS .Handle_BAS_ChangeMktType (O0OOO00OOOO0O00OO )#line:5103
            if OO00O0O0O0OO0O0O0 :#line:5104
                O0O0000OO00O000O0 .__O0O00O0000O0O0000 (O0OOO000OO0OOO0OO .SolIce ,O0OOO000OO0OOO0OO .BAS )#line:5105
        except Exception as O0O0O00000O0O00OO :#line:5106
            O0O0000OO00O000O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_RTQuote_BAS:{O0O0O00000O0O00OO}")#line:5108
    def __O0OOO0OO00O00O0O0 (O0O0OOOO0OOO0O0O0 ,O0O00OO0OOO0OOOO0 :str ,O0OO0O0O0O0O0OOO0 :bool ):#line:5112
        ""#line:5113
        try :#line:5114
            OO0000000OO0OO000 =f"Quote/TWS/*/*/{O0O00OO0OOO0OOOO0}/RECOVER"#line:5115
            OO00OO0O0OOOO00O0 ,OO0OOOO0O0OOOO0OO =O0O0OOOO0OOO0O0O0 .__O00O0OOOO000000OO (O0O0OOOO0OOO0O0O0 ._vRcvTopic_Stk ,OO0000000OO0OO000 ,'utf-8',O0O0OOOO0OOO0O0O0 ._vRcvTopic_Stk_Req )#line:5117
            if OO00OO0O0OOOO00O0 :#line:5119
                OOO000O00OO0OO0O0 =json .loads (OO0OOOO0O0OOOO0OO )#line:5120
                if "status"in OOO000O00OO0OO0O0 and len (OOO000O00OO0OO0O0 ["status"])>0 :#line:5121
                    if OOO000O00OO0OO0O0 ["status"][0 ]=="error":#line:5122
                        O0O0OOOO0OOO0O0O0 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteSTK取個一般上市上櫃股票商品檔](aData={OO0OOOO0O0OOOO0OO})行情回補資料有誤!")#line:5124
                        return RCode .FAIL #line:5125
                if "BAS"in OOO000O00OO0OO0O0 and len (OOO000O00OO0OO0O0 ["BAS"])==0 :#line:5126
                    O0O0OOOO0OOO0O0O0 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteSTK取個一般上市上櫃股票商品檔](aData={OO0OOOO0O0OOOO0OO})沒有BAS資料!")#line:5128
                    return RCode .FAIL #line:5129
                if "HL"in OOO000O00OO0OO0O0 and len (OOO000O00OO0OO0O0 ["HL"])==0 :#line:5130
                    O0O0OOOO0OOO0O0O0 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteSTK取個一般上市上櫃股票商品檔](aData={OO0OOOO0O0OOOO0OO})沒有HL資料!")#line:5132
                    return RCode .FAIL #line:5133
            if OO00OO0O0OOOO00O0 and OO0OOOO0O0OOOO0OO !="":#line:5135
                OO0OO0OOO0O0O0O0O =OOO000O00OO0OO0O0 ["HL"][0 ].split ('|')[1 ]#line:5136
                if OO0OO0OOO0O0O0O0O ==O0O0OOOO0OOO0O0O0 .__OOOOOO0OOO000OO0O :#line:5137
                    O0OO000OOOOO0OO00 =O0O0OOOO0OOO0O0O0 .__OO00000000O0OO0O0 (False ,O0O00OO0OOO0OOOO0 ,O0OO0O0O0O0O0OOO0 ,OOO000O00OO0OO0O0 )#line:5138
                else :#line:5139
                    O0OO000OOOOO0OO00 =O0O0OOOO0OOO0O0O0 .__O00O00000O00000O0 (False ,O0O00OO0OOO0OOOO0 ,O0OO0O0O0O0O0OOO0 ,OOO000O00OO0OO0O0 )#line:5140
                return O0OO000OOOOO0OO00 #line:5141
            else :#line:5142
                return RCode .FAIL #line:5143
        except Exception as OOO000O0O000OO00O :#line:5144
            O0O0OOOO0OOO0O0O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteSTK:{OOO000O0O000OO00O}")#line:5145
            O0O0OOOO0OOO0O0O0 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteSTK]{O0O00OO0OOO0OOOO0}新增紀錄失敗!({OOO000O0O000OO00O})")#line:5146
            OOO0O00000000O000 =threading .Thread (target =O0O0OOOO0OOO0O0O0 .__O000OO0000OO00O00 ,args =(STKxFUT .STK ,O0O00OO0OOO0OOOO0 ))#line:5148
            OOO0O00000000O000 .start ()#line:5149
            return RCode .FAIL #line:5150
    def __OO00000OO0O0OOOO0 (O00O0O0O00O0O000O ,OOO0O0O0O000O00OO :str ,O00OO0O00O0OO0O00 :bool ):#line:5152
        ""#line:5153
        try :#line:5154
            O0000O00O0OOO0000 =TCacheJob ()#line:5155
            O0000O00O0OOO0000 .prod =OOO0O0O0O000O00OO #line:5156
            O0000O00O0OOO0000 .TopicBAS =f"Quote/TWS/*/*/{OOO0O0O0O000O00OO}/BAS"#line:5157
            O0000O00O0OOO0000 .RequestID =O00O0O0O00O0O000O .GetRequestID ()#line:5158
            O0000O00O0OOO0000 .HandleProc =O00O0O0O00O0O000O .__OO000OOOO0O0O00OO #line:5159
            O00O0O0O00O0O000O ._fMapCacheJob [O0000O00O0OOO0000 .RequestID ]=O0000O00O0OOO0000 #line:5160
            O00O0O0O00O0O000O .__O0OOOOO0O000OO00O (O0000O00O0OOO0000 .RequestID ,O0000O00O0OOO0000 .TopicBAS )#line:5161
            return RCode .OK #line:5162
        except Exception as OO0O00OOOO0000OO0 :#line:5163
            O00O0O0O00O0O000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteSTK:{OO0O00OOOO0000OO0}")#line:5164
            O00O0O0O00O0O000O .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteSTK]{OOO0O0O0O000O00OO}新增紀錄失敗!({OO0O00OOOO0000OO0})")#line:5165
            OO0OOOOOO0OO00000 =threading .Thread (target =O00O0O0O00O0O000O .__O000OO0000OO00O00 ,args =(STKxFUT .STK ,OOO0O0O0O000O00OO ))#line:5167
            OO0OOOOOO0OO00000 .start ()#line:5168
            return RCode .FAIL #line:5169
    def __O00000O00OO0OOO0O (OOOOOOO000O00OO00 ,OO0O0OOOO0000O0O0 :str ,O0O000OOO00O0000O :bool ):#line:5171
        ""#line:5172
        try :#line:5173
            O000000OOOOOOOOO0 =f"Quote/TWS/{OO0O0OOOO0000O0O0}/*/*/RECOVER"#line:5174
            OO00O0O00O0OOO000 ,O0O00OO0OOOO000O0 =OOOOOOO000O00OO00 .__O00O0OOOO000000OO (OOOOOOO000O00OO00 ._vRcvTopic_Stk ,O000000OOOOOOOOO0 ,'utf-8',OOOOOOO000O00OO00 ._vRcvTopic_Stk_Req )#line:5175
            if OO00O0O00O0OOO000 and O0O00OO0OOOO000O0 !="":#line:5177
                OOO0OO0OO0O0O00O0 =json .loads (O0O00OO0OOOO000O0 )#line:5179
                if "status"in OOO0OO0OO0O0O00O0 and len (OOO0OO0OO0O0O00O0 ["status"])>0 :#line:5180
                    if OOO0OO0OO0O0O00O0 ["status"][0 ]=="error":#line:5181
                        OOO0OOO0OOO0000OO =f"[證][DoSubQuoteByCategory](aCat={OO0O0OOOO0000O0O0}, sResData={O0O00OO0OOOO000O0})行情回補資料有誤!"#line:5182
                        OOOOOOO000O00OO00 .__OO0OO0O00OOOO00O0 (OOO0OOO0OOO0000OO )#line:5183
                        return False #line:5184
                if "BAS"in OOO0OO0OO0O0O00O0 and len (OOO0OO0OO0O0O00O0 ["BAS"])==0 :#line:5185
                    OOO0OOO0OOO0000OO =f"[證][DoSubQuoteByCategory](aCat={OO0O0OOOO0000O0O0}, sResData={O0O00OO0OOOO000O0})沒有BAS資料!"#line:5186
                    OOOOOOO000O00OO00 .__OO0OO0O00OOOO00O0 (OOO0OOO0OOO0000OO )#line:5187
                    return False #line:5188
                if "HL"in OOO0OO0OO0O0O00O0 and len (OOO0OO0OO0O0O00O0 ["HL"])==0 :#line:5189
                    OOO0OOO0OOO0000OO =f"[證][DoSubQuoteByCategory](aCat={OO0O0OOOO0000O0O0}, sResData={O0O00OO0OOOO000O0})沒有HL資料!"#line:5190
                    OOOOOOO000O00OO00 .__OO0OO0O00OOOO00O0 (OOO0OOO0OOO0000OO )#line:5191
                    return False #line:5192
                if OO0O0OOOO0000O0O0 ==OOOOOOO000O00OO00 .__OOOOOO0OOO000OO0O :#line:5194
                    OOOOOOO000O00OO00 .__OO00000000O0OO0O0 (True ,OO0O0OOOO0000O0O0 ,O0O000OOO00O0000O ,OOO0OO0OO0O0O00O0 )#line:5195
                else :#line:5196
                    OOOOOOO000O00OO00 .__O00O00000O00000O0 (True ,OO0O0OOOO0000O0O0 ,O0O000OOO00O0000O ,OOO0OO0OO0O0O00O0 )#line:5197
                return True #line:5198
        except Exception as OO00O0OO0O0O00O0O :#line:5199
            OOOOOOO000O00OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteByCategorySTK:{OO00O0OO0O0O00O0O}")#line:5200
            OOOOOOO000O00OO00 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteByCategorySTK]{OO0O0OOOO0000O0O0}新增紀錄失敗!({OO00O0OO0O0O00O0O})")#line:5201
        OOO00OOOO00O00000 =threading .Thread (target =OOOOOOO000O00OO00 .__O000OO0000OO00O00 ,args =(STKxFUT .STK ,OO0O0OOOO0000O0O0 ))#line:5204
        OOO00OOOO00O00000 .start ()#line:5205
    def __O00OOOO000OO000OO (OO0OO00O0O000OO00 ,O0OOOOOOOO0OOOO0O :str ,O0OO000OOOO00OO00 :bool ):#line:5207
        ""#line:5208
        try :#line:5209
            O0000OO00O00OO000 =TCacheJob ()#line:5210
            O0000OO00O00OO000 .TopicBAS =f"Quote/TWS/{O0OOOOOOOO0OOOO0O}/*/*/BAS"#line:5211
            O0000OO00O00OO000 .oneProd =False #line:5212
            O0000OO00O00OO000 .RequestID =OO0OO00O0O000OO00 .GetRequestID ()#line:5213
            O0000OO00O00OO000 .HandleProc =OO0OO00O0O000OO00 .__OO000OOOO0O0O00OO #line:5214
            O0000OO00O00OO000 .Params ["Category"]="SubQuoteByCategory_BAS"#line:5215
            OO0OO00O0O000OO00 ._fMapCacheJob [O0000OO00O00OO000 .RequestID ]=O0000OO00O00OO000 #line:5216
            OO0OO00O0O000OO00 .__O0OOOOO0O000OO00O (O0000OO00O00OO000 .RequestID ,O0000OO00O00OO000 .TopicBAS )#line:5217
            return RCode .OK #line:5218
        except Exception as O0O0O0OO0OOO0OOO0 :#line:5219
            OO0OO00O0O000OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteByCategorySTK:{O0O0O0OO0OOO0OOO0}")#line:5220
            OO0OO00O0O000OO00 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteByCategorySTK]{O0OOOOOOOO0OOOO0O}新增紀錄失敗!({O0O0O0OO0OOO0OOO0})")#line:5221
        O00OO0OO0O00O0O0O =threading .Thread (target =OO0OO00O0O000OO00 .__O000OO0000OO00O00 ,args =(STKxFUT .STK ,O0OOOOOOOO0OOOO0O ))#line:5224
        O00OO0OO0O00O0O0O .start ()#line:5225
    def __OO000O0O0O0OOO0OO (OOOO00O00O00O0OO0 ,OO00000000OO0OO0O :str ,O0O0OO0O00000O00O :bool ):#line:5227
        ""#line:5230
        try :#line:5231
            O0OOOO0O0OOOO00O0 =TCacheJob ()#line:5232
            O0OOOO0O0OOOO00O0 .prod =OO00000000OO0OO0O #line:5233
            O0OOOO0O0OOOO00O0 .TopicBAS =f"Quote/TWF/*/{OO00000000OO0OO0O}/BAS"#line:5234
            O0OOOO0O0OOOO00O0 .RequestID =OOOO00O00O00O0OO0 .GetRequestID ()#line:5235
            O0OOOO0O0OOOO00O0 .HandleProc =OOOO00O00O00O0OO0 .__OOOO0OO00O0O0000O #line:5236
            OOOO00O00O00O0OO0 ._fMapCacheJob [O0OOOO0O0OOOO00O0 .RequestID ]=O0OOOO0O0OOOO00O0 #line:5237
            OOOO00O00O00O0OO0 .__O0OOOOO0O000OO00O (O0OOOO0O0OOOO00O0 .RequestID ,O0OOOO0O0OOOO00O0 .TopicBAS )#line:5238
            return RCode .OK #line:5239
        except Exception as O00O0OO0O00000OOO :#line:5240
            OOOO00O00O00O0OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteFUT:{O00O0OO0O00000OOO}")#line:5241
            OOOO00O00O00O0OO0 .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteFUT]{OO00000000OO0OO0O}新增紀錄失敗!({O00O0OO0O00000OOO})")#line:5242
            O00OOO000OOO00O0O =threading .Thread (target =OOOO00O00O00O0OO0 .__O000OO0000OO00O00 ,args =(STKxFUT .FUT ,OO00000000OO0OO0O ))#line:5243
            O00OOO000OOO00O0O .start ()#line:5244
            return RCode .FAIL #line:5245
    def __OOO000O0OOOO00000 (O0OO0OO000O00OOOO ,OOO0OOO00OOOOOOOO :str ,OOOO0000OO00OO00O :bool ):#line:5247
        ""#line:5250
        try :#line:5251
            O00OO0OOOOOO00O00 :str =f"Quote/TWF/*/{OOO0OOO00OOOOOOOO}/RECOVER"#line:5252
            O0000OO000O00OO0O ,OO00O0OOO000000O0 =O0OO0OO000O00OOOO .__O00O0OOOO000000OO (O0OO0OO000O00OOOO ._vRcvTopic_Fut ,O00OO0OOOOOO00O00 ,'utf-8',O0OO0OO000O00OOOO ._vRcvTopic_Fut_Req )#line:5254
            if O0000OO000O00OO0O and OO00O0OOO000000O0 !="":#line:5256
                O0O0O0OOO0000O0O0 =json .loads (OO00O0OOO000000O0 )#line:5257
                if "status"in O0O0O0OOO0000O0O0 and len (O0O0O0OOO0000O0O0 ["status"])>0 :#line:5258
                    if O0O0O0OOO0000O0O0 ["status"][0 ]=="error":#line:5259
                        O0OO0OO000O00OOOO .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteFUT](aSolIce={OOO0OOO00OOOOOOOO}, aData={OO00O0OOO000000O0})行情回補資料有誤!")#line:5260
                        return RCode .FAIL #line:5261
                if "BAS"in O0O0O0OOO0000O0O0 and len (O0O0O0OOO0000O0O0 ["BAS"])==0 :#line:5262
                    O0OO0OO000O00OOOO .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteFUT](aSolIce={OOO0OOO00OOOOOOOO},aData={OO00O0OOO000000O0})沒有BAS資料!")#line:5263
                    return RCode .FAIL #line:5264
                if "HL"in O0O0O0OOO0000O0O0 and len (O0O0O0OOO0000O0O0 ["HL"])==0 :#line:5265
                    O0OO0OO000O00OOOO .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteFUT](aSolIce={OOO0OOO00OOOOOOOO},aData={OO00O0OOO000000O0})沒有HL資料!")#line:5266
                    return RCode .FAIL #line:5267
                OO0OOO0OO0OO00000 =O0OO0OO000O00OOOO .__OOOO00000O0O0OOO0 (False ,OOO0OOO00OOOOOOOO ,OOOO0000OO00OO00O ,O0O0O0OOO0000O0O0 )#line:5270
                return OO0OOO0OO0OO00000 #line:5271
            else :#line:5272
                return RCode .FAIL #line:5273
        except Exception as OOO0OOO0OO0O0O00O :#line:5274
            O0OO0OO000O00OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteFUT:{OOO0OOO0OO0O0O00O}")#line:5275
            O0OO0OO000O00OOOO .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteFUT]{OOO0OOO00OOOOOOOO}新增紀錄失敗!({OOO0OOO0OO0O0O00O})")#line:5276
            OOOOO000OOO0OOO0O =threading .Thread (target =O0OO0OO000O00OOOO .__O000OO0000OO00O00 ,args =(STKxFUT .FUT ,OOO0OOO00OOOOOOOO ))#line:5277
            OOOOO000OOO0OOO0O .start ()#line:5278
            return RCode .FAIL #line:5279
    def __OO00O000OOO0000OO (OOO00OO0O0O000000 ,O0000O0O0O0OOO0OO :str ,OOOOO000OOO0000OO :bool ):#line:5280
        try :#line:5281
            O0OO0O00O00O00O00 :bool =False #line:5282
            OOOOO00OOO0000000 :str =f"Quote/TWF/{O0000O0O0O0OOO0OO}/*/RECOVER"#line:5283
            O0OOOOOOOO00OO000 :str =""#line:5284
            O0OO0O00O00O00O00 ,O0OOOOOOOO00OO000 =OOO00OO0O0O000000 .__O00O0OOOO000000OO (OOO00OO0O0O000000 ._vRcvTopic_Fut ,OOOOO00OOO0000000 ,'utf-8',OOO00OO0O0O000000 ._vRcvTopic_Fut_Req )#line:5286
            if O0OO0O00O00O00O00 :#line:5288
                O0OOO0O0O0O0OO0OO =json .loads (O0OOOOOOOO00OO000 )#line:5289
                if "status"in O0OOO0O0O0O0OO0OO and len (O0OOO0O0O0O0OO0OO ["status"])>0 :#line:5292
                    if O0OOO0O0O0O0OO0OO ["status"][0 ]=="error":#line:5293
                        OOO00OO0O0O000000 .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteByCategory](aCat={O0000O0O0O0OOO0OO}, aData={O0OOOOOOOO00OO000})行情回補資料有誤!")#line:5294
                        return #line:5295
                if "BAS"in O0OOO0O0O0O0OO0OO and len (O0OOO0O0O0O0OO0OO ["BAS"])==0 :#line:5296
                    OOO00OO0O0O000000 .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteByCategory](aCat={O0000O0O0O0OOO0OO}, aData={O0OOOOOOOO00OO000})沒有BAS資料!")#line:5297
                    return #line:5298
                if "HL"in O0OOO0O0O0O0OO0OO and len (O0OOO0O0O0O0OO0OO ["HL"])==0 :#line:5299
                    OOO00OO0O0O000000 .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuoteByCategory](aCat={O0000O0O0O0OOO0OO}, aData={O0OOOOOOOO00OO000})沒有HL資料!")#line:5300
                    return #line:5301
                OOO00OO0O0O000000 .__OOOO00000O0O0OOO0 (True ,O0000O0O0O0OOO0OO ,OOOOO000OOO0000OO ,O0OOO0O0O0O0OO0OO )#line:5304
                return #line:5305
        except Exception as OO00OOOOO0OO0OO0O :#line:5306
            pass #line:5307
        O0O0O0O0OO0O0O00O =threading .Thread (target =OOO00OO0O0O000000 .__O000OO0000OO00O00 ,args =(STKxFUT .FUT ,f"[期]新增分類紀錄失敗{O0000O0O0O0OOO0OO}"))#line:5309
        O0O0O0O0OO0O0O00O .start ()#line:5310
    def __OO0OO0O0OOOOOOOO0 (O000OOO000OO00OO0 ,O0O0O0OO0OOOO0O00 :str ,OO00OO00O000000O0 :bool ):#line:5312
        ""#line:5313
        try :#line:5314
            OOOOO00OO000OOOO0 =TCacheJob ()#line:5315
            OOOOO00OO000OOOO0 .TopicBAS =f"Quote/TWF/{O0O0O0OO0OOOO0O00}/*/BAS"#line:5316
            OOOOO00OO000OOOO0 .oneProd =False #line:5317
            OOOOO00OO000OOOO0 .RequestID =O000OOO000OO00OO0 .GetRequestID ()#line:5318
            OOOOO00OO000OOOO0 .HandleProc =O000OOO000OO00OO0 .__OOOO0OO00O0O0000O #line:5319
            OOOOO00OO000OOOO0 .Params ["Category"]="SubQuoteByCategory_BAS"#line:5320
            O000OOO000OO00OO0 ._fMapCacheJob [OOOOO00OO000OOOO0 .RequestID ]=OOOOO00OO000OOOO0 #line:5321
            O000OOO000OO00OO0 .__O0OOOOO0O000OO00O (OOOOO00OO000OOOO0 .RequestID ,OOOOO00OO000OOOO0 .TopicBAS )#line:5322
            return RCode .OK #line:5323
        except Exception as OOOOO0O00OOO0O000 :#line:5324
            O000OOO000OO00OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteByCategoryFUT:{OOOOO0O00OOO0O000}")#line:5325
            O000OOO000OO00OO0 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuoteByCategoryFUT]{O0O0O0OO0OOOO0O00}新增紀錄失敗!({OOOOO0O00OOO0O000})")#line:5326
        O0OO0000O000O00OO =threading .Thread (target =O000OOO000OO00OO0 .__O000OO0000OO00O00 ,args =(STKxFUT .FUT ,f"[期]新增分類紀錄失敗{O0O0O0OO0OOOO0O00}"))#line:5328
        O0OO0000O000O00OO .start ()#line:5329
    def __OO0OOO0O00OOOOOOO (O000O00OOOOOOO000 ,OOOOOOO00000OOOOO :str ,OO00OO00O000OOOOO :bool ):#line:5331
        try :#line:5332
            OOO0O0OO0O0OOO0O0 :bool =False #line:5333
            O00OO000O0OOO0O0O =f"QuoteOvs/*/*/{OOOOOOO00000OOOOO}/RECOVER"#line:5335
            OOO0O0OO0O0OOO0O0 ,OOO0000OO00OOO0O0 =O000O00OOOOOOO000 .__O00O0OOOO000000OO (O000O00OOOOOOO000 ._vRcvTopic_OvsFut ,O00OO000O0OOO0O0O ,'big5',O000O00OOOOOOO000 ._vRcvTopic_OvsFut_Req )#line:5336
            if OOO0O0OO0O0OOO0O0 :#line:5338
                OOOO000O000O00O0O =json .loads (OOO0000OO00OOO0O0 )#line:5339
                if "status"in OOOO000O000O00O0O and len (OOOO000O000O00O0O ["status"])>0 :#line:5340
                    if OOOO000O000O00O0O ["status"][0 ]=="error":#line:5341
                         O000O00OOOOOOO000 .__OO0OO0O00OOOO00O0 (f"[海期][DoSubQuoteOvsFUT](aSolIce={OOOOOOO00000OOOOO}, aData={OOO0000OO00OOO0O0})行情回補資料有誤!")#line:5342
                         return RCode .FAIL #line:5343
                    if "BAS"in OOOO000O000O00O0O and len (OOOO000O000O00O0O ["BAS"])==0 :#line:5344
                        O000O00OOOOOOO000 .__OO0OO0O00OOOO00O0 (f"[海期][DoSubQuoteOvsFUT](aSolIce={OOOOOOO00000OOOOO}, aData={OOO0000OO00OOO0O0})沒有BAS資料!")#line:5345
                        return RCode .FAIL #line:5346
                OO0OOOOO00O0OO000 =O000O00OOOOOOO000 .__O00O0000O0OO0OO0O (False ,OOOOOOO00000OOOOO ,OO00OO00O000OOOOO ,OOOO000O000O00O0O )#line:5349
                return OO0OOOOO00O0OO000 #line:5351
            else :#line:5352
                return RCode .FAIL #line:5353
        except Exception as OOO0O00OOOO0O0OO0 :#line:5354
            O000O00OOOOOOO000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuoteOvsFUT: {OOO0O00OOOO0O0OO0}")#line:5356
            O0O00OOO0O0O00OO0 =TQtRcvEventData ()#line:5358
            O0O00OOO0O0O00OO0 .SetRcvBAS_Fail (OOOOOOO00000OOOOO )#line:5359
            O000O00OOOOOOO000 .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O0O00OOO0O0O00OO0 )#line:5360
            return RCode .FAIL #line:5361
    def __O0OOO000OOO0OO0OO (O0OO00O0O0000O0OO ,O0OO00000000000O0 :bool ,aExchange :str ="*"):#line:5363
        ""#line:5367
        try :#line:5368
            OOO000OO000000000 :bool =False #line:5369
            O0O00O000OOO00O0O :str =f"QuoteOvs/{aExchange}/FUT/*/RECOVER"#line:5370
            O00000O0OO00O00O0 :str =""#line:5371
            OOO000OO000000000 ,O00000O0OO00O00O0 =O0OO00O0O0000O0OO .__O00O0OOOO000000OO (O0OO00O0O0000O0OO ._vRcvTopic_OvsFut ,O0O00O000OOO00O0O ,'big5',O0OO00O0O0000O0OO ._vRcvTopic_OvsFut_Req )#line:5372
            if OOO000OO000000000 :#line:5374
                OOOO00OOOOO00OO00 =json .loads (O00000O0OO00O00O0 )#line:5375
                if "status"in OOOO00OOOOO00OO00 and len (OOOO00OOOOO00OO00 ["status"])>0 :#line:5377
                    if OOOO00OOOOO00OO00 ["status"][0 ]=="error":#line:5378
                        O0OO00O0O0000O0OO .__OO0OO0O00OOOO00O0 (f"[海期][DoSubQuoteByCategory](aSolIce={aExchange}, aData={O00000O0OO00O00O0})行情回補資料有誤!")#line:5379
                        return RCode .FAIL #line:5380
                    if "BAS"in OOOO00OOOOO00OO00 and len (OOOO00OOOOO00OO00 ["BAS"])==0 :#line:5381
                        O0OO00O0O0000O0OO .__OO0OO0O00OOOO00O0 (f"[海期][DoSubQuoteByCategory](aSolIce={aExchange}, aData={O00000O0OO00O00O0})沒有BAS資料!")#line:5382
                        return RCode .FAIL #line:5383
                O0OOO0O0O00OO0O0O =O0OO00O0O0000O0OO .__O00O0000O0OO0OO0O (False ,aExchange ,O0OO00000000000O0 ,OOOO00OOOOO00OO00 )#line:5387
                return O0OOO0O0O00OO0O0O #line:5388
            else :#line:5389
                return RCode .FAIL #line:5390
        except Exception as OOOO00O00OO0O0OO0 :#line:5391
            O0OO00O0O0000O0OO .__OO0OO0O00OOOO00O0 (f"[海期][DoSubQuoteByCategoryOvsFUT] 新增分類紀錄失敗!")#line:5392
            return RCode .FAIL #line:5393
    def __OO0O000O0OO0000OO (OO0OOO0OOOO0OOO00 ,O0O0O0OOOOOO0O0OO :str ):#line:5395
        ""#line:5398
        OO00O00OO00O0OO0O :str =""#line:5400
        try :#line:5401
            O0OO000O00OO00O0O :list =[]#line:5402
            O0OOOO0OO0O00O00O ,O0OO000O00OO00O0O ,OO00O00OO00O0OO0O =OO0OOO0OOOO0OOO00 ._fMapQuoteOvsFUT .GetItem_ByExchange (O0O0O0OOOOOO0O0OO )#line:5403
            if O0OOOO0OO0O00O00O ==False :#line:5404
                return False ,OO00O00OO00O0OO0O #line:5405
            for O000OO000O00O0O0O in O0OO000O00OO00O0O :#line:5406
                OO0OOO0OOOO0OOO00 .__O0OOOOO0OOOO0000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000OO000O00O0O0O )#line:5407
            return True ,""#line:5408
        except Exception as O0OOO0O00000O00OO :#line:5410
            OO00O00OO00O0OO0O =f"[海期][DoUnSubQuoteByCategory](aExchange={O0O0O0OOOOOO0O0OO}){O0OOO0O00000O00OO}"#line:5411
        return False ,OO00O00OO00O0OO0O #line:5412
    def __O00O00000O00000O0 (OOOO0O0OO00O00000 ,OO0O000000OO0000O :bool ,OO00OO0OO00O0OOO0 :str ,O0O0O00O0OO00000O :bool ,OOO0OO0O0OOOO00O0 ,topic :str =""):#line:5414
        ""#line:5415
        try :#line:5416
            OO0O0O00O0OOO0OOO :TObjStkQuoteMap =None #line:5417
            OOO0O00000000OOOO :str =""#line:5418
            OO0O000O00OOOOO00 ,OO0O0O00O0OOO0OOO ,OOO0O00000000OOOO =OOOO0O0OO00O00000 ._fMapQuoteSTK .AddDataBySolIce (OO0O000000OO0000O ,OO00OO0OO00O0OOO0 ,OOO0OO0O0OOOO00O0 ,O0O0O00O0OO00000O ,topic )#line:5419
            if OO0O000O00OOOOO00 :#line:5420
                OOOO0O0OO00O00000 .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .STK ,arg2 =OO0O0O00O0OOO0OOO )#line:5421
                for O0000OO0O00O0O0OO ,OO00O0O0O0OO0OOO0 in OO0O0O00O0OOO0OOO .items ():#line:5424
                    OOOOO0OO0OOO00O0O :TStkQuoteData =OO00O0O0O0OO0OOO0 #line:5425
                    if topic =="":#line:5426
                        OOOO0O0OO00O00000 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .STK ,arg2 =OOOOO0OO0OOO00O0O .HL .TopicTX )#line:5427
                        OOOO0O0OO00O00000 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .STK ,arg2 =OOOOO0OO0OOO00O0O .HL .Topic5Q )#line:5428
                    else :#line:5429
                        OOOO0O0OO00O00000 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .STK ,arg2 =OOOOO0OO0OOO00O0O .BAS .TopicTX )#line:5430
                        OOOO0O0OO00O00000 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .STK ,arg2 =OOOOO0OO0OOO00O0O .BAS .Topic5Q )#line:5431
                return RCode .OK #line:5432
            else :#line:5433
                OOOO0O0OO00O00000 .__OO0OO0O00OOOO00O0 (f"[證][DoSubQuote_RTonlySTK]({OO0O000000OO0000O},{OO00OO0OO00O0OOO0})回補失敗!({OOO0O00000000OOOO})")#line:5434
                return RCode .FAIL #line:5435
        except Exception as OOOO0O0OO0O0O0OOO :#line:5437
            OOOO0O0OO00O00000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuote_RTonlySTK: {OOOO0O0OO0O0O0OOO}")#line:5439
            return RCode .FAIL #line:5440
    def __OOOO00000O0O0OOO0 (O0OO0000OOOO0OO0O ,O0O0O0OOOO000OO0O :bool ,O00O00O0OOO0O0000 :str ,OO0000OO0OOO0OOO0 :bool ,O00O00OO00OO0O0OO ,topic :str =""):#line:5442
        ""#line:5445
        try :#line:5446
            O0OO00OO0O0OO0OO0 :TObjFutQuoteMap =None #line:5447
            O0O0O000OOOO00000 :str =""#line:5448
            OOOO0O0OO00O000OO ,O0OO00OO0O0OO0OO0 ,O0O0O000OOOO00000 =O0OO0000OOOO0OO0O ._fMapQuoteFUT .AddDataBySolIce (O0O0O0OOOO000OO0O ,O00O00O0OOO0O0000 ,O00O00OO00OO0O0OO ,OO0000OO0OOO0OOO0 ,topic )#line:5449
            if OOOO0O0OO00O000OO :#line:5450
                O0OO0000OOOO0OO0O .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .FUT ,arg2 =O0OO00OO0O0OO0OO0 )#line:5451
                for O0OOO0O0O0OOOOO00 ,OOOO000OO0OO0OOO0 in O0OO00OO0O0OO0OO0 .items ():#line:5454
                    O000O00O0O0O00O0O :TFutQuoteData =OOOO000OO0OO0OOO0 #line:5455
                    if topic =="":#line:5456
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .HL .TopicTX )#line:5457
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .HL .Topic5Q )#line:5458
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .HL .Topic5QTOT )#line:5459
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .HL .TopicBAS )#line:5460
                    else :#line:5461
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .BAS .TopicTX )#line:5462
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .BAS .Topic5Q )#line:5463
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .BAS .Topic5QTOT )#line:5464
                        O0OO0000OOOO0OO0O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00O0O0O00O0O .BAS .TopicBAS )#line:5465
                return RCode .OK #line:5466
            else :#line:5467
                O0OO0000OOOO0OO0O .__OO0OO0O00OOOO00O0 (f"[期][DoSubQuote_RTonlyFUT]{O00O00O0OOO0O0000}新增紀錄失敗!({O0O0O000OOOO00000})")#line:5468
                return RCode .FAIL #line:5469
        except Exception as O0O0OO000OO0OOOO0 :#line:5471
            O0OO0000OOOO0OO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuote_RTonlyFUT: {O0O0OO000OO0OOOO0}")#line:5473
            return RCode .FAIL #line:5474
    def __O00O0000O0OO0OO0O (OO00OO00OOO0OO000 ,OO0000O0OOO0OO0OO :bool ,OOOO0OOO0O00OO000 :str ,OOO00OO000OO00O00 :bool ,OO0O00OO00OO0OOO0 ):#line:5476
        ""#line:5478
        try :#line:5479
            O0O0OO00O0O0O0OOO :TMapOvsFutQuoteData =None #line:5480
            OOO00OOO00O0OOO0O :str =""#line:5481
            OOO00O0000OOOOO00 ,O0O0OO00O0O0O0OOO ,OOO00OOO00O0OOO0O =OO00OO00OOO0OO000 ._fMapQuoteOvsFUT .AddDataBySolIce (OO0000O0OOO0OO0OO ,OOOO0OOO0O00OO000 ,OO0O00OO00OO0OOO0 ,OOO00OO000OO00O00 )#line:5482
            if OOO00O0000OOOOO00 :#line:5483
                O00OOOOOOOOO000OO =TQtRcvEventData ()#line:5485
                O00OOOOOOOOO000OO .SetRcvBAS_Succ ("",O0O0OO00O0O0O0OOO )#line:5486
                OO00OO00OOO0OO000 .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O00OOOOOOOOO000OO )#line:5487
                for OOOO00OOO00OOOOOO ,O00OOO00O0O00O0O0 in O0O0OO00O0O0O0OOO .items ():#line:5490
                    O0O0O0O0OO000O0O0 :TOvsFutQuoteData =O00OOO00O0O00O0O0 #line:5491
                    OO00OO00OOO0OO000 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O0O0O0O0OO000O0O0 .HL .TopicTX )#line:5492
                    OO00OO00OOO0OO000 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .OVSFUT ,arg2 =O0O0O0O0OO000O0O0 .HL .Topic5Q )#line:5493
                return RCode .OK #line:5494
            else :#line:5495
                OO00OO00OOO0OO000 .__OO0OO0O00OOOO00O0 (f"[海期][DoSubQuote_RTonlyOvsFUT]{OOOO0OOO0O00OO000}新增紀錄失敗!({OOO00OOO00O0OOO0O})")#line:5496
                return RCode .FAIL #line:5497
        except Exception as O00000O0O0O00O000 :#line:5498
            OO00OO00OOO0OO000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubQuote_RTonlyOvsFUT: {O00000O0O0O00O000}")#line:5499
            return RCode .FAIL #line:5500
    def __O0O00OO00OOOOO0OO (OO0O00OOOOO00OOO0 ,OO0OOO00000O0OOOO :str ,O00OOOOO0O000OO0O :bool ):#line:5504
        ""#line:5507
        try :#line:5508
            OOOOO00OOO00OO0OO =False #line:5509
            OO000OO00OO0000O0 =f"Quote/TWS/*/*/{OO0OOO00000O0OOOO}/RECOVER"#line:5510
            O00OOO000O000O0O0 =""#line:5511
            OOOOO00OOO00OO0OO ,O00OOO000O000O0O0 =OO0O00OOOOO00OOO0 .__O00O0OOOO000000OO (OO0O00OOOOO00OOO0 ._vRcvTopic_Stk ,OO000OO00OO0000O0 ,'utf-8',OO0O00OOOOO00OOO0 ._vRcvTopic_Stk_Req )#line:5513
            if OOOOO00OOO00OO0OO :#line:5514
                O0O000OOOO0000O00 =json .loads (O00OOO000O000O0O0 )#line:5515
            if OOOOO00OOO00OO0OO and O00OOO000O000O0O0 !="":#line:5516
                OO00O00O0O0O0O0O0 :TStkQuoteData =None #line:5517
                OO00O0000OOO0OOO0 :str #line:5518
                O0OOOO0O0O0OOOO00 ,OO00O00O0O0O0O0O0 ,OO00O0000OOO0OOO0 =OO0O00OOOOO00OOO0 ._fMapQuoteSTK .AddRcvData (TStkProdKind .pkIndex ,OO0OOO00000O0OOOO ,O00OOO000O000O0O0 ,O00OOOOO0O000OO0O )#line:5520
                if O0OOOO0O0O0OOOO00 :#line:5521
                    OO0O00OOOOO00OOO0 .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .STK ,arg2 =OO00O00O0O0O0O0O0 )#line:5523
                    OO0O00OOOOO00OOO0 .__OO00000000O0OO0O0 (OO00O00O0O0O0O0O0 .HL .Market ,OO00O00O0O0O0O0O0 .HL .StkKind ,OO0OOO00000O0OOOO ,O0O000OOOO0000O00 )#line:5525
                    return #line:5526
                else :#line:5527
                    OO0O00OOOOO00OOO0 .__OO0OO0O00OOOO00O0 (f"[證][DoSubIdxQuoteSTK]{OO0OOO00000O0OOOO}新增紀錄失敗!")#line:5529
        except Exception as O000O000O000O0OO0 :#line:5531
            OO0O00OOOOO00OOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubIdxQuoteSTK:{O000O000O000O0OO0}")#line:5532
        OOO0OO00OO000OOO0 =threading .Thread (target =OO0O00OOOOO00OOO0 .__O000OOO00OOO0OOOO ,args =OO0OOO00000O0OOOO )#line:5534
        OOO0OO00OO000OOO0 .start ()#line:5535
    def __O00OOOOOO00OO0OOO (O0000O0OOOO00000O ,O00OO000O0OO00O0O :str ,O0OO0O000O0O00O0O :bool ):#line:5537
        ""#line:5540
        try :#line:5541
            OOOOO0OOOOOOOO000 :str =f"Quote/TWF/IDX/{O00OO000O0OO00O0O}/MR"#line:5543
            if O0000O0OOOO00000O ._fMapQuoteFUT .AddData (TFutProdKind .pkIndex ,O00OO000O0OO00O0O ,O0OO0O000O0O00O0O ,OOOOO0OOOOOOOO000 ,O0000O0OOOO00000O .__O0O00O0OOO000OOOO ):#line:5544
                O0000O0OOOO00000O .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .FUT ,arg2 =OOOOO0OOOOOOOO000 )#line:5545
            else :#line:5546
                O0000O0OOOO00000O .__OO0OO0O00OOOO00O0 (f"[期][DoSubIdxQuote_RTonly]{O00OO000O0OO00O0O}新增紀錄失敗!")#line:5548
        except Exception as O0OOOO00OO00O00O0 :#line:5549
            O0000O0OOOO00000O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubIdxQuoteFUT:{O0OOOO00OO00O00O0}")#line:5550
    def __OO00000000O0OO0O0 (O0000OO00OOOOO0O0 ,OO0O00OO0OO00O0O0 :bool ,O0OO000O0OOO0O000 :str ,O0O000O0O0OOOO000 :bool ,OO0O0O00OOOOO0OOO ):#line:5552
        ""#line:5556
        try :#line:5557
            OO0O0O00O00OOOO00 :TObjStkQuoteMap =None #line:5558
            O0O00OOOOOO000O00 :str =""#line:5559
            OO00O0OO000000OOO ,OO0O0O00O00OOOO00 ,O0O00OOOOOO000O00 =O0000OO00OOOOO0O0 ._fMapQuoteSTK .AddIdxDataBySolIce (OO0O00OO0OO00O0O0 ,O0OO000O0OOO0O000 ,OO0O0O00OOOOO0OOO ,O0O000O0O0OOOO000 )#line:5560
            if OO00O0OO000000OOO :#line:5562
                O0000OO00OOOOO0O0 .__O0OO0OOOO0OO0OOOO (OO0O0O00O00OOOO00 )#line:5564
                for O000OO0O0O0000OO0 ,OO0O00OO00OOO0OO0 in OO0O0O00O00OOOO00 .items ():#line:5568
                    O00O000O000OO0000 :TStkQuoteData =OO0O00OO00OOO0OO0 #line:5569
                    O0000OO00OOOOO0O0 .__O0O00000OOO0O000O .Add (arg1 =STKxFUT .STK ,arg2 =O00O000O000OO0000 .HL .TopicTX )#line:5570
                return RCode .OK #line:5571
            else :#line:5572
                O0000OO00OOOOO0O0 .__OO0OO0O00OOOO00O0 (f"[證][HandleRecover_Idx]({OO0O00OO0OO00O0O0},{O0OO000O0OOO0O000})新增紀錄失敗!({O0O00OOOOOO000O00})")#line:5573
                return RCode .FAIL #line:5574
        except Exception as O0000OOO0OO0OOOOO :#line:5575
            O0000OO00OOOOO0O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoSubIdxQuote_RTonlySTK:{O0000OOO0OO0OOOOO}")#line:5577
            return RCode .FAIL #line:5578
    def __O0OOOOO0O000OO00O (OOOOO0O0O0O0OO0O0 ,O00O0OOO00OOO00OO ,O0O00O00OOO000O00 :str ):#line:5581
        OOO000OO00OOOOOOO =CachedMessageSubscriptionRequest .as_available ("dc01",TopicSubscription .of (O0O00O00OOO000O00 ),60000 )#line:5582
        OOOOO0O0O0O0OO0O0 ._message_receiver .request_cached (OOO000OO00OOOOOOO ,O00O0OOO00OOO00OO ,OOOOO0O0O0O0OO0O0 ._cacheReqOutListener )#line:5583
    def callcache (OOO0OO0O0OO00O000 ,O0OOOO0OOO0OO0O0O ,OOOO0OOO0000O00O0 :str ):#line:5585
        OOO0OO0O0OO00O000 .__O0OOOOO0O000OO00O (O0OOOO0OOO0OO0O0O ,OOOO0OOO0000O00O0 )#line:5586
    def __OO000OOOO0O0O00OO (OOOOOO0O0OOO00O0O ,O0O0OO00OO0O000OO :TCacheJob ):#line:5588
        ""#line:5589
        try :#line:5590
            O00000O0OO00OO0OO :dict ={}#line:5591
            for OOO0O0O0O0O0OO0OO ,OO00OO0O0OOO0OO0O in O0O0OO00OO0O000OO .CacheData .items ():#line:5592
                OOO0OOO0000OO0000 :'InboundMessage'=OO00OO0O0OOO0OO0O #line:5593
                OOOOOOO0000O000O0 =OOO0OOO0000OO0000 .get_destination_name ()#line:5594
                OO0O0O0O00O0OOO00 =OOO0OOO0000OO0000 .get_payload_as_bytes ().decode ('utf-8')#line:5595
                O00O0000OO00O0OO0 :str =""#line:5596
                if OOOOOOO0000O000O0 .endswith (OOOOOO0O0OOO00O0O ._vQuote_BAS ):#line:5597
                    O00000O0OO00OO0OO ["BAS"]=[OO0O0O0O00O0OOO00 ]#line:5598
                    O00O0000OO00O0OO0 =OOOOOOO0000O000O0 #line:5599
                elif OOOOOOO0000O000O0 .endswith (OOOOOO0O0OOO00O0O ._vQuote_HL ):#line:5600
                    O00000O0OO00OO0OO ["HL"]=[OO0O0O0O00O0OOO00 ]#line:5601
            OOOOOO0O0OOO00O0O .__O00O00000O00000O0 (False ,O0O0OO00OO0O000OO .prod ,True ,O00000O0OO00OO0OO ,O00O0000OO00O0OO0 )#line:5603
        except Exception as O0000000000O00OO0 :#line:5605
            OOOOOO0O0OOO00O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_CacheJob_StkBAS Error:{O0000000000O00OO0}")#line:5606
    def __OO00OO00OO0O0OOOO (O0000OO0O0OO00OO0 ,O0O0OO00OO0OO0OO0 :TCacheJob ):#line:5608
        try :#line:5610
            O000OOOO00OOO0O0O :'InboundMessage'=O0O0OO00OO0OO0OO0 .CacheData [O0O0OO00OO0OO0OO0 .TopicHL ]#line:5611
            O00O0OOO00O0O0000 =O000OOOO00OOO0O0O .get_payload_as_bytes ().decode ('utf-8')#line:5612
            if O0000OO0O0OO00OO0 ._fMapQuoteSTK .get (O0O0OO00OO0OO0OO0 .TopicTX )is not None :#line:5613
                OOOO000OOOOO0OOOO :TObjStkQuoteMap =TObjStkQuoteMap ()#line:5614
                OOO0OO0OOOO0OOOO0 :TStkQuoteData =O0000OO0O0OO00OO0 ._fMapQuoteSTK [O0O0OO00OO0OO0OO0 .TopicTX ]#line:5615
                OOO0OO0OOOO0OOOO0 .UpdateHL =True #line:5616
                OOO0OO0OOOO0OOOO0 .HL .Handle_HL (O00O0OOO00O0O0000 )#line:5617
                OOO0OO0OOOO0OOOO0 .QtTX .HighPrice =OOO0OO0OOOO0OOOO0 .HL .Get_HighPrice ()#line:5619
                OOO0OO0OOOO0OOOO0 .QtTX .LowPrice =OOO0OO0OOOO0OOOO0 .HL .Get_LowPrice ()#line:5620
                OOO0OO0OOOO0OOOO0 .QtTX .HL_Sn_5Q =OOO0OO0OOOO0OOOO0 .HL .Get_Sn_5Q ()#line:5622
                OOO0OO0OOOO0OOOO0 .QtTX .HL_TotAmt =OOO0OO0OOOO0OOOO0 .HL .Get_TotAmt2Int ()#line:5624
                OOOO000OOOOO0OOOO [O0O0OO00OO0OO0OO0 .prod ]=OOO0OO0OOOO0OOOO0 #line:5625
                O0000OO0O0OO00OO0 .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .STK ,arg2 =OOOO000OOOOO0OOOO )#line:5627
            else :#line:5628
                OOOOOO00O00O00O00 =TCacheJob ()#line:5629
                OOOOOO00O00O00O00 .prod =O0O0OO00OO0OO0OO0 .prod #line:5630
                OOOOOO00O00O00O00 .TopicBAS =O0O0OO00OO0OO0OO0 .TopicBAS #line:5631
                OOOOOO00O00O00O00 .TopicHL =O0O0OO00OO0OO0OO0 .TopicHL #line:5632
                OOOOOO00O00O00O00 .TopicTX =O0O0OO00OO0OO0OO0 .TopicTX #line:5633
                OOOOOO00O00O00O00 .RequestID =O0000OO0O0OO00OO0 .GetRequestID ()#line:5634
                OOOOOO00O00O00O00 .HandleProc =O0000OO0O0OO00OO0 .__OO00OO00OO0O0OOOO #line:5635
                O0000OO0O0OO00OO0 ._fMapCacheJob [OOOOOO00O00O00O00 .RequestID ]=OOOOOO00O00O00O00 #line:5636
                O0000OO0O0OO00OO0 .__O0OOOOO0O000OO00O (OOOOOO00O00O00O00 .RequestID ,OOOOOO00O00O00O00 .TopicHL )#line:5637
        except Exception as O00OO0000O0000O0O :#line:5638
            O0000OO0O0OO00OO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"__Handle_RTQuote_STK_HL:{O00OO0000O0000O0O}")#line:5639
    def __OOOO0OO00O0O0000O (O000O00OO00OO0000 ,OOOOOOOOO0OO0O0OO :TCacheJob ):#line:5641
        ""#line:5642
        try :#line:5643
            O00OOO0O0000OOO00 :dict ={}#line:5644
            for O0000OO0O0000OO0O ,OO0OOOO000000OOO0 in OOOOOOOOO0OO0O0OO .CacheData .items ():#line:5645
                O0OO0OO00O000O00O :'InboundMessage'=OO0OOOO000000OOO0 #line:5646
                O00OO0000OO0000OO =O0OO0OO00O000O00O .get_destination_name ()#line:5647
                O0O0000OOOO0O0OOO =O0OO0OO00O000O00O .get_payload_as_bytes ().decode ('utf-8')#line:5648
                O0O0OO0OOOOO0000O :str =""#line:5649
                if O00OO0000OO0000OO .endswith (O000O00OO00OO0000 ._vQuote_BAS ):#line:5650
                    O00OOO0O0000OOO00 ["BAS"]=[O0O0000OOOO0O0OOO ]#line:5651
                    O0O0OO0OOOOO0000O =O00OO0000OO0000OO #line:5652
                elif O00OO0000OO0000OO .endswith (O000O00OO00OO0000 ._vQuote_HL ):#line:5653
                    O00OOO0O0000OOO00 ["HL"]=[O0O0000OOOO0O0OOO ]#line:5654
            O000O00OO00OO0000 .__OOOO00000O0O0OOO0 (False ,OOOOOOOOO0OO0O0OO .prod ,True ,O00OOO0O0000OOO00 ,O0O0OO0OOOOO0000O )#line:5656
        except Exception as OOO0OOOO00O000O0O :#line:5658
            O000O00OO00OO0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Handle_CacheJob_FutBAS Error:{OOO0OOOO00O000O0O}")#line:5659
    def __O0OOOO0O0OO0OOOOO (O00O0O0OO0OO0O0OO ,OO000O000OO0O000O :TCacheJob ):#line:5661
        try :#line:5663
            OOO00000OO0000OO0 :'InboundMessage'=OO000O000OO0O000O .CacheData [OO000O000OO0O000O .TopicHL ]#line:5664
            O0000OO00O00O0O00 =OOO00000OO0000OO0 .get_payload_as_bytes ().decode ('utf-8')#line:5665
            if O00O0O0OO0OO0O0OO ._fMapQuoteFUT .get (OO000O000OO0O000O .TopicTX )is not None :#line:5666
                O000O00OOO00O00O0 :TObjFutQuoteMap =TObjFutQuoteMap ()#line:5667
                O0O0OOOO000O00OOO :TFutQuoteData =O00O0O0OO0OO0O0OO ._fMapQuoteFUT [OO000O000OO0O000O .TopicTX ]#line:5668
                O0O0OOOO000O00OOO .UpdateHL =True #line:5669
                O0O0OOOO000O00OOO .HL .Handle_HL (O0000OO00O00O0O00 )#line:5670
                O0O0OOOO000O00OOO .QtTX .HighPrice =O0O0OOOO000O00OOO .HL .Get_HighPrice2Dec ()#line:5671
                O0O0OOOO000O00OOO .QtTX .LowPrice =O0O0OOOO000O00OOO .HL .Get_LowPrice2Dec ()#line:5672
                O000O00OOO00O00O0 [OO000O000OO0O000O .prod ]=O0O0OOOO000O00OOO #line:5673
                O00O0O0OO0OO0O0OO .__O0OO00O000000OOOO .Add (arg1 =STKxFUT .FUT ,arg2 =O000O00OOO00O00O0 )#line:5675
            else :#line:5676
                OOO0OO000O0O0O00O ,O0OOO0OO0O00OO00O =OO000O000OO0O000O .ReSet ()#line:5677
                if OOO0OO000O0O0O00O :#line:5679
                    O0O00O000O0OO0OOO =TCacheJob ()#line:5680
                    O0O00O000O0OO0OOO .prod =OO000O000OO0O000O .prod #line:5681
                    O0O00O000O0OO0OOO .TopicBAS =OO000O000OO0O000O .TopicBAS #line:5682
                    O0O00O000O0OO0OOO .TopicHL =OO000O000OO0O000O .TopicHL #line:5683
                    O0O00O000O0OO0OOO .TopicTX =OO000O000OO0O000O .TopicTX #line:5684
                    O0O00O000O0OO0OOO .fCurCnt =OO000O000OO0O000O .fCurCnt #line:5685
                    O0O00O000O0OO0OOO .RequestID =O00O0O0OO0OO0O0OO .GetRequestID ()#line:5686
                    O0O00O000O0OO0OOO .HandleProc =O00O0O0OO0OO0O0OO .__O0OOOO0O0OO0OOOOO #line:5687
                    O00O0O0OO0OO0O0OO ._fMapCacheJob [O0O00O000O0OO0OOO .RequestID ]=O0O00O000O0OO0OOO #line:5688
                    O00O0O0OO0OO0O0OO .__O0OOOOO0O000OO00O (O0O00O000O0OO0OOO .RequestID ,O0O00O000O0OO0OOO .TopicHL )#line:5689
        except Exception as OOOO00OO0OO00OO00 :#line:5690
            O00O0O0OO0OO0O0OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"__Handle_RTQuote_FUT_HL:{OOOO00OO0OO00OO00}")#line:5691
    def __O00OO0OO0O0O0O000 (OOO0O0OO00OO0OO0O ,O00O0O0O000O0OOO0 :STKxFUT ,O0OOO000O00OOOOOO :str ):#line:5693
        try :#line:5694
            with OOO0O0OO00OO0OO0O ._lock :#line:5695
                OOO0O0OO00OO0OO0O ._message_receiver .add_subscription (TopicSubscription .of (O0OOO000O00OOOOOO ))#line:5696
        except Exception as OOO0OOOO00OO00OOO :#line:5697
            OOO0O0OO00OO0OO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SolaceSubTopic:{O0OOO000O00OOOOOO}, {OOO0OOOO00OO00OOO}")#line:5699
    def __O00O0O0O0O00O00O0 (OO00OO0OOOOOOOO0O ,O00O00OO0OO00OO00 :str ):#line:5701
        ""#line:5704
        O00O0O000OOO000OO :str =""#line:5705
        try :#line:5706
            O00O0OOOOOOO0O0OO =[]#line:5707
            O000O0O00O0OO0O00 :bool #line:5708
            O000O0O00O0OO0O00 ,O00O0OOOOOOO0O0OO ,O00O0O000OOO000OO =OO00OO0OOOOOOOO0O ._fMapQuoteSTK .GetItem_BySolIce (O00O00OO0OO00OO00 )#line:5710
            if O000O0O00O0OO0O00 ==False :#line:5711
                return False ,O00O0O000OOO000OO #line:5712
            for OOO0O0OO000OO00OO in O00O0OOOOOOO0O0OO :#line:5713
                OO00OO0OOOOOOOO0O .__O0OOOOO0OOOO0000O .Add (arg1 =STKxFUT .STK ,arg2 =OOO0O0OO000OO00OO )#line:5714
            return True ,""#line:5715
        except Exception as OO00000OO0O000O00 :#line:5716
            OO00OO0OOOOOOOO0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoUnSubTopicSTK:{OO00000OO0O000O00}")#line:5717
            return False ,f"[證][DoUnSubTopicSTK](aSolICE={O00O00OO0OO00OO00}){OO00000OO0O000O00}"#line:5718
    def __OOO0OOOO00O0000OO (O00O00OO0O0OOOOOO ,O00000OOO0OO0OOOO :str ):#line:5719
        ""#line:5721
        OOO0O0O0O00O00O00 :str =""#line:5722
        try :#line:5723
            O0O0000OO0000OOO0 =[]#line:5724
            OO0O0000000O000O0 ,O0O0000OO0000OOO0 ,OOO0O0O0O00O00O00 =O00O00OO0O0OOOOOO ._fMapQuoteSTK .GetItem_ByCategory (O00000OOO0OO0OOOO )#line:5725
            if OO0O0000000O000O0 ==False :#line:5726
                return RCode .FAIL ,OOO0O0O0O00O00O00 #line:5727
            for O0O0O0O000OO00OO0 in O0O0000OO0000OOO0 :#line:5729
                O00O00OO0O0OOOOOO .__O0OOOOO0OOOO0000O .Add (arg1 =STKxFUT .STK ,arg2 =O0O0O0O000OO00OO0 )#line:5730
            return RCode .OK ,""#line:5731
        except Exception as OO0OO0O0O0OOOOOO0 :#line:5732
            OOO0O0O0O00O00O00 =f"[證][DoUnSubTopicByCategory](aCat={O00000OOO0OO0OOOO}){OO0OO0O0O0OOOOOO0}"#line:5733
        return RCode .FAIL ,OOO0O0O0O00O00O00 #line:5734
    def __OO0OO0O0000OOOO00 (O00OO0O0O0O00OOOO ,OO00OOO000O000O0O :str ):#line:5736
        ""#line:5739
        OOOO000O0O00000O0 :str =""#line:5740
        try :#line:5741
            OOOO0O000000OOOOO =[]#line:5742
            OOO00OOOOO0O0OO00 :bool #line:5743
            OOO00OOOOO0O0OO00 ,OOOO0O000000OOOOO ,OOOO000O0O00000O0 =O00OO0O0O0O00OOOO ._fMapQuoteFUT .GetItem_BySolIce (OO00OOO000O000O0O )#line:5745
            if OOO00OOOOO0O0OO00 ==False :#line:5746
                return False ,OOOO000O0O00000O0 #line:5747
            for O00OO0OOOOOO0OO0O in OOOO0O000000OOOOO :#line:5748
                O00OO0O0O0O00OOOO .__O0OOOOO0OOOO0000O .Add (arg1 =STKxFUT .FUT ,arg2 =O00OO0OOOOOO0OO0O )#line:5749
            return True ,""#line:5750
        except Exception as OOO0O000O0000OO0O :#line:5751
            O00OO0O0O0O00OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoUnSubTopicFUT:{OOO0O000O0000OO0O}")#line:5752
            return False ,f"[期][DoUnSubTopicSTK](aSolICE={OO00OOO000O000O0O}){OOO0O000O0000OO0O}"#line:5753
    def __OO0O0OO0OOOO000OO (OO00O0000OOOO0O00 ,O00OOO0O0O0000000 :str ):#line:5756
        ""#line:5757
        O0O00O0OOO00OOOOO :str =""#line:5758
        try :#line:5759
            O00O0OO0000O00O0O =[]#line:5760
            O0O000O00O000OOOO ,O00O0OO0000O00O0O ,O0O00O0OOO00OOOOO =OO00O0000OOOO0O00 ._fMapQuoteFUT .GetItem_ByCategory (O00OOO0O0O0000000 )#line:5761
            if O0O000O00O000OOOO ==False :#line:5762
                return RCode .FAIL ,O0O00O0OOO00OOOOO #line:5763
            for O00OOO00000O0O000 in O00O0OO0000O00O0O :#line:5764
                OO00O0000OOOO0O00 .__O0OOOOO0OOOO0000O .Add (arg1 =STKxFUT .FUT ,arg2 =O00OOO00000O0O000 )#line:5765
            return RCode .OK ,""#line:5766
        except Exception as O000O0O00OOO00O00 :#line:5768
            O0O00O0OOO00OOOOO =f"[期][DoUnSubTopicByCategoryFUT](aCat={O00OOO0O0O0000000}){O000O0O00OOO00O00}"#line:5769
        return RCode .FAIL ,O0O00O0OOO00OOOOO #line:5770
    def __O0OOO00000OO0OO0O (O00000O0000O00000 ,OO0000OO0OOOO0OOO :str ):#line:5773
        ""#line:5775
        O0O00O0O0OO0OOO00 =""#line:5776
        try :#line:5777
            OOO00O0O00O0OO0O0 =[]#line:5778
            OO000OOO000O00OO0 ,OOO00O0O00O0OO0O0 ,O00OO0OOO00O000OO =O00000O0000O00000 ._fMapQuoteOvsFUT .GetItem_BySolIce (OO0000OO0OOOO0OOO )#line:5780
            if OO000OOO000O00OO0 ==False :#line:5781
                return False ,O00OO0OOO00O000OO #line:5782
            for OO0OO000O0O0OO0O0 in OOO00O0O00O0OO0O0 :#line:5783
                O00000O0000O00000 .__O0OOOOO0OOOO0000O .Add (arg1 =STKxFUT .OVSFUT ,arg2 =OO0OO000O0O0OO0O0 )#line:5785
            return True ,""#line:5786
        except Exception as O000000O0OO0000O0 :#line:5787
            O00000O0000O00000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DoUnSubTopicOvsFUT:{O000000O0OO0000O0}")#line:5789
            O0O00O0O0OO0OOO00 =f"[證][DoUnSubTopic](aSolICE={OO0000OO0OOOO0OOO}){O000000O0OO0000O0}"#line:5790
            return False ,O0O00O0O0OO0OOO00 #line:5791
    def __O00O0OO00OO0OO00O (O0OOO00OOO0O00OOO ,O00OO0O000OO000OO :STKxFUT ,O00O0OO00OO0OO00O :str ):#line:5793
        try :#line:5794
            with O0OOO00OOO0O00OOO ._lock :#line:5795
                O0OOO00OOO0O00OOO ._message_receiver .remove_subscription (TopicSubscription .of (O00O0OO00OO0OO00O ))#line:5797
        except Exception as O0O00O00O0OOO0O0O :#line:5798
            O0OOO00OOO0O00OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SolaceUnSubTopic:{O00O0OO00OO0OO00O}, {O0O00O00O0OOO0O0O}")#line:5800
    def __O00OO0O00OOO00OO0 (OOOO0OO00OOO0OO0O ):#line:5802
        if OOOO0OO00OOO0OO0O .__O000OOO000000O0O0 is None or OOOO0OO00OOO0OO0O .__O000OOO000000O0O0 ._run ==False :#line:5803
            OOOO0OO00OOO0OO0O .__O000OOO000000O0O0 =TSolaceMessageThreadClass ("Trd_HandleQuote",OOOO0OO00OOO0OO0O ._log ,OOOO0OO00OOO0OO0O .__OO0OOOOO0OO00O0OO )#line:5805
        if OOOO0OO00OOO0OO0O .__O0OO00O000000OOOO is None or OOOO0OO00OOO0OO0O .__O0OO00O000000OOOO ._run ==False :#line:5807
            OOOO0OO00OOO0OO0O .__O0OO00O000000OOOO =TMyWorkItemThreadClass ("Trd_HandleRcvQuote",OOOO0OO00OOO0OO0O ._log ,OOOO0OO00OOO0OO0O .__O000O00O0000OOOO0 )#line:5809
        if OOOO0OO00OOO0OO0O .__O0O00000OOO0O000O is None or OOOO0OO00OOO0OO0O .__O0O00000OOO0O000O ._run ==False :#line:5811
            OOOO0OO00OOO0OO0O .__O0O00000OOO0O000O =TMyWorkItemThreadClass ("Trd_SolaceSubTopic",OOOO0OO00OOO0OO0O ._log ,OOOO0OO00OOO0OO0O .__O00OO0OO0O0O0O000 )#line:5813
        if OOOO0OO00OOO0OO0O .__O0OOOOO0OOOO0000O is None or OOOO0OO00OOO0OO0O .__O0OOOOO0OOOO0000O ._run ==False :#line:5815
            OOOO0OO00OOO0OO0O .__O0OOOOO0OOOO0000O =TMyWorkItemThreadClass ("Trd_SolaceUnSubTopic",OOOO0OO00OOO0OO0O ._log ,OOOO0OO00OOO0OO0O .__O00O0OO00OO0OO00O )#line:5817
    def __O00O000OO00OO0OOO (O00000O0O000OOO0O ):#line:5819
        with O00000O0O000OOO0O ._lock :#line:5820
            O00000O0O000OOO0O .__O000OOO000000O0O0 ._run =False #line:5822
            O00000O0O000OOO0O .__O0OO00O000000OOOO ._run =False #line:5824
            O00000O0O000OOO0O .__O0O00000OOO0O000O ._run =False #line:5826
            O00000O0O000OOO0O .__O0OOOOO0OOOO0000O ._run =False #line:5828
    def QryProdID_NormalStock (OO0O0000OOO0OOOOO ):#line:5831
        ""#line:5834
        O00OOO00O0OOOOO00 =None #line:5835
        try :#line:5836
            OO000OOOOO0O0O00O =False #line:5837
            O0O0OO00OO00O0OOO ="Quote/TWS/S/TSE/*/RECOVER"#line:5838
            O0OO0O0O000OO0OO0 =""#line:5839
            OO000OOOOO0O0O00O ,O0OO0O0O000OO0OO0 =OO0O0000OOO0OOOOO .__O00O0OOOO000000OO (OO0O0000OOO0OOOOO ._vRcvTopic_Stk ,O0O0OO00OO00O0OOO ,'utf-8',OO0O0000OOO0OOOOO ._vRcvTopic_Stk_Req )#line:5841
            if OO000OOOOO0O0O00O :#line:5842
                OOOO0OO0OOO0O00OO =json .loads (O0OO0O0O000OO0OO0 )#line:5843
                if "status"in OOOO0OO0OOO0O00OO and len (OOOO0OO0OOO0O00OO ["status"])>0 :#line:5846
                    if OOOO0OO0OOO0O00OO ["status"][0 ]=="error":#line:5847
                        OO0O0000OOO0OOOOO .__OO0OO0O00OOOO00O0 (f"[證][取個一般上市上櫃股票商品檔](aData={O0OO0O0O000OO0OO0})行情回補資料有誤!")#line:5849
                        return RCode .FAIL ,O00OOO00O0OOOOO00 #line:5850
                if "BAS"in OOOO0OO0OOO0O00OO and len (OOOO0OO0OOO0O00OO ["BAS"])==0 :#line:5851
                    OO0O0000OOO0OOOOO .__OO0OO0O00OOOO00O0 (f"[證][取個一般上市上櫃股票商品檔](aData={O0OO0O0O000OO0OO0})沒有BAS資料!")#line:5853
                    return RCode .FAIL ,O00OOO00O0OOOOO00 #line:5854
                if "HL"in OOOO0OO0OOO0O00OO and len (OOOO0OO0OOO0O00OO ["HL"])==0 :#line:5855
                    OO0O0000OOO0OOOOO .__OO0OO0O00OOOO00O0 (f"[證][取個一般上市上櫃股票商品檔](aData={O0OO0O0O000OO0OO0})沒有HL資料!")#line:5857
                    return RCode .FAIL ,O00OOO00O0OOOOO00 #line:5858
                O00OOO00O0OOOOO00 =TQryStkProdMap ()#line:5861
                for O0O0OOO000O0000OO in OOOO0OO0OOO0O00OO ["BAS"]:#line:5862
                    try :#line:5863
                        OOO00O000O0O000O0 =TStkQtBase ()#line:5864
                        OOO00O000O0O000O0 .Handle_BAS (O0O0OOO000O0000OO )#line:5865
                        if O00OOO00O0OOOOO00 .data .get (OOO00O000O0O000O0 .StkNo )is None :#line:5867
                            OOO000OO000OO000O =TQryStkProdRec ()#line:5868
                            OOO000OO000OO000O .tmpBase =OOO00O000O0O000O0 #line:5869
                            O00OOO00O0OOOOO00 [OOO00O000O0O000O0 .StkNo ]=OOO000OO000OO000O #line:5870
                    except Exception as O00O000OOOOOOOO0O :#line:5871
                        OO0O0000OOO0OOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_NormalStock(BAS):{O00O000OOOOOOOO0O}")#line:5873
                for O0O0OOO000O0000OO in OOOO0OO0OOO0O00OO ["HL"]:#line:5875
                    try :#line:5876
                        OOO00O000O0O000O0 =TStkQtHL ()#line:5877
                        OOO00O000O0O000O0 .Handle_HL (O0O0OOO000O0000OO )#line:5878
                        O00OOO000O0O000O0 :TQryStkProdRec =None #line:5880
                        O00OOO000O0O000O0 =next ((OOOO0O0O0O000O000 for OOOO0O0O0O000O000 in O00OOO00O0OOOOO00 .values ()if OOOO0O0O0O000O000 .tmpBase .StkNo ==OOO00O000O0O000O0 .Symbol ),None )#line:5882
                        if O00OOO000O0O000O0 is not None :#line:5883
                            O00OOO000O0O000O0 .tmpHL =OOO00O000O0O000O0 #line:5884
                            O00OOO000O0O000O0 .SetDataInit ()#line:5885
                    except Exception as O00O000OOOOOOOO0O :#line:5886
                        OO0O0000OOO0OOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_NormalStock(HL):{O00O000OOOOOOOO0O}")#line:5888
                return RCode .OK ,O00OOO00O0OOOOO00 #line:5890
        except Exception as O00O000OOOOOOOO0O :#line:5891
            OO0O0000OOO0OOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[證][QryProdID_NormalStock]取個一般上市上櫃股票商品檔失敗!({O00O000OOOOOOOO0O})")#line:5893
        return RCode .FAIL ,None #line:5895
    def QryProdID_FutStk_FirstMth (O000OOO000OOO00OO ):#line:5897
        ""#line:5899
        OOO0O00O0O0OOOOOO :TQryFutProdMap =None #line:5900
        try :#line:5901
            O000OO000000OOOO0 :bool =False #line:5902
            OO0OOOOO00O0000O0 :O0O0OO000O0000OO0 ="Quote/TWF/FUT/*/RECOVER"#line:5903
            OO0OOOO0OOOO0000O :O0O0OO000O0000OO0 =""#line:5904
            O000OO000000OOOO0 ,OO0OOOO0OOOO0000O =O000OOO000OOO00OO .__O00O0OOOO000000OO (O000OOO000OOO00OO ._vRcvTopic_Fut ,OO0OOOOO00O0000O0 ,'utf-8',O000OOO000OOO00OO ._vRcvTopic_Fut_Req )#line:5907
            if O000OO000000OOOO0 and OO0OOOO0OOOO0000O !="":#line:5909
                OOOO00OOO00OOOO0O =json .loads (OO0OOOO0OOOO0000O )#line:5910
                if "status"in OOOO00OOO00OOOO0O and len (OOOO00OOO00OOOO0O ["status"])>0 :#line:5912
                    if OOOO00OOO00OOOO0O ["status"][0 ]=="error":#line:5913
                        O000OOO000OOO00OO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_FutStk_FirstMth](aData={OO0OOOO0OOOO0000O})行情回補資料有誤!")#line:5915
                        return False ,OOO0O00O0O0OOOOOO #line:5916
                if "BAS"in OOOO00OOO00OOOO0O and len (OOOO00OOO00OOOO0O ["BAS"])==0 :#line:5917
                    O000OOO000OOO00OO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_FutStk_FirstMth](aData={OO0OOOO0OOOO0000O})沒有BAS資料!")#line:5919
                    return False ,OOO0O00O0O0OOOOOO #line:5920
                if "HL"in OOOO00OOO00OOOO0O and len (OOOO00OOO00OOOO0O ["HL"])==0 :#line:5921
                    O000OOO000OOO00OO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_FutStk_FirstMth](aData={OO0OOOO0OOOO0000O})沒有HL資料!")#line:5923
                    return False ,OOO0O00O0O0OOOOOO #line:5924
                OOO0O00O0O0OOOOOO =TQryFutProdMap ()#line:5928
                for O0O0OO000O0000OO0 in OOOO00OOO00OOOO0O ["BAS"]:#line:5929
                    try :#line:5930
                        OO000OOOO000000OO :TFutQtBase =TFutQtBase ()#line:5931
                        OO000OOOO000000OO .Handle_BAS (O0O0OO000O0000OO0 )#line:5932
                        if OO000OOOO000000OO .StkNo .isspace ()==False and len (OO000OOOO000000OO .StkNo )>0 :#line:5933
                            if OOO0O00O0O0OOOOOO .data .get (OO000OOOO000000OO .StkNo )is None :#line:5934
                                OOOO000O00000O000 :TQryFutProdRec =TQryFutProdRec ()#line:5935
                                OOOO000O00000O000 .tmpBase =OO000OOOO000000OO #line:5936
                                OOO0O00O0O0OOOOOO [OO000OOOO000000OO .ProdID ]=OOOO000O00000O000 #line:5937
                            elif (int (OO000OOOO000000OO .SettleMth )<int (OOO0O00O0O0OOOOOO [OO000OOOO000000OO .ProdID ].tmpBase .SettleMth )):#line:5938
                                OOO0O00O0O0OOOOOO [OO000OOOO000000OO .ProdID ].tmpBase =OO000OOOO000000OO #line:5939
                    except Exception as O000000O00OOO000O :#line:5940
                        O000OOO000OOO00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_FutStk_FirstMth(BAS):{O000000O00OOO000O}")#line:5942
                for O0O0OO000O0000OO0 in OOOO00OOO00OOOO0O ["HL"]:#line:5945
                    try :#line:5946
                        OO000OOOO000000OO :TFutQtHL =TFutQtHL ()#line:5947
                        OO000OOOO000000OO .Handle_HL (O0O0OO000O0000OO0 )#line:5948
                        OO000O0000O0O0OOO :TQryStkProdRec =None #line:5949
                        OO000O0000O0O0OOO =next ((O0OOO00O0000O0O00 for O0OOO00O0000O0O00 in OOO0O00O0O0OOOOOO .values ()if O0OOO00O0000O0O00 .tmpBase .OrdProdID ==OO000OOOO000000OO .Symbol ),None )#line:5951
                        if OO000O0000O0O0OOO is not None :#line:5952
                            OO000O0000O0O0OOO .tmpHL =OO000OOOO000000OO #line:5953
                            OO000O0000O0O0OOO .SetDataInit ()#line:5954
                    except Exception as O000000O00OOO000O :#line:5955
                        O000OOO000OOO00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_FutStk_FirstMth(HL):{O000000O00OOO000O}")#line:5957
                return True ,OOO0O00O0O0OOOOOO #line:5959
        except Exception as O000000O00OOO000O :#line:5960
            O000OOO000OOO00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProdID_FutStk_FirstMth:{O000000O00OOO000O}")#line:5962
            O000OOO000OOO00OO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_FutStk_FirstMth]取個期貨商品檔(近1月)失敗!({O000000O00OOO000O})")#line:5964
        return False ,None #line:5965
    def QryProd_Fut (O00O0OOOOOO00OOOO ,O00O0000O00000000 :bool ,OO00OOO00000O0O0O :bool ,O0O000O0000O00O0O :bool ):#line:5967
        ""#line:5973
        OO00O00O00000O000 :TObjBaseFutMap =None #line:5974
        try :#line:5975
            OO00O0OOO00OO0OO0 :OOOO0000OO0O0OOOO ="Quote/TWF/FUT/*/RECOVER"#line:5976
            O0O000OO00OOOOOOO :OOOO0000OO0O0OOOO =""#line:5977
            O000OO000OO0O0OO0 ,O0O000OO00OOOOOOO =O00O0OOOOOO00OOOO .__O00O0OOOO000000OO (O00O0OOOOOO00OOOO ._vRcvTopic_Fut ,OO00O0OOO00OO0OO0 ,'utf-8',O00O0OOOOOO00OOOO ._vRcvTopic_Fut_Req )#line:5979
            if O000OO000OO0O0OO0 and O0O000OO00OOOOOOO !="":#line:5981
                O0000OO0O0O00000O =json .loads (O0O000OO00OOOOOOO )#line:5982
                if "status"in O0000OO0O0O00000O and len (O0000OO0O0O00000O ["status"])>0 :#line:5985
                    if O0000OO0O0O00000O ["status"][0 ]=="error":#line:5986
                        O00O0OOOOOO00OOOO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_Fut](aData={O0O000OO00OOOOOOO})行情回補資料有誤!")#line:5988
                        return RCode .FAIL ,OO00O00O00000O000 #line:5989
                if "BAS"in O0000OO0O0O00000O and len (O0000OO0O0O00000O ["BAS"])==0 :#line:5990
                    O00O0OOOOOO00OOOO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_Fut](aData={O0O000OO00OOOOOOO})沒有BAS資料!")#line:5992
                    return RCode .FAIL ,OO00O00O00000O000 #line:5993
                if "HL"in O0000OO0O0O00000O and len (O0000OO0O0O00000O ["HL"])==0 :#line:5994
                    O00O0OOOOOO00OOOO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_Fut](aData={O0O000OO00OOOOOOO})沒有HL資料!")#line:5996
                    return RCode .FAIL ,OO00O00O00000O000 #line:5997
                OO00O00O00000O000 :TObjBaseFutMap =TObjBaseFutMap ()#line:6001
                for OOOO0000OO0O0OOOO in O0000OO0O0O00000O ["BAS"]:#line:6002
                    try :#line:6003
                        OO000O00O0OOOOOOO :TFutQtBase =TFutQtBase ()#line:6004
                        OO000O00O0OOOOOOO .Handle_BAS (OOOO0000OO0O0OOOO )#line:6005
                        if OO000O00O0OOOOOOO .StkNo .isspace ()==False and len (OO000O00O0OOOOOOO .StkNo )>0 :#line:6007
                            if OO00OOO00000O0O0O :#line:6008
                                if O0O000O0000O00O0O ==False and OO000O00O0OOOOOOO .FutName .startswith ("小型"):#line:6010
                                    pass #line:6011
                                else :#line:6012
                                    OO00O00O00000O000 .AddItem_ByProdID (OO000O00O0OOOOOOO )#line:6013
                        elif O00O0000O00000000 :#line:6014
                            OO00O00O00000O000 .AddItem_ByProdID (OO000O00O0OOOOOOO )#line:6015
                    except Exception as OO00000OOO0OOOOO0 :#line:6016
                        O00O0OOOOOO00OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut(BAS):{OO00000OOO0OOOOO0}")#line:6018
                OO00O00O00000O000 .ReAddAll ()#line:6020
                return RCode .OK ,OO00O00O00000O000 #line:6023
        except Exception as OO00000OOO0OOOOO0 :#line:6024
            O00O0OOOOOO00OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut:{OO00000OOO0OOOOO0}")#line:6025
            O00O0OOOOOO00OOOO .__OO0OO0O00OOOO00O0 (f"[期][QryProdID_Fut]取期貨商品檔(不含選擇權)失敗!({OO00000OOO0OOOOO0})")#line:6026
        return RCode .FAIL ,OO00O00O00000O000 #line:6027
    def QryProd_FutCom (OO0OO0OO0OOOO0OOO ):#line:6029
        ""#line:6030
        OOO0O0000O000OO0O :TObjFutComList =None #line:6031
        try :#line:6032
            O0O0OOOOOO0OOOO0O :str ="Quote/TWF/SPD/*/SYMBOL"#line:6033
            OO00000O000O000OO :str =""#line:6034
            OO0O00O000OOOOO0O ,OO00000O000O000OO =OO0OO0OO0OOOO0OOO .__O00O0OOOO000000OO (OO0OO0OO0OOOO0OOO ._vRcvTopic_Fut ,O0O0OOOOOO0OOOO0O ,'utf-8',OO0OO0OO0OOOO0OOO ._vRcvTopic_Fut_Req )#line:6036
            if OO0O00O000OOOOO0O :#line:6038
                O0O00OO00OOO0O0OO =json .loads (OO00000O000O000OO )#line:6039
                if "status"in O0O00OO00OOO0O0OO and len (O0O00OO00OOO0O0OO ["status"])>0 :#line:6041
                    if O0O00OO00OOO0O0OO ["status"][0 ]=="error":#line:6042
                        OO0OO0OO0OOOO0OOO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_FutCom](aData={OO00000O000O000OO})行情回補資料有誤!")#line:6044
                        return False ,OOO0O0000O000OO0O #line:6045
                if "SYMBOL"in O0O00OO00OOO0O0OO and len (O0O00OO00OOO0O0OO ["SYMBOL"])==0 :#line:6046
                    OO0OO0OO0OOOO0OOO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_FutCom](aData={OO00000O000O000OO})沒有SYMBOL資料!")#line:6048
                    return False ,OOO0O0000O000OO0O #line:6049
                OOO0O0000O000OO0O :TObjFutComList =TObjFutComList ()#line:6052
                OOO000O0O00OO000O =O0O00OO00OOO0O0OO ["SYMBOL"][0 ].split ('|')#line:6053
                for O00O0OO0OO0OO0000 in OOO000O0O00OO000O :#line:6054
                    OOO0O0000O000OO0O .AddItem (O00O0OO0OO0OO0000 )#line:6055
                return True ,OOO0O0000O000OO0O #line:6057
        except Exception as OOOOOOOO0OOOO0O0O :#line:6058
            OO0OO0OO0OOOO0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_FutCom:{OOOOOOOO0OOOO0O0O}")#line:6059
            OO0OO0OO0OOOO0OOO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_FutCom]取複式期貨商品檔失敗!({OOOOOOOO0OOOO0O0O})")#line:6060
        return False ,OOO0O0000O000OO0O #line:6061
    def QryProd_FutCom2 (O00OO0000O0OO00OO ):#line:6063
        ""#line:6065
        OO00000000O0OOO0O :TObjFutComList =None #line:6066
        try :#line:6067
            OO0OOO0O00OO0O00O :TObjBaseFutMap =None #line:6068
            OO0O0000O0O0O00OO ,OO0OOO0O00OO0O00O =O00OO0000O0OO00OO .QryProd_Fut (True ,True ,True )#line:6069
            if OO0O0000O0O0O00OO ==False :#line:6070
                O00OO0000O0OO00OO .__OO0OO0O00OOOO00O0 ("[QryProd_FutCom2]載入期貨單式商品失敗!")#line:6071
                return RCode .FAIL ,OO00000000O0OOO0O #line:6072
            OO00000000O0OOO0O :TObjFutComList =TObjFutComList ()#line:6073
            O000O00OOO00OO0OO ,OOOO0OO0O0OO00OOO =0 ,0 #line:6075
            O0000000OO0O0O0O0 =[O0OOO0O0OOO0OOOO0 for O0OOO0O0OOO0OOOO0 in OO0OOO0O00OO0O00O .keys ()if not O0OOO0O0OOO0OOOO0 .startswith ("MX")or O0OOO0O0OOO0OOOO0 =="MXF"]#line:6077
            for OOOO0OOOO000OO00O in O0000000OO0O0O0O0 :#line:6079
                O00OOOO0OO00000O0 =OO0OOO0O00OO0O00O [OOOO0OOOO000OO00O ]#line:6080
                if len (O00OOOO0OO00000O0 )<=1 :#line:6081
                    continue #line:6082
                for O000O00OOO00OO0OO in range (len (O00OOOO0OO00000O0 )):#line:6083
                    for OOOO0OO0O0OO00OOO in range (O000O00OOO00OO0OO +1 ,len (O00OOOO0OO00000O0 )):#line:6084
                        OOOOO000O0OOO00O0 =O00OOOO0OO00000O0 [O000O00OOO00OO0OO ]#line:6085
                        OO00O0O0O0000O000 =O00OOOO0OO00000O0 [OOOO0OO0O0OO00OOO ]#line:6086
                        OO00000000O0OOO0O .AddItem ("{}^{}".format (OOOOO000O0OOO00O0 .OrdProdID ,OO00O0O0O0000O000 .OrdProdID [3 :5 ]))#line:6088
            O00OOO0000OO0O00O =OO0OOO0O00OO0O00O ["MXF"]#line:6091
            OO0OO0O0O0OOOO000 =[OO0000O0000OO0O0O for OO0000O0000OO0O0O in OO0OOO0O00OO0O00O .keys ()if OO0000O0000OO0O0O .startswith ("MX")and OO0000O0000OO0O0O !="MXF"]#line:6093
            for O000O00OOO00OO0OO in range (len (OO0OO0O0O0OOOO000 )):#line:6094
                OOO0OOOO0OO00OO00 =OO0OOO0O00OO0O00O [OO0OO0O0O0OOOO000 [O000O00OOO00OO0OO ]][0 ]#line:6095
                for OOOO0OO0O0OO00OOO in range (O000O00OOO00OO0OO +1 ,len (OO0OO0O0O0OOOO000 )):#line:6097
                    O00OOOO0OOO0OO0OO =OO0OOO0O00OO0O00O [OO0OO0O0O0OOOO000 [OOOO0OO0O0OO00OOO ]][0 ]#line:6098
                    if OOO0OOOO0OO00OO00 .SettleMth ==O00OOOO0OOO0OO0OO .SettleMth :#line:6099
                        if ord (OOO0OOOO0OO00OO00 .OrdProdID [2 ])<ord (O00OOOO0OOO0OO0OO .OrdProdID [2 ]):#line:6101
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (OOO0OOOO0OO00OO00 .OrdProdID ,O00OOOO0OOO0OO0OO .OrdProdID ))#line:6103
                        else :#line:6104
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (O00OOOO0OOO0OO0OO .OrdProdID ,OOO0OOOO0OO00OO00 .OrdProdID ))#line:6107
                    else :#line:6108
                        if int (OOO0OOOO0OO00OO00 .SettleMth )<int (O00OOOO0OOO0OO0OO .SettleMth ):#line:6109
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (OOO0OOOO0OO00OO00 .OrdProdID ,O00OOOO0OOO0OO0OO .OrdProdID ))#line:6111
                        else :#line:6112
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (O00OOOO0OOO0OO0OO .OrdProdID ,OOO0OOOO0OO00OO00 .OrdProdID ))#line:6115
                if OOO0OOOO0OO00OO00 .SettleMth ==O00OOO0000OO0O00O [0 ].SettleMth :#line:6118
                    if OOO0OOOO0OO00OO00 .ProdID =="MX1"or OOO0OOOO0OO00OO00 .ProdID =="MX2":#line:6119
                        for OO0OO00OO0O00O0OO in O00OOO0000OO0O00O :#line:6120
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (OOO0OOOO0OO00OO00 .OrdProdID ,OO0OO00OO0O00O0OO .OrdProdID ))#line:6122
                    else :#line:6123
                        for OO0OO00OO0O00O0OO in O00OOO0000OO0O00O :#line:6124
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (OO0OO00OO0O00O0OO .OrdProdID ,OOO0OOOO0OO00OO00 .OrdProdID ))#line:6126
                else :#line:6127
                    if int (OOO0OOOO0OO00OO00 .SettleMth )<int (O00OOO0000OO0O00O [0 ].SettleMth ):#line:6128
                        for OO0OO00OO0O00O0OO in O00OOO0000OO0O00O :#line:6129
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (OOO0OOOO0OO00OO00 .OrdProdID ,OO0OO00OO0O00O0OO .OrdProdID ))#line:6131
                    else :#line:6132
                        for OO0OO00OO0O00O0OO in O00OOO0000OO0O00O :#line:6133
                            OO00000000O0OOO0O .AddItem ("{}^{}".format (OO0OO00OO0O00O0OO .OrdProdID ,OOO0OOOO0OO00OO00 .OrdProdID ))#line:6135
            return RCode .OK ,OO00000000O0OOO0O #line:6137
        except Exception as O000O0O0OOO00OOOO :#line:6138
            O00OO0000O0OO00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_FutCom2:{O000O0O0OOO00OOOO}")#line:6139
            O00OO0000O0OO00OO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_FutCom2]取複式期貨商品檔失敗!({O000O0O0OOO00OOOO})")#line:6140
        return RCode .FAIL ,OO00000000O0OOO0O #line:6141
    def QryProd_Opt (OO0OO000O0OO0O0OO ,OO0OO0000OO0OO000 :bool ,OO0OOOOO0O00OOOOO :bool ,O000OO0O0O000OO0O :bool ):#line:6143
        ""#line:6148
        OOOOOOO0OOO0OOOO0 :TObjBaseOptMap =None #line:6149
        try :#line:6150
            OO0O0OOO00OO0000O :OO0OOO0O00O000O00 ="Quote/TWF/OPT/*/RECOVER"#line:6151
            OOO000O0O000OOO0O :OO0OOO0O00O000O00 =""#line:6152
            O0O000000O0O00O0O ,OOO000O0O000OOO0O =OO0OO000O0OO0O0OO .__O00O0OOOO000000OO (OO0OO000O0OO0O0OO ._vRcvTopic_Fut ,OO0O0OOO00OO0000O ,'utf-8',OO0OO000O0OO0O0OO ._vRcvTopic_Fut_Req )#line:6154
            if O0O000000O0O00O0O :#line:6156
                OO0OOOO0OOO00O00O =json .loads (OOO000O0O000OOO0O )#line:6157
                if "status"in OO0OOOO0OOO00O00O and len (OO0OOOO0OOO00O00O ["status"])>0 :#line:6159
                    if OO0OOOO0OOO00O00O ["status"][0 ]=="error":#line:6160
                        OO0OO000O0OO0O0OO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_Opt](aData={OOO000O0O000OOO0O})行情回補資料有誤!")#line:6162
                        return RCode .FAIL ,OOOOOOO0OOO0OOOO0 #line:6163
                if "BAS"in OO0OOOO0OOO00O00O and len (OO0OOOO0OOO00O00O ["BAS"])==0 :#line:6164
                    OO0OO000O0OO0O0OO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_Opt](aData={OOO000O0O000OOO0O})沒有BAS資料!")#line:6166
                    return RCode .FAIL ,OOOOOOO0OOO0OOOO0 #line:6167
                if "HL"in OO0OOOO0OOO00O00O and len (OO0OOOO0OOO00O00O ["HL"])==0 :#line:6168
                    OO0OO000O0OO0O0OO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_Opt](aData={OOO000O0O000OOO0O})沒有HL資料!")#line:6170
                    return RCode .FAIL ,OOOOOOO0OOO0OOOO0 #line:6171
                OOOOOOO0OOO0OOOO0 =TObjBaseOptMap ()#line:6174
                for OO0OOO0O00O000O00 in OO0OOOO0OOO00O00O ["BAS"]:#line:6175
                    try :#line:6176
                        OOO0O0OO0000OO0OO :TFutQtBase =TFutQtBase ()#line:6177
                        OOO0O0OO0000OO0OO .Handle_BAS (OO0OOO0O00O000O00 )#line:6178
                        if OOO0O0OO0000OO0OO .StkNo .isspace ()==False and len (OOO0O0OO0000OO0OO .StkNo )>0 :#line:6180
                            if OO0OOOOO0O00OOOOO :#line:6181
                                if O000OO0O0O000OO0O ==False and OOO0O0OO0000OO0OO .FutName .startswith ("小型"):#line:6183
                                    pass #line:6184
                                else :#line:6185
                                    OOOOOOO0OOO0OOOO0 .AddItem_ByProdID (OOO0O0OO0000OO0OO )#line:6186
                        elif OO0OO0000OO0OO000 :#line:6187
                            OOOOOOO0OOO0OOOO0 .AddItem_ByProdID (OOO0O0OO0000OO0OO )#line:6188
                    except Exception as OOOO00O0OOO0000O0 :#line:6189
                        OO0OO000O0OO0O0OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Opt:{OOOO00O0OOO0000O0}")#line:6191
                return RCode .OK ,OOOOOOO0OOO0OOOO0 #line:6194
        except Exception as OOOO00O0OOO0000O0 :#line:6195
            OO0OO000O0OO0O0OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Opt:{OOOO00O0OOO0000O0}")#line:6196
            OO0OO000O0OO0O0OO .__OO0OO0O00OOOO00O0 (f"[期][QryProd_Opt]取個選擇權商品檔失敗!({OOOO00O0OOO0000O0})")#line:6197
        return RCode .FAIL ,OOOOOOO0OOO0OOOO0 #line:6198
    def QryProd_OvsFut (O0000O0OO00OO00O0 ):#line:6200
        ""#line:6203
        O0OOO00000OO0000O :TObjOvsFutProdMthMap =None #line:6204
        try :#line:6205
            OO0OO000OO00OOOOO =False #line:6206
            OOOOOO0OO0OO0O0OO ="QuoteOvs/*/FUT/*/RECOVER"#line:6207
            OOO0000O0OOO0OOO0 =""#line:6208
            OO0OO000OO00OOOOO ,OOO0000O0OOO0OOO0 =O0000O0OO00OO00O0 .__O00O0OOOO000000OO (O0000O0OO00OO00O0 ._vRcvTopic_OvsFut ,OOOOOO0OO0OO0O0OO ,'big5',O0000O0OO00OO00O0 ._vRcvTopic_OvsFut_Req )#line:6210
            if OO0OO000OO00OOOOO :#line:6211
                O00000OOO00O000O0 =json .loads (OOO0000O0OOO0OOO0 )#line:6212
                if "status"in O00000OOO00O000O0 and len (O00000OOO00O000O0 ["status"])>0 :#line:6214
                    if O00000OOO00O000O0 ["status"][0 ]=="error":#line:6215
                        O0000O0OO00OO00O0 .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsFut](aData={OOO0000O0OOO0OOO0})行情回補資料有誤!")#line:6217
                        return False ,O0OOO00000OO0000O #line:6218
                if "BAS"in O00000OOO00O000O0 and len (O00000OOO00O000O0 ["BAS"])==0 :#line:6219
                    O0000O0OO00OO00O0 .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsFut](aData={OOO0000O0OOO0OOO0})沒有BAS資料!")#line:6221
                    return False ,O0OOO00000OO0000O #line:6222
                O0OOO00000OO0000O =TObjOvsFutProdMthMap ("","")#line:6225
                for OOOOOO000OOO0O0O0 in O00000OOO00O000O0 ["BAS"]:#line:6226
                    try :#line:6227
                        O0OO000000O0OOOOO =TOvsFutQtBase ()#line:6228
                        O0OO000000O0OOOOO .Handle_BAS (OOOOOO000OOO0O0O0 )#line:6229
                        O0OOO00000OO0000O .AddItem (O0OO000000O0OOOOO )#line:6231
                    except Exception as O0O0O0OO0OOOOOOOO :#line:6232
                        O0000O0OO00OO00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsFut: {O0O0O0OO0OOOOOOOO}")#line:6234
                return True ,O0OOO00000OO0000O #line:6236
        except Exception as O0O0O0OO0OOOOOOOO :#line:6237
            O0000O0OO00OO00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsFut:{O0O0O0OO0OOOOOOOO}")#line:6238
            O0000O0OO00OO00O0 .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsFut]取期貨商品檔(不含選擇權)失敗!({O0O0O0OO0OOOOOOOO})")#line:6239
        return False ,O0OOO00000OO0000O #line:6240
    def QryProd_OvsOpt (OOO0000000O0000OO ):#line:6242
        ""#line:6244
        OO0OOO0OO00000O00 :None #line:6245
        try :#line:6246
            OOO00OO00O0OO0OOO :bool =False #line:6247
            OOO00OO0OOO000OO0 ="QuoteOvs/*/OPT/*/RECOVER"#line:6248
            OOO0O0OOOOO0O0O00 =""#line:6249
            OOO00OO00O0OO0OOO ,OOO0O0OOOOO0O0O00 =OOO0000000O0000OO .__O00O0OOOO000000OO (OOO0000000O0000OO ._vRcvTopic_OvsFut ,OOO00OO0OOO000OO0 ,'big5',OOO0000000O0000OO ._vRcvTopic_OvsFut_Req )#line:6251
            if OOO00OO00O0OO0OOO :#line:6252
                O000OO0O0OOO0000O =json .loads (OOO0O0OOOOO0O0O00 )#line:6253
                if "status"in O000OO0O0OOO0000O and len (O000OO0O0OOO0000O ["status"])>0 :#line:6255
                    if O000OO0O0OOO0000O ["status"][0 ]=="error":#line:6256
                        OOO0000000O0000OO .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsOpt](aData={OOO0O0OOOOO0O0O00})行情回補資料有誤!")#line:6258
                        return False ,OO0OOO0OO00000O00 #line:6259
                if "BAS"in O000OO0O0OOO0000O and len (O000OO0O0OOO0000O ["BAS"])==0 :#line:6260
                    OOO0000000O0000OO .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsOpt](aData={OOO0O0OOOOO0O0O00})沒有BAS資料!")#line:6262
                    return False ,OO0OOO0OO00000O00 #line:6263
                OO0OOO0OO00000O00 =TObjOvsFutProdMthMap ("","")#line:6266
                for OOOOO000OOO00OO00 in O000OO0O0OOO0000O ["BAS"]:#line:6267
                    try :#line:6268
                        OO0OO00OOOO0OO00O =TOvsFutQtBase ()#line:6269
                        OO0OO00OOOO0OO00O .Handle_BAS (OOOOO000OOO00OO00 )#line:6270
                        OO0OOO0OO00000O00 .AddItem (OO0OO00OOOO0OO00O )#line:6271
                    except Exception as O0OOO0OOO00OOOOO0 :#line:6272
                        OOO0000000O0000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsOpt: {O0OOO0OOO00OOOOO0}")#line:6274
                return True ,OO0OOO0OO00000O00 #line:6276
        except Exception as O0OOO0OOO00OOOOO0 :#line:6277
            OOO0000000O0000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_OvsOpt:{O0OOO0OOO00OOOOO0}")#line:6278
            OOO0000000O0000OO .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OptOvs]取選擇權商品檔失敗!({O0OOO0OOO00OOOOO0})")#line:6279
        return False ,OO0OOO0OO00000O00 #line:6280
    def QryProd_Fut_ByExchangeTree (OO0000OOOOO0O00O0 ,O0OOOOOOOO0OO0O0O :bool ):#line:6282
        ""#line:6285
        OO0OO00O000O000O0 :TObjBaseOvsFutExchageTree =None #line:6286
        try :#line:6287
            O000O0O0OOOOOOOO0 :bool =False #line:6288
            OO00O0O0OO00O0000 ="QuoteOvs/*/FUT/*/RECOVER"#line:6289
            OO0O0OOOOOOOOOOO0 =""#line:6290
            O000O0O0OOOOOOOO0 ,OO0O0OOOOOOOOOOO0 =OO0000OOOOO0O00O0 .__O00O0OOOO000000OO (OO0000OOOOO0O00O0 ._vRcvTopic_OvsFut ,OO00O0O0OO00O0000 ,'big5',OO0000OOOOO0O00O0 ._vRcvTopic_OvsFut_Req )#line:6292
            if O000O0O0OOOOOOOO0 :#line:6293
                OO000O0000OOO00OO =json .loads (OO0O0OOOOOOOOOOO0 )#line:6294
                if "status"in OO000O0000OOO00OO and len (OO000O0000OOO00OO ["status"])>0 :#line:6296
                    if OO000O0000OOO00OO ["status"][0 ]=="error":#line:6297
                        OO0000OOOOO0O00O0 .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsFut](aData={OO0O0OOOOOOOOOOO0})行情回補資料有誤!")#line:6299
                        return False ,OO0OO00O000O000O0 #line:6300
                if "BAS"in OO000O0000OOO00OO and len (OO000O0000OOO00OO ["BAS"])==0 :#line:6301
                    OO0000OOOOO0O00O0 .__OO0OO0O00OOOO00O0 (f"[海期][QryProd_OvsFut](aData={OO0O0OOOOOOOOOOO0})沒有BAS資料!")#line:6303
                    return False ,OO0OO00O000O000O0 #line:6304
                OO0OO00O000O000O0 =TObjBaseOvsFutExchageTree ()#line:6307
                for O0OO0O000OOOO0OOO in OO000O0000OOO00OO ["BAS"]:#line:6308
                    try :#line:6309
                        OOOO00OO0O0OO0000 =TOvsFutQtBase ()#line:6310
                        OOOO00OO0O0OO0000 .Handle_BAS (O0OO0O000OOOO0OOO )#line:6311
                        if OOOO00OO0O0OO0000 .Market =="4":#line:6312
                            if O0OOOOOOOO0OO0O0O ==False or (O0OOOOOOOO0OO0O0O and OOOO00OO0O0OO0000 .Display =="Y"):#line:6314
                                OO0OO00O000O000O0 .AddItem (OOOO00OO0O0OO0000 )#line:6315
                    except Exception as O000O0OO000O0000O :#line:6316
                        OO0000OOOOO0O00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut_ByExchangeTree: {O000O0OO000O0000O}")#line:6318
                OO0OO00O000O000O0 .SetInit ()#line:6319
                return True ,OO0OO00O000O000O0 #line:6322
        except Exception as O000O0OO000O0000O :#line:6323
            OO0000OOOOO0O00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QryProd_Fut_ByExchangeTree:{O000O0OO000O0000O}")#line:6325
            OO0000OOOOO0O00O0 .__OO0OO0O00OOOO00O0 (f"[海期][QryProdID_Fut]取期貨商品檔(不含選擇權)失敗!({O000O0OO000O0000O})")#line:6326
        return False ,OO0OO00O000O000O0 #line:6327
    def __OO0OO0O000O0OOO00 (O0OO0O00OO0OO0OOO ,O00OOOO0O0OO00OO0 :str ,O0O000OOOOOOOO0O0 :str ):#line:6331
        try :#line:6332
            with O0OO0O00OO0OO0OOO ._lock :#line:6333
                O0O00OO0O0O0O0O0O =O0OO0O00OO0OO0OOO ._direct_publish_service .start_async ()#line:6334
                O0O00OO0O0O0O0O0O .result ()#line:6335
                OOOO00O0OO0OO0000 ='utf-8'#line:6336
                O0O0O0O0OOOOO0O00 =bytearray (f'{O0O000OOOOOOOO0O0}',OOOO00O0OO0OO0000 )#line:6337
                O0000000OOO0000O0 :OutboundMessage =O0OO0O00OO0OO0OOO ._message_service .message_builder ().build (O0O0O0O0OOOOO0O00 )#line:6338
                O0OO0O00OO0OO0OOO ._direct_publish_service .publish (O00OOOO0O0OO00OO0 ,O0000000OOO0000O0 )#line:6339
        except Exception as O00O00O0O0OOOOOO0 :#line:6341
            O0OO0O00OO0OO0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SendMessage:{O00O00O0O0OOOOOO0}")#line:6342
    def __O00O0OOOO000000OO (OOO0000O00O000O00 ,OOO0O000000OOOO00 :str ,O0O00OO0OO00O0OOO :str ,OO0O0O00OOO0OOO00 :str ,OO000OO0OOOO000OO :str ):#line:6346
        ""#line:6349
        OO0OO00O0O0OOOO00 =""#line:6350
        O0OO0OO0OO0O0OOOO =bytearray (f'{O0O00OO0OO00O0OOO}',OO0O0O00OOO0OOO00 )#line:6356
        O0O00O0O00OO0OOOO :OutboundMessage =OOO0000O00O000O00 ._message_service .message_builder ().build (payload =O0OO0OO0OO0O0OOOO )#line:6357
        try :#line:6359
            with OOO0000O00O000O00 ._lock :#line:6360
                OO000O0O00OOO0O00 =OOO0000O00O000O00 ._message_requester .publish_await_response (request_message =O0O00O0O00OO0OOOO ,request_destination =Topic .of (OOO0O000000OOOO00 ),reply_timeout =OOO0000O00O000O00 ._reply_timeout )#line:6364
                OO00O0O0OO00O0O0O =OO000O0O00OOO0O00 .get_payload_as_bytes ().decode (OO0O0O00OOO0OOO00 )#line:6365
                return True ,OO00O0O0OO00O0O0O #line:6366
        except Exception as OOOO0O00O0O00O0O0 :#line:6367
            OOO0000O00O000O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"send_request exception! topic={OOO0O000000OOOO00}, msg={O0O00OO0OO00O0OOO}, exception={OOOO0O00O0O00O0O0}")#line:6369
            OO00O0O0OO00O0O0O =""#line:6370
        return False ,OO00O0O0OO00O0O0O #line:6372
    def Subscribe (O0OO0OOO0000O000O ,OOOO0000O000OOOOO :str ,OOOOO00O00O0O0OOO :str )->RCode :#line:6376
        ""#line:6379
        O0OO0OOO0000O000O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[Subscribe]exchange={OOOO0000O000OOOOO}, symbol={OOOOO00O00O0O0OOO}")#line:6380
        if EXCHANGE .TWF ==OOOO0000O000OOOOO :#line:6383
            O000OO0OO0OO000OO =O0OO0OOO0000O000O .__OO000O0O0O0OOO0OO (OOOOO00O00O0O0OOO ,True )#line:6384
        elif EXCHANGE .TWS ==OOOO0000O000OOOOO :#line:6386
            O000OO0OO0OO000OO =O0OO0OOO0000O000O .__OO00000OO0O0OOOO0 (OOOOO00O00O0O0OOO ,True )#line:6387
        return O000OO0OO0OO000OO #line:6389
    def OvsSubscribe (OOOO000OOO000O000 ,O0O0000O00O000OOO :str ):#line:6390
        ""#line:6391
        return OOOO000OOO000O000 .__OO0OOO0O00OOOOOOO (O0O0000O00O000OOO ,True )#line:6392
    def OvsSubscribeWithCategory (O0OO0O00000O000OO ,aMrt :str ="FUT",aExchange :str ="*"):#line:6394
        ""#line:6395
        if aMrt =="FUT":#line:6396
            return O0OO0O00000O000OO .__O0OOO000OOO0OO0OO (True ,aExchange )#line:6397
        else :#line:6398
            O0OO0O00000O000OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"OvsSubscribeWithCategory aMrt:{aMrt}")#line:6399
            return RCode .FAIL #line:6400
    def Unsubscribe (OOO0OO0OO0O0OOOO0 ,OO000OOO0OO0OOOOO :str ,OO00OO000OO0O0000 :str )->RCode :#line:6402
        ""#line:6405
        OOO0OO0OO0O0OOOO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[Unsubscribe]exchange={OO000OOO0OO0OOOOO}, symbol={OO00OO000OO0O0000}")#line:6406
        O00O0O0OO0O0O00OO :str =""#line:6408
        if EXCHANGE .TWF ==OO000OOO0OO0OOOOO :#line:6410
            O0O00O0O0O000000O ,O00O0O0OO0O0O00OO =OOO0OO0OO0O0OOOO0 .__OO0OO0O0000OOOO00 (OO00OO000OO0O0000 )#line:6411
            if O0O00O0O0O000000O ==False :#line:6412
                O0O0O00000OO0O000 =SystemEvent (RCode .SUBSCRIPTION_FAIL ,O00O0O0OO0O0O00OO )#line:6413
                OOO0OO0OO0O0OOOO0 .__OOO0O0O00OOOO00O0 .Fire_OnSystemEvent (O0O0O00000OO0O000 )#line:6414
                return RCode .FAIL #line:6415
        elif EXCHANGE .TWS ==OO000OOO0OO0OOOOO :#line:6417
            O0O00O0O0O000000O ,O00O0O0OO0O0O00OO =OOO0OO0OO0O0OOOO0 .__O00O0O0O0O00O00O0 (OO00OO000OO0O0000 )#line:6418
            if O0O00O0O0O000000O ==False :#line:6419
                O0O0O00000OO0O000 =SystemEvent (RCode .SUBSCRIPTION_FAIL ,O00O0O0OO0O0O00OO )#line:6420
                OOO0OO0OO0O0OOOO0 .__OOO0O0O00OOOO00O0 .Fire_OnSystemEvent (O0O0O00000OO0O000 )#line:6421
                return RCode .FAIL #line:6422
        return RCode .OK #line:6424
    def OvsUnSubscribe (OOO000OO0OO0O0000 ,O000O0OO00OOO0000 :str )->bool :#line:6425
        ""#line:6426
        O00O000O0OO0OO0OO :str =""#line:6428
        OO0OOOOO0O0OO000O ,O00O000O0OO0OO0OO =OOO000OO0OO0O0000 .__O0OOO00000OO0OO0O (O000O0OO00OOO0000 )#line:6429
        if OO0OOOOO0O0OO000O :#line:6430
            OOO000OO0OO0O0000 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[OvsUnSubscribe]aSymbol={O000O0OO00OOO0000}")#line:6431
            return RCode .OK #line:6432
        else :#line:6433
            OOO000OO0OO0O0000 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[OvsUnSubscribe]aSymbol={O000O0OO00OOO0000}, sErrMsg={O00O000O0OO0OO0OO}")#line:6434
            return RCode .FAIL #line:6435
    def SubscribeWithCategory (O000O00000OO0O00O ,OO0O000O0O000O0O0 :str ,OOO0OO00OOOO0O00O :str )->RCode :#line:6436
        O000O00000OO0O00O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[SubscribeWithCategory]exchange={OO0O000O0O000O0O0}, subscriptionCategory={OOO0OO00OOOO0O00O}")#line:6437
        if EXCHANGE .TWF ==OO0O000O0O000O0O0 :#line:6439
            OOOO00O000000OO0O =threading .Thread (target =O000O00000OO0O00O .__OO0OO0O0OOOOOOOO0 ,args =(OOO0OO00OOOO0O00O ,True ))#line:6441
            OOOO00O000000OO0O .start ()#line:6442
        elif EXCHANGE .TWS ==OO0O000O0O000O0O0 :#line:6444
            OOOO00O000000OO0O =threading .Thread (target =O000O00000OO0O00O .__O00OOOO000OO000OO ,args =(OOO0OO00OOOO0O00O ,True ))#line:6446
            OOOO00O000000OO0O .start ()#line:6447
        return RCode .OK #line:6448
    def UnsubscribeWithCategory (OO00O0000OOO0000O ,O00OOO0O00OO00OO0 :str ,O000O0OO0OOO000OO :str )->RCode :#line:6450
        ""#line:6452
        OO000000O00000000 :str =""#line:6453
        if EXCHANGE .TWF ==O00OOO0O00OO00OO0 :#line:6455
            O0O00OOO0O0O0O0O0 ,OO000000O00000000 =OO00O0000OOO0000O .__OO0O0OO0OOOO000OO (O000O0OO0OOO000OO )#line:6456
            if O0O00OOO0O0O0O0O0 ==RCode .FAIL :#line:6457
                return RCode .FAIL ,OO000000O00000000 #line:6458
        elif EXCHANGE .TWS ==O00OOO0O00OO00OO0 :#line:6460
            O0O00OOO0O0O0O0O0 ,OO000000O00000000 =OO00O0000OOO0000O .__OOO0OOOO00O0000OO (O000O0OO0OOO000OO )#line:6461
            if O0O00OOO0O0O0O0O0 ==RCode .FAIL :#line:6462
                return RCode .FAIL ,OO000000O00000000 #line:6463
        return RCode .OK ,OO000000O00000000 #line:6464
    def OvsUnSubscribeWithCategory (O000O0OOOO0O0O000 ,aMrt :str ="FUT",aExchange :str ="*"):#line:6465
        O000O0OO0OO0OOO0O :str =""#line:6466
        if aMrt =="FUT":#line:6467
            OOO0OO00OO0OOOOO0 ,O000O0OO0OO0OOO0O =O000O0OOOO0O0O000 .__OO0O000O0OO0000OO (aExchange )#line:6468
            if OOO0OO00OO0OOOOO0 :#line:6469
                return RCode .OK ,""#line:6470
            else :#line:6471
                return RCode .FAIL ,O000O0OO0OO0OOO0O #line:6472
        else :#line:6473
            return RCode .FAIL ,"Mart is not 'FUT'"#line:6474
    def __OO0O000000000O00O (OOOO0OOO0OO00O000 ,O000000O0O000OO00 :str ,O00OO00O00O00O0OO :bool ,OO00O0O0O00000OOO :TObjStkQuoteMap ):#line:6477
        ""#line:6478
        if O00OO00O00O00O0OO ==False :#line:6479
            OOOO0OOO0OO00O000 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[證券行情回補]回補失敗!({O000000O0O000OO00})")#line:6480
            return #line:6481
        try :#line:6482
            for O0O0O0OOO0OO00O00 ,O0O0OO0O0OOO0000O in OO00O0O0O00000OOO .items ():#line:6483
                OO000000O0O00O0O0 :TStkQuoteData =O0O0OO0O0OOO0000O #line:6484
                O00000OO0O0OO000O =OO000000O0O00O0O0 .BAS .StkNo #line:6485
                if OOOO0OOO0OO00O000 ._fPrdSnapshotMap .NewItemStk (O00000OO0O0OO000O ,OO000000O0O00O0O0 ):#line:6486
                    OO0OOOOOOO00O00O0 :ProductSnapshot =OOOO0OOO0OO00O000 ._fPrdSnapshotMap [O00000OO0O0OO000O ]#line:6488
                    if OO000000O0O00O0O0 .UpdateBAS :#line:6489
                        OOOO0OOO0OO00O000 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateBasic (OO0OOOOOOO00O00O0 .BasicData )#line:6490
                        OO000000O0O00O0O0 .UpdateBAS =False #line:6491
                    if OO000000O0O00O0O0 .UpdateHL :#line:6492
                        OO0OOOOOOO00O00O0 .TickData =ProductTick_Stk (OO000000O0O00O0O0 )#line:6493
                        OOOO0OOO0OO00O000 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateLastSnapshot (OOOO0OOO0OO00O000 ._fPrdSnapshotMap [O00000OO0O0OO000O ])#line:6494
                        OO000000O0O00O0O0 .UpdateHL =False #line:6495
        except Exception as O000OO0000O0O0O0O :#line:6501
            OOOO0OOO0OO00O000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQtRcvEvent]aMsg={O000000O0O000OO00}, aIsOK={O00OO00O00O00O0OO}, ex:{O000OO0000O0O0O0O}")#line:6502
    def __OO0OOO000OOOOO0O0 (O000OO0O00OO00O00 ,OO0OOOOO0OOOO0O00 :str ,O00OOOO0000O00000 :str ,O000O000O00OO0O00 :TObjStkQuoteMap ):#line:6504
        ""#line:6505
        if O00OOOO0000O00000 ==False :#line:6506
            O000OO0O00OO00O00 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"[證券行情回補(指數)]{OO0OOOOO0OOOO0O00}回補失敗!")#line:6507
            return #line:6508
        try :#line:6509
            for OOOO0O0OOOO0O0O0O ,O0O00000OOO0O000O in O000O000O00OO0O00 .items ():#line:6510
                OOOO0O00OO0OOOO0O :TStkQuoteData =O0O00000OOO0O000O #line:6511
                OOO0OO0O0O0O0O000 =OOOO0O00OO0OOOO0O .BAS .StkNo #line:6512
                if O000OO0O00OO00O00 ._fPrdSnapshotMap .NewItemStk (OOO0OO0O0O0O0O000 ,OOOO0O00OO0OOOO0O ):#line:6513
                    if O000OO0O00OO00O00 .__O0O000O000O0O00OO ==False :#line:6514
                        OOOO0OOOOO0OOOOO0 :ProductSnapshot =O000OO0O00OO00O00 ._fPrdSnapshotMap [OOO0OO0O0O0O0O000 ]#line:6515
                        O000OO0O00OO00O00 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateBasic (OOOO0OOOOO0OOOOO0 .BasicData )#line:6516
                        O000OO0O00OO00O00 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateLastSnapshot (O000OO0O00OO00O00 ._fPrdSnapshotMap [OOO0OO0O0O0O0O000 ])#line:6517
            if O000OO0O00OO00O00 .__O0O000O000O0O00OO :#line:6518
                if len (O000OO0O00OO00O00 ._fPrdSnapshotMap )>0 :#line:6519
                    OOOOOOO0O0OO00O0O =list (O000OO0O00OO00O00 ._fPrdSnapshotMap .values ())#line:6520
                    O000OO0O00OO00O00 .__OOO0O0O00OOOO00O0 .Fire_OnUpdateProductBasicList (OOOOOOO0O0OO00O0O )#line:6521
        except Exception as OO0O0OOO0O00OO000 :#line:6522
            O000OO0O00OO00O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQtIdxRcvEvent]aMsg={OO0OOOOO0OOOO0O00}, aIsOK={O00OOOO0000O00000}, ex:{OO0O0OOO0O00OO000}")#line:6523
    def __OOO00O000000O00OO (OO00OOOOOO0OO0O00 ,O0O0000000000O0OO :str ,O00OOOOO00O0O000O :TStkQtTX ):#line:6525
        ""#line:6526
        try :#line:6527
            O0O000OOOOO000OO0 :ProductSnapshot =None #line:6528
            OOO0OO00O0O0O0OOO ,O0O000OOOOO000OO0 =OO00OOOOOO0OO0O00 ._fPrdSnapshotMap .GetItem (O0O0000000000O0OO )#line:6530
            if OOO0OO00O0O0O0OOO :#line:6532
                OO000OO000O0O00OO :ProductTick_Stk =O0O000OOOOO000OO0 .TickData #line:6533
                OOO0OO00O0O0O0OOO ,OOOOO00OOO0O0O0O0 =OO000OO000O0O00OO .Upt_TX (O00OOOOO00O0O000O )#line:6534
                if OOO0OO00O0O0O0OOO :#line:6535
                    OO00OOOOOO0OO0O00 .__OOO0O0O00OOOO00O0 .Fire_OnMatch (OO00OOOOOO0OO0O00 ._fPrdSnapshotMap [O0O0000000000O0OO ].TickData )#line:6536
                else :#line:6538
                    OO00OOOOOO0OO0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"STK_TXEvent Error:{OOOOO00OOO0O0O0O0} aSolIce:{O0O0000000000O0OO} tmpQtTx:{O00OOOOO00O0O000O}")#line:6539
        except Exception as O00O0OOOOOO0OO000 :#line:6540
            OO00OOOOOO0OO0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[STK_TXEvent]ProdID={O0O0000000000O0OO}, ex:{O00O0OOOOOO0OO000}")#line:6541
    def __OO0OOOO0O00O0O0O0 (O00O00000OO0O00O0 ,O00000O0O00000000 :str ,O0O000O0O000OO00O :TStkQt5Q ):#line:6542
        ""#line:6543
        try :#line:6544
            O00OOO00OO0OOO0OO :ProductSnapshot =None #line:6545
            O0OOO0O00O00000OO ,O00OOO00OO0OOO0OO =O00O00000OO0O00O0 ._fPrdSnapshotMap .GetItem (O00000O0O00000000 )#line:6546
            if O0OOO0O00O00000OO :#line:6547
                O000000OOOOO0OOO0 :ProductTick_Stk =O00OOO00OO0OOO0OO .TickData #line:6548
                O0OOO0O00O00000OO ,OOOO000O0O00OOOOO =O000000OOOOO0OOO0 .Upt_5Q (O0O000O0O000OO00O )#line:6550
                if O0OOO0O00O00000OO :#line:6551
                    O00O00000OO0O00O0 .__OOO0O0O00OOOO00O0 .Fire_OnOrderBook (O00O00000OO0O00O0 ._fPrdSnapshotMap [O00000O0O00000000 ].TickData )#line:6552
                else :#line:6554
                    O00O00000OO0O00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"STK_5QEvent Error:{OOOO000O0O00OOOOO} aSolIce={O00000O0O00000000} tmpQt5Q:{O0O000O0O000OO00O}")#line:6555
        except Exception as O00OOOO00O00O0O0O :#line:6556
            O00O00000OO0O00O0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[STK_5QEvent]ProdID={O00000O0O00000000}, ex:{O00OOOO00O00O0O0O}")#line:6557
    def __O0OO0000O0OO00OO0 (OO00OOO0000O0OOOO ,OOOO0OO00OO00O0OO :str ,O00O0O00OO0O0O0O0 :TStkQtIDX ):#line:6558
        ""#line:6559
        try :#line:6560
            OO00O00O00O0OOOOO :ProductSnapshot =None #line:6561
            O0OO000O00000O000 ,OO00O00O00O0OOOOO =OO00OOO0000O0OOOO ._fPrdSnapshotMap .GetItem (OOOO0OO00OO00O0OO )#line:6563
            if O0OO000O00000O000 :#line:6564
                O00OOO000O00O000O :ProductTick_Stk =OO00O00O00O0OOOOO .TickData #line:6565
                O0OO000O00000O000 ,O0OO0O0OOO0O000O0 =O00OOO000O00O000O .Upt_IDX (O00O0O00OO0O0O0O0 )#line:6567
                if O0OO000O00000O000 :#line:6568
                    OO00OOO0000O0OOOO .__OOO0O0O00OOOO00O0 .Fire_OnMatch (OO00OOO0000O0OOOO ._fPrdSnapshotMap [OOOO0OO00OO00O0OO ].TickData )#line:6569
                else :#line:6571
                    OO00OOO0000O0OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"STK_IDXEvent Error:{O0OO0O0OOO0O000O0} aSolIce:{OOOO0OO00OO00O0OO} tmpQtIDX:{O00O0O00OO0O0O0O0}")#line:6572
        except Exception as OO00OO000O0OO0000 :#line:6573
            OO00OOO0000O0OOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[SolQuoteStkAPI_OnQtIDXEvent]ProdID={OOOO0OO00OO00O0OO}, ex:{OO00OO000O0OO0000}")#line:6574
class SolAPIHH (SolAPI ):#line:6580
    def __init__ (O000000OOOOOOOOOO ,__OO00O0O000OOO0OO0 :MarketDataMart ,OOOOOO0O00OO0O0OO :str ,loglv =logging .INFO ,conlv =logging .INFO ):#line:6581
        super ().__init__ (__OO00O0O000OOO0OO0 ,OOOOOO0O00OO0O0OO ,False ,loglv ,conlv )#line:6582
    def Logon (OOO000OOOO0O0O00O ,O0O0OO00O0OO00000 :str ,O0O0O000OOO000000 :str ,OO00O0OOO00O000OO :str ,aCompressLevel :int =5 )->RCode :#line:6584
        ""#line:6590
        if aCompressLevel <1 :#line:6591
            return RCode .FAIL #line:6592
        return OOO000OOOO0O0O00O .Connect (O0O0OO00O0OO00000 +":55003","api",O0O0O000OOO000000 ,OO00O0OOO00O000OO ,aCompressLevel )#line:6594
class TSolaceMessageThreadClass (MessageHandler ):#line:6600
    ""#line:6601
    def __init__ (O00OO0OO000O00OO0 ,OO00OO0OO0O00O00O :str ,OO0OO000O00000O0O :logging .Logger ,O0O00O0OOOO000000 ):#line:6604
        O00OO0OO000O00OO0 ._name =OO00OO0OO0O00O00O #line:6605
        O00OO0OO000O00OO0 ._msgHandler =O0O00O0OOOO000000 #line:6606
        O00OO0OO000O00OO0 ._lock =Lock ()#line:6607
        O00OO0OO000O00OO0 ._log =OO0OO000O00000O0O #line:6608
        O00OO0OO000O00OO0 ._list =[]#line:6609
        O00OO0OO000O00OO0 ._run =True #line:6610
        O00OO0OO000O00OO0 .thrd =threading .Thread (target =O00OO0OO000O00OO0 .OnThread ,name =O00OO0OO000O00OO0 ._name )#line:6611
        O00OO0OO000O00OO0 .thrd .start ()#line:6612
    def OnThread (OOOOO0000OO0OOOOO ):#line:6614
        OOO0OOO000O00O00O =[]#line:6615
        OO0O00O0OOO0000OO ,OO0OO00OO0OO0OOOO ,OOO0OOOO0OOO0O000 =0 ,0 ,0 #line:6616
        while OOOOO0000OO0OOOOO ._run :#line:6617
            try :#line:6619
                with OOOOO0000OO0OOOOO ._lock :#line:6620
                    OOO0OOO000O00O00O =OOOOO0000OO0OOOOO ._list .copy ()#line:6621
                    OO0O00O0OOO0000OO =len (OOO0OOO000O00O00O )#line:6622
                    if (len (OOOOO0000OO0OOOOO ._list )>3000 )and OO0O00O0OOO0000OO ==OO0OO00OO0OO0OOOO :#line:6623
                        OOOOO0000OO0OOOOO ._list =[]#line:6624
                for OOO0OOOO0OOO0O000 in range (OO0OO00OO0OO0OOOO ,OO0O00O0OOO0000OO ):#line:6626
                    OOOOO0000OO0OOOOO ._msgHandler (OOO0OOO000O00O00O [OOO0OOOO0OOO0O000 ])#line:6627
                OO0OO00OO0OO0OOOO =OO0O00O0OOO0000OO #line:6629
            except Exception as OOO0OO0O00OOOOOOO :#line:6630
                OOOOO0000OO0OOOOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"TSolaceMessageThreadClass __Handle_RTQuote_Main exception! exception={OOO0OO0O00OOOOOOO}")#line:6632
            finally :#line:6633
                sleep (0.001 )#line:6634
    def Add (O0OO00000OO00O00O ,O0OOO0O0O00000OO0 ):#line:6636
        with O0OO00000OO00O00O ._lock :#line:6637
            O0OO00000OO00O00O ._list .append (O0OOO0O0O00000OO0 )#line:6638
    def on_message (O0OOOOO0000000000 ,OOO00000OO000O0OO ):#line:6640
        ""#line:6641
        O0OOOOO0000000000 .Add (OOO00000OO000O0OO )#line:6642
class TMyWorkItemThreadClass :#line:6647
    def __init__ (O000O0O0OOO0O0O00 ,O0O0000OO0OO0O00O :str ,O00O00O000OOO0O00 :logging .Logger ,O0OOO00O0O00O0O0O ):#line:6648
        O000O0O0OOO0O0O00 ._name =O0O0000OO0OO0O00O #line:6649
        O000O0O0OOO0O0O00 ._msgHandler =O0OOO00O0O00O0O0O #line:6650
        O000O0O0OOO0O0O00 ._lock =Lock ()#line:6651
        O000O0O0OOO0O0O00 ._log =O00O00O000OOO0O00 #line:6652
        O000O0O0OOO0O0O00 ._run =True #line:6653
        O000O0O0OOO0O0O00 ._queue =queue .Queue ()#line:6654
        O0O000000O0O00OO0 =threading .Thread (target =O000O0O0OOO0O0O00 .OnThread ,name =O000O0O0OOO0O0O00 ._name )#line:6655
        O0O000000O0O00OO0 .start ()#line:6656
    def OnThread (O00OO00OO0OOOOO00 ):#line:6658
        while O00OO00OO0OOOOO00 ._run :#line:6659
            try :#line:6661
                with O00OO00OO0OOOOO00 ._lock :#line:6662
                    while not O00OO00OO0OOOOO00 ._queue .empty ():#line:6663
                        O000O00OOOOO0000O =O00OO00OO0OOOOO00 ._queue .get ()#line:6664
                        O00OO00OO0OOOOO00 ._msgHandler (O000O00OOOOO0000O ["arg1"],O000O00OOOOO0000O ["arg2"])#line:6666
            except Exception as OO0O00O0000OOOO0O :#line:6668
                O00OO00OO0OOOOO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"TMyWorkItemThreadClass send_msg exception! exception={OO0O00O0000OOOO0O}")#line:6669
            finally :#line:6670
                sleep (0.001 )#line:6671
    def Add (O00OOO0OOO00OOO00 ,**O00OO000O000OO0O0 ):#line:6673
        with O00OOO0OOO00OOO00 ._lock :#line:6674
            O00OOO0OOO00OOO00 ._queue .put (O00OO000O000OO0O0 )#line:6675
class CacheReqOutListener (CacheRequestOutcomeListener ):#line:6677
    def __init__ (OO000OO0OO0OO000O ,O00O00OO0O0OOOOO0 ,OOOOOO0O0O0OO0000 :TSolaceMessageThreadClass ,O0O0000O00000OOO0 :SolaceLog )->None :#line:6678
        OO000OO0OO0OO000O ._solapi =O00O00OO0O0OOOOO0 #line:6679
        OO000OO0OO0OO000O ._thrdMag :TSolaceMessageThreadClass =OOOOOO0O0O0OO0000 #line:6680
        OO000OO0OO0OO000O ._log :SolaceLog =O0O0000O00000OOO0 #line:6681
    def on_completion (O00OOO0O0OOOO0O0O ,O0OO00000OO00OOOO :CacheRequestOutcome ,OOO0OO0OOOOO0OOOO :int ,OOO0O0O0O000O0O0O :Exception ):#line:6682
        if O0OO00000OO00OOOO ==CacheRequestOutcome .FAILED :#line:6684
            O00OOO0O0OOOO0O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"cache completion fail: result:{O0OO00000OO00OOOO} id:{OOO0OO0OOOOO0OOOO} exception:{OOO0O0O0O000O0O0O}")#line:6685
            OO00OOOO0O000O000 :TCacheJob =O00OOO0O0OOOO0O0O ._solapi ._fMapCacheJob [OOO0OO0OOOOO0OOOO ]#line:6686
        elif O0OO00000OO00OOOO ==CacheRequestOutcome .OK :#line:6689
            O00OOO0O0OOOO0O0O ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"cache completion OK: result:{O0OO00000OO00OOOO} id:{OOO0OO0OOOOO0OOOO} exception:{OOO0O0O0O000O0O0O}")#line:6690
            if O00OOO0O0OOOO0O0O ._solapi ._fMapCacheJob .get (OOO0OO0OOOOO0OOOO ):#line:6691
                OO00OOOO0O000O000 :TCacheJob =O00OOO0O0OOOO0O0O ._solapi ._fMapCacheJob [OOO0OO0OOOOO0OOOO ]#line:6692
                O00OO0OOO0O00O0O0 =OO00OOOO0O000O000 .Params .get ("Category")#line:6693
                if (O00OO0OOO0O00O0O0 =="SubQuoteByCategory_BAS"):#line:6696
                    OOOOO0OO00OOO00OO =TCacheJob ()#line:6698
                    OO0OO0O00O0O0OO0O =OO00OOOO0O000O000 .TopicBAS .split ("/")#line:6699
                    if OO00OOOO0O000O000 .TopicBAS .startswith ("Quote/TWS/"):#line:6700
                        OO0OO0O00O0O0OO0O [len (OO0OO0O00O0O0OO0O )-1 ]="HL"#line:6701
                        OO0OO0O00O0O0OO0O [len (OO0OO0O00O0O0OO0O )-2 ]="*"#line:6702
                        OO0OO0O00O0O0OO0O [len (OO0OO0O00O0O0OO0O )-3 ]="*"#line:6703
                        OOOOO0OO00OOO00OO .TopicHL ="/".join (OO0OO0O00O0O0OO0O )#line:6704
                    elif OO00OOOO0O000O000 .TopicBAS .startswith ("Quote/TWF/"):#line:6705
                        OO0OO0O00O0O0OO0O [len (OO0OO0O00O0O0OO0O )-1 ]="HL"#line:6706
                        OO0OO0O00O0O0OO0O [len (OO0OO0O00O0O0OO0O )-2 ]="*"#line:6707
                        OOOOO0OO00OOO00OO .TopicHL ="/".join (OO0OO0O00O0O0OO0O )#line:6708
                    OOOOO0OO00OOO00OO .oneProd =False #line:6709
                    OOOOO0OO00OOO00OO .RequestID =O00OOO0O0OOOO0O0O ._solapi .GetRequestID ()#line:6710
                    OOOOO0OO00OOO00OO .Params ["Category"]="SubQuoteByCategory_HL"#line:6711
                    O00OOO0O0OOOO0O0O ._solapi ._fMapCacheJob [OOOOO0OO00OOO00OO .RequestID ]=OOOOO0OO00OOO00OO #line:6712
                    O00OOO0O0OOOO0O0O ._solapi .callcache (OOOOO0OO00OOO00OO .RequestID ,OOOOO0OO00OOO00OO .TopicHL )#line:6714
