from collections import UserDict
import decimal
from enum import Enum
import math
from pydoc_data import topics
import queue
import threading
from threading import Lock
import time
from typing import Union

from solace.messaging.messaging_service import MessagingService, ReconnectionListener, ReconnectionAttemptListener, ServiceInterruptionListener, ServiceEvent
from solace.messaging.receiver.message_receiver import MessageHandler, InboundMessage
from solace.messaging.publisher.outbound_message import OutboundMessage
from solace.messaging.resources.topic import Topic
from solace.messaging.resources.topic_subscription import TopicSubscription
from solace.messaging.utils.cache_request_outcome import CacheRequestOutcome
from solace.messaging.resources.cached_message_subscription_request import CachedMessageSubscriptionRequest
from solace.messaging.receiver.receiver_cache_requests import ReceiverCacheRequests
from solace.messaging.receiver.inbound_message import *
from solace.messaging.utils.life_cycle_control import TerminationNotificationListener
from solace.messaging.utils.cache_request_outcome_listener import CacheRequestOutcomeListener
from solace.messaging.utils._termination_notification_util import TerminationNotificationEvent
from solace.messaging.receiver.direct_message_receiver import DirectMessageReceiver
from solace.messaging.publisher.request_reply_message_publisher import RequestReplyMessagePublisher
from solace.messaging.publisher.publisher_health_check import PublisherReadinessListener
from datetime import datetime

import json
import os
from os.path import dirname
from decimal import Decimal
from PY_Trade_package.MarketDataMart import MarketDataMart, SystemEvent
from PY_Trade_package.Product import ProductSnapshot, ProductTick_Fut, ProductTick_Stk, TMapPrdOvs, TMapPrdSnapshot

from PY_Trade_package.SolPYAPI_Model import *

from PY_Trade_package.SolLog import *
import logging
from time import sleep


class TStkQuoteConnStu(Enum):
    stuUnConn = 0
    """未連線"""
    stuConnIng = 10
    """連線中"""
    stuConnected = 20
    """初次連線成功"""
    stuReConnected = 21
    """再次連線成功"""
    stuDisConnIng = 30
    """準備斷線"""


class TStkProdKind(Enum):
    pkNone = 0
    pkNormal = 10
    """一般證券"""
    pkIndex = 20
    """指數商品(EX:加權指數)"""


class STKxFUT(Enum):
    STK = 0
    FUT = 1
    OPT = 2
    OVSFUT = 3

# ------------------------data info class-----------------------------
# region STK
class TStkQtBase():
    fHasBAS = False

    TopicTX:str = ""
    Topic5Q:str = ""
    TopicHL:str = ""

    fBAS = []
    StkNo: str  #fBAS[0]
    """證券代碼"""
    StkName: str    #fBAS[1]
    """證券中文"""
    RefPriceOrg: str    #fBAS[4]
    """參考價"""
    LimitPrice_UpOrg: str   #fBAS[5]
    """漲停價"""
    LimitPrice_DownOrg: str #fBAS[6]
    """跌停價"""
    IndustryCategory:str    #fBAS[7]
    "產業別"
    StockCategory:str   #fBAS[8]
    "證券別"
    StockAnomalyCode:str #fBAS[10]
    "股票異常代碼"
    BoardRemark:str #fBAS[11]
    "板別註記"
    ClassRemark:str #fBAS[12]
    "類股註記"
    NonTenFaceValueIndicator:str #fBAS[13]
    "非10元面額註記"
    AbnormalRecommendationIndicator:str #fBAS[14]
    "異常推介個股註記"
    AbnormalSecuritiesIndicator:str # fBAS[15]
    "特殊異常證券註記"
    DayTradingIndicator:str #fBAS[16]
    "可現股當沖註記"
    TradingUnit:str #fBAS[30]
    "交易單位"
    def Get_TradingUnit(self):
        return self.TransToInt(self.fBAS[30])
    TickSizeInfo: str   #fBAS[33]
    """跳動點資訊"""
    TotQtyPre: str      #fBAS[34]
    """(前交易日)成交總量"""
    TotAmtPre: str  #fBAS[35]
    """(前交易日)成交總額"""

    RefPPre:str #fBAS[36]
    "上一交易日參考價"
    CPPre:str #fBAS[37]
    "上一交易日收盤價"

    def __init__(self, topic:str =  ""):
        if topic != "":
            arr = topic.split("/")
            arr[len(arr)-1] = "HL"
            self.TopicHL = "/".join(arr)#最高低價
            arr[len(arr)-1] = "TX"
            self.TopicTX = "/".join(arr)#成交
            arr[len(arr)-1] = "5Q"
            self.Topic5Q = "/".join(arr)#五檔


    def Get_RefPrice(self) -> decimal:
        return self.TransToDecimal(self.fBAS[4])

    def Get_LimitPrice_Up(self) -> decimal:
        return self.TransToDecimal(self.fBAS[5])

    def Get_LimitPrice_Down(self) -> decimal:
        return self.TransToDecimal(self.fBAS[6])

    def Get_TotQtyPre(self) -> decimal:
        return self.TransToDecimal(self.fBAS[34])

    def Get_TotAmtPre(self) -> decimal:
        return self.TransToDecimal(self.fBAS[35])

    def Handle_BAS(self, aData: str):
        self.fBAS = aData.split('|')
        self.fHasBAS = len(self.fBAS) > 0
        self.StkNo = self.fBAS[0]
        self.StkName = self.fBAS[1]
        self.RefPriceOrg = self.fBAS[4]
        self.LimitPrice_UpOrg = self.fBAS[5]
        self.LimitPrice_DownOrg = self.fBAS[6]
        self.IndustryCategory = self.fBAS[7]
        self.StockCategory = self.fBAS[8]
        self.StockAnomalyCode = self.fBAS[10]
        self.BoardRemark = self.fBAS[11]
        self.ClassRemark = self.fBAS[12]
        self.NonTenFaceValueIndicator = self.fBAS[13]
        self.AbnormalRecommendationIndicator = self.fBAS[14]
        self.AbnormalSecuritiesIndicator = self.fBAS[15]
        self.DayTradingIndicator = self.fBAS[16]
        self.TradingUnit = self.fBAS[30]
        self.TickSizeInfo = self.fBAS[33]
        self.TotQtyPre = self.fBAS[34]
        self.TotAmtPre = self.fBAS[35]
        self.RefPPre = self.fBAS[36]
        self.CPPre = self.fBAS[37]
        if self.TopicTX != "":
            arr = self.TopicHL.split("/")
            arr[len(arr)-2] = self.StkNo            
            self.TopicHL = "/".join(arr)#最高低價
            arr = self.TopicTX.split("/")
            arr[len(arr)-2] = self.StkNo
            self.TopicTX = "/".join(arr)#成交
            arr = self.Topic5Q.split("/")
            arr[len(arr)-2] = self.StkNo
            self.Topic5Q = "/".join(arr)#五檔
            

    def TransToInt(self, aOrgStr: str) -> int:

        try:
            return int(aOrgStr)
        except Exception as ex:
            pass
            # print(f"Not a Int{ex}")
        return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            print(f"Not a Decimal{ex}")
        return 0
class TStkQtHL():
    HasHL = False
    fHL = []
    TopicTX:str = ""
    Topic5Q:str = ""

    Market: str = ""#fHL[0]
    """市場別(TSE/OTC)"""
    StkKind: str = ""#fHL[1]
    """"證券別(S/W/Idx)"""
    Symbol: str = ""#fHL[2]
    """委託商品代碼(2330)"""
    DealTime: str = ""#fHL[3]
    """撮合時間(成交)(EX:173547.32700)"""
    DealSn: str = ""#fHL[4]
    """成交序號"""

    def Get_DealSn(self) -> int:
        return self.TransToInt(self.fHL[4])
    Sn_5Q: str  = ""#fHL[5]
    """五檔序號(指數類=空字串)"""

    def Get_Sn_5Q(self) -> int:
        return self.TransToInt(self.fHL[5])
    DealPriceOrg: str = "" #fHL[6]
    """成交價"""

    def Get_DealPrice(self) -> decimal:
        return self.TransToDecimal(self.fHL[6])

    # fDealPrice = 0m
    DealPrice: decimal
    """成交價"""
    DealQty: str = ""#fHL[7]
    """成交單量(指數類=0)"""

    def Get_DealQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fHL[7])

    def Get_DealQty2Int(self) -> int:
        return self.TransToInt(self.fHL[7])

    HighPriceOrg: str = ""#fHL[8]
    """當日最高價"""

    def Get_HighPrice(self) -> decimal:
        return self.TransToDecimal(self.fHL[8])

    LowPriceOrg: str = ""#fHL[9]
    """當日最低價"""

    def Get_LowPrice(self) -> decimal:
        return self.TransToDecimal(self.fHL[9])

    TotAmt: str = ""#fHL[10]
    """成交總額(指數類=0)"""

    def Get_TotAmt2Dec(self) -> decimal:
        return self.TransToDecimal(self.fHL[10])

    def Get_TotAmt2Int(self) -> int:
        return self.TransToInt(self.fHL[10])

    TotQty: str = ""#fHL[11]
    """成交總量(指數類=0)"""

    def Get_TotQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fHL[11])

    def Get_TotQty2Int(self) -> int:
        return self.TransToInt(self.fHL[11])

       
    FirstDerivedBuyPrice:str = ""# fHL[35]
    "衍生委託單第一檔買進價格"        
    FirstDerivedBuyQty:str = ""# fHL[36]
    "衍生委託單第一檔買進價格數量"        
    FirstDerivedSellPrice:str = ""# fHL[37]
    "衍生委託單第一檔賣出價格數量"   
    FirstDerivedSellQty:str = ""# fHL[38]
    "衍生委託單第一檔賣出價格數量"

    OpenPriceOrg: str = ""# fHL[42]
    """開盤價"""

    def Get_OpenPrice(self) -> decimal:
        return self.TransToDecimal(self.fHL[42])
    
    TryMark_Deal:str = ""# fHL[43]
    "成交試撮註記(試撮=1, 非試撮=0)"        
    TryMark_5Q:str = ""# fHL[44]
    "五檔試撮註記(試撮=1, 非試撮=0)"
    
    # region 五檔買價量
    fAryB5Q_P = [13, 15, 17, 19, 21]
    """買五檔價在字串中的位置"""
    fAryB5Q_Q = [14, 16, 18, 20, 22]
    """買五檔價在字串中的位置"""
    # fB5QCount = 0
    """買5檔的檔數"""
    B5QCountOrg: str = ""
    """買5檔的檔數(指數類=0)"""
    B5QCount = 0
    """買5檔的檔數(指數類=0)"""

    def B5Q_POrg(self, aN: int) -> str:
        """買5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.B5QCount:
            return ""
        else:
            return self.fHL[self.fAryB5Q_P[aN-1]]

    def Get_B5Q_P(self, aN: int) -> decimal:
        """"取得買5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if aN > self.B5QCount:
            return 0
        else:
            return self.TransToDecimal(self.fHL[self.fAryB5Q_P[aN - 1]])

    def B5Q_QOrg(self, aN: int) -> str:
        """買5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if(aN > self.B5QCount):
            return ""
        else:
            return self.fHL[self.fAryB5Q_Q[aN-1]]

    def Get_B5Q_Q(self, aN: int) -> int:
        """取得買5檔-量 aN:5檔中的第幾檔(1~5)"""
        if(aN > self.B5QCount):
            return 0
        else:
            return self.TransToInt(self.fHL[self.fAryB5Q_Q[aN-1]])
    # endregion
    # region 五檔賣價量
    fAryS5Q_P = [24, 26, 28, 30, 32]
    """賣五檔價在字串中的位置"""
    fAryS5Q_Q = [25, 27, 29, 31, 33]
    """賣五檔價在字串中的位置"""
    # int fS5QCount = 0;//賣5檔的檔數
    S5QCountOrg: str = ""
    """賣5檔的檔數(指數類=0)"""
    S5QCount: int

    def S5Q_POrg(self, aN: int) -> str:
        """賣5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.S5QCount:
            return ""
        else:
            return self.fHL[self.fAryS5Q_P[aN - 1]]

    def Get_S5Q_P(self, aN: int) -> decimal:
        """取得賣5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if aN > self.S5QCount:
            return 0
        else:
            return self.TransToDecimal(self.fHL[self.fAryS5Q_P[aN - 1]])

    def S5Q_QOrg(self, aN: int) -> str:
        """賣5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.S5QCount:
            return ""
        else:
            return self.fHL[self.fAryS5Q_Q[aN - 1]]

    def Get_S5Q_Q(self, aN: int) -> int:
        """取得賣5檔-量 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fS5QCount:
            return 0
        else:
            return self.TransToInt(self.fHL[self.fAryS5Q_Q[aN - 1]])
    # endregion

    # region 整體市場
    WholeTotAmt: str
    """整體市場成交總額"""

    def Get_WholeTotAmt(self) -> int:
        return self.TransToInt(self.fHL[34])

    WholeTotQty: str
    """整體市場成交數量"""

    def Get_WholeTotQty(self) -> int:
        return self.TransToInt(self.fHL[35])

    WholeDealCount: str
    """整體市場成交筆數"""

    def Get_WholeDealCount(self) -> int:
        return self.TransToInt(self.fHL[36])

    SumBuyOrderCount: str
    """整體市場委託買進筆數"""

    def Get_SumBuyOrderCount(self) -> int:
        return self.TransToInt(self.fHL[37])

    SumSellOrderCount: str
    """整體市場委託賣出筆數"""

    def Get_SumSellOrderCount(self) -> int:
        return self.TransToInt(self.fHL[38])

    SumBuyOrderQty: str
    """整體市場委託買進數量"""

    def Get_SumBuyOrderQty(self) -> int:
        return self.TransToInt(self.fHL[39])

    SumSellOrderQty: str
    """整體市場委託賣出數量"""

    def Get_SumSellOrderQty(self) -> int:
        return self.TransToInt(self.fHL[40])
    # endregion

    def Handle_HL(self, aData: str):
        self.fHL = aData.split('|')
        self.HasHL = len(self.fHL) > 0

        self.Market = self.fHL[0]
        self.StkKind = self.fHL[1]
        self.Symbol = self.fHL[2]
        self.DealTime = self.fHL[3]
        self.DealSn = self.fHL[4]
        self.Sn_5Q = self.fHL[5]
        self.DealPriceOrg = self.fHL[6]
        self.DealPrice = self.TransToDecimal(self.DealPriceOrg)
        self.DealQty = self.fHL[7]
        self.HighPriceOrg = self.fHL[8]
        self.LowPriceOrg = self.fHL[9]
        self.TotAmt = self.fHL[10]
        self.TotQty = self.fHL[11]
        self.FirstDerivedBuyPrice = self.fHL[35]
        self.FirstDerivedBuyQty = self.fHL[36]
        self.FirstDerivedSellPrice = self.fHL[37]
        self.FirstDerivedSellQty = self.fHL[38]

        self.B5QCountOrg = self.fHL[12]
        self.B5QCount = self.TransToInt(self.B5QCountOrg)
        self.S5QCountOrg = self.fHL[23]
        self.S5QCount = self.TransToInt(self.S5QCountOrg)
        self.WholeTotAmt = self.fHL[34]
        self.WholeTotQty = self.fHL[35]
        self.WholeDealCount = self.fHL[36]
        self.SumBuyOrderCount = self.fHL[37]
        self.SumSellOrderCount = self.fHL[38]
        self.SumBuyOrderQty = self.fHL[39]
        self.SumSellOrderQty = self.fHL[40]

        self.OpenPriceOrg = self.fHL[42]
        self.TryMark_Deal = self.fHL[43]
        self.TryMark_5Q = self.fHL[44]
        if self.HasHL:        
            self.TopicTX = f"Quote/TWS/{self.StkKind}/{self.Market}/{self.Symbol}/TX"
            self.Topic5Q = f"Quote/TWS/{self.StkKind}/{self.Market}/{self.Symbol}/5Q"
        

    # region Tool
    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0
    # endregion

    def __init__(self) -> None:
        pass

    def __str__(self) -> str:
        return f"""Market:{self.Market} StkKind:{self.StkKind} Symbol:{self.Symbol} DealTime:{self.DealTime}"""+\
                """DealSn:{self.DealSn} Sn_5Q:{self.Sn_5Q} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty}"""+\
                """HighPriceOrg:{self.HighPriceOrg} LowPriceOrg:{self.LowPriceOrg} TotAmt:{self.TotAmt} TotQty:{self.TotQty}"""+\
                """B5QCountOrg:{self.B5QCountOrg} S5QCount:{self.S5QCount} WholeTotAmt:{self.WholeTotAmt} WholeTotQty:{self.WholeTotQty}"""+\
                """WholeDealCount:{self.WholeDealCount} SumBuyOrderCount:{self.SumBuyOrderCount} SumSellOrderCount:{self.SumSellOrderCount}"""+\
                """SumBuyOrderQty:{self.SumBuyOrderQty} SumSellOrderQty:{self.SumSellOrderQty} OpenPriceOrg:{self.OpenPriceOrg}"""
class TStkQtTX:
    fTX = []
    HL_Sn_5Q = 0
    """來自HL回補的5檔序號(當收到即時成交行情時,若帶五檔行情,需判斷是否比HL紀錄的還大, 若比較小, 表示很久沒有成交行情, 但五檔一直在變動, 則不可使用成交行情裡的五檔資料)"""
    HL_TotAmt:decimal = 0
    """來自HL的成交總額，用於累加收到成交行情時的成交價*成交單量*交易單位"""
    BAS_TradingUnit = 1
    """來自BAS的交易單位用，用於累加收到成交行情時的成交價*成交單量*交易單位"""

    def Handle_TXRcv(self, aData: str):
        """處理回補"""
        try:
            iValTX: int = 0
            iValRcv: int = 0
            aryRcv = aData.split('|')

            if aryRcv[4] == TSolQuoteStkSet.TryMark_No:  # 即時
                self.fPROC_HandleData = self.HandleData  # 處理即時

                if self.fTX == None:
                    self.fTX = aryRcv
                    self.SetData()
                else:
                    iValRcv = self.TransToInt(aryRcv[3])
                    iValTX = self.Get_DealSn()
                    if iValRcv > iValTX:  # 若回補的成交序號比較小, 則不更新
                        self.fTX = aryRcv
                        self.SetData()

                self.fPROC_CalcHightLowPrice()  # 計算最高低價
                self.CalTotalTradingAmount() #計算成交總額

                #來自HL回補的5檔序號(當收到即時成交行情時,若帶五檔行情,需判斷是否比HL紀錄的還大, 若比較小, 表示很久沒有成交行情, 但五檔一直在變動, 則不可使用成交行情裡的五檔資料)
                iValTX = self.Get_DealSn()
                if iValTX >= self.HL_Sn_5Q:
                    self.fB5QCount = self.TransToInt(
                        self.B5QCountOrg)  # 買5檔的檔數
                    self.fS5QCount = self.TransToInt(
                        self.S5QCountOrg)  # 賣5檔的檔數
                else:
                    self.fB5QCount = 0
                    self.fS5QCount = 0
            else:
                self.fPROC_HandleData = self.HandleData_TryMarket
                self.fPROC_HandleData(aData)
        except Exception as ex:
            pass

    def Handle_TX(self, aData: str):
        """處理即時"""
        self.fPROC_HandleData(aData)

    # region 試撮 or 盤中

    def HandleData_TryMarket(self, aData: str):
        """處理試撮:試撮行情"""
        if aData.split('|')[4] == TSolQuoteStkSet.TryMark_No:  # 非試撮
            fPROC_HandleData = self.HandleData
            fPROC_HandleData(aData)
        else:
            self.fTX = aData.split('|')  # 試撮行情
            self.SetData()
            self.B5QCount = self.TransToInt(self.B5QCountOrg)  # 買5檔的檔數
            self.S5QCount = self.TransToInt(self.S5QCountOrg)  # 賣5檔的檔數

    def HandleData(self, aData: str):
        """處理即時"""
        self.fTX = aData.split('|')
        self.SetData()
        self.fPROC_CalcHightLowPrice()  # 計算最高低價
        self.CalTotalTradingAmount() #計算成交總額
        self.B5QCount = self.TransToInt(self.B5QCountOrg)  # 買5檔的檔數
        self.S5QCount = self.TransToInt(self.S5QCountOrg)  # 賣5檔的檔數

    def SetData(self):
        self.SysTime = self.fTX[1]
        self.DealTime = self.fTX[2]
        self.DealSn = self.fTX[3]
        self.TryMark = self.fTX[4]
        self.Has5Q = self.fTX[5]
        self.PriceLimitMark = self.fTX[7]
        if len(self.fTX) > 7 and self.fTX[7][6:8] in ("01", "10"):
            self.IsMatchingSuspension = True  # 暫緩撮合 00：一般揭示 01：暫緩撮合且瞬間趨跌 10：暫緩撮合且瞬間趨漲 11：（保留）
        if len(self.fTX) > 8:
            self.IsDelayedOpening = self.fTX[8][1] == '1'#延後開盤
        if len(self.fTX) > 8:
            self.IsOpenRecord = self.fTX[8][4] == '1'
        if len(self.fTX) > 8:
            self.IsCloseRecord = self.fTX[8][5] == '1'
        self.TotQty = self.fTX[9]
        self.DealPriceOrg = self.fTX[10]
        self.DealQty = self.fTX[11]
        self.B5QCountOrg = self.fTX[12]
        self.S5QCountOrg = self.fTX[23]

        self.WholeTotAmt = self.fTX[34]
        self.WholeTotQty = self.fTX[35]
        self.WholeDealCount = self.fTX[36]
        self.SumBuyOrderCount = self.fTX[37]
        self.SumSellOrderCount = self.fTX[38]
        self.SumBuyOrderQty = self.fTX[39]
        self.SumSellOrderQty = self.fTX[40]
        self.IsFixedPriceTransaction = self.fTX[41]

    # delegate void PROC_HandleData(string aData);
    fPROC_HandleData: callable = None
    """PROC_HandleData"""
    # endregion

    # region
    SysTime: str
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""
    DealTime: str
    """撮合時間(成交)(EX:085229.843665)"""
    DealSn: str
    """序號(成交序號、5檔序號)"""

    def Get_DealSn(self) -> int:
        return self.TransToInt(self.fTX[3])
    TryMark = "1"
    """試撮註記(試撮=1, 非試撮=0)"""
    Has5Q: str
    """五檔揭示註記(揭示=1, 不揭示=0)"""
    PriceLimitMark:str
    """漲跌停註記"""
    IsMatchingSuspension:bool = False
    """是否為暫緩撮合 00：一般揭示 01：暫緩撮合且瞬間趨跌 10：暫緩撮合且瞬間趨漲 11：（保留）"""
    IsDelayedOpening:bool = False
    """此筆是否為延後開盤"""
    IsOpenRecord:bool = False
    """此筆是否為開盤行情(False:僅代表此筆非開盤行情, 並不代表盤中或收盤狀態)"""
    IsCloseRecord:bool = False
    """此筆是否為收盤行情(False:僅代表此筆非收盤行情, 並不代表盤中或開盤狀態)"""

    TotQty: str
    """成交總量"""

    def Get_TotQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fTX[9])

    def Get_TotQty2Int(self) -> int:
        return self.TransToInt(self.fTX[9])

    DealPriceOrg: str
    """成交價"""

    def Get_DealPrice(self) -> decimal:
        return self.TransToDecimal(self.fTX[10])

    DealQty: str
    """成交單量"""

    def Get_DealQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fTX[11])

    def Get_DealQty2Int(self) -> int:
        return self.TransToInt(self.fTX[11])
    # endregion

    # region 五檔買價量
    fAryB5Q_P = [13, 15, 17, 19, 21]
    """買五檔價在字串中的位置"""
    fAryB5Q_Q = [14, 16, 18, 20, 22]
    """買五檔價在字串中的位置"""
    # int fB5QCount = 0;//買5檔的檔數

    B5QCountOrg: str
    """買5檔的檔數"""
    B5QCount: int
    """買5檔的檔數"""

    def B5Q_POrg(self, aN: int) -> str:
        """買5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return ""
        else:
            return self.fTX[self.fAryB5Q_P[aN - 1]]

    def Get_B5Q_P(self, aN: int) -> decimal:
        """取得買5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return 0
        else:
            return self.TransToDecimal(self.fTX[self.fAryB5Q_P[aN - 1]])

    def B5Q_QOrg(self, aN: int) -> str:
        """買5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return ""
        else:
            return self.fTX[self.fAryB5Q_Q[aN - 1]]

    def Get_B5Q_Q(self, aN: int) -> int:
        """取得買5檔-量 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return 0
        else:
            return self.TransToInt(self.fTX[self.fAryB5Q_Q[aN - 1]])
    # endregion

    # region 五檔賣價量
    fAryS5Q_P = [24, 26, 28, 30, 32]
    """賣五檔價在字串中的位置"""
    fAryS5Q_Q = [25, 27, 29, 31, 33]
    """賣五檔價在字串中的位置"""
    # int fS5QCount = 0;//賣5檔的檔數

    S5QCountOrg: str
    """賣5檔的檔數"""
    S5QCount: int
    """賣5檔的檔數"""

    def S5Q_POrg(self, aN: int) -> str:
        """賣5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return ""
        else:
            return self.fTX[self.fAryS5Q_P[aN - 1]]

    def Get_S5Q_P(self, aN: int) -> decimal:
        """取得賣5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return 0
        else:
            return self.TransToDecimal(self.fTX[self.fAryS5Q_P[aN - 1]])

    def S5Q_QOrg(self, aN: int) -> str:
        """賣5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return""
        else:
            return self.fTX[self.fAryS5Q_Q[aN - 1]]

    def Get_S5Q_Q(self, aN: int) -> int:
        """"取得賣5檔-量 aN:檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return 0
        else:
            return self.TransToInt(self.fTX[self.fAryS5Q_Q[aN - 1]])
    # endregion

    # region 計算最高低價
    fDealPrice = 0
    """成交價"""
    HighPrice = 0
    """當日最高價"""
    LowPrice = 0
    """當日最低價"""

    def CalcHightLowPrice(self):
        """計算最高低價"""
        try:
            self.fDealPrice = self.Get_DealPrice()
            self.HighPrice = max(self.fDealPrice, self.HighPrice)
            if self.LowPrice == 0:
                self.LowPrice = self.fDealPrice
            else:
                self.LowPrice = min(self.fDealPrice, self.LowPrice)

        except:
            pass

    def CalcHightLowPrice_None(self):
        pass

        # delegate void PROC_CalcHightLowPrice();
    fPROC_CalcHightLowPrice: callable = None
    """PROC_CalcHightLowPrice """

    # endregion

    #region 計算成交總額
    fDealQty:int = 0 #成交單量

        
    def CalTotalTradingAmount(self):
        "計算成交總額"
        
        try:
            self.fDealQty = self.Get_DealQty2Int()

            #計算成交總額(成交價*成交單量*交易單位)，沿用計算高低價中的成交價
            self.HL_TotAmt += self.fDealPrice * self.fDealQty * self.BAS_TradingUnit
        except Exception as ex:
            pass
        
    #endregion 計算成交總額

    #region 整體市場    
    WholeTotAmt:str #fTX[34]
    "整體市場成交總額"
    def Get_WholeTotAmt(self)->int:
        return self.TransToInt(self.fTX[34])
    WholeTotQty:str #fTX[35]
    "整體市場成交數量"
    def Get_WholeTotQty(self)->int:
        return self.TransToInt(self.fTX[35])    
    WholeDealCount:str #fTX[36]
    "整體市場成交筆數"
    def Get_WholeDealCount(self)->int:
        return self.TransToInt(self.fTX[36])
    SumBuyOrderCount:str # fTX[37]
    "整體市場委託買進筆數"
    def Get_SumBuyOrderCount(self)->int:
        return self.TransToInt(self.fTX[37])
    SumSellOrderCount:str # fTX[38]
    "整體市場委託賣出筆數"
    def Get_SumSellOrderCount(self)->int: 
        return self.TransToInt(self.fTX[38])
    SumBuyOrderQty:str # fTX[39]
    "整體市場委託買進數量"
    def Get_SumBuyOrderQty(self):
        return self.TransToInt(self.fTX[39])
    SumSellOrderQty:str # fTX[40]
    "整體市場委託賣出數量"
    def Get_SumSellOrderQty(self):
        return self.TransToInt(self.fTX[40])
    IsFixedPriceTransaction:str #fTX[41]
    "是否為定盤交易"
        
    #endregion 整體市場

    # region Tool
    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0
    # endregion

    def __init__(self, aCalcHightLowPrice: bool) -> None:
        self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice_None
        if aCalcHightLowPrice:
            self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice
        # 處理試撮/盤中:試撮行情
        self.fPROC_HandleData = self.HandleData_TryMarket

    def __str__(self) -> str:
        return f"""SysTime:{self.SysTime} DealTime:{self.DealTime} DealSn:{self.DealSn} TryMark:{self.TryMark}"""+\
                """Has5Q:{self.Has5Q} TotQty:{self.TotQty} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty}"""+\
                """B5QCountOrg:{self.B5QCountOrg} S5QCountOrg:{self.S5QCountOrg} fTX:{self.fTX}"""
class TStkQt5Q():
    f5Q = []

    def Handle_5Q(self, aData: str):
        self.fPROC_HandleData(aData)

    # region 試撮 or 盤中
    def HandleData_TryMarket(self, aData: str):
        """處理試撮:試撮行情"""
        if aData.split('|')[4] == TSolQuoteStkSet.TryMark_No:  # 非試撮
            self.fPROC_HandleData = self.HandleData
            self.fPROC_HandleData(aData)
        else:
            self.f5Q = aData.split('|')  # 試撮五檔
            self.SetData()
            self.B5QCount = self.TransToInt(self.B5QCountOrg)  # 買5檔的檔數
            self.S5QCount = self.TransToInt(self.S5QCountOrg)  # 賣5檔的檔數

    def HandleData(self, aData: str):  # 處理即時
        self.f5Q = aData.split('|')
        self.SetData()
        self.B5QCount = self.TransToInt(self.B5QCountOrg)  # 買5檔的檔數
        self.S5QCount = self.TransToInt(self.S5QCountOrg)  # 賣5檔的檔數

    def SetData(self):
        self.SysTime = self.f5Q[1]
        self.DataTime = self.f5Q[2]
        self.DealSn = self.f5Q[3]
        if len(self.f5Q) > 7 and self.f5Q[7][6:8] in ("01", "10"):
            self.IsMatchingSuspension = True  # 暫緩撮合 00：一般揭示 01：暫緩撮合且瞬間趨跌 10：暫緩撮合且瞬間趨漲 11：（保留
        if len(self.f5Q) > 8:
            self.IsDelayedOpening = self.f5Q[8][1] == '1'#延後開盤
        if len(self.f5Q) > 4:
            self.TryMark = self.f5Q[4]
        if len(self.f5Q) > 8:
            self.IsOpenRecord = self.f5Q[8][4] == '1'
        if len(self.f5Q) > 8:
            self.IsCloseRecord = self.f5Q[8][5] == '1'

        self.TotQty = self.f5Q[9]
        self.B5QCountOrg = self.f5Q[12]
        self.S5QCountOrg = self.f5Q[23]

    # delegate void PROC_HandleData(string aData);
    fPROC_HandleData = None
    """PROC_HandleData"""
    # endregion

    SysTime: str    #f5Q[1]
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""
    DataTime: str   #f5Q[2]
    """資料時間(交易所)(EX:173547.32700)"""
    DealSn: str #f5Q[3]
    """序號(5檔序號)"""
    def Get_DealSn(self) -> int:
        return self.TransToInt(self.f5Q[3])
    TryMark = "1"   #f5Q[4]
    """試撮註記(試撮=1, 非試撮=0)"""
    IsMatchingSuspension:bool = False
    """是否為暫緩撮合 00：一般揭示 01：暫緩撮合且瞬間趨跌 10：暫緩撮合且瞬間趨漲 11：（保留）"""
    IsDelayedOpening:bool = False
    """此筆是否為延後開盤"""
    IsOpenRecord:bool = False #f5Q[8].ToCharArray()[4]
    """此筆是否為開盤行情(False:僅代表此筆非開盤行情, 並不代表盤中或收盤狀態)"""
    IsCloseRecord:bool = False #f5Q[8].ToCharArray()[5]
    """此筆是否為收盤行情(False:僅代表此筆非收盤行情, 並不代表盤中或開盤狀態)"""

    TotQty: str #f5Q[9]
    """成交總量"""

    def Get_TotQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.f5Q[9])

    def Get_TotQty2Int(self) -> int:
        return self.TransToInt(self.f5Q[9])

    # region 五檔買價量
    fAryB5Q_P = [13, 15, 17, 19, 21]
    """買五檔價在字串中的位置"""
    fAryB5Q_Q = [14, 16, 18, 20, 22]
    """買五檔價在字串中的位置"""
    # int fB5QCount = 0;//買5檔的檔數
    B5QCountOrg: str    #f5Q[12]
    """買5檔的檔數"""
    B5QCount: int
    """買5檔的檔數"""

    def B5Q_POrg(self, aN: int) -> str:
        """買5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return ""
        else:
            return self.f5Q[self.fAryB5Q_P[aN - 1]]

    def Get_B5Q_P(self, aN: int) -> decimal:
        """取得買5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return 0
        else:
            return self.TransToDecimal(self.f5Q[self.fAryB5Q_P[aN - 1]])

    def B5Q_QOrg(self, aN: int) -> str:
        """買5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return ""
        else:
            return self.f5Q[self.fAryB5Q_Q[aN - 1]]

    def Get_B5Q_Q(self, aN: int) -> int:
        """取得買5檔-量 aN:檔中的第幾檔(1~5)"""
        if (aN > self.B5QCount):
            return 0
        else:
            return self.TransToInt(self.f5Q[self.fAryB5Q_Q[aN - 1]])
    # endregion

    # region 五檔賣價量
    fAryS5Q_P = [24, 26, 28, 30, 32]
    """賣五檔價在字串中的位置"""
    fAryS5Q_Q = [25, 27, 29, 31, 33]
    """賣五檔價在字串中的位置"""
    # int fS5QCount = 0;//賣5檔的檔數
    S5QCountOrg: str    #f5Q[23]
    """賣5檔的檔數"""
    S5QCount: int
    """賣5檔的檔數"""

    def S5Q_POrg(self, aN: int) -> str:
        """賣5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return ""
        else:
            return self.f5Q[self.fAryS5Q_P[aN - 1]]

    def Get_S5Q_P(self, aN: int) -> decimal:
        """取得賣5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return 0
        else:
            return self.TransToDecimal(self.f5Q[self.fAryS5Q_P[aN - 1]])

    def S5Q_QOrg(self, aN: int) -> str:
        """賣5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return ""
        else:
            return self.f5Q[self.fAryS5Q_Q[aN - 1]]

    def Get_S5Q_Q(self, aN: int) -> int:
        """取得賣5檔-量 aN:5檔中的第幾檔(1~5)"""
        if (aN > self.S5QCount):
            return 0
        else:
            return self.TransToInt(self.f5Q[self.fAryS5Q_Q[aN - 1]])
    # endregion

    # region Tool
    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0
    # endregion

    def __init__(self) -> None:
        # 處理試撮/盤中:試撮行情
        self.fPROC_HandleData = self.HandleData_TryMarket

    def __str__(self) -> str:
        return f"""SysTime:{self.SysTime} DataTime:{self.DataTime} DealSn:{self.DealSn} TryMark:{self.TryMark}"""+\
                """TotQty:{self.TotQty} B5QCountOrg:{self.B5QCountOrg} S5QCountOrg:{self.S5QCountOrg} f5Q:{self.f5Q}"""
class TStkQtIDX():
    fIDX = []

    def Handle_IDXRcv(self, aData: str):
        """處理回補"""
        try:
            iValTX: int = 0
            iValRcv: int = 0
            aryRcv = aData.split('|')
            if self.fIDX == None:
                self.fIDX = aryRcv
            else:
                iValRcv = self.TransToInt(aryRcv[3])
                iValTX = self.Get_DealSn()
                if iValRcv > iValTX:  # 若回補的成交序號比較小, 則不更新
                    self.fIDX = aryRcv
                    self.SetData()

                self.fPROC_CalcHightLowPrice()  # 計算最高低價

        except Exception as ex:
            pass

    def Handle_IDX(self, aData: str):
        """處理即時"""
        self.fIDX = aData.split('|')
        self.SetData()
        self.fPROC_CalcHightLowPrice()  # 計算最高低價

    def SetData(self):
        self.SysTime = self.fIDX[1]
        self.DealTime = self.fIDX[2]
        self.DealSn = self.fIDX[3]

        self.DealPriceOrg = self.fIDX[10]
        self.WholeTotAmt = self.fIDX[34]

        self.TotQty = self.fIDX[35]
        self.WholeTotQty = self.fIDX[35]
        self.WholeDealCount = self.fIDX[36]
        self.SumBuyOrderCount = self.fIDX[37]
        self.SumSellOrderCount = self.fIDX[38]
        self.SumBuyOrderQty = self.fIDX[39]
        self.SumSellOrderQty = self.fIDX[40]

# region data
    SysTime: str    #fIDX[1]
    """系統時間Unix Timestamp(us)(EX:1642553376085607)"""
    DealTime: str   #fIDX[2]
    """撮合時間(成交)(EX:085229.843665)"""
    DealSn: str #fIDX[3]
    """序號"""

    def Get_DealSn(self) -> int:
        return self.TransToInt(self.fIDX[3])
    TotQty: str #fIDX[35]
    """成交總量"""

    def Get_TotQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fIDX[35])

    def Get_TotQty2Int(self) -> int:
        return self.TransToInt(self.fIDX[35])
    DealPriceOrg: str   #fIDX[10]
    """成交價"""

    def Get_DealPrice(self) -> decimal:
        return self.TransToDecimal(self.fIDX[10])
# endregion
# region 計算最高低價
    fDealPrice = 0
    """成交價"""
    HighPrice = 0
    """當日最高價"""
    LowPrice = 0
    """當日最低價"""

    def CalcHightLowPrice(self):
        """計算最高低價"""
        try:
            self.fDealPrice = self.Get_DealPrice()

            self.HighPrice = max(self.fDealPrice, self.HighPrice)
            if self.LowPrice == 0:
                self.LowPrice = self.fDealPrice
            else:
                self.LowPrice = min(self.fDealPrice, self.LowPrice)
        except Exception as ex:
            pass

    def CalcHightLowPrice_None(self):
        pass

    # delegate void PROC_CalcHightLowPrice();
    fPROC_CalcHightLowPrice = None
    """PROC_CalcHightLowPrice"""

# endregion

# region 整體市場
    HasWholeMarketData: bool  # WholeTotAmt.Length > 0

    WholeTotAmt: str    #fIDX[34]
    """整體市場成交總額"""

    def Get_WholeTotAmt(self) -> int:
        if (self.HasWholeMarketData):
            return self.TransToInt(self.fIDX[34])

    def Get_WholeTotAmt(self) -> decimal:
        if (self.HasWholeMarketData):
            return self.TransToDecimal(self.fIDX[34])
        else:
            return 0

    WholeTotQty: str    #fIDX[35]
    """整體市場成交數量"""

    def Get_WholeTotQty(self) -> int:
        if (self.HasWholeMarketData):
            return self.TransToInt(self.fIDX[35])
        else:
            return 0
    WholeDealCount: str #fIDX[36]
    """整體市場成交筆數"""

    def Get_WholeDealCount(self) -> int:
        if self.HasWholeMarketData:
            return self.TransToInt(self.fIDX[36])
        else:
            return 0

    SumBuyOrderCount: str   #fIDX[37]
    """整體市場委託買進筆數"""

    def Get_SumBuyOrderCount(self) -> int:
        if self.HasWholeMarketData:
            return self.TransToInt(self.fIDX[37])
        else:
            return 0
    SumSellOrderCount: str  #fIDX[38]
    """整體市場委託賣出筆數"""

    def Get_SumSellOrderCount(self) -> int:
        if self.HasWholeMarketData:
            return self.TransToInt(self.fIDX[38])
        else:
            return 0
    SumBuyOrderQty: str #fIDX[39]
    """整體市場委託買進數量"""

    def Get_SumBuyOrderQty(self) -> int:
        if self.HasWholeMarketData:
            return self.TransToInt(self.fIDX[39])
        else:
            return 0
    SumSellOrderQty: str    #fIDX[40]
    """整體市場委託賣出數量"""

    def Get_SumSellOrderQty(self) -> int:
        if self.HasWholeMarketData:
            return self.TransToInt(self.fIDX[40])
        else:
            return 0
# endregion

# region Tool
    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0
# endregion

    def __init__(self, aCalcHightLowPrice: bool) -> None:
        """aCalcHightLowPrice:是否計算最高低價"""
        # 計算最高低價
        self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice_None
        if (aCalcHightLowPrice):
            self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice
class TStkQuoteData:

    BAS: TStkQtBase = None
    HL: TStkQtHL = None
    QtTX: TStkQtTX = None
    Qt5Q: TStkQt5Q = None
    QtIDX: TStkQtIDX = None

    def __init__(self, enukind: TStkProdKind, parSol: str, aCalcHightLowPrice: bool) -> None:
        """aCalcHightLowPrice:是否需要計算最高最低價"""
        self.SolIce = parSol
        self.ProdKind: TStkProdKind = enukind
        self._lock = Lock()
        self.UpdateBAS = True
        self.UpdateHLTX = False
        if enukind == TStkProdKind.pkNormal:  # 一般證券
            self.BAS = TStkQtBase()
            self.HL = TStkQtHL()
            self.QtTX = TStkQtTX(aCalcHightLowPrice)
            self.Qt5Q = TStkQt5Q()
        elif enukind == TStkProdKind.pkIndex:  # 指數
            self.BAS = TStkQtBase()
            self.HL = TStkQtHL()
            self.QtIDX = TStkQtIDX(aCalcHightLowPrice)
       
    def SetDataInit(self):
        """"此Function在回補資料回來後,才會執行"""
        if self.ProdKind == TStkProdKind.pkNormal:  # 一般證券
            # 最高低價
            self.QtTX.HighPrice = self.HL.Get_HighPrice()
            self.QtTX.LowPrice = self.HL.Get_LowPrice()
            #五檔序號(給成交行情做判斷用, 若成交行情帶五檔的序號, 比來自HL回補的5檔序號, 還要小, 表示很久沒有成交行情, 但五檔一直在變動, 則不可使用成交行情裡的五檔資料)
            self.QtTX.HL_Sn_5Q = self.HL.Get_Sn_5Q()
            #交易單位
            self.QtTX.BAS_TradingUnit = self.BAS.Get_TradingUnit()
            #市場成交總額
            self.QtTX.HL_TotAmt = self.HL.Get_TotAmt2Int()
        elif self.ProdKind == TStkProdKind.pkIndex:  # 指數商品
            # 最高低價
            self.QtIDX.HighPrice = self.HL.Get_HighPrice()
            self.QtIDX.LowPrice = self.HL.Get_LowPrice()      


class TObjStkQuoteMap(UserDict):
    """ConcurrentDictionary<string, TStkQuoteData>
        Key=原為SolIce, 回補完後成則變為TX與5Q的TOPIC"""
    # MapQtProc:Dict
    """各商品拆解行情proc(EX:2330的TX與5Q, 行情拆解,是不同Proc)
        Dictionary<string, PROC_Handle_StkRTQuote> MapQtProc = new Dictionary<string, PROC_Handle_StkRTQuote>();"""

    # def __init__(self):
    #     self.MapQtProc:Dict = None
    #預設行情解析proc
    DefProc_TX:callable=None
    DefProc_5Q:callable=None
    DefProc_Idx:callable=None
    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        self.MapQtProc = {}
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddRcvData(self, enu: TStkProdKind, aSolIce: str, aData: str, aCalcHightLowPrice: bool):
        """是否需要計算最高最低價
        out True,False
        out TStkQuoteData tmpQt
        out string aErrMsg
        """
        aErrMsg = ""
        tmpQt: TStkQuoteData = None
        try:
            # map = JsonConvert.DeserializeObject<Dictionary<string, List<string>>>(aData);            
            # region 檢核
            map = json.loads(aData)
            if "status" in map and len(map["status"]) > 0:
                if map["status"][0] == "error":
                    aErrMsg = f"[證][AddRcvData](aSolIce={aSolIce}, aData={aData})行情回補資料有誤!"
                    return False, tmpQt, aErrMsg
            if "BAS" in map and len(map["BAS"]) == 0:
                aErrMsg = f"[證][AddRcvData](aSolIce={aSolIce}, aData={aData})沒有BAS資料!"
                return False, tmpQt, aErrMsg
            if "HL" in map and len(map["HL"]) == 0:
                aErrMsg = f"[證][AddRcvData](aSolIce={aSolIce}, aData={aData})沒有HL資料!"
                return False, tmpQt, aErrMsg
            # endregion

            if self.data.get(aSolIce) is None:
                tmp = TStkQuoteData(enu, aSolIce, aCalcHightLowPrice)
                tmp.BAS.Handle_BAS(map["BAS"][0])
                tmp.HL.Handle_HL(map["HL"][0])
                tmp.SetDataInit()
                tmpQt = tmp
                self[aSolIce] = tmp
                return True, tmpQt, ""
            else:
                tmp: TStkQuoteData = self[aSolIce]
                with tmp._lock:
                    tmp.BAS.Handle_BAS(map["BAS"][0])
                    tmp.HL.Handle_HL(map["HL"][0])
                    tmp.SetDataInit()
                    tmpQt = tmp
                return True, tmpQt, ""
        except Exception as ex:
            aErrMsg = f"[證][AddRcvData](aSolIce={aSolIce}, aData={aData}){ex}"
            return False, tmpQt, aErrMsg

    def AddDataBySolIce(self, aIsCat:bool, aSolIce:str, mapResData, aCalcHightLowPrice, topic:str=""):
        """ aSolIce: EX:2330
            aTopicTX: Quote/TWS/S/TSE/2330/TX
            aProcTX: 拆解成交行情的function
            aTopic5Q: Quote/TWS/S/TSE/2330/5Q
            aProc5Q: 拆解5檔行情的function
            return 1.bool
                2. out TObjStkQuoteMap aQtMap
                3. out string aErrMsg"""
        try:
            aErrMsg:str = ""
            aQtMap:TObjStkQuoteMap = TObjStkQuoteMap()
            #region 拆解基本資料
            if mapResData.get("BAS") is not None:
                for strBAS in mapResData["BAS"]:                
                    tmpBAS:TStkQtBase = TStkQtBase(topic)
                    tmpBAS.Handle_BAS(strBAS)                
                    if aQtMap.data.get(tmpBAS.StkNo) is None:
                        tmpQt:TStkQuoteData = TStkQuoteData(TStkProdKind.pkNormal, tmpBAS.StkNo, aCalcHightLowPrice)
                        tmpQt.BAS = tmpBAS  
                        tmpQt.UpdateHLTX = False
                        #交易單位
                        tmpQt.QtTX.BAS_TradingUnit = tmpBAS.Get_TradingUnit()                  
                        aQtMap[tmpBAS.StkNo]= tmpQt     
                    if topic != "":
                        sTopicTX:str = tmpBAS.TopicTX #成交
                        sTopic5Q:str = tmpBAS.Topic5Q #五檔
                        self[sTopicTX] = tmpQt
                        self[sTopic5Q] = tmpQt                        
                        if self.MapQtProc.get(sTopicTX) is None:
                            self.MapQtProc[sTopicTX] = self.DefProc_TX
                        if self.MapQtProc.get(sTopic5Q) is None:
                            self.MapQtProc[sTopic5Q] = self.DefProc_5Q
            #endregion 拆解基本資料
            #region 拆解HL                        
            if mapResData.get("HL") is not None:
                for strHL in mapResData["HL"]:            
                    tmpHL = TStkQtHL()                    
                    tmpHL.Handle_HL(strHL)
                    if aQtMap.data.get(tmpHL.Symbol): #商品基本資料
                        tmpQt = aQtMap[tmpHL.Symbol]
                        tmpQt.UpdateHLTX = True
                        tmpQt.HL = tmpHL #商品最新行情(含5檔)
                        tmpQt.SetDataInit()
                    if topic == "":
                        sTopicTX:str = tmpHL.TopicTX #成交
                        sTopic5Q:str = tmpHL.Topic5Q #五檔
                        self[sTopicTX] = tmpQt
                        self[sTopic5Q] = tmpQt
                        if self.MapQtProc.get(sTopicTX) is None:
                            self.MapQtProc[sTopicTX] = self.DefProc_TX
                        if self.MapQtProc.get(sTopic5Q) is None:
                            self.MapQtProc[sTopic5Q] = self.DefProc_5Q
            #endregion 拆解HL
            return len(aQtMap) > 0, aQtMap, aErrMsg
        except Exception as ex:
            aErrMsg = f"[證][AddDataBySolIce](aIsCat={aIsCat}, aSolIce={aSolIce}){ex}"
        return False, aQtMap, aErrMsg
  
    def AddIdxDataBySolIce(self, aIsCat:bool, aSolIce:str, mapResData, aCalcHightLowPrice:bool ):
        """PROC_Handle_StkRTQuote aProcIDX
            aSolIce: EX:IX0001
            aTopicIDX: Quote/TWS/S/TSE/IX0001/TX
            aProcIDX: 拆解指數行情的function
            return 1.bool
            2.out TMapStkQuoteData aQtMap
            3.out string aErrMsg"""
        try:
            aErrMsg = ""
            aQtMap:TObjStkQuoteMap = TObjStkQuoteMap()
            #region 拆解基本資料            
            for str in mapResData["BAS"]:            
                tmpBAS:TStkQtBase = TStkQtBase()
                tmpBAS.Handle_BAS(str)
                if aQtMap.data.get(tmpBAS.StkNo) is None:
                    tmpQt:TStkQuoteData = TStkQuoteData(TStkProdKind.pkIndex, tmpBAS.StkNo, aCalcHightLowPrice)
                    tmpQt.BAS = tmpBAS
                    aQtMap[tmpBAS.StkNo]= tmpQt
            #endregion 拆解基本資料
            #region 拆解HL
            for str in mapResData["HL"]:               
                tmpHL = TStkQtHL()
                tmpHL.Handle_HL(str)
                if aQtMap.data.get(tmpHL.Symbol): #商品基本資料
                    tmpQt = aQtMap[tmpHL.Symbol]
                    tmpQt.HL = tmpHL #商品最新行情(含5檔)
                    tmpQt.SetDataInit()

                    sTopicTX = tmpQt.HL.TopicTX #成交                    

                    self[sTopicTX] = tmpQt
                    
                    if self.MapQtProc.get(sTopicTX) is None:
                        self.MapQtProc[sTopicTX] = self.DefProc_Idx
            #endregion 拆解HL
            return len(aQtMap) > 0, aQtMap, aErrMsg
        except Exception as ex:
            aErrMsg = f"[證][AddIdxDataBySolIce](aIsCat={aIsCat}, aSolIce={aSolIce}){ex}"
        return False, aQtMap, aErrMsg
    

    def GetItem_BySolIce(self, aSolIce: str):
        """
            return  1:bool 
                    2:out List<string> aTopicList
                    3:out string aErrMsg        
        """
        try:
            retlist = []
            for key, val in self.items():
                Stkdat: TStkQuoteData
                Stkdat = val
                if Stkdat.SolIce == aSolIce:
                    retlist.append(key)
            if retlist is None or len(retlist) == 0:
                return False, [], f"[證][GetItem_BySolIce](aSolIce={aSolIce})商品已不存存!"
            else:
                return True, retlist, ""
        except Exception as ex:
            return False, [], f"[證][GetItem_BySolIce](aSolIce={aSolIce}){ex}"
    def GetItem_ByCategory(self, aCat:str):
        """return  1:bool 
                    2:out List<string> aTopicList
                    3:out string aErrMsg       """
        # aErrMsg = string.Empty;        
        try:
            retlist = []            
            for key, val in self.items():
                Stkdat: TStkQuoteData = val
                arr = key.split('/')                
                if arr[2] == aCat:# if Stkdat.HL.StkKind == aCat:
                    retlist.append(key)
              
            if retlist is None or len(retlist) == 0:
                return False, [], f"[證][GetItem_ByCategory](aCat={aCat})商品已不存存!"
            else:
                return True, retlist, ""        
          
        except Exception as ex:
            return False, [], f"[證][GetItem_ByCategory](aCat={aCat}){ex}"
        
        

class TQryStkProdMap(UserDict):
    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)
    """Dictionary<string, TQryStkProdRec>"""

    def __setitem__(self, key, value):
        super().__setitem__(key, value)


class TQryStkProdRec():
    tmpBase: TStkQtBase = None
    tmpHL: TStkQtHL = None

    def SetDataInit(self):
        pass

# endregion STK
# region FUT


class TFutQtBase:

    fHasBAS: bool = False
    TopicTX:str = ""
    Topic5Q:str = ""
    TopicHL:str = ""
    Topic5QTOT:str = ""
    TopicBAS:str = ""

    fBAS = []
    # region Data
    DECIMAL_LOCATOR_Org: int = 0
    """價格欄位小數位數"""
    DECIMAL_LOCATOR_Dgt: decimal = 1
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""
    OrdProdID: str  # fBAS[0]
    """商品委託代碼(EX:CDFC3)"""
    RefPriceOrg: str  # fBAS[4]
    """參考價"""

    def Get_RefPrice2Str(self) -> str:
        return self.TransPrice2Str(self.fBAS[4])

    def Get_RefPrice2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fBAS[4])

    LimitPrice_UpOrg: str  # fBAS[5]
    """漲停價"""

    def Get_LimitPrice_Up2Str(self) -> str:
        return self.TransPrice2Str(self.fBAS[5])

    def Get_LimitPrice_Up2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fBAS[5])

    LimitPrice_DownOrg: str  # fBAS[6]
    """跌停價"""
    
    ProdKind:str #fBAS[7]
    """契約種類"""

    def Get_LimitPrice_Down2Str(self) -> str:
        return self.TransPrice2Str(self.fBAS[6])

    def Get_LimitPrice_Down2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fBAS[6])

    IdxDgtOrg: str  # fBAS[8]
    """指數小數位數"""

    def Get_IdxDgtOrg(self) -> int:
        return self.TransToInt(self.fBAS[8])
   
    StrikePriceDecimalLocator:str #fBAS[9]
    "選擇權商品代號之履約價小數位數"
     
    BeginDate:str #fBAS[10]
    "上市日期"        
    EndDate:str #fBAS[11]
    "下市日期"        
    FlowGroup:str #fBAS[12]
    "流程群組"        
    DeliveryDate:str #fBAS[13]
    "最後結算日"        
    DynamicBanding:str #fBAS[14]
    "適用動態價格穩定"

    ProdID: str  # fBAS[15]
    """契約代號 (EX:CDF)"""
    FutName: str  # fBAS[16]
    """期貨契約中文(EX:小型環球晶)"""
    StkNo: str  # fBAS[17]
    """現股代碼(EX:2330)"""
    ValuePerUnitOrg: str  # fBAS[18]
    """契約乘數"""

    def Get_ValuePerUnit(self) -> decimal:
        return self.TransToDecimal(self.fBAS[18])    
    
    StatusCode:str # fBAS[19]
    "狀態碼"
    Currency:str # fBAS[20]
    "幣別"
    AcceptQuoteFlag:str # fBAS[21]
    "是否可報價"
    BlockTradeFlag:str # fBAS[22]
    "是否可鉅額交易"
    ExpiryType:str # fBAS[23]
    "到期別"
    UnderlyingType:str # fBAS[24]
    "現貨類別"
    MarketCloseGroup:str # fBAS[25]
    "商品收盤時間群組"
    EndSession:str # fBAS[26]

    MktType: str  # fBAS[27]
    """早午盤識別(早盤:0, 午盤:1)"""
    SettleMth: str
    """交割月"""
    CallPutType: str #fBAS[28]
    """C/P"""
    StrikeP: str    #fBAS[28]
    """履約價"""
    
    PreTotalMatchQty:str # fBAS[29]
    """昨日成交總量"""    
    PreOpenInterest:str # fBAS[30]
    """昨日未平倉合約數"""    
    PreTodayRefPrice:str # fBAS[31]
    """昨日參考價"""
    def Get_PreTodayRefPrice2Str(self):
        return self.TransPrice2Dec(self.fBAS[31])
    def Get_PreTodayRefPrice2Dec(self):
        return self.TransPrice2Dec(self.fBAS[31])
    
    PreClosePrice:str # fBAS[32]
    """昨日收盤價"""
    def Get_PreClosePrice2Str(self):
        return self.TransPrice2Str(self.fBAS[32])
    def Get_PreClosePrice2Dec(self):
        return self.TransPrice2Dec(self.fBAS[32])
    
    PreSettlePrice:str # fBAS[33]
    """昨日結算價"""
    def Get_PreSettlePrice2Str(self):
        return self.TransPrice2Str(self.fBAS[33])
    def Get_PreSettlePrice2Dec(self):
        return self.TransPrice2Dec(self.fBAS[33])
        
    TickSizeInfo: str   #fBAS[36]
    """跳動點資訊"""
    # endregion

    def Handle_BAS(self, aData: str):
        self.fBAS = aData.split("|")
        self.fHasBAS = len(self.fBAS) > 0
        self.OrdProdID = self.fBAS[0]
        self.RefPriceOrg = self.fBAS[4]
        self.LimitPrice_UpOrg = self.fBAS[5]
        self.LimitPrice_DownOrg = self.fBAS[6]
        self.ProdKind = self.fBAS[7]
        self.IdxDgtOrg = self.fBAS[8]
        self.StrikePriceDecimalLocator = self.fBAS[9]
        self.BeginDate = self.fBAS[10]
        self.EndDate = self.fBAS[11]
        self.FlowGroup = self.fBAS[12]
        self.DeliveryDate = self.fBAS[13]
        self.DynamicBanding = self.fBAS[14]
        self.ProdID = self.fBAS[15]
        self.FutName = self.fBAS[16]
        self.StkNo = self.fBAS[17]
        self.ValuePerUnitOrg = self.fBAS[18]
        self.StatusCode = self.fBAS[19]
        self.Currency= self.fBAS[20]
        self.AcceptQuoteFlag = self.fBAS[21]
        self.BlockTradeFlag = self.fBAS[22]
        self.ExpiryType = self.fBAS[23]
        self.UnderlyingType = self.fBAS[24]
        self.MarketCloseGroup = self.fBAS[25]
        self.EndSession = self.fBAS[26]
        self.MktType = self.fBAS[27]
        if len(self.fBAS[28]) == 0 or self.fBAS[28] is None or self.fBAS[28].isspace():
            self.SettleMth = ""
        else:
            self.SettleMth = self.fBAS[28].split(".")[1]

        self.CallPutType = ""
        if len(self.fBAS[28]) == 0 or self.fBAS[28] is None or self.fBAS[28].isspace():  # C/P
            self.CallPutType = ""
        if "C" in self.fBAS[28]:
            self.CallPutType = "C"
        if "P" in self.fBAS[28]:
            self.CallPutType = "P"

        self.StrikeP = ""
        if len(self.fBAS[28]) == 0 or self.fBAS[28] is None or self.fBAS[28].isspace():  # 履約價
            self.StrikeP = ""
        if "C" in self.fBAS[28]:
            idx = self.fBAS[28].find(".C.")            
            self.StrikeP = self.fBAS[28][idx + 3:].strip()
        if "P" in self.fBAS[28]:
            idx = self.fBAS[28].find(".P.") 
            self.StrikeP = self.fBAS[28][idx + 3:].strip()

        self.PreTotalMatchQty = self.fBAS[29]
        self.PreOpenInterest = self.fBAS[30]
        self.PreTodayRefPrice = self.fBAS[31]
        self.PreClosePrice = self.fBAS[32]
        self.PreSettlePrice = self.fBAS[33]

        self.TickSizeInfo = self.fBAS[36]
        if self.fHasBAS:
            # 價格欄位小數位數
            self.DECIMAL_LOCATOR_Org = self.Get_IdxDgtOrg()
            if self.DECIMAL_LOCATOR_Org == 0:
                self.DECIMAL_LOCATOR_Dgt = 1  # 若DECIMAL_LOCATOR_Org=2, 則此值為0.001
            else:
                self.DECIMAL_LOCATOR_Dgt = 1 / \
                    Decimal("1".ljust(self.DECIMAL_LOCATOR_Org + 1, '0'))
        
        if self.TopicTX != "":
            arr = self.TopicTX.split("/")
            arr[len(arr)-2] = self.OrdProdID
            self.TopicTX = "/".join(arr)#成交
            arr = self.Topic5Q.split("/")
            arr[len(arr)-2] = self.OrdProdID
            self.Topic5Q = "/".join(arr)#五檔
            arr = self.TopicHL.split("/")
            arr[len(arr)-2] = self.OrdProdID            
            self.TopicHL = "/".join(arr)#最高低價
            arr = self.Topic5QTOT.split("/")
            arr[len(arr)-2] = self.OrdProdID            
            self.Topic5QTOT = "/".join(arr)#累計買賣委託筆數、累計買賣委託筆數
            arr = self.TopicBAS.split("/")
            arr[len(arr)-2] = self.OrdProdID            
            self.TopicBAS = "/".join(arr)#基本資料         

    def Handle_BAS_ChangeMktType(self, aData: str) -> bool:
        """處理變盤 return: True=變盤"""
        try:
            if self.fBAS is not None and len(self.fBAS) > 28:
                ary = aData.split("|")
                if len(ary) > 28:
                    if ary[27] != self.fBAS[27]:  # //ary[7]=早盤 : 0 午盤:  1
                        self.Handle_BAS(aData)
                        return True
        except Exception as ex:
            return False

    # region Tool
    def TransPrice2Dec(self, aOrgStr: str) -> decimal:
        try:
            aVal = Decimal(aOrgStr)
            aVal = aVal * self.DECIMAL_LOCATOR_Dgt
            return aVal
        except Exception as ex:
            print(f"Not a Decimal{ex}")
            return 0

    def TransPrice2Str(self, aOrgStr: str) -> str:
        if self.DECIMAL_LOCATOR_Dgt == 1:
            return aOrgStr
        if aOrgStr == "0":
            return ""
        if len(aOrgStr) < self.DECIMAL_LOCATOR_Org:
            return aOrgStr
        if not aOrgStr or aOrgStr.isspace():
            return ""
        try:
            ln = len(aOrgStr)
            return aOrgStr[:ln-self.DECIMAL_LOCATOR_Org] + '.' + aOrgStr[ln-self.DECIMAL_LOCATOR_Org:]
        except Exception as ex:
            return ""

    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            # print(f"Not a Int{ex}")
            pass
        return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            print(f"Not a Decimal{ex}")
        return 0
    # endregion

    def __init__(self,topic:str = "") -> None:
        if topic != "":
            arr = topic.split("/")
            arr[len(arr)-1] = "HL"
            self.TopicHL = "/".join(arr)#最高低價
            arr[len(arr)-1] = "TX"
            self.TopicTX = "/".join(arr)#成交
            arr[len(arr)-1] = "5Q"
            self.Topic5Q = "/".join(arr)#五檔
            arr[len(arr)-1] = "5QTOT"
            self.Topic5QTOT = "/".join(arr)#累計買賣委託筆數、累計買賣委託筆數
            arr[len(arr)-1] = "BAS"
            self.TopicBAS = "/".join(arr)#基本資料(I010、I011) for 換盤資訊

    def __str__(self) -> str:
        return f"""OrdProdID:{self.OrdProdID} RefPriceOrg:{self.RefPriceOrg} LimitPrice_UpOrg:{self.LimitPrice_UpOrg} LimitPrice_DownOrg:{self.LimitPrice_DownOrg}"""+\
                """IdxDgtOrg:{self.IdxDgtOrg} ProdID:{self.ProdID} FutName:{self.FutName} StkNo:{self.StkNo} ValuePerUnitOrg:{self.ValuePerUnitOrg}"""+\
                """MktType:{self.MktType} SettleMth:{self.SettleMth} CallPutType:{self.CallPutType} StrikeP:{self.StrikeP} TickSizeInfo:{self.TickSizeInfo} """
class TFutQtHL:

    HasHL: bool = False
    fHL = []
    TopicTX = "" #成交
    Topic5Q = "" #五檔
    Topic5QTOT = "" #累計買賣委託筆數、累計買賣委託筆數
    TopicBAS = "" #基本資料(I010、I011) for 換盤資訊
    # region Data
    DECIMAL_LOCATOR_Org: int = 0
    """價格欄位小數位數"""
    DECIMAL_LOCATOR_Dgt: decimal = 1
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""
    Exchange:str = ""#fHL[0]
    "市場別(TWS/TWF)"
    Market: str = ""# fHL[1]
    """商品別(FUT/OPT)"""
    Symbol: str = ""# fHL[3]
    """委託商品代碼(TXFA2)"""
    TryMark_Deal:str = ""#fHL[4]
    """成交試撮註記(試撮=1, 非試撮=0"""
    TryMark: str = ""# fHL[5]
    """試撮註記(試撮=1, 非試撮=0)"""
    DealTime: str = ""# fHL[6]
    """撮合時間(成交)(EX:173547.32700)"""
    DealSn: str = ""# fHL[7]
    """成交序號"""

    def Get_DealSn(self) -> int:
        return self.TransToInt(self.fHL[7])
    Sn_5Q: str = ""# fHL[8]
    """五檔序號"""

    def Get_Sn_5Q(self) -> int:
        return self.TransToInt(self.fHL[8])
    DealPriceOrg: str = ""# fHL[9]
    """成交價"""
    def Get_DealPrice2Str(self) -> str:
        return self.TransPrice2Str(self.fHL[9])
    def Get_DealPrice2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fHL[9])

    fDealPrice: decimal = 0
    """成交價"""

    def DealPrice(self) -> decimal:
        return self.fDealPrice
    DealQty: str = ""# fHL[10]
    """成交單量"""

    def Get_DealQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fHL[10])

    def Get_DealQty2Int(self) -> int:
        return self.TransToInt(self.fHL[10])
    HighPriceOrg: str = ""# fHL[11]
    """當日最高價"""

    def Get_HighPrice2Str(self) -> str:
        return self.TransPrice2Str(self.fHL[11])

    def Get_HighPrice2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fHL[11])
    LowPriceOrg: str = ""# fHL[12]
    """當日最低價"""

    def Get_LowPrice2Str(self) -> str:
        return self.TransPrice2Str(self.fHL[12])

    def Get_LowPrice2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fHL[12])
    TotAmt:str = ""#fHL[13]
    """成交總額"""
    TotQty: str = ""# fHL[14]
    """成交總量"""

    def Get_TotQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fHL[14])

    def Get_TotQty2Int(self) -> int:
        return self.TransToInt(self.fHL[14])    
    
    FirstDerivedBuyPriceOrg:str # fHL[35]
    "衍生委託單第一檔買進價格"
    def Get_FirstDerivedBuyPrice(self):
        return self.TransPrice2Str(self.fHL[35])
    FirstDerivedBuyQty:str #fHL[36]
    "衍生委託單第一檔買進價格數量"    
    FirstDerivedSellPriceOrg:str# fHL[37]
    "衍生委託單第一檔賣出價格數量"
    def Get_FirstDerivedSellPrice(self):
        return self.TransPrice2Str(self.fHL[37])        
    FirstDerivedSellQty:str # fHL[38]
    "衍生委託單第一檔賣出價格數量"

    OpenPriceOrg: str = ""# fHL[39]
    """開盤價"""
    def Get_OpenPrice2Str(self):
        return self.TransPrice2Str(self.fHL[39])
    def Get_OpenPrice2Dec(self):
        return self.TransPrice2Dec(self.fHL[39])

    def Get_OpenPrice2Str(self) -> str:
        return self.TransPrice2Str(self.fHL[39])

    def Get_OpenPrice2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fHL[39])    
    
    TryMark_5Q:str = ""# fHL[40]
    "五檔試撮註記(試撮=1, 非試撮=0)"    
    ClosePrice:str = ""#fHL[41]
    "收盤價"
    def Get_ClosePrice(self):
        return self.TransPrice2Str(self.fHL[41])    
    SettlePrice:str = ""# fHL[42]
    "結算價<"
    def Get_SettlePrice(self):
        return self.TransPrice2Str(self.fHL[42])    
    OpenInterest:str = ""# fHL[43]
    "未平倉合約數"

    # endregion
    # region 五檔買價量
    fAryB5Q_P = [15, 17, 19, 21, 23]
    """買五檔價在字串中的位置"""
    fAryB5Q_Q = [16, 18, 20, 22, 24]
    """買五檔價在字串中的位置"""
    fB5QCount: int = 5
    """買5檔的檔數"""

    def B5Q_POrg(self, aN: int) -> str:
        """買5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fB5QCount:
            return ""
        else:
            return self.fHL[self.fAryB5Q_P[aN - 1]]

    def Get_B5Q_P2Dec(self, aN: int) -> decimal:
        """取得買5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fB5QCount:
            return 0
        else:
            return self.TransPrice2Dec(self.fHL[self.fAryB5Q_P[aN - 1]])

    def Get_B5Q_P2Str(self, aN: int) -> str:
        """取得買5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fB5QCount:
            return ""
        else:
            return self.TransPrice2Str(self.fHL[self.fAryB5Q_P[aN - 1]])

    def B5Q_QOrg(self, aN: int) -> str:
        """買5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fB5QCount:
            return ""
        else:
            return self.fHL[self.fAryB5Q_Q[aN - 1]]

    def Get_B5Q_Q(self, aN: int) -> int:
        """取得買5檔量 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fB5QCount:
            return 0
        else:
            return self.TransToInt(self.fHL[self.fAryB5Q_Q[aN - 1]])

    # endregion
    # region 五檔賣價量
    fAryS5Q_P = [25, 27, 29, 31, 33]
    """買五檔價在字串中的位置"""
    fAryS5Q_Q = [26, 28, 30, 32, 34]
    """買五檔價在字串中的位置"""
    fS5QCount: int = 5
    """賣5檔的檔數"""

    def S5Q_POrg(self, aN: int) -> str:
        """賣5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fS5QCount:
            return ""
        else:
            return self.fHL[self.fAryS5Q_P[aN - 1]]

    def Get_S5Q_P2Dec(self, aN: int) -> decimal:
        """取得賣5檔-價格 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fS5QCount:
            return 0
        else:
            return self.TransPrice2Dec(self.fHL[self.fAryS5Q_P[aN - 1]])

    def Get_S5Q_P2Str(self, aN: int) -> str:
        """取得賣5檔價格 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fS5QCount:
            return ""
        else:
            return self.TransPrice2Str(self.fHL[self.fAryS5Q_P[aN - 1]])

    def S5Q_QOrg(self, aN: int) -> str:
        """賣5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fS5QCount:
            return ""
        else:
            return self.fHL[self.fAryS5Q_Q[aN - 1]]

    def Get_S5Q_Q(self, aN: int) -> int:
        """取得賣5檔-量 aN:5檔中的第幾檔(1~5)"""
        if aN > self.fS5QCount:
            return 0
        else:
            return self.TransToInt(self.fHL[self.fAryS5Q_Q[aN - 1]])
    # endregion

    def Handle_HL(self, aData: str):
        self.fHL = aData.split('|')
        self.HasHL = len(self.fHL) > 0
        self.Exchange = self.fHL[0]
        self.Market = self.fHL[1]
        self.Symbol = self.fHL[3]
        self.TryMark_Deal = self.fHL[4]
        self.TryMark = self.fHL[5]
        self.DealTime = self.fHL[6]
        self.DealSn = self.fHL[7]
        self.Sn_5Q = self.fHL[8]
        self.DealPriceOrg = self.fHL[9]
        self.DealQty = self.fHL[10]
        self.HighPriceOrg = self.fHL[11]
        self.LowPriceOrg = self.fHL[12]
        self.TotAmt = self.fHL[13]
        self.TotQty = self.fHL[14]
        self.FirstDerivedBuyPriceOrg = self.fHL[35]
        self.FirstDerivedBuyQty = self.fHL[36]
        self.FirstDerivedSellPriceOrg = self.fHL[37]
        self.FirstDerivedSellQty = self.fHL[38]
        self.OpenPriceOrg = self.fHL[39]
        self.TryMark_5Q = self.fHL[40]
        self.ClosePrice = self.fHL[41]
        self.SettlePrice = self.fHL[42]
        self.OpenInterest = self.fHL[43]
        if self.HasHL:
            self.TopicTX = f"Quote/TWF/{self.Market}/{self.Symbol}/TX" #成交
            self.Topic5Q = f"Quote/TWF/{self.Market}/{self.Symbol}/5Q" #五檔
            self.Topic5QTOT = f"Quote/TWF/{self.Market}/{self.Symbol}/5QTOT" #累計買賣委託筆數、累計買賣委託筆數
            self.TopicBAS = f"Quote/TWF/{self.Market}/{self.Symbol}/BAS" #基本資料(I010、I011) for 換盤資訊

        self.fDealPrice = self.TransPrice2Dec(self.DealPriceOrg)  # 成交價轉換
    # region Tool

    def TransPrice2Dec(self, aOrgStr: str) -> decimal:
        try:
            aVal = Decimal(aOrgStr)
            aVal = aVal * self.DECIMAL_LOCATOR_Dgt
            return aVal
        except Exception as ex:
            return 0

    def TransPrice2Str(self, aOrgStr: str) -> str:
        if self.DECIMAL_LOCATOR_Dgt == 1:
            return aOrgStr
        if aOrgStr == "0":
            return ""
        if len(aOrgStr) < self.DECIMAL_LOCATOR_Org:
            return aOrgStr
        if not aOrgStr or aOrgStr.isspace():
            return ""
        try:
            ln = len(aOrgStr)
            return aOrgStr[:ln-self.DECIMAL_LOCATOR_Org] + '.' + aOrgStr[ln-self.DECIMAL_LOCATOR_Org:]
        except Exception as ex:
            return ""

    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            # print(f"Not a Int{ex}")
            pass
        return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            print(f"Not a Decimal{ex}")
        return 0
    # endregion Tool

    def __init__(self) -> None:
        pass

    def __str__(self) -> str:
        return f"""Market:{self.Market} Symbol:{self.Symbol} TryMark:{self.TryMark} DealTime:{self.DealTime} DealSn:{self.DealSn}"""+\
                """Sn_5Q:{self.Sn_5Q} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} HighPriceOrg:{self.HighPriceOrg} LowPriceOrg:{self.LowPriceOrg}"""+\
                """TotQty:{self.TotQty} OpenPriceOrg:{self.OpenPriceOrg}"""
class TFutQtTX:

    DECIMAL_LOCATOR_Org: int = 0
    """價格欄位小數位數"""
    DECIMAL_LOCATOR_Dgt: decimal = 1
    """價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"""
    fTX = []
    # region Data
    SystemTime: str #fTX[1]
    """系統時間(Epoch & Unix Timestamp(us))"""
    DataTime: str  # fTX[2]
    """資料時間(交易所給的)(EX:173547.32700)"""
    DealSn: str  # fTX[3]
    """成交序號"""
    TryMark: str  # { get { return (fTX != null) ? fTX[4] : "1"; } }
    """試撮註記(試撮=1, 非試撮=0)"""
    DealTime: str  # fTX[5]
    """撮合時間(成交)(EX:173547.32700)"""    
    DealShowMark:str # fTX[6]
    """成交資料揭示項目註記(*結算價此欄為空)"""
    def Get_SystemTime(self)->int:
        return self.TransToInt(self.fTX[1])

    def Get_DealSn(self) -> int:
        return self.TransToInt(self.fTX[3])
    TotQty: str  # fTX[7]
    """成交總量"""

    def Get_TotQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fTX[7])

    def Get_TotQty2Int(self) -> int:
        return self.TransToInt(self.fTX[7])
    SumBuyDealCount: str  # fTX[8]
    """累計買進成交筆數"""

    def Get_SumBuyDealCount(self) -> int:
        return self.TransToInt(self.fTX[8])
    SumSellDealCount: str  # fTX[9]
    """累計賣出成交筆數"""

    def Get_SumSellDealCount(self) -> int:
        return self.TransToInt(self.fTX[9])
    DealCount: str  # fTX[11]
    fDealCount:int
    """成交價量檔數"""

    def Get_DealCount(self) -> int:
        return self.TransToInt(self.fTX[11])
    DealPriceOrg: str  # fTX[12]
    """成交價"""

    def Get_DealPrice2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fTX[12])

    def Get_DealPrice2Str(self) -> str:
        return self.TransPrice2Str(self.fTX[12])

    def Get_DealPrice2IdxVal(self, aDealNum:int)->decimal:
        return self.TransPrice2Dec(self.fTX[12 + (aDealNum * 2)])

    DealQty: str  # fTX[13]
    fDealQty:int
    """成交單量"""

    def Get_DealQty2Dec(self) -> decimal:
        return self.TransToDecimal(self.fTX[13])

    def Get_DealQty2Int(self) -> int:
        return self.TransToInt(self.fTX[13])
    def Get_DealQty2IdxVal(self, aDealNum:int) -> int:
        return self.TransToInt(self.fTX[13 + (aDealNum * 2)])
    # endregion

    # region 計算最高低價
    fDealPrice: decimal = 0
    "成交價"
    HighPrice: decimal = 0
    "當日最高價"
    LowPrice: decimal = 0
    "當日最低價"

    def CalcHightLowPrice(self):
        "計算最高低價"
        try:
            self.fDealCount = self.Get_DealCount()
            for fDealIdx in range(self.fDealCount):
                self.fDealQty = self.Get_DealQty2IdxVal(fDealIdx)
                self.fDealPrice = self.Get_DealPrice2IdxVal(fDealIdx)
                if self.fDealQty > 0 and self.fDealPrice > 0:
                    # self.fDealPrice = self.Get_DealQty2Dec()
                    self.HighPrice = max(self.fDealPrice, self.HighPrice)
                    self.LowPrice = self.fDealPrice if self.LowPrice == 0 else min(
                        self.fDealPrice, self.LowPrice)
        except Exception as ex:
            pass

    def CalcHightLowPrice_None(self):
        pass

    fPROC_CalcHightLowPrice: callable = None
    "PROC_CalcHightLowPrice"
    # endregion

    def SetData(self):
        self.SystemTime = self.fTX[1]
        self.DataTime = self.fTX[2]
        self.DealSn = self.fTX[3]
        self.TryMark = "1" if self.fTX[4] is None else self.fTX[4]
        self.DealTime = self.fTX[5]
        self.DealShowMark = self.fTX[6]
        self.TotQty = self.fTX[7]
        self.SumBuyDealCount = self.fTX[8]
        self.SumSellDealCount = self.fTX[9]
        self.DealCount = self.fTX[11]
        self.DealPriceOrg = self.fTX[12]
        self.DealQty = self.fTX[13]

    def Handle_TXRcv(self, aData: str):
        try:
            iValTX: int = 0
            iValRcv: int = 0
            aryRcv = aData.split('|')

            if aryRcv[4] == TSolQuoteFutSet.TryMark_No:  # 即時
                self.fPROC_HandleData = self.HandleData  # 處理即時

                if self.fTX == None:
                    self.fTX = aryRcv
                    self.SetData()
                else:
                    iValRcv = self.TransToInt(aryRcv[3])
                    iValTX = self.Get_DealSn()
                    if iValRcv > iValTX:  # 若回補的成交序號比較小, 則不更新
                        self.fTX = aryRcv
                        self.SetData()
                self.fPROC_CalcHightLowPrice()  # 計算最高低價
            else:
                self.fPROC_HandleData = self.HandleData_TryMarket
                self.fPROC_HandleData(aData)

        except Exception as ex:
            pass

    def Handle_TX(self, aData: str):
        self.fPROC_HandleData(aData)

    # region 試撮 or 盤中
    def HandleData_TryMarket(self, aData: str):
        "處理試撮:試撮行情"
        if aData.split('|')[4] == TSolQuoteFutSet.TryMark_No:  # 非試撮
            self.fPROC_HandleData = self.HandleData
            self.fPROC_HandleData(aData)
        else:
            self.fTX = aData.split('|')
            self.SetData()

    def HandleData(self, aData: str):
        "處理即時"
        self.fTX = aData.split('|')
        self.SetData()
        self.fPROC_CalcHightLowPrice()  # 計算最高低價

    fPROC_HandleData: callable = None
    "PROC_HandleData"
    # endregion
    # region Tool

    def TransPrice2Dec(self, aOrgStr: str) -> decimal:
        try:
            aVal = Decimal(aOrgStr)
            aVal = aVal * self.DECIMAL_LOCATOR_Dgt
            return aVal
        except Exception as ex:
            return 0

    def TransPrice2Str(self, aOrgStr: str) -> str:
        if self.DECIMAL_LOCATOR_Dgt == 1:
            return aOrgStr
        if aOrgStr == "0":
            return ""
        if len(aOrgStr) < self.DECIMAL_LOCATOR_Org:
            return aOrgStr
        if not aOrgStr or aOrgStr.isspace():
            return ""
        try:
            ln = len(aOrgStr)
            return aOrgStr[:ln-self.DECIMAL_LOCATOR_Org] + '.' + aOrgStr[ln-self.DECIMAL_LOCATOR_Org:]
        except Exception as ex:
            return ""

    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            # print(f"Not a Int{ex}")
            pass
        return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            print(f"Not a Decimal{ex}")
        return 0
    # endregion

    def __init__(self, aCalcHightLowPrice: bool) -> None:
        # 計算最高低價
        self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice_None
        if aCalcHightLowPrice:
            self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice
        # 處理試撮/盤中:試撮行情
        self.fPROC_HandleData = self.HandleData_TryMarket

    def __str__(self):
        return f"""DataTime:{self.DataTime} TryMark:{self.TryMark} DealTime:{self.DealTime} DealSn:{self.DealSn}"""+\
                """TotQty:{self.TotQty} SumBuyDealCount:{self.SumBuyDealCount} SumSellDealCount:{self.SumSellDealCount}"""+\
                """DealCount:{self.DealCount} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} fDealPrice:{self.fDealPrice}"""+\
                """HighPrice:{self.HighPrice} LowPrice:{self.LowPrice} \n"""
class TFutQt5Q:

    DECIMAL_LOCATOR_Org: int = 0
    "價格欄位小數位數"
    DECIMAL_LOCATOR_Dgt: decimal = 1
    "價格欄位小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"
    f5Q = []

    SystemTime:str #f5Q[1]
    """系統時間(Epoch & Unix Timestamp(us))"""
    DataTime: str  # f5Q[2]
    "資料時間(交易所給的)(EX:173547.32700)"
    Sn: str  # f5Q[3]
    "序號"
    def Get_SystemTime(self)->int:
        return self.TransToInt(self.f5Q[1])    
    def Get_Sn(self) -> int:
        return self.TransToInt(self.f5Q[3])
    TryMark: str  # { get { return (f5Q != null) ? f5Q[4] : "1"; } }
    "試撮註記(試撮=1, 非試撮=0)"

    FirstDerivedBuyPriceOrg:str #f5Q[25]
    "衍生委託單第一檔買進價格"
    def Get_FirstDerivedBuyPrice(self):
        return self.TransPrice2Dec(self.f5Q[25])
    FirstDerivedBuyQty:str #f5Q[26]
    "衍生委託單第一檔買進價格數量"
    FirstDerivedSellPriceOrg:str #f5Q[27]
    "衍生委託單第一檔賣出價格數量"
    def Get_FirstDerivedSellPrice(self):
        return self.TransPrice2Str(self.f5Q[27])    
    FirstDerivedSellQty:str #f5Q[28]
    "衍生委託單第一檔賣出價格數量"
    def Handle_5Q(self, aData: str):
        self.fPROC_HandleData(aData)
    # region 試撮 or 盤中

    def HandleData_TryMarket(self, aData: str):
        "處理試撮:試撮行情, 不更新"
        if aData.split('|')[4] == TSolQuoteFutSet.TryMark_No:  # 非試撮
            self.fPROC_HandleData = self.HandleData
            self.fPROC_HandleData(aData)
        else:
            self.f5Q = aData.split('|')
            self.SetData()

    def HandleData(self, aData: str):
        "處理即時"
        self.f5Q = aData.split('|')
        self.SetData()

    def SetData(self):
        self.DataTime = self.f5Q[2]
        self.Sn = self.f5Q[3]
        self.TryMark = "1" if self.f5Q is None else self.f5Q[4]
        self.FirstDerivedBuyPriceOrg = self.f5Q[25]
        self.FirstDerivedBuyQty = self.f5Q[26]
        self.FirstDerivedSellPriceOrg = self.f5Q[27]
        self.FirstDerivedSellQty = self.f5Q[28]

    fPROC_HandleData: callable = None
    "PROC_HandleData"
    # endregion

    # region 五檔買價量
    fAryB5Q_P = [5, 7, 9, 11, 13]
    "買五檔價在字串中的位置"
    fAryB5Q_Q = [6, 8, 10, 12, 14]
    "買五檔價在字串中的位置"
    fB5QCount: int = 5
    "買5檔的檔數"

    def B5Q_POrg(self, aN: int) -> str:
        "買5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"
        if aN > self.fB5QCount:
            return ""
        elif self.f5Q is None:
            return ""
        else:
            return self.f5Q[self.fAryB5Q_P[aN - 1]]

    def Get_B5Q_P2Dec(self, aN: int) -> decimal:
        "取得買5檔-價格 aN:5檔中的第幾檔(1~5)"
        if aN > self.fB5QCount:
            return 0
        elif self.f5Q is None:
            return 0
        else:
            return self.TransPrice2Dec(self.f5Q[self.fAryB5Q_P[aN - 1]])

    def Get_B5Q_P2Str(self, aN: int) -> str:
        "取得買5檔-價格 aN:5檔中的第幾檔(1~5)"
        if aN > self.fB5QCount:
            return ""
        elif self.f5Q is None:
            return ""
        else:
            return self.TransPrice2Str(self.f5Q[self.fAryB5Q_P[aN - 1]])

    def B5Q_QOrg(self, aN: int) -> str:
        "買5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"

        if aN > self.fB5QCount:
            return ""
        elif self.f5Q is None:
            return ""
        else:
            return self.f5Q[self.fAryB5Q_Q[aN - 1]]

    def Get_B5Q_Q(self, aN: int) -> int:
        "取得買5檔-量 aN:5檔中的第幾檔(1~5)"
        if aN > self.fB5QCount:
            return 0
        elif self.f5Q is None:
            return 0
        else:
            return self.TransToInt(self.f5Q[self.fAryB5Q_Q[aN - 1]])

    # endregion

    # region 五檔賣價量
    fAryS5Q_P = [15, 17, 19, 21, 23]
    "買五檔價在字串中的位置"
    fAryS5Q_Q = [16, 18, 20, 22, 24]
    "買五檔價在字串中的位置"
    fS5QCount: int = 5
    "賣5檔的檔數"

    def S5Q_POrg(self, aN: int) -> str:
        "賣5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~5)"
        if aN > self.fS5QCount:
            return ""
        elif self.f5Q is None:
            return ""
        else:
            return self.f5Q[self.fAryS5Q_P[aN - 1]]

    def Get_S5Q_P2Dec(self, aN: int) -> decimal:
        "取得賣5檔-價格 aN:5檔中的第幾檔(1~5)"
        if aN > self.fS5QCount:
            return 0
        elif self.f5Q is None:
            return 0
        else:
            return self.TransPrice2Dec(self.f5Q[self.fAryS5Q_P[aN - 1]])

    def Get_S5Q_P2Str(self, aN: int) -> str:
        "取得賣5檔-價格 aN:5檔中的第幾檔(1~5)"
        if aN > self.fS5QCount:
            return ""
        elif self.f5Q is None:
            return ""
        else:
            return self.TransPrice2Str(self.f5Q[self.fAryS5Q_P[aN - 1]])

    def S5Q_QOrg(self, aN: int) -> str:
        "賣5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~5)"
        if aN > self.fS5QCount:
            return ""
        elif self.f5Q is None:
            return ""
        else:
            return self.f5Q[self.fAryS5Q_Q[aN - 1]]

    def Get_S5Q_Q(self, aN: int) -> int:
        "取得賣5檔-量 aN:5檔中的第幾檔(1~5)"
        if aN > self.fS5QCount:
            return 0
        elif self.f5Q is None:
            return 0
        else:
            return self.TransToInt(self.f5Q[self.fAryS5Q_Q[aN - 1]])

    # endregion

    # region Tool
    def TransPrice2Dec(self, aOrgStr: str) -> decimal:
        try:
            aVal = Decimal(aOrgStr)
            aVal = aVal * self.DECIMAL_LOCATOR_Dgt
            return aVal
        except Exception as ex:
            return 0

    def TransPrice2Str(self, aOrgStr: str) -> str:
        if self.DECIMAL_LOCATOR_Dgt == 1:
            return aOrgStr
        if aOrgStr == "0":
            return ""
        if len(aOrgStr) < self.DECIMAL_LOCATOR_Org:
            return aOrgStr
        if not aOrgStr or aOrgStr.isspace():
            return ""
        try:
            ln = len(aOrgStr)
            return aOrgStr[:ln-self.DECIMAL_LOCATOR_Org] + '.' + aOrgStr[ln-self.DECIMAL_LOCATOR_Org:]
        except Exception as ex:
            return ""

    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            # print(f"Not a Int{ex}")
            pass
        return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            print(f"Not a Decimal{ex}")
        return 0
    # endregion

    def __init__(self) -> None:
        # 處理試撮/盤中:試撮行情, 不更新
        self.fPROC_HandleData = self.HandleData_TryMarket

    def __str__(self):
        return f"""DataTime:{self.DataTime} Sn:{self.Sn} TryMark:{self.TryMark} f5Q:{self.f5Q}"""
class TFutQt5QTOT:
    f5QTOT = []

    DataTime: str  # f5QTOT[2]
    "資料時間(交易所給的)(EX:173547.32700)"
    Sn: str  # f5QTOT[3]
    "序號"

    def Get_Sn(self) -> int:
        return self.TransToInt(self.f5QTOT[3])
    SumBuyOrderCount: str  # f5QTOT[4]
    "買進累計委託筆數"

    def Get_SumBuyOrderCount(self) -> int:
        return self.TransToInt(self.f5QTOT[4])
    SumBuyOrderQty: str  # f5QTOT[5]
    "買進累計委託合約數"

    def Get_SumBuyOrderQty(self) -> int:
        return self.TransToInt(self.f5QTOT[5])
    SumSellOrderCount: str  # f5QTOT[6]
    "賣出累計委託筆數"

    def Get_SumSellOrderCount(self) -> int:
        return self.TransToInt(self.f5QTOT[6])
    SumSellOrderQty: str  # f5QTOT[7]
    "賣出累計委託合約數"

    def Get_SumSellOrderQty(self) -> int:
        return self.TransToInt(self.f5QTOT[7])

    def Handle_5QTOT(self, aData: str):
        self.f5QTOT = aData.split('|')

        self.DataTime = self.f5QTOT[2]
        self.Sn = self.f5QTOT[3]
        self.SumBuyOrderCount = self.f5QTOT[4]
        self.SumBuyOrderQty = self.f5QTOT[5]
        self.SumSellOrderCount = self.f5QTOT[6]
        self.SumSellOrderQty = self.f5QTOT[7]

    # region Tool
    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0
    # endregion

    def __init__(self) -> None:
        pass

    def __str__(self) -> str:
        return f"""DataTime:{self.DataTime} Sn:{self.Sn} SumBuyOrderCount:{self.SumBuyOrderCount} SumBuyOrderQty:{self.SumBuyOrderQty}"""+\
        """SumSellOrderCount:{self.SumSellOrderCount} SumSellOrderQty:{self.SumSellOrderQty}"""
class TFutQtIDX:
    fIsGotDgtVal: bool = False
    fDECIMAL_LOCATOR_Org: int = 0
    "指數小數位數"
    fDECIMAL_LOCATOR_Dgt: decimal = 1
    "指數小數位數(若DECIMAL_LOCATOR_Org=2, 則此值為0.001)"
    fIdx = []

    # region
    DataTime: str  # fIdx[2]
    "資料時間(交易所給的)(EX:173547.32700)"
    Sn: str  # fIdx[3]
    "序號"

    def Get_Sn(self) -> int:
        return self.TransToInt(self.fIdx[3])
    TryMark: str  # fIdx[4]
    "試撮註記(試撮=1, 非試撮=0)"
    DealTime: str  # fIdx[5]
    "指數編篡時間(EX:173547.32700)"
    IdxDgtOrg: str  # fIdx[7]
    "指數小數位數"

    def Get_IdxDgtOrg(self) -> int:
        return self.TransToInt(self.fIdx[7])
    IdxValueOrg: str  # fIdx[6]
    "指數"

    def Get_IdxValue2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fIdx[6])

    def Get_IdxValue2Str(self) -> str:
        return self.TransPrice2Str(self.fIdx[6])
    HighIdxValueOrg: str  # fIdx[8]
    "當日最高指數"

    def Get_HighIdxValue2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fIdx[8])

    def Get_HighIdxValue2Str(self) -> str:
        return self.TransPrice2Str(self.fIdx[8])

    LowIdxValueOrg: str  # fIdx[9]
    "當日最低指數"

    def Get_LowIdxValue2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fIdx[9])

    def Get_LowIdxValue2Str(self) -> str:
        return self.TransPrice2Str(self.fIdx[9])

    OpenIdxValueOrg: str  # fIdx[10]
    "開盤指數"

    def Get_OpenIdxValue2Dec(self) -> decimal:
        return self.TransPrice2Dec(self.fIdx[10])

    def Get_OpenIdxValue2Str(self) -> str:
        return self.TransPrice2Str(self.fIdx[10])
    # endregion

    def Handle_IDX(self, aData: str):
        self.fIdx = aData.split('|')

        self.DataTime = self.fIdx[2]
        self.Sn = self.fIdx[3]
        self.TryMark = self.fIdx[4]
        self.DealTime = self.fIdx[5]
        self.IdxValueOrg = self.fIdx[6]
        self.IdxDgtOrg = self.fIdx[7]
        self.HighIdxValueOrg = self.fIdx[8]
        self.LowIdxValueOrg = self.fIdx[9]
        self.OpenIdxValueOrg = self.fIdx[10]

        # 指數小數位數
        if self.fIsGotDgtVal == False:
            #__Fire_LogEvent(string.Format("[FUT.Handle_IDX]{0}", aData));
            self.fDECIMAL_LOCATOR_Org = self.Get_IdxDgtOrg()
            if self.fDECIMAL_LOCATOR_Org == 0:
                self.fDECIMAL_LOCATOR_Dgt = 1  # 若DECIMAL_LOCATOR_Org=2, 則此值為0.001
            else:
                self.fDECIMAL_LOCATOR_Dgt = 1 / \
                    Decimal("1".ljust(self.fDECIMAL_LOCATOR_Dgt + 1, '0'))

            self.fIsGotDgtVal = True

    # region Tool
    def TransPrice2Dec(self, aOrgStr: str) -> decimal:
        try:
            aVal = Decimal(aOrgStr)
            aVal = aVal * self.DECIMAL_LOCATOR_Dgt
            return aVal
        except Exception as ex:
            print(f"Not a Decimal{ex}")
            return 0

    def TransPrice2Str(self, aOrgStr: str) -> str:
        if self.DECIMAL_LOCATOR_Dgt == 1:
            return aOrgStr
        if aOrgStr == "0":
            return ""
        if len(aOrgStr) < self.DECIMAL_LOCATOR_Org:
            return aOrgStr
        if not aOrgStr or aOrgStr.isspace():
            return ""
        try:
            ln = len(aOrgStr)
            return aOrgStr[:ln-self.DECIMAL_LOCATOR_Org] + '.' + aOrgStr[ln-self.DECIMAL_LOCATOR_Org:]
        except Exception as ex:
            return ""

    def TransToInt(self, aOrgStr: str) -> int:
        try:
            return int(aOrgStr)
        except Exception as ex:
            # print(f"Not a Int{ex}")
            pass
        return 0

    def TransToDecimal(self, aOrgStr: str) -> decimal:
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            print(f"Not a Decimal{ex}")
        return 0
    # endregion

    def __init__(self) -> None:
        pass

    def __str__(self) -> str:
        return f"""DataTime:{self.DataTime} Sn:{self.Sn} TryMark:{self.TryMark} DealTime:{self.DealTime} IdxValueOrg:{self.IdxValueOrg}"""+\
                """IdxDgtOrg:{self.IdxDgtOrg} HighIdxValueOrg:{self.HighIdxValueOrg} LowIdxValueOrg:{self.LowIdxValueOrg} OpenIdxValueOrg:{self.OpenIdxValueOrg}"""
class TFutQuoteData:
    SolIce = ""
    ProdKind: TFutProdKind = TFutProdKind.pkNone
    BAS: TFutQtBase = None
    HL: TFutQtHL = None
    QtTX: TFutQtTX = None
    Qt5Q: TFutQt5Q = None
    Qt5QTOT: TFutQt5QTOT = None
    QtIDX: TFutQtIDX = None

    def __init__(self, enu: TFutProdKind, aSolIce: str, aCalcHightLowPrice: bool):
        "aCalcHightLowPrice:是否需要計算最高最低價"

        self.SolIce = aSolIce
        self.ProdKind = enu
        self._lock = Lock()
        self.UpdateBAS = True
        self.UpdateHLTX = False
        if enu == TFutProdKind.pkNormal:  # 一般期貨
            self.BAS = TFutQtBase()
            self.HL = TFutQtHL()
            self.QtTX = TFutQtTX(aCalcHightLowPrice)
            self.Qt5Q = TFutQt5Q()
            self.Qt5QTOT = TFutQt5QTOT()

        elif enu == TFutProdKind.pkIndex:  # 指數商品
            self.QtIDX = TFutQtIDX()

    def SetDataInit(self, type:str=""):
        "此Function在回補資料回來後,才會執行"
        if self.ProdKind == TFutProdKind.pkNormal:
            if type == "BAS" or type == "":            
                self.HL.DECIMAL_LOCATOR_Dgt = self.BAS.DECIMAL_LOCATOR_Dgt
                self.QtTX.DECIMAL_LOCATOR_Dgt = self.BAS.DECIMAL_LOCATOR_Dgt
                self.Qt5Q.DECIMAL_LOCATOR_Dgt = self.BAS.DECIMAL_LOCATOR_Dgt

                self.HL.DECIMAL_LOCATOR_Org = self.BAS.DECIMAL_LOCATOR_Org
                self.QtTX.DECIMAL_LOCATOR_Org = self.BAS.DECIMAL_LOCATOR_Org
                self.Qt5Q.DECIMAL_LOCATOR_Org = self.BAS.DECIMAL_LOCATOR_Org
            if type == "HL" or type == "":            
                self.QtTX.HighPrice = self.HL.Get_HighPrice2Dec()
                self.QtTX.LowPrice = self.HL.Get_LowPrice2Dec()

class TObjFutQuoteMap(UserDict):
    """Key=原為SolIce, 回補完後成則變為TX與5Q的TOPIC
    class TObjFutQuoteMap : ConcurrentDictionary<string, TFutQuoteData>"""
    # /// <summary>各商品拆解行情proc(EX:TXF的TX與5Q, 行情拆解,是不同Proc)</summary>
    # public Dictionary<string, PROC_Handle_FutRTQuote> MapQtProc = new Dictionary<string, PROC_Handle_FutRTQuote>();
    #預設行情解析proc
    DefProc_TX:callable=None
    DefProc_5Q:callable=None
    DefProc_Idx:callable=None
    DefProc_5QTOT:callable=None
    DefProc_BAS:callable=None
    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )

        self.MapQtProc = {}
        "各商品拆解行情proc(EX:TXF的TX與5Q, 行情拆解,是不同Proc)"
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddRcvData(self, aSolIce: str, aData: str, aCalcHightLowPrice: bool):
        """是否需要計算最高最低價
            return  1:bool
                    2.out TFutQuoteData tmpQt
                    3.out string aErrMsg"""
        aErrMsg = ""
        tmpQt: TFutQuoteData = None
        try:
            map = json.loads(aData)
            # region 檢核
            if "status" in map and len(map["status"]) > 0:
                if map["status"][0] == "error":
                    aErrMsg = f"[期][AddRcvData](aSolIce={aSolIce}, aData={aData})行情回補資料有誤!"
                    return False, tmpQt, aErrMsg
            if "BAS" in map and len(map["BAS"]) == 0:
                aErrMsg = f"[期][AddRcvData](aSolIce={aSolIce}, aData={aData})沒有BAS資料!"
                return False, tmpQt, aErrMsg
            if "HL" in map and len(map["HL"]) == 0:
                aErrMsg = f"[期][AddRcvData](aSolIce={aSolIce}, aData={aData})沒有HL資料!"
                return False, tmpQt, aErrMsg
            # endregion

            if self.data.get(aSolIce) is None:
                tmp = TFutQuoteData(TFutProdKind.pkNormal,
                                    aSolIce, aCalcHightLowPrice)
                tmp.BAS.Handle_BAS(map["BAS"][0])
                tmp.HL.Handle_HL(map["HL"][0])
                tmp.SetDataInit()
                tmpQt = tmp
                self[aSolIce] = tmp
                return True, tmpQt, ""
            else:
                tmp: TFutQuoteData = self[aSolIce]
                with tmp._lock:
                    tmp.BAS.Handle_BAS(map["BAS"][0])
                    tmp.HL.Handle_HL(map["HL"][0])
                    tmp.SetDataInit()
                    tmpQt = tmp
                return True, tmpQt, ""
        except Exception as ex:
            aErrMsg = f"[期][AddRcvData](aSolIce={aSolIce}, aData={aData}){ex}"
        return False, tmpQt, aErrMsg

    def AddData(self, enu: TFutProdKind, aSolIce: str, aCalcHightLowPrice: bool, aTopic: str, aProc: callable):
        """ aCalcHightLowPrice:是否需要計算最高最低價
            aTopic:EX:Quote/TWF/IDX/TAIWANVIX/MR
            aProcTX:拆解行情的function"""
        try:
            if self.data.get(aSolIce) is None:
                tmp = TFutQuoteData(enu, aSolIce, aCalcHightLowPrice)
                self[aTopic] = tmp

                if self.MapQtProc.get(aTopic) is None:
                    self.MapQtProc[aTopic] = aProc

                return True
            else:
                return True
        except Exception as ex:
            pass
        return False

    def AddDataBySolIce(self, aIsCat:bool, aSolIce:str, map, aCalcHightLowPrice:bool, topic:str=""):        
        """ aIsCat:是否為分類訂閱
            aSolIce:EX:TXFA2
            aCalcHightLowPrice:是否計算最高低價        
            return  1.bool
                    2.out TMapFutQuoteData aQtMap
                    3.out string aErrMsg        """
        aErrMsg = ""        
        try:
            #region 拆解基本資料
            aQtMap:TObjFutQuoteMap = TObjFutQuoteMap()
            if map.get("BAS") is not None:
                for strBAS in map["BAS"]:
                    tmpBAS:TFutQtBase = TFutQtBase(topic)
                    tmpBAS.Handle_BAS(strBAS)                
                    if aQtMap.data.get(tmpBAS.OrdProdID) is None:
                        tmpQt = TFutQuoteData(TFutProdKind.pkNormal, tmpBAS.OrdProdID, aCalcHightLowPrice)
                        tmpQt.BAS = tmpBAS
                        tmpQt.UpdateHLTX = False
                        tmpQt.SetDataInit("BAS")
                        aQtMap[tmpBAS.OrdProdID] = tmpQt           
                    if topic != "":
                        sTopicTX = tmpQt.BAS.TopicTX #成交
                        sTopic5Q = tmpQt.BAS.Topic5Q #五檔
                        sTopic5QTOT = tmpQt.BAS.Topic5QTOT #累計買賣委託筆數、累計買賣委託筆數
                        sTopicBas = tmpQt.BAS.TopicBAS #基本資料(I010、I011) for 換盤資訊                    
                        self[sTopicTX] = tmpQt
                        self[sTopic5Q] = tmpQt
                        self[sTopic5QTOT] = tmpQt                        
                        self[sTopicBas] = tmpQt                        
                        if self.MapQtProc.get(sTopicTX) is None:
                            self.MapQtProc[sTopicTX] = self.DefProc_TX
                        if self.MapQtProc.get(sTopic5Q) is None:
                            self.MapQtProc[sTopic5Q] = self.DefProc_5Q
                        if self.MapQtProc.get(sTopic5QTOT) is None:
                            self.MapQtProc[sTopic5QTOT] = self.DefProc_5QTOT
                        if self.MapQtProc.get(sTopicBas) is None:
                            self.MapQtProc[sTopicBas] = self.DefProc_BAS
            #endregion 拆解基本資料
            #region 拆解HL
            if map.get("HL") is not None:
                for str in map["HL"]:
                    tmpHL = TFutQtHL()
                    tmpHL.Handle_HL(str)
                    if aQtMap.data.get(tmpHL.Symbol): #商品基本資料                    
                        tmpQt:TFutQuoteData = aQtMap[tmpHL.Symbol]
                        tmpQt.UpdateHLTX = True
                        tmpQt.HL = tmpHL #商品最新行情(含5檔)
                        tmpQt.SetDataInit()
                    if topic == "":
                        sTopicTX = tmpHL.TopicTX #成交
                        sTopic5Q = tmpHL.Topic5Q #五檔
                        sTopic5QTOT = tmpHL.Topic5QTOT #累計買賣委託筆數、累計買賣委託筆數
                        sTopicBas = tmpHL.TopicBAS #基本資料(I010、I011) for 換盤資訊      
                        self[sTopicTX] = tmpQt
                        self[sTopic5Q] = tmpQt
                        self[sTopic5QTOT] = tmpQt
                        self[sTopicBas] = tmpQt
                        if self.MapQtProc.get(sTopicTX) is None:
                            self.MapQtProc[sTopicTX] = self.DefProc_TX
                        if self.MapQtProc.get(sTopic5Q) is None:
                            self.MapQtProc[sTopic5Q] = self.DefProc_5Q
                        if self.MapQtProc.get(sTopic5QTOT) is None:
                            self.MapQtProc[sTopic5QTOT] = self.DefProc_5QTOT
                        if self.MapQtProc.get(sTopicBas) is None:
                            self.MapQtProc[sTopicBas] = self.DefProc_BAS

            #endregion 拆解HL
            return len(aQtMap) > 0, aQtMap, aErrMsg
        except Exception as ex:
            aErrMsg = f"[期][AddDataBySolIce](aIsCat={aIsCat}, aSolIce={aSolIce}){ex}"
        return False, aQtMap, aErrMsg
            

    def GetItem_BySolIce(self, aSolIce: str):
        """return   1.bool
                    2.out List<string> aTopicList
                    3.out string aErrMsg"""
        aErrMsg = ""
        aTopicList = None
        try:
            retlist = []
            for key, val in self.items():
                Futdat: TFutQuoteData
                Futdat = val
                if(Futdat.SolIce == aSolIce):
                    retlist.append(key)
            aTopicList = retlist
            if aTopicList is None or len(aTopicList) == 0:
                aErrMsg = f"[期][GetItem_BySolIce](aSolIce={aSolIce})商品已不存存!"
                return False, aTopicList, aErrMsg
            else:
                return True, aTopicList, ""
        except Exception as ex:
            aErrMsg = f"[期][GetItem_BySolIce](aSolIce={aSolIce}){ex}"
        return False, aTopicList, aErrMsg
    
    def GetItem_ByCategory(self, aCat:str):
        """return 1.bool
            2. out List<string> aTopicList
            3. out string aErrMsg"""
        aErrMsg:str = ""
        aTopicList = None
        try:
            retlist = []
            for key, val in self.items():
                Futdat: TFutQuoteData = val
                arr = key.split('/')                
                if arr[2] == aCat:# if(Futdat.HL.Market == aCat):
                    retlist.append(key)
            aTopicList = retlist
            if aTopicList is None or len(aTopicList) == 0:
                aErrMsg = f"期][GetItem_ByCategory](aCat={aCat})商品已不存存!"
                return False, aTopicList, aErrMsg
            else:
                return True, aTopicList, ""                
        except Exception as ex:
            aErrMsg =f"[期][GetItem_ByCategory](aCat={aCat}){ex}"
        return False, aTopicList, aErrMsg
        

class TObjBaseFutMap(UserDict):
    """期貨商品(Key=ProdID, Value=商品Base)(EX:Key=TXF, Value=TXF可交易月份們)
        public class TObjBaseFutMap : Dictionary<string, TObjBaseFutList>"""
    # Dictionary<string, SortedList<string, TFutQtBase>> fSortMap = new Dictionary<string, SortedList<string, TFutQtBase>>();//<ProdID, <交割月, TFutQtBase>>

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )

        self.fSortMap = {}
        "<ProdID, <交割月, TFutQtBase>>"
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem_ByStkNo(self, tmp: TFutQtBase):
        try:
            if self.fSortMap.get(tmp.StkNo) is None:
                MthObj = {tmp.SettleMth: tmp}
                self.fSortMap[tmp.StkNo] = MthObj
            else:
                olddic = self.fSortMap[tmp.StkNo]
                olddic[tmp.SettleMth] = tmp
                sortdic = sorted(olddic.items())
                newdic = dict(sortdic)
                self.fSortMap[tmp.StkNo] = newdic
        except Exception as ex:
            pass

    def AddItem_ByProdID(self, tmp: TFutQtBase):
        try:
            if self.fSortMap.get(tmp.ProdID) is None:
                MthObj = {tmp.SettleMth: tmp}
                self.fSortMap[tmp.ProdID] = MthObj
            else:
                olddic = self.fSortMap[tmp.ProdID]
                olddic[tmp.SettleMth] = tmp
                sortdic = sorted(olddic.items())
                newdic = dict(sortdic)
                self.fSortMap[tmp.ProdID] = newdic
        except Exception as ex:
            pass

    def ReAddAll(self):
        if self.fSortMap.keys() is None:
            return

        for sKey in self.fSortMap.keys():
            ls = TObjBaseFutList()
            [ls.append(self.fSortMap[sKey][o]) for o in self.fSortMap[sKey]]
            self[sKey] = ls

class TObjBaseFutList(list):
    "public class TObjBaseFutList : ObservableCollection<TFutQtBase>"
    pass
class TObjFutComList(UserDict):
    """Key=SolIce(EX:CDFL2^C3)
        public class TObjFutComList : SortedList<string, TFutCom>"""

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem(self, aSolIce: str):
        try:
            tmp = TFutCom()
            tmp.SolIce = aSolIce  # CDFL2^C3
            tmp.Leg1_SolIce = aSolIce.split('^')[0]  # CDFL2
            tmp.Leg2_SolIce = tmp.Leg1_SolIce[:len(
                tmp.Leg1_SolIce) - 2] + aSolIce.split('^')[1]  # CDFC3
            self[aSolIce] = tmp
            self.data = dict(sorted(self.data.items()))  # sort itself
        except Exception as ex:
            pass

class TFutCom:
    SolIce: str
    "CDFL2^C3"
    Leg1_SolIce: str
    "CDFL2"
    Leg2_SolIce: str
    "CDFC3"

# region 選擇權


class TObjBaseOptMap(UserDict):
    """選擇權商品(Key=ProdID, Value=商品Base(可交易月份-->CallPut-->履約價))(EX:Key=TXO)
        public class TObjBaseOptMap : Dictionary<string, TObjBaseOptMthList>"""

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem_ByProdID(self, tmp: TFutQtBase):
        try:
            if self.data.get(tmp.ProdID) is None:
                BasOptMth_list = TObjBaseOptMthList()
                BasOptMth_list.NewItem(tmp)
                self[tmp.ProdID] = BasOptMth_list
            else:
                BasOptMth_list: TObjBaseOptMthList = self[tmp.ProdID]
                BasOptMth_list.NewItem(tmp)
        except Exception as ex:
            pass
class TObjBaseOptMthList(UserDict):
    """Key=月份
        public class TObjBaseOptMthList : SortedList<string, TObjBaseOptCallPutList> """
    ProdName: str = ""

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def NewItem(self, tmp: TFutQtBase):
        sMth = tmp.SettleMth

        if self.data.get(sMth) is None:
            fProdName = tmp.FutName
            BasCPDict = TObjBaseOptCallPutList()
            BasCPDict.NewItem(tmp)
            self[sMth] = BasCPDict
        else:
            BasCPDict: TObjBaseOptCallPutList = self[sMth]
            BasCPDict.NewItem(tmp)
        # sort it myself after add item
        olddict = self.data
        sortdict = sorted(olddict.items())
        newdict = dict(sortdict)
        self.data = newdict
class TObjBaseOptCallPutList(UserDict):
    """Key=C/P
        class TObjBaseOptCallPutList : SortedList<string, TObjBaseOptList> """

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def NewItem(self, tmp: TFutQtBase):
        sCP = tmp.CallPutType

        if self.data.get(sCP) is None:
            basOptlist = TObjBaseOptList()
            basOptlist.append(tmp)
            self[sCP] = basOptlist
        else:
            oldlist: TObjBaseOptList = self[sCP]
            oldlist.append(tmp)
        # sort it myself after add item
        olddict = self.data
        sortdict = sorted(olddict.items())
        newdict = dict(sortdict)
        self.data = newdict
class TObjBaseOptList(list):
    """class TObjBaseOptList : ObservableCollection<TFutQtBase> { }"""
    pass

# endregion 選擇權

class TQryFutProdMap(UserDict):
    """商品檔(明細)
        class TQryFutProdMap : Dictionary<string, TQryFutProdRec> { }"""

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

class TQryFutProdRec:

    tmpBase: TFutQtBase = None
    tmpHL: TFutQtHL = None

    def SetDataInit(self):
        self.tmpHL.DECIMAL_LOCATOR_Dgt = self.tmpBase.DECIMAL_LOCATOR_Dgt
        self.tmpHL.DECIMAL_LOCATOR_Org = self.tmpBase.DECIMAL_LOCATOR_Org

# endregion FUT
# region OvsFUT

class TOvsFutQtDef:
    DecimalMultiply: decimal = 1
    "DecimalMultiply(一個契約含多少Shares)"
    Price_Denominator: decimal = 1
    "分母價格(為1者, 不是分子分母報價方式)"
    # region Tool

    def TransPrice2Dec(self, aOrgStr: str):
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0

    # ????aDg_tPrice還要確認一下會放什麼值
    def TransPrice2Str(self, aPrice: decimal, aDg_tPrice: str = ""):
        if self.Price_Denominator == 1:
            if self.DecimalMultiply == 1:  # 表示不用處理數值
                if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice.isspace():
                    return str(aPrice)
                else:
                    return aDg_tPrice.format(aPrice)
            if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice.isspace():
                return "{:.8f}".format(aPrice * self.DecimalMultiply)
            else:
                return aDg_tPrice.format(aPrice * self.DecimalMultiply)

        else:  # 分子分母報價方式
            # 將小數改用分子分母顯示
            dIntPrice: decimal = math.trunc(aPrice)
            dPrice: decimal = aPrice - dIntPrice
            if aDg_tPrice is None or not aDg_tPrice or aDg_tPrice.isspace():
                return "{0} {1:.8f}/{2}".format( dIntPrice, (dPrice * self.Price_Denominator), self.Price_Denominator)
            else:
                return "{0} {1:.8f}/{2}".format( dIntPrice, aDg_tPrice.format(dPrice * self.Price_Denominator), self.Price_Denominator)

    def TransToInt(self, aOrgStr: str):
        try:
            return int(aOrgStr)
        except Exception as ex:
            return 0

    def TransToDecimal(self, aOrgStr: str):
        try:
            return Decimal(aOrgStr)
        except Exception as ex:
            return 0
    # endregion Tool

    def __init__(self) -> None:
        pass

class TOvsFutQtBase(TOvsFutQtDef):
    fHasBAS: bool = False
    fBAS = []

    SolICE: str  # fBAS[0]
    "台新行情代碼(NQ.202212)"
    SysTime: str  # fBAS[1]
    "系統時間"
    RefPriceOrg: str  # fBAS[2]
    "參考價"

    def Get_RefPrice(self):
        return self.TransPrice2Dec(self.RefPriceOrg)

    def GetDply_RefPrice(self, aDg_tPrice: str = ""):
        if(self.fBAS == None):
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.RefPriceOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)
    ProdID: str  # fBAS[3]
    "台新商品代碼 (EX:NQ)"
    FutName: str  # fBAS[4]
    "商品中文名稱(EX:小型環球晶)"
    OrdProdId: str  # fBAS[5]
    "台新商品委託代碼(EX:NQ)"
    ICEProdId: str  # fBAS[6]
    "台新行情代碼(EX:NQ, 艾揚的為ICE開頭)"
    MktStr: str  # fBAS[7]
    "台新市場別(FUT/OPT)"
    Market: str  # {  fBAS[7] == "FUT" ? "4" : "5";  }
    "台新市場別(4=FUT/5=OPT)"
    BaseUnit: str  # fBAS[8]
    "基本跳動點(選擇權商品為TickSizeList, 如:0=0.05;5=0.25)"

    def Get_BaseUnit(self):
        dVal: decimal = 1
        dVal = self.TransToDecimal(self.BaseUnit)
        if dVal == 0:
            dVal = 1
        return dVal

    ValuePerUnitOrg: str  # fBAS[9]
    "每點價值"

    def Get_ValuePerUnit(self):
        return self.TransToDecimal(self.ValuePerUnitOrg)
    DecimalMultiplyOrg: str  # fBAS[10]
    "DecimalMultiply(一個契約含多少Shares)"

    def Get_DecimalMultiply(self):
        return self.TransToDecimal(self.DecimalMultiplyOrg)
    Exchange: str  # fBAS[11]
    "台新交易所代碼"
    ExchangeName: str  # fBAS[12]
    "台新商品代碼 (EX:NQ)"
    Price_DenominatorOrg: str  # fBAS[13]
    "分母價格(為1者, 不是分子分母報價方式)"

    def Get_Price_Denominator(self):
        return self.TransToDecimal(self.Price_DenominatorOrg)
    Display: str  # fBAS[14]
    "是否可交易(Y/N)"
    SettleMth: str  # fBAS[15]
    "交割月"
    CP: str  # fBAS[16]
    "C/P(非選擇權者為空字串)"
    StrikeP: str  # fBAS[17]
    "履約價(非選擇權者為空字串)"
    PreSettlePriceOrg: str  # fBAS[18]
    "昨日結算價"

    def Get_PreSettlePrice(self):
        if self.fBAS is None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.PreSettlePriceOrg)
        return dVal

    def GetDply_PreSettlePrice(self, aDg_tPrice: str = ""):
        if self.fBAS == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.PreSettlePriceOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)
    PreClosePriceOrg: str  # fBAS[19]

    def Get_PreClosePrice(self):
        if self.fBAS == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.PreClosePriceOrg)
        return dVal

    def GetDply_PreClosePrice(self, aDg_tPrice: str = ""):
        if self.fBAS == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Str(self.PreClosePriceOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)

    LastTxDate: str  # fBAS[20]
    "最後交易日"
    TickSizeList: str  # fBAS[21]
    "TickSizeList(僅選擇權有值, 如:0=0.05;5=0.25)"

    def Get_OptTickSizeList(self):
        """Tick Size List(Key=權利金, Value=跳動點)
            SortedList<decimal, decimal>"""
        # SortedList<decimal, decimal> lsTickSize = new SortedList<decimal, decimal>();
        lsTickSize = {}
        try:
            if self.MktStr == "FUT":  # 期貨
                return lsTickSize
            if self.TickSizeList is None or not self.TickSizeList or self.TickSizeList.isspace:
                return lsTickSize

            # 0=0.05;5=0.25
            ary = self.TickSizeList.split(';')
            for str in ary:
                lsTickSize[Decimal(str.split('=')[0])] = Decimal(
                    str.split('=')[1])
            lsTickSize = dict(sorted(lsTickSize.items()))  # sort itself
        except Exception as ex:
            pass
        return lsTickSize    

    def GetFavorStr(self) -> str:
        "格式:|Exchange|ProdID|Mth|ICE|"
        return "|{0}|{1}|{2}|{3}|".format(self.Exchange, self.ProdID, self.SettleMth, self.SolICE)

    def Handle_BAS(self, aData: str):
        self.fBAS = aData.split('|')
        self.fHasBAS = len(self.fBAS) > 0
        self.Set_Data()
        if self.fHasBAS:
            self.DecimalMultiply = self.Get_DecimalMultiply()
            self.Price_Denominator = self.Get_Price_Denominator()

    def Set_Data(self):
        self.SolICE = self.fBAS[0]
        self.SysTime = self.fBAS[1]
        self.RefPriceOrg = self.fBAS[2]
        self.ProdID = self.fBAS[3]
        self.FutName = self.fBAS[4]
        self.OrdProdId = self.fBAS[5]
        self.ICEProdId = self.fBAS[6]
        self.MktStr = self.fBAS[7]
        self.Market = "4" if self.fBAS[7] == "FUT" else "5"
        self.BaseUnit = self.fBAS[8]
        self.ValuePerUnitOrg = self.fBAS[9]
        self.DecimalMultiplyOrg = self.fBAS[10]
        self.Exchange = self.fBAS[11]
        self.ExchangeName = self.fBAS[12]
        self.Price_DenominatorOrg = self.fBAS[13]
        self.Display = self.fBAS[14]
        self.SettleMth = self.fBAS[15]
        self.CP = self.fBAS[16]
        self.StrikeP = self.fBAS[17]
        self.PreSettlePriceOrg = self.fBAS[18]
        self.PreClosePriceOrg = self.fBAS[19]
        self.LastTxDate = self.fBAS[20]
        self.TickSizeList = self.fBAS[21]

    def IsSameBAS(self, aProdID: str, aMth: str):
        return aProdID == self.ProdID and self.SettleMth == aMth
class TOvsFutQtTX(TOvsFutQtDef):
    fTX = []

    # region
    SolICE: str  # fTX[0]
    "台新行情代碼(NQ.202212)"
    SysTime: str  # fTX[1]
    "系統時間(EX:143211.693)"
    DataTime: str  # fTX[2]
    "資料時間(交易所給的)(EX:14:32:11.752025)"
    QtSrc: str  # fTX[3]
    "行情來源(EX:PATS.NQ/CQG.NQ)"
    DealTime: str  # fTX[4]
    "成交時間(EX:14:32:11.752025)"
    DealShowMark: str  # fTX[5]
    "成交資料揭示項目註記(0:請略過,1:成交行情,空字串:收盤/結算)"
    TotQty: str  # fTX[6]
    "成交總量"

    def Get_TotQty2Dec(self):
        return self.TransToDecimal(self.TotQty)

    def Get_TotQty2Int(self):
        return self.TransToInt(self.TotQty)
    SumBuyDealCount: str  # fTX[7]
    "累計買進成交筆數"

    def Get_SumBuyDealCount(self):
        return self.TransToInt(self.SumBuyDealCount)
    SumSellDealCount: str  # fTX[8]
    "累計賣出成交筆數"

    def Get_SumSellDealCount(self):
        return self.TransToInt(self.SumSellDealCount)
    DealCount: str  # fTX[9]
    "成交價量檔數(目前海期都給1)"

    def Get_DealCount(self):
        return self.TransToInt(self.DealCount)
    DealPriceOrg: str  # fTX[10]
    "成交價"

    def Get_DealPrice(self):
        if self.fTX is None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.DealPriceOrg)
        return dVal

    def GetDply_DealPrice(self, aDg_tPrice: str = ""):
        if self.fTX == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.DealPriceOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)
    DealQty: str  # fTX[11]
    "成交單量"

    def Get_DealQty2Dec(self):
        return self.TransPrice2Dec(self.DealQty)

    def GetDealQty2Int(self):
        return self.TransToInt(self.DealQty)
    DayHighOrg: str  # fTX[12]
    "最高價"

    def Get_DayHigh(self):
        if self.fTX is None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.DayHighOrg)
        return dVal

    def GetDply_DayHigh(self, aDg_tPrice: str = ""):
        if self.fTX == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.DayHighOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)
    DayLowOrg: str  # fTX[13]
    "最低價"

    def Get_DayLow(self):
        if self.fTX == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.DayLowOrg)
        return dVal

    def GetDply_DayLow(self, aDg_tPrice: str = ""):
        if self.fTX == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.DayLowOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)
    OpenPriceOrg: str  # fTX[14]
    "開盤價"

    def Get_OpenPrice(self):
        if self.fTX == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.OpenPriceOrg)
        return dVal

    def GetDply_OpenPrice(self, aDg_tPrice: str = ""):
        if self.fTX == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.OpenPriceOrg)
        return self.TransPrice2Dec(dVal, aDg_tPrice)
    ClosePriceOrg: str  # fTX[15]
    "收盤價"

    def Get_ClosePrice(self):
        if self.fTX == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.ClosePriceOrg)
        return dVal

    def GetDply_ClosePrice(self, aDg_tPrice: str = ""):

        if self.fTX == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.ClosePriceOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)

    SettlePriceOrg: str  # fTX[16]
    "結算價"

    def Get_SettlePrice(self):
        if self.fTX == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.SettlePriceOrg)
        return dVal

    def GetDply_SettlePrice(self, aDg_tPrice: str = ""):
        if self.fTX == None:
            return ""
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.SettlePriceOrg)
        return self.TransPrice2Str(dVal, aDg_tPrice)
    # endregion
    # region 計算最高低價
    fDealPrice: decimal = 0
    "成交價"
    HighPrice: decimal = 0
    "當日最高價"
    LowPrice: decimal = 0
    "當日最低價"

    def CalcHightLowPrice(self):
        "計算最高低價"
        try:
            self.fDealPrice = self.Get_DealPrice()

            self.HighPrice = max(self.fDealPrice, self.HighPrice)
            if self.LowPrice == 0:
                self.LowPrice = self.fDealPrice
            else:
                self.LowPrice = min(self.fDealPrice, self.LowPrice)
        except Exception as ex:
            pass

    def CalcHightLowPrice_None(self):
        pass
    fPROC_CalcHightLowPrice: callable = None
    "PROC_CalcHightLowPrice"
    # endregion

    def Set_Data(self):
        self.SolICE = self.fTX[0]
        self.SysTime = self.fTX[1]
        self.DataTime = self.fTX[2]
        self.QtSrc = self.fTX[3]
        self.DealTime = self.fTX[4]
        self.DealShowMark = self.fTX[5]
        self.TotQty = self.fTX[6]
        self.SumBuyDealCount = self.fTX[7]
        self.SumSellDealCount = self.fTX[8]
        self.DealCount = self.fTX[9]
        self.DealPriceOrg = self.fTX[10]
        self.DealQty = self.fTX[11]
        self.DayHighOrg = self.fTX[12]
        self.DayLowOrg = self.fTX[13]
        self.OpenPriceOrg = self.fTX[14]
        self.ClosePriceOrg = self.fTX[15]
        self.SettlePriceOrg = self.fTX[16]

    def Handle_TX(self, aData: str):
        "處理即時"
        self.fTX = aData.split('|')
        self.Set_Data()

        self.fPROC_CalcHightLowPrice()  # 計算最高低價

    def __init__(self, aCalcHightLowPrice: bool) -> None:
        # 計算最高低價
        self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice_None
        if aCalcHightLowPrice:
            self.fPROC_CalcHightLowPrice = self.CalcHightLowPrice
        super().__init__()

    def __str__(self) -> str:
        return f"""SolICE:{self.SolICE} SysTime:{self.SysTime} DataTime:{self.DataTime} QtSrc:{self.QtSrc} DealTime:{self.DealTime}"""+\
                """DealShowMark:{self.DealShowMark} TotQty:{self.TotQty} SumBuyDealCount:{self.SumBuyDealCount} SumSellDealCount:{self.SumSellDealCount}"""+\
                """DealCount:{self.DealCount} DealPriceOrg:{self.DealPriceOrg} DealQty:{self.DealQty} DayHighOrg:{self.DayHighOrg}"""+\
                """DayLowOrg:{self.DayLowOrg} OpenPriceOrg:{self.OpenPriceOrg} ClosePriceOrg:{self.ClosePriceOrg} SettlePriceOrg:{self.SettlePriceOrg}"""+\
                """fDealPrice:{self.fDealPrice} HighPrice:{self.HighPrice} LowPrice:{self.LowPrice}"""
class TOvsFutQt5Q(TOvsFutQtDef):
    f5Q = []

    SolICE: str  # f5Q[0]
    "台新行情代碼(NQ.202212)"
    DataTime: str  # f5Q[2]
    "資料時間(交易所給的)(EX:14:32:19.676684)"
    QtSrc: str  # f5Q[3]
    "行情來源(EX:PATS.NQ/CQG.NQ)"
    # region 五檔買價量
    fAryB5Q_P = [4, 6, 8, 10, 12, 24, 26, 28, 30, 32]
    "買五檔價在字串中的位置"
    fAryB5Q_Q = [5, 7, 9, 11, 13, 25, 27, 29, 31, 33]
    "買五檔價在字串中的位置"
    fB5QCount: int = 10
    "買5檔的檔數"

    def B5Q_POrg(self, aN: int):
        "買5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~10)"
        if aN > self.fB5QCount:
            return ""
        elif self.f5Q == None:
            return ""
        else:
            return self.f5Q[self.fAryB5Q_P[aN - 1]]

    def Set_B5Q_P(self, aN: int):
        "取得買5檔-價格 aN:5檔中的第幾檔(1~10)"
        if aN > self.fB5QCount:
            return 0
        elif self.f5Q == None:
            return 0
        else:
            return self.TransPrice2Dec(self.f5Q[self.fAryB5Q_P[aN - 1]])

    def Get_B5Q_P(self, aN: int):
        if self.f5Q == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.f5Q[self.fAryB5Q_P[aN - 1]])
        return dVal

    def GetDply_B5Q_P(self, aN: int, aDg_tPrice: str = ""):
        if aN > self.fB5QCount:
            return ""
        elif self.f5Q == None:
            return ""
        else:
            dVal: decimal = 0
            dVal = self.TransPrice2Dec(self.f5Q[self.fAryB5Q_P[aN - 1]])
            return self.TransPrice2Str(dVal, aDg_tPrice)

    def B5Q_QOrg(self, aN: int):
        "買5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~10)"
        if aN > self.fB5QCount:
            return ""
        elif self.f5Q == None:
            return ""
        else:
            return self.f5Q[self.fAryB5Q_Q[aN - 1]]

    def Set_B5Q_Q(self, aN: int):
        "取得買5檔-量 aN:5檔中的第幾檔(1~10)"

        if aN > self.fB5QCount:
            return 0
        elif self.f5Q == None:
            return 0
        else:
            return self.TransToInt(self.f5Q[self.fAryB5Q_Q[aN - 1]])

    def Get_B5Q_Q(self, aN: int):

        iVal: int = 0
        iVal = self.Set_B5Q_Q(aN)
        return str(iVal)
    # endregion
    # region 五檔賣價量
    fAryS5Q_P = [14, 16, 18, 20, 22,  34, 36, 38, 40, 42]
    "買五檔價在字串中的位置"
    fAryS5Q_Q = [15, 17, 19, 21, 23,  35, 37, 39, 41, 43]
    "買五檔價在字串中的位置"
    fS5QCount: int = 10
    "賣5檔的檔數"

    def S5Q_POrg(self, aN: int):
        "賣5檔-價格-的原始字串內容 aN:5檔中的第幾檔(1~10)"
        if aN > self.fS5QCount:
            return ""
        elif self.f5Q == None:
            return ""
        else:
            return self.f5Q[self.fAryS5Q_P[aN - 1]]

    def Set_S5Q_P(self, aN: int):
        "取得賣5檔-價格 aN:5檔中的第幾檔(1~10)"
        if aN > self.fS5QCount:
            return 0
        elif self.f5Q == None:
            return 0
        else:
            return self.TransPrice2Dec(self.f5Q[self.fAryS5Q_P[aN - 1]])

    def Get_S5Q_P(self, aN: int):
        if self.f5Q == None:
            return 0
        dVal: decimal = 0
        dVal = self.TransPrice2Dec(self.f5Q[self.fAryS5Q_P[aN - 1]])
        return dVal

    def GetDply_S5Q_P(self, aN: int, aDg_tPrice: str = ""):
        if aN > self.fS5QCount:
            return ""
        elif self.f5Q == None:
            return ""
        else:
            dVal: decimal = 0
            dVal = self.TransPrice2Dec(self.f5Q[self.fAryS5Q_P[aN - 1]])
            return self.TransPrice2Str(dVal, aDg_tPrice)

    def S5Q_QOrg(self, aN: int):
        "賣5檔-量-的原始字串內容 aN:5檔中的第幾檔(1~10)"
        if aN > self.fS5QCount:
            return ""
        elif self.f5Q == None:
            return ""
        else:
            return self.f5Q[self.fAryS5Q_Q[aN - 1]]

    def Set_S5Q_Q(self, aN: int):
        "取得賣5檔-量 aN:5檔中的第幾檔(1~10)"
        if aN > self.fS5QCount:
            return 0
        elif self.f5Q == None:
            return 0
        else:
            return self.TransToInt(self.f5Q[self.fAryS5Q_Q[aN - 1]])

    def Get_S5Q_Q(self, aN: int):
        iVal: int = 0
        iVal = self.Set_S5Q_Q(aN)
        return str(iVal)

    # endregion
    def Handle_5Q(self, aData: str):
        self.f5Q = aData.split('|')
        self.SetData()

    def SetData(self):
        self.SolICE = self.f5Q[0]
        self.DataTime = self.f5Q[2]
        self.QtSrc = self.f5Q[3]

    def __init__(self) -> None:
        pass

    def __str__(self) -> str:
        return f"SolICE:{self.SolICE} DataTime:{self.DataTime} QtSrc:{self.QtSrc} f5Q:{self.f5Q}"
class TOvsFutQuoteData:
    SolIce: str = ""

    ProdKind: TOvsFutProdKind = TOvsFutProdKind.pkNone

    BAS: TOvsFutQtBase = None
    QtTX: TOvsFutQtTX = None
    Qt5Q: TOvsFutQt5Q = None

    def __init__(self, enu: TOvsFutProdKind, aSolIce: str, aCalcHightLowPrice: bool):
        "aCalcHightLowPrice:是否需要計算最高最低價"
        self.SolIce = aSolIce
        self.ProdKind = enu
        self._lock = Lock()
        if enu == TOvsFutProdKind.pkNormal:  # 一般期貨
            self.BAS = TOvsFutQtBase()
            self.QtTX = TOvsFutQtTX(aCalcHightLowPrice)
            self.Qt5Q = TOvsFutQt5Q()
        elif enu == TOvsFutProdKind.pkIndex:  # 指數商品
            pass

    def SetDataInit(self):
        "此Function在回補資料回來後,才會執行"
        if self.ProdKind == TOvsFutProdKind.pkNormal:
            self.QtTX.DecimalMultiply = self.BAS.DecimalMultiply
            self.Qt5Q.DecimalMultiply = self.BAS.DecimalMultiply
            self.QtTX.Price_Denominator = self.BAS.Price_Denominator
            self.Qt5Q.Price_Denominator = self.BAS.Price_Denominator

class TMapOvsFutQuoteData(UserDict):
    "Dictionary<string, TOvsFutQuoteData>"
    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        self.MapQtProc = {}
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

class TObjOvsFutQuoteMap(UserDict):
    # 預設行情解析proc
    DefProc_TX: callable = None  # PROC_Handle_OvsFutRTQuote
    "成交行情解析proc"
    DefProc_5Q: callable = None  # PROC_Handle_OvsFutRTQuote
    "五檔行情解析proc"

    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )

        # public Dictionary<string, PROC_Handle_OvsFutRTQuote> MapQtProc = new Dictionary<string, PROC_Handle_OvsFutRTQuote>();
        self.MapQtProc = {}
        "各商品拆解行情proc(EX:NQ的TX與5Q, 行情拆解,是不同Proc)"
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddRcvData(self, aSolIce: str, aData: str, aCalcHightLowPrice: bool):
        """aCalcHightLowPrice:是否需要計算最高最低價
            return  1.bool
                    2.TOvsFutQuoteData tmpQt
                    3.string aErrMsg          """

        aErrMsg = ""
        tmpQt: TOvsFutQuoteData = None
        try:
            map = json.loads(aData)
            # region 檢核
            if "status" in map and len(map["status"]) > 0:
                if map["status"][0] == "error":
                    aErrMsg = f"[海期][AddRcvData](aSolIce={aSolIce}, aData={aData})行情回補資料有誤!"
                    return False, tmpQt, aErrMsg
            if "BAS" in map and len(map["BAS"]) == 0:
                aErrMsg = f"[海期][AddRcvData](aSolIce={aSolIce}, aData={aData})沒有BAS資料!"
                return False, tmpQt, aErrMsg
            # endregion

            if self.data.get(aSolIce) is None:
                tmp = TOvsFutQuoteData(
                    TOvsFutProdKind.pkNormal, aSolIce, aCalcHightLowPrice)
                tmp.BAS.Handle_BAS(map["BAS"][0])
                # tmp.HL.Handle_HL(map["HL"][0]);
                tmp.SetDataInit()
                tmpQt = tmp
                self[aSolIce] = tmp
                return True, tmpQt, ""
            else:
                tmp: TOvsFutQuoteData = self[aSolIce]
                with tmp._lock:
                    tmp.BAS.Handle_BAS(map["BAS"][0])
                    # tmp.HL.Handle_HL(map["HL"][0])
                    tmp.SetDataInit()
                    tmpQt = tmp
                return True, tmpQt, ""
        except Exception as ex:
            aErrMsg = f"[海期][AddRcvData](aSolIce={aSolIce}, aData={aData}){ex}"
        return False, tmpQt, aErrMsg

    def AddData(self, enu: TOvsFutProdKind, aSolIce: str, aCalcHightLowPrice: bool, aTopic: str, aProc: callable):
        """ aCalcHightLowPrice:是否需要計算最高最低價
            aTopic:EX:Quote/TWF/IDX/TAIWANVIX/MR
            aProcTX:拆解行情的function PROC_Handle_OvsFutRTQuote
        """
        try:
            if self.data.get(aSolIce) is None:
                tmp = TOvsFutQuoteData(enu, aSolIce, aCalcHightLowPrice)
                self[aTopic] = tmp

                if self.MapQtProc.get(aTopic) is None:
                    self.MapQtProc[aTopic] = aProc

                return True
            else:
                return True
        except Exception as ex:
            pass
        return False

    def AddDataBySolIce(self, aIsCat:bool, aSolIce:str, map, aCalcHightLowPrice:bool):
        """aIsCat:是否為分類訂閱, aSolIce:EX:NQ.202202, aCalcHightLowPrice:是否計算最高低價    
            aTopicTX:QuoteOvs/交易所/FUT/NQ.202212/TX
            aTopic5Q:QuoteOvs/交易所/FUT/NQ.202212/5Q
            aTopicHL:QuoteOvs/交易所/FUT/NQ.202212/HL
            return  1.bool
                    2.TMapOvsFutQuoteData aQtMap
                    3.aErrMsg
        """
        aErrMsg = ""
        aQtMap:TOvsFutQuoteData = None
        try:
            #region 拆解基本資料
            aQtMap = TMapOvsFutQuoteData()
            for str in map["BAS"]:     
                tmpBAS = TOvsFutQtBase()
                tmpBAS.Handle_BAS(str)

                if aQtMap.data.get(tmpBAS.Symbol):                
                    tmpQt = TOvsFutQuoteData(TOvsFutProdKind.pkNormal, tmpBAS.Symbol, aCalcHightLowPrice)
                    tmpQt.BAS = tmpBAS
                    tmpQt.SetDataInit()

                    sTopicTX = tmpQt.BAS.TopicTX#成交
                    sTopic5Q = tmpQt.BAS.Topic5Q#五檔

                    self[sTopicTX] = tmpQt
                    self[sTopic5Q] = tmpQt
                    
                    if self.MapQtProc.get(sTopicTX) is None:
                        self.MapQtProc[sTopicTX]= self.DefProc_TX
                    if self.MapQtProc.get(sTopic5Q) is None:
                        self.MapQtProc[sTopic5Q]= self.DefProc_5Q

                    aQtMap.Add(tmpBAS.Symbol, tmpQt)
            return len(aQtMap) > 0, aQtMap, aErrMsg      
            #endregion 拆解基本資料
        except Exception as ex:
            aErrMsg = f"[海期][AddDataBySolIce](aIsCat={aIsCat}, aSolIce={aSolIce}){ex}"
        return False, aQtMap, aErrMsg

    def GetItem_BySolIce(self, aSolIce: str):
        """ 1.bool
            2. List<string> aTopicList
            3. string aErrMsg"""

        aErrMsg: str = ""
        aTopicList = None
        try:
            retlist = []
            for key, val in self.items():
                OvsFutdat: TOvsFutQuoteData = val
                if OvsFutdat.SolIce == aSolIce:
                    retlist.append(key)

            aTopicList = retlist
            if aTopicList is None or len(aTopicList) == 0:
                aErrMsg = f"[海期][GetItem_BySolIce](aSolIce={aSolIce})商品已不存存!"
                return False, aTopicList, aErrMsg
            return True, aTopicList, aErrMsg
        except Exception as ex:
            aErrMsg = f"[海期][GetItem_BySolIce](aSolIce={aSolIce}){ex}"
        return False, aTopicList, aErrMsg
    def GetItem_ByExchange(self, aExchange:str):
        """out List<string> aTopicList, out string aErrMsg"""
        aErrMsg = ""
        aTopicList = None
        try: 
            retlist = []
            for key, val in self.items():
                OvsFutdat: TOvsFutQuoteData = val
                if OvsFutdat.BAS.Exchange == aExchange:
                    retlist.append(key)
                aTopicList = retlist
            if aTopicList is None or len(aTopicList) == 0:
                aErrMsg = f"[海期][GetItem_ByExchange](aExchange={aExchange})商品已不存存!"
                return False, aTopicList, aErrMsg
                
            return True, aTopicList, aErrMsg
            
        except Exception as ex:
            aErrMsg = f"[海期][GetItem_ByExchange](aExchange={aExchange}){ex}"
        return False, aTopicList, aErrMsg
        

# region 商品檔查詢

class TObjOvsFutProdMthMap(UserDict):
    """Dictionary<string, TObjOvsFutMthList>
    期貨商品(Key=ProdID, Value=商品Base)(EX:Key=NQ, Value=NQ可交易月份們)"""

    def __init__(self, aExchange: str, aExchangeName: str):
        self.Exchange = aExchange
        self.ExchangeName = aExchangeName
        mapping = {}
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem(self, tmpBAS: TOvsFutQtBase):
        if self.data.get(tmpBAS.ProdID) is None:
            OvsFutlist = TObjOvsFutMthList(tmpBAS.ProdID, tmpBAS.FutName)
            OvsFutlist.AddItem(tmpBAS)
            self[tmpBAS.ProdID] = OvsFutlist
        else:
            OvsFutlist: TObjOvsFutMthList = self[tmpBAS.ProdID]
            OvsFutlist.AddItem(tmpBAS)

class TObjOvsFutMthList(UserDict):
    """SortedList<string, TObjOvsFutBasMap>
        Key=交割月"""

    def __init__(self, aProdID: str, aProdName: str):
        self.ProdID = aProdID
        self.ProdName = aProdName
        mapping = {}
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem(self, tmpBAS: TOvsFutQtBase):
        if self.data.get(tmpBAS.SettleMth) is None:
            OvsFut: TObjOvsFutBasMap = TObjOvsFutBasMap(tmpBAS.SettleMth)
            OvsFut.AddItem(tmpBAS)
            self[tmpBAS.SettleMth] = OvsFut
        else:
            OvsFut: TObjOvsFutBasMap = self[tmpBAS.SettleMth]
            OvsFut.AddItem(tmpBAS)
        self.data = dict(sorted(self.data.items()))  # sort itself

class TObjOvsFutBasMap(UserDict):
    "Dictionary<string, TOvsFutQtBase> Key=Symbol, Value=商品基本檔 "

    def __init__(self, aSettleMth: str):
        self.SettleMth = aSettleMth
        mapping = {}
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem(self, tmpBAS: TOvsFutQtBase):
        if self.data.get(tmpBAS.SolICE) is None:
            self[tmpBAS.SolICE] = tmpBAS

class TObjBaseOvsFutExchageTree(UserDict):
    """Dictionary<string, TObjOvsFutProdMthMap>
    海期商品及月份之樹狀(Key1=Exchange, Key2=ProdID, Key3=交割月) """
    fProdMthList: TObjOvsFutProdMthMap = TObjOvsFutProdMthMap("", "")
    "Key=ProdID, Values=可交易月份們"
    # Dictionary<string, TOvsFutQtBase> fMapSolICE = new Dictionary<string, TOvsFutQtBase>();//Key=SolICE
    fMapSolICE = {}
    "Key=SolICE Dictionary<string, TOvsFutQtBase>()"

    def __init__(self):
        mapping = {}
        super().__init__(mapping)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)

    def AddItem(self, tmpBAS: TOvsFutQtBase):
        if self.data.get(tmpBAS.Exchange) is None:
            OvsFutProdMthMap = TObjOvsFutProdMthMap(
                tmpBAS.Exchange, tmpBAS.ExchangeName)
            self[tmpBAS.Exchange] = OvsFutProdMthMap
        else:
            OvsFutProdMthMap: TObjOvsFutMthList = self[tmpBAS.Exchange]
            OvsFutProdMthMap.AddItem(tmpBAS)

    def SetInit(self):
        try:
            #紀錄一份, 方便用ProdID找尋
            for mapProd in self.values():  # values => TObjOvsFutProdMthMap
                prod: TObjOvsFutProdMthMap
                prod = mapProd
                # tmpProd => TObjOvsFutMthList
                tmpProd: TObjOvsFutMthList = next(
                    iter(prod.values()), None)  # values => TObjOvsFutMthList

                if tmpProd.ProdID in self.fProdMthList:  # Key = ProdID
                    continue
                # 月份們 fProdMthList->TObjOvsFutProdMthMap
                # Key=交割月 TObjOvsFutMthList : SortedList<string, TObjOvsFutBasMap>
                self.fProdMthList[tmpProd.ProdID] = tmpProd

                for o in tmpProd.values():  # values => TObjOvsFutBasMap
                    for v in o.values():  # values => TOvsFutQtBase
                        self.fMapSolICE[v.SolICE] = v
        except Exception as ex:
            pass

    def GetItem_BySolICE(self, aSolIce: str):
        """return   1.bool
                2.out TOvsFutQtBase tmpBAS"""
        tmpBAS = None
        try:
            if self.fMapSolICE.get(aSolIce) is not None:
                tmpBAS = self.fMapSolICE[aSolIce]
                return True, tmpBAS
        except Exception as ex:
            pass
        return False, tmpBAS

    def IsExists(self, aProdID: str, aMth: str):
        try:
            if self.fProdMthList.get(aProdID) is not None:
                if aMth in self.fProdMthList[aProdID]:
                    return True
        except Exception as ex:
            pass
        return False

    def GetExchangeAndProdList(self):
        """return   1. SortedList<string, string> aExchangeList
                    2. SortedList<string, TObjOvsFutMthList> aProdList
        """
        aExchangeList = {}  # new SortedList<string,string>();
        aProdList = {}  # new SortedList<string, TObjOvsFutMthList>();
        try:

            for mapProd in self.values():
                aExchangeList[mapProd.Exchange] = mapProd.ExchangeName
                for mapMthBas in mapProd.Values:
                    aProdList[mapMthBas.ProdName] = mapMthBas
            return True, aExchangeList, aProdList

        except Exception as ex:
            pass
        return False, aExchangeList, aProdList


class ITQtRcvEventData:
    SolIce: str
    IsOK: bool
    tmpRcvKind: TOvsFutQtRcvKind
    tmpQt: TOvsFutQuoteData

class TQtRcvEventData(ITQtRcvEventData):
    def __init__(self) -> None:
        self.SolIce = ""
        self.IsOK = False
        self.tmpQt = None
        super().__init__()

    def SetRcvBAS_Succ(self, aSolIce: str, tmpQt: TOvsFutQuoteData):
        self.IsOK = True
        self.SolIce = aSolIce
        self.tmpRcvKind = TOvsFutQtRcvKind.pkQtRcv_BAS
        self.tmpQt = tmpQt

    def SetRcvBAS_Fail(self, aSolIce: str):
        self.IsOK = False
        self.SolIce = aSolIce
        self.tmpRcvKind = TOvsFutQtRcvKind.pkQtRcv_BAS
# endregion 商品檔查詢
# endregion OvsFUT

# Inner classes for error handling
class ServiceEventHandler(ReconnectionListener, ReconnectionAttemptListener, ServiceInterruptionListener):
    def __init__(self, callbackInterrupt:callable) -> None:
        self._callbackInterrupt = callbackInterrupt
        super().__init__()

    def on_reconnected(self, e: ServiceEvent):
        print("\non_reconnected")
        print(f"Error cause: {e.get_cause()}")
        print(f"Message: {e.get_message()}")
    
    def on_reconnecting(self, e: "ServiceEvent"):
        print("\non_reconnecting")
        print(f"Error cause: {e.get_cause()}")
        print(f"Message: {e.get_message()}")

    def on_service_interrupted(self, e: "ServiceEvent"):
        #print("\non_service_interrupted")
        #print(f"Error cause: {e.get_cause()}")
        #print(f"Message: {e.get_message()}")
        self._callbackInterrupt(f"Error cause: {e.get_cause()} Message: {e.get_message()}")

class TerminationNotificationHandler(TerminationNotificationListener):
    def __init__(self, callbackfunc:callable) -> None:
        self._callbackfunc = callbackfunc
        super().__init__()
    def on_termination(self, event: 'TerminationNotificationEvent'):
        #print(f"Error cause:{event.cause()} Message:{event.message}")
        self._callbackfunc(f"Error cause:{event.cause()} Message:{event.message}")        

class TCacheJobMap(UserDict):
    """Dictionary<long, TCacheJob>"""
    _Lock = Lock()
    def __init__(self, mapping=None, **kwargs):
        if mapping is not None:
            mapping = {
                str(key).upper(): value for key, value in mapping.items()
            }
        else:
            mapping = {}
        if kwargs:
            mapping.update(
                {str(key).upper(): value for key, value in kwargs.items()}
            )
        super().__init__(mapping)    

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
    
    
    def IsExists(self, aRequestID)->bool:        
        with self._Lock:
            if self.data.get(aRequestID) is None:
                return False
            else:
                return True        
        
    def AddRcvData(self, msg:'InboundMessage')->bool:#IMessage
        
        with self._Lock:    
            if self.data.get(msg.get_cache_request_id()) is None:
                return False
            else:
                self.data[msg.get_cache_request_id()] = msg                
                return True
        
    def DeleteJob(self, aRequestID)->bool:
        """out TCacheJob job"""
        job = None
        with self._Lock:
            if self.data.get(aRequestID) is None:
                return False, None
            else:                            
                job = self.data.pop(aRequestID)                
                return True, job

class TCacheJob:
    
    def __init__(self) -> None:
        self.RequestID:int = 0
        self.prod:str=""
        self.oneProd:bool = True
        self.getcache = False
        self.TopicBAS:str=""
        self.TopicHL:str=""
        self.TopicTX:str=""        
        self.Topic5Q:str=""
        self.Topic5QTOT:str=""
        self.HandleProc:callable = None #PROC_Handle_CacheRcv
        self.CacheData:dict = {}#new List<IMessage>() #public List<IMessage>
        self.Params:dict = {} #public Dictionary<string, dynamic> 
        
        self.fTotCnt = 10 #總次數
        self.fCurCnt = 0 #已執行次數
        
    def ReSet(self)->bool:
        """out string aErrMsg"""
        aErrMsg = ""
        if self.fCurCnt >= self.fTotCnt:        
            aErrMsg = f"已超過總執行次數:{self.fTotCnt}"
            return False, aErrMsg        
        
        self.fCurCnt+=1
        # self.CacheData.clear()

        return True, ""
        

class SolAPI:
    _fPrdSnapshotMap:TMapPrdSnapshot = TMapPrdSnapshot()
    _fPrdOvsMap:TMapPrdOvs = TMapPrdOvs()    
    _fMapQuoteSTK: TObjStkQuoteMap = TObjStkQuoteMap()
    _fMapQuoteFUT: TObjFutQuoteMap = TObjFutQuoteMap()
    _fMapQuoteOvsFUT: TObjOvsFutQuoteMap = TObjOvsFutQuoteMap()
    def __init__(self, __mdm:MarketDataMart, pypath:str, aRcvUseList:bool=False, loglv = logging.INFO, conlv = logging.INFO):
        """aRcvUseList: true:回補資料, 一次使用回來(註:EVENT請務必要接OnUpdateBasicList); false:回補資料, 一筆一筆傳回"""    
        self.__fWorkThr_HandleQuote = None
        self.__fWorkThr_HandleRcvQuote = None
        self.__fWorkThr_SolaceSubTopic = None
        self.__fWorkThr_SolaceUnSubTopic = None
        self.__fRcvUseList = aRcvUseList
        self.__mdm:MarketDataMart = __mdm
        self._pypath = pypath
        self._is_connected = False        
        self._lock = Lock()
        self._lockQtTX_Stk = Lock()
        self._lockQtTX_Fut = Lock()
        self._lockQtIDX_Stk = Lock()
        self._lockQtIDX_Fut = Lock()
        self._fMapQuoteSTK.DefProc_TX = self.__Handle_RTQuote_TXSTK
        self._fMapQuoteSTK.DefProc_5Q = self.__Handle_RTQuote_5QSTK
        self._fMapQuoteSTK.DefProc_Idx = self.__Handle_RTQuote_IDXSTK
        self.__OnQtRcvEventSTK = self.__SolQuoteStkAPI_OnQtRcvEvent #行情回補
        self.__OnQtIdxRcvEventSTK = self.__SolQuoteStkAPI_OnQtIdxRcvEvent #回補(指數)
        self.__OnQtTXEventSTK = self.__SolQuoteStkAPI_OnQtTXEvent #即時成交(一般證券)
        self.__OnQt5QEventSTK = self.__SolQuoteStkAPI_OnQt5QEvent #5檔行情(一般證券)
        self.__OnQtIDXEventSTK = self.__SolQuoteStkAPI_OnQtIDXEvent#指數行情(EX:VIX)
        self._fMapCacheJob = TCacheJobMap()
        self._last_ReqID = 0
        self._lock_ReqID = Lock()
        self._fMapQuoteFUT.DefProc_TX = self.__Handle_RTQuote_TXFUT
        self._fMapQuoteFUT.DefProc_5Q = self.__Handle_RTQuote_5QFUT
        self._fMapQuoteFUT.DefProc_5QTOT = self.__Handle_RTQuote_5QTOTFUT
        self._fMapQuoteFUT.DefProc_BAS = self.__Handle_RTQuote_BASFUT
        self.__OnQtRcvEventFUT = self.__SolQuoteFutApi_OnQtRcvEvent #行情回補
        self.__OnQtTXEventFUT = self.__SolQuoteFutApi_OnQtTXEvent #即時成交(一般期貨)
        self.__OnQt5QEventFUT = self.__SolQuoteFutApi_OnQt5QEvent #5檔行情(一般期貨)
        self.__OnQt5QTOTEventFUT = self.__SolQuoteFutApi_OnQt5QTOTEvent #累計買賣委託筆數、累計買賣委託合約數 行情(一般期貨)
        self.__OnQtIDXEventFUT = self.__SolQuoteFutApi_OnQtIDXEvent #指數行情(EX:VIX)
        self.__OnChangeMktStuEventFUT = self.__SolQuoteFutApi_OnChangeMktStuEvent #早午盤變更

        self._fMapQuoteOvsFUT.DefProc_TX = self.__Handle_RTQuote_TXOvsFUT
        self._fMapQuoteOvsFUT.DefProc_5Q = self.__Handle_RTQuote_5QOvsFUT
        self.__OnQtRcvEventOvsFUT = self.__SolQuoteOvsFutAPI_OnQtRcvEvent #行情回補
        self.__OnQtTXEventOvsFUT = self.__SolQuoteOvsFutAPI_OnQtTXEvent #即時成交(海外期貨)
        self.__OnQt5QEventOvsFUT = self.__SolQuoteOvsFutAPI_OnQt5QEvent #5檔行情(海外期貨)

        self._message_service: MessagingService
        self._message_receiver: DirectMessageReceiver
        self._message_requester: RequestReplyMessagePublisher
        self._loglv = loglv
        self._conlv = conlv
        self._log = SolaceLog(self._pypath, loglv, conlv)
        self._log.Add(arg1=SolLogType.Debug, arg2=f"pypath:{pypath}, aRcvUseList:{aRcvUseList}, loglv:{loglv} conlv:{conlv}") 
        self._reply_timeout = 120000  # unit ms
        self._vRcvTopic_Stk = "Quote_TWS_RECOVER"
        "證券回補TOPIC"
        self._vRcvTopic_Stk_Req = "Quote_TWS_REQ"
        "收到證券回補TOPIC"
        self._vRcvTopic_Fut = "Quote_TWF_RECOVER"
        "期貨回補TOPIC"
        self._vRcvTopic_Fut_Req = "Quote_TWF_REQ"
        "收到期貨回補TOPIC"
        self._vRcvTopic_OvsFut = "QuoteOvs_RECOVER"
        "海期貨回補TOPIC"
        self._vRcvTopic_OvsFut_Req = "QuoteOvs_REQ"        
        "收到海期貨回補TOPIC"
        self._vExchange = ""
        self.__vIdxTopic = "Idx"
        self._vQuote_FUT = "Quote/TWF/"  # 期貨
        self._vQuote_STK = "Quote/TWS/"  # 證券
        self._vQuote_OvsFUT = "QuoteOvs/"  # 期貨
        self._vQuote_BAS = "/BAS" 
        self._vQuote_HL = "/HL" 
        self._vQuote_TX = "/TX" 
        self._vQuote_5Q = "/5Q" 
        self._vQuote_5QTOT = "/5QTOT" 

    def GetRequestID(self):
        try:
            with self._lock_ReqID:
                res = int(datetime.now().strftime("%y%m%d%H%M%S%f"))
                if res <= self._last_ReqID:
                    res = self._last_ReqID + 1
                self._last_ReqID = res        
                return res        
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"Error GetRequestID: {ex}")
    # region 回補(一般證券)
    __OnQtRcvEventSTK: callable = None
    __OnQtRcvEventFUT: callable = None
    __OnQtRcvEventOvsFUT: callable = None
    def __Fire_OnQtRcv_OKEvent(self, stk: STKxFUT, par):
        """par: stk->
                fut->TFutQuoteData    """
        if stk == STKxFUT.STK:
            if self.__OnQtRcvEventSTK == None:
                return
            aQuoteData: TObjStkQuoteMap = par
            self.__OnQtRcvEventSTK("STK", True, aQuoteData)
        elif stk == STKxFUT.FUT:
            if self.__OnQtRcvEventFUT == None:
                return
            aQuoteData: TObjFutQuoteMap = par
            self.__OnQtRcvEventFUT("FUT", True, aQuoteData)
        elif stk == STKxFUT.OVSFUT:
            if self.__OnQtRcvEventOvsFUT == None:
                return
            aQuoteData: TQtRcvEventData = par
            if aQuoteData.IsOK:
                self.__OnQtRcvEventOvsFUT(
                    self, aQuoteData.SolIce, aQuoteData.IsOK, aQuoteData.tmpRcvKind, aQuoteData.tmpQt)
            else:
                self.__OnQtRcvEventOvsFUT(
                    self, aQuoteData.SolIce, aQuoteData.IsOK, aQuoteData.tmpRcvKind, None)
    def __Fire_OnQtRcv_FailEvent(self, stk: STKxFUT, aSolIce: str):
        if stk == STKxFUT.STK:
            if self.__OnQtRcvEventSTK == None:
                return
            self.__OnQtRcvEventSTK(aSolIce, False, None)
        elif stk == STKxFUT.FUT:
            if self.__OnQtRcvEventFUT == None:
                return
            self.__OnQtRcvEventFUT(aSolIce, False, None)
        elif stk == STKxFUT.OVSFUT:
            if self.__OnQtRcvEventOvsFUT == None:
                return
            pass
    # endregion 回補(一般證券)
    # region 回補(指數)
    __OnQtIdxRcvEventSTK: callable = None
    def Set_OnQtIdxRcvEventSTK(self, func: callable):
        self.__OnQtIdxRcvEventSTK = func
    def __Fire_OnQtIdxRcv_OKEvent(self, aQuoteData: TObjStkQuoteMap):
        if self.__OnQtIdxRcvEventSTK == None:
            return
        self.__OnQtIdxRcvEventSTK("STKIdx", True, aQuoteData)
    def __Fire_OnQtIdxRcv_FailEvent(self, aSolIce: str):
        if self.OnQtIdxRcvEvent == None:
            return
        self.OnQtIdxRcvEvent(self, aSolIce, False, None)
    # endregion 回補(指數)
    # region 即時成交
    # 即時成交(一般證券)
    __OnQtTXEventSTK: callable = None
    """QtTXEventHandler"""

    def Set_OnQtTXEventSTK(self, func: callable):
        self.__OnQtTXEventSTK = func

    def __Fire_QtTXEventSTK(self, aSolIce: str, tmpQtTx: TStkQtTX):
        if self.__OnQtTXEventSTK == None:
            return
        self.__OnQtTXEventSTK(aSolIce, tmpQtTx)

    def __SolQuoteFutApi_OnQtRcvEvent(self, aMsg:str, aIsOK:bool, aMapQt:TObjFutQuoteMap):
        "//行情回補(註:指數類沒有回補(EX:TAIWANVIX))"
        
        if aIsOK == False:
            self._log.Add(arg1=SolLogType.Info, arg2=f"[期貨行情回補]{aMsg}回補失敗!")
            return
        try:        
            for key, val in aMapQt.items():
                tmpQt:TFutQuoteData = val
                sSolIce = tmpQt.BAS.OrdProdID
                if self._fPrdSnapshotMap.NewItemFut(sSolIce, tmpQt):
                    # if self.__fRcvUseList == False:
                    prd:ProductSnapshot = self._fPrdSnapshotMap[sSolIce]
                    if tmpQt.UpdateBAS:
                        self.__mdm.Fire_OnUpdateBasic(prd.BasicData)
                        tmpQt.UpdateBAS = False
                    if tmpQt.UpdateHLTX:
                        prd.TickData = ProductTick_Fut(tmpQt)                        
                        prd.TickData.Upt_TX(tmpQt.QtTX)
                        prd.TickData.Upt_5Q(tmpQt.Qt5Q)   
                        prd.TickData.Upt_5QTOT(tmpQt.Qt5QTOT)
                        self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[sSolIce])
                        tmpQt.UpdateHLTX = False
            # if self.__fRcvUseList:
            #     if len(self._fPrdSnapshotMap) > 0:                
            #         ls = list(self._fPrdSnapshotMap.values())
            #         self.__mdm.Fire_OnUpdateProductBasicList(ls)            
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteFutApi_OnQtRcvEvent]aMsg={aMsg}, aIsOK={aIsOK}, ex:{ex}")        

    def __SolQuoteFutApi_OnQtTXEvent(self, aSolIce:str, tmpQtTx:TFutQtTX):
        "即時成交(一般期貨)"        
        try:        
            tmpPrd:ProductSnapshot = None

            ret, tmpPrd = self._fPrdSnapshotMap.GetItem(aSolIce)
            if ret:
                tmpTick:ProductTick_Fut = tmpPrd.TickData
                if tmpTick.Upt_TX(tmpQtTx):                
                    self.__mdm.Fire_OnMatch(self._fPrdSnapshotMap[aSolIce].TickData)
                    # self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[aSolIce])
        except Exception as ex:        
            self._log.Add(arg1=SolLogType.Error,arg2=f"[SolQuoteFutApi_OnQtTXEvent]ProdID={aSolIce}, ex:{ex}" )       
        
    def __SolQuoteFutApi_OnQt5QEvent(self, aSolIce:str, tmpQt5Q:TFutQt5Q):
        " 5檔行情(一般期貨)"
        try:        
            tmpPrd:ProductSnapshot = None

            ret, tmpPrd = self._fPrdSnapshotMap.GetItem(aSolIce)
            if ret:
                tmpTick:ProductTick_Fut = tmpPrd.TickData

                if tmpTick.Upt_5Q(tmpQt5Q):
                    self.__mdm.Fire_OnOrderBook(self._fPrdSnapshotMap[aSolIce].TickData)
                    # self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[aSolIce])            
        except Exception as ex:            
         self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteFutApi_OnQt5QEvent]ProdID={aSolIce}, ex:{ex}")
        
    def __SolQuoteFutApi_OnQt5QTOTEvent(self, aSolIce:str, tmpQt5QTOT:TFutQt5QTOT):
        "累計買賣委託筆數、累計買賣委託合約數 行情(一般期貨)"        
        try:
            tmpPrd:ProductSnapshot = None

            ret, tmpPrd = self._fPrdSnapshotMap.GetItem(aSolIce)
            if ret:
                tmpTick:ProductTick_Fut = tmpPrd.TickData

                if tmpTick.Upt_5QTOT(tmpQt5QTOT):
                    self.__mdm.Fire_OnUpdateTotalOrderQty(self._fPrdSnapshotMap[aSolIce].TickData)
                    # self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[aSolIce])
        except Exception as ex:            
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteFutApi_OnQt5QTOTEvent]ProdID={aSolIce}, ex:{ex}")
    def __SolQuoteFutApi_OnQtIDXEvent(self, aSolIce:str, tmpQtIDX:TFutQtIDX): #指數行情(EX:VIX)
        try:
            pass
            # //lock (tmpQtIDX)
            # //{
            # //    var tmp = new TIdxRec(tmpQtIDX);
            # //    fQtIdxList.Add(new TIdxRec(tmpQtIDX));
            # //}
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteFutApi_OnQtIDXEvent]ProdID={aSolIce}, ex:{ex}")
    def __SolQuoteFutApi_OnChangeMktStuEvent(self, aSolIce:str, tmpBAS:TFutQtBase):
        "早午盤變更"        
        try:
            pass
            # //StringBuilder sb = new StringBuilder();
            # //sb.AppendFormat("商品:{0}, ", aSolIce);
            # //sb.AppendFormat("盤別(0早/1午):{0}", tmpBAS.MktType);

            # //decimal dVal = 0m;
            # //tmpBAS.Set_RefPrice(ref dVal);//參考價
            # //sb.AppendFormat(", 參考價:{0}", dVal);

            # //tmpBAS.Set_LimitPrice_Up(ref dVal);//漲停價
            # //sb.AppendFormat(", 漲停價:{0}", dVal);

            # //tmpBAS.Set_LimitPrice_Down(ref dVal);//跌停價 
            # //sb.AppendFormat(", 跌停價:{0}", dVal);
            # //sb.AppendLine();

            # //ProcessLog(sb.ToString());        
        except Exception as ex:
            pass

    def __SolQuoteOvsFutAPI_OnQtRcvEvent(self, tmpRcvData:ITQtRcvEventData): #行情回補        
        if tmpRcvData == None:
            self._log.Add(arg1=SolLogType.Info,arg2=f"[海期行情回補] 回補失敗!")
            return
        if tmpRcvData.IsOK == False:
            self._log.Add(arg1=SolLogType.Info, arg2=f"[海期行情回補]{tmpRcvData.SolIce}回補失敗!")
            return
        try:
            if self._fPrdOvsMap.NewItem(tmpRcvData.QtMap):
                self.__mdm.Fire_OnUpdateOvsBasic(tmpRcvData.QtMap)
            
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteOvsFutAPI_OnQtRcvEvent]aSolIce={tmpRcvData.SolIce}, aIsOK={tmpRcvData.IsOK}, ex:{ex}")
    def __SolQuoteOvsFutAPI_OnQtTXEvent(self, aSolIce:str, tmpQtTx:TOvsFutQtTX):#即時成交(海外期貨)
        try:            
            tmpPrd:TOvsFutQuoteData = None

            ret, tmpPrd = self._fPrdOvsMap.GetItem(aSolIce)
            if ret:
                tmpPrd.QtTX = tmpQtTx
                self.__mdm.Fire_OnUpdateOvsMatch(tmpPrd)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteOvsFutAPI_OnQtTXEvent]ProdID={aSolIce}, ex:{ex}")
    def __SolQuoteOvsFutAPI_OnQt5QEvent(self, aSolIce:str, tmpQt5Q:TOvsFutQt5Q): #5檔行情(海外期貨)
        try:        
            tmpPrd:TOvsFutQuoteData = None

            ret, tmpPrd = self._fPrdOvsMap.GetItem(aSolIce)
            if ret:
                tmpPrd.Qt5Q = tmpQt5Q
                self.__mdm.Fire_OnUpdateOvsOrderBook(tmpPrd)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteStkAPI_OnQt5QEvent]ProdID={aSolIce}, ex:{ex}")
                     
        
    # 即時成交(一般期貨)
    __OnQtTXEventFUT: callable = None

    def Set_OnQtTXEventFUT(self, func: callable):
        self.__OnQtTXEventFUT = func

    def __Fire_QtTXEventFUT(self, aSolIce: str, tmpQtTx: TFutQtTX):
        if self.__OnQtTXEventFUT == None:
            return
        # self.__OnQtTXEventFUT(self, aSolIce, tmpQtTx)
        self.__OnQtTXEventFUT(aSolIce, tmpQtTx)

    # 即時成交(海期)
    __OnQtTXEventOvsFUT: callable = None

    def Set_OnQtTXEventOvsFUT(self, func: callable):
        self.__OnQtTXEventOvsFUT = func

    def __Fire_QtTXEventOvsFUT(self, aSolIce: str, tmpQtTx: TOvsFutQtTX):
        if self.__OnQtTXEventOvsFUT == None:
            return
        self.__OnQtTXEventOvsFUT(aSolIce, tmpQtTx)
    # endregion 即時成交
    # region 5檔行情
    # 5檔行情(一般證券)
    __OnQt5QEventSTK: callable = None
    """Qt5QEventHandler"""

    def Set_OnQt5QEventSTK(self, func: callable):
        self.__OnQt5QEventSTK = func

    def __Fire_Qt5QEventSTK(self, aSolIce: str, tmpQt5Q: TStkQt5Q):
        if self.__OnQt5QEventSTK == None:
            return
        self.__OnQt5QEventSTK(aSolIce, tmpQt5Q)

    # 5檔行情(一般期貨)
    __OnQt5QEventFUT: callable = None

    def Set_OnQt5QEventFUT(self, func: callable):
        self.__OnQt5QEventFUT = func

    def __Fire_Qt5QEventFUT(self, aSolIce: str, tmpQt5Q: TFutQt5Q):
        if self.__OnQt5QEventFUT == None:
            return
        # self.__OnQt5QEventFUT(self, aSolIce, tmpQt5Q)
        self.__OnQt5QEventFUT(aSolIce, tmpQt5Q)

    # 5檔行情(海期)
    __OnQt5QEventOvsFUT: callable = None

    def Set_OnQt5QEventOvsFUT(self, func: callable):
        self.__OnQt5QEventOvsFUT = func

    def __Fire_Qt5QEventOvsFUT(self, aSolIce: str, tmpQt5Q: TOvsFutQt5Q):
        if self.__OnQt5QEventOvsFUT == None:
            return
        self.__OnQt5QEventOvsFUT(self, aSolIce, tmpQt5Q)
    # endregion 5檔行情
    # region 累計買賣委託筆數、累計買賣委託合約數 行情(一般期貨)
    __OnQt5QTOTEventFUT: callable = None  # Qt5QTOTEventHandler

    def Set_OnQt5QTOTEventFUT(self, func: callable):
        self.__OnQt5QTOTEventFUT = func

    def __Fire_Qt5QTOTEventFUT(self, aSolIce: str, tmpQt5QTOT: TFutQt5QTOT):
        if self.__OnQt5QTOTEventFUT == None:
            return
        self.__OnQt5QTOTEventFUT(aSolIce, tmpQt5QTOT)
    # endregion 累計買賣委託筆數、累計買賣委託合約數 行情(一般期貨)
    # region 早午盤別變更
    __OnChangeMktStuEventFUT: callable = None  # ChangeMktStuEventHandler

    def Set_OnChangeMktStuEventFUT(self, func: callable):
        self.__OnChangeMktStuEventFUT = func

    def __Fire_ChangeMktStuEventFUT(self, aSolIce: str, tmpBAS: TFutQtBase):
        if self.__OnChangeMktStuEventFUT == None:
            return
        self.__OnChangeMktStuEventFUT(aSolIce, tmpBAS)
    # endregion 早午盤別變更
    # region 指數行情(EX:VIX)
    __OnQtIDXEventSTK: callable = None

    def Set_OnQtIDXEventSTK(self, func: callable):
        self.__OnQtIDXEventSTK = func

    def __Fire_QtIDXEventSTK(self, aSolIce: str, tmpQtIDX: TStkQtIDX):
        if self.__OnQtIDXEventSTK == None:
            return
        self.__OnQtIDXEventSTK(aSolIce, tmpQtIDX)
    __OnQtIDXEventFUT: callable = None

    def Set_OnQtIDXEventFUT(self, func: callable):
        self.__OnQtIDXEventFUT = func

    def __Fire_QtIDXEventFUT(self, aSolIce: str, tmpQtIDX: TFutQtIDX):
        if self.__OnQtIDXEventFUT == None:
            return
        self.__OnQtIDXEventFUT(aSolIce, tmpQtIDX)
    # endregion 指數行情(EX:VIX)
    # region Other Message
    __OnOtherMessageEvent: callable = None
    """OtherMessageEventHandler"""

    def Set_OnOtherMessageEvent(self, func: callable):
        self.__OnOtherMessageEvent = func

    def __Fire_OtherMessageEvent(self, aOtherMsg: str):
        if self.__OnOtherMessageEvent == None:
            return
        self.__OnOtherMessageEvent(aOtherMsg)
    # endregion Other Message
    # region Log messgae
    __OnLogEvent: callable = None
    """LogEventHandler"""
    __OnInterruptEvent:callable = None
    __OnTerminationEvent:callable = None

    def Set_OnLogEvent(self, func: callable):
        self.__OnLogEvent = func

    def __Fire_LogEvent(self, aMsg: str):
        if self.__OnLogEvent == None:
            return
        self.__OnLogEvent(aMsg)
    # endregion Log messgae
    def Set_OnInterruptEvent(self, func: callable):
        self.__OnInterruptEvent = func
    def __Fire_InterruptEvent(self, aMsg:str):
        if self.__OnInterruptEvent == None:
            return
        self.__OnInterruptEvent(aMsg)
    def Set_OnTerminationEvent(self, func:callable):
        self.__OnTerminationEvent = func
    def __Fire_TerminationEvent(self, aMsg:str):
        if self.__OnTerminationEvent == None:
            return
        self.__OnTerminationEvent(aMsg)
    def __DoSolaceConn(self, aSolConnData:TSolClientConnData) -> RCode:
        try:
            if self._is_connected:
                return RCode.OK
            if self._log._run == False:
                self._log = SolaceLog(self._pypath, self._loglv, self._conlve)
            self._log.Add(arg1=SolLogType.Info, arg2="DoSolaceConn")
            self.__DoRunThread()
            self._log.Add(arg1=SolLogType.Debug, arg2=f"host:{aSolConnData.Host} vpn:{aSolConnData.MessageVPN} username:{aSolConnData.Username} pwd:{aSolConnData.Password} cmplv:{aSolConnData.CompressLevel}")
            dicConn:dict={}
            dicConn["solace.messaging.transport.host"] = aSolConnData.Host
            dicConn["solace.messaging.service.vpn-name"] = aSolConnData.MessageVPN
            dicConn["solace.messaging.authentication.basic.username"] = aSolConnData.Username
            dicConn["solace.messaging.authentication.basic.password"] = aSolConnData.Password
            dicConn["solace.messaging.transport.compression-level"] = aSolConnData.CompressLevel
            #初次連線重連設定
            dicConn['solace.messaging.transport.connection-retries'] = 3
            dicConn['solace.messaging.transport.connection.retries-per-host'] = 4
            dicConn['solace.messaging.transport.connection-attempts-timeout'] = 30000 #ms
            #斷線重連次數
            dicConn['solace.messaging.transport.reconnection-attempts'] = 10
            dicConn['solace.messaging.transport.reconnection-attempts-wait-interval'] = 1000 #重連間隔ms                
            # spConn.ReapplySubscriptions = true; //斷線重連後要重新訂閱TOPIC
            # self._message_service = MessagingService.builder().from_properties(self._props_from_file).build()
            self._cacheReqOutListener = CacheReqOutListener(self, self.__fWorkThr_HandleQuote,self._log)
            self._message_service = MessagingService.builder().from_properties(dicConn).build()
            self._message_service.connect()               
            self._service_handler = ServiceEventHandler(self.__Fire_InterruptEvent)
            self._message_service.add_service_interruption_listener(self._service_handler)
            self._termination_handler = TerminationNotificationHandler(self.__Fire_TerminationEvent)           
            self._message_receiver = self._message_service.create_direct_message_receiver_builder().build()
            self._message_receiver.start()            
            self._message_receiver.receive_async(self.__fWorkThr_HandleQuote)
            self._message_receiver.set_termination_notification_listener(self._termination_handler)
            self._direct_publish_service = self._message_service.create_direct_message_publisher_builder().build()
            self._message_requester = self._message_service.request_reply(
            ).create_request_reply_message_publisher_builder().build().start()
            self._is_connected = self._message_service.is_connected
            if self._is_connected:
                return RCode.OK
            else:
                return RCode.FAIL
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"DoSolaceConn error: {ex}")
            return RCode.FAIL

    def Connect(self, host:str, vpn:str, username:str, password:str, aCompressLevel:int=0):
        aSolConnData:TSolClientConnData = TSolClientConnData()
        aSolConnData.Host = host
        aSolConnData.MessageVPN = vpn
        aSolConnData.Username = username
        aSolConnData.Password = password
        aSolConnData.CompressLevel = aCompressLevel
        return self.__DoSolaceConn(aSolConnData)
    
    def IsConnect(self):
        return self._message_service.is_connected
    
    def DisConnect(self) -> RCode:        
        if self._is_connected:
            start = time.time() 
            while (True):
                empsub = self.__fWorkThr_SolaceSubTopic._queue.empty()
                empunsub = self.__fWorkThr_SolaceUnSubTopic._queue.empty()
                if empsub and empunsub:
                    sleep(2)#緩衝兩秒確定topic都處理完成
                    with self._lock:
                        if hasattr(self, '_message_service') and self._is_connected:
                            self._message_receiver.terminate()
                            self._message_requester.terminate()
                            self._message_service.disconnect()
                        self._is_connected = False
                    break
                end = time.time()
                duration = end - start
                if duration > 30:# >20sec都無法等到sub跟unsub都沒有queue在disconnect
                    with self._lock:
                        if hasattr(self, '_message_service') and self._is_connected:
                            self._message_receiver.terminate()
                            self._message_requester.terminate()
                            self._message_service.disconnect()
                        self._is_connected = False
                    break
        self.__DoCloseThread()
        if self._log._run:
            self._log.Wrtie_log(SolLogType.Info, "DisConnect")
            self._log._run = False
        return RCode.OK
#  /// <summary>即時資料</summary>

# region 行情解析    
    def __Handle_RTQuote_Main(self, msg):
        """receive data from solace"""
        data: str = ""
        try:
            #region 回補結束
            if isinstance(msg, int):#handle cache job data 回補結束
                reqID:int = msg             
                job_new = self._fMapCacheJob.get(reqID)
                if job_new is None:                    
                    self._log.Add(arg1=SolLogType.Warning, arg2=f"[handle cache job data 回補結束]reqID={msg}")
                else:                    
                    ret, job = self._fMapCacheJob.DeleteJob(reqID)
                    if ret:
                        job.HandleProc(job)               
                return           
            #endregion 回補結束                
            message_type=msg.get_cache_status()
            data = msg.get_payload_as_bytes().decode('utf-8')
            if len(data) == 0:
                return
            msg_destname:str = msg.get_destination_name()            
            #region cache data
            if message_type.value == message_type.CACHED.value:                
                job: TCacheJob = self._fMapCacheJob[msg.get_cache_request_id()]
                if job is not None:
                    if job.oneProd:#單一商品
                        if job.getcache:
                            return
                        job.getcache = True
                        arr = msg_destname.split("/")
                        if msg_destname.endswith(self._vQuote_BAS):
                            arr[len(arr)-1] = "HL"
                            job.TopicHL = "/".join(arr)
                            arr[len(arr)-1] = "TX"
                            job.TopicTX = "/".join(arr)      
                            arr[len(arr)-1] = "5Q"
                            job.Topic5Q = "/".join(arr)                         
                            job.CacheData[msg_destname] = msg                            
                            self._fMapCacheJob[msg.get_cache_request_id()] = job
                            if job.CacheData.get(job.TopicHL) is None:
                                jobHL = TCacheJob()
                                jobHL.prod = arr[len(arr)-2]
                                jobHL.TopicBAS = job.TopicBAS
                                jobHL.TopicHL = job.TopicHL
                                jobHL.TopicTX = job.TopicTX
                                jobHL.Topic5Q = job.Topic5Q                                 
                                jobHL.RequestID = self.GetRequestID()
                                if msg_destname.startswith(self._vQuote_STK):
                                    jobHL.HandleProc = self.__Handle_RTQuote_STK_HL
                                elif msg_destname.startswith(self._vQuote_FUT):
                                    jobHL.HandleProc = self.__Handle_RTQuote_FUT_HL
                                self._fMapCacheJob[jobHL.RequestID] = jobHL
                                self.__SolcacheReq_as_available(jobHL.RequestID, jobHL.TopicHL)
                        elif msg_destname.endswith(self._vQuote_HL):
                            job.CacheData[job.TopicHL] = msg
                            self._fMapCacheJob[msg.get_cache_request_id()] = job
                        elif msg_destname.endswith(self._vQuote_TX):
                            job.CacheData[job.TopicTX] = msg
                            self._fMapCacheJob[msg.get_cache_request_id()] = job
                        elif msg_destname.endswith(self._vQuote_5Q):
                            job.CacheData[job.Topic5Q] = msg
                            self._fMapCacheJob[msg.get_cache_request_id()] = job
                        elif msg_destname.endswith(self._vQuote_5QTOT):
                            job.CacheData[job.Topic5QTOT] = msg
                            self._fMapCacheJob[msg.get_cache_request_id()] = job
                        self.__fWorkThr_HandleQuote.Add(msg.get_cache_request_id())
                    else:#Category subcribe
                        arr:list = msg_destname.split('/')
                        prod_get = arr[len(arr)-2] #商品黨名稱
                        if msg_destname.endswith(self._vQuote_BAS):
                            job_new = TCacheJob()
                            job_new.prod = prod_get
                            job_new.TopicBAS = msg_destname
                            job_new.RequestID = self.GetRequestID()
                            if msg_destname.startswith(self._vQuote_STK):
                                job_new.HandleProc = self.__Handle_CacheJob_StkBAS
                            elif msg_destname.startswith(self._vQuote_FUT):
                                job_new.HandleProc = self.__Handle_CacheJob_FutBAS
                            job_new.CacheData[msg_destname] = msg
                            self._fMapCacheJob[job_new.RequestID] = job_new
                            self.__fWorkThr_HandleQuote.Add(job_new.RequestID)
                        elif msg_destname.endswith(self._vQuote_HL):
                            job_new = TCacheJob()
                            job_new.prod = prod_get                               
                            arr[len(arr)-1] = "TX"
                            job_new.TopicTX = "/".join(arr)
                            job_new.TopicHL = msg_destname
                            job_new.RequestID = self.GetRequestID()
                            if msg_destname.startswith(self._vQuote_STK):
                                job_new.HandleProc = self.__Handle_RTQuote_STK_HL
                            elif msg_destname.startswith(self._vQuote_FUT):
                                job_new.HandleProc = self.__Handle_RTQuote_FUT_HL                            
                            job_new.CacheData[msg_destname] = msg
                            self._fMapCacheJob[job_new.RequestID] = job_new                            
                            self.__fWorkThr_HandleQuote.Add(job_new.RequestID)                        
                else:#if job is not None:
                    self.__Fire_LogEvent(f"[cache job is none]dest={msg_destname}")
                    self._log.Add(arg1=SolLogType.Warning, arg2=f"[cache job is none]dest={msg_destname}")
                return
            #endregion cache data
            if msg_destname.startswith(self._vQuote_STK):
                tmpQt = self._fMapQuoteSTK.get(msg_destname)
                if tmpQt:
                    self._fMapQuoteSTK.MapQtProc[msg_destname](tmpQt, data, msg)
            elif msg_destname.startswith(self._vQuote_FUT):
                tmpQt = self._fMapQuoteFUT.get(msg_destname)
                if tmpQt:
                    self._fMapQuoteFUT.MapQtProc[msg_destname](tmpQt, data, msg)
            elif msg_destname.startswith(self._vQuote_OvsFUT):
                tmpQt = self._fMapQuoteOvsFUT.get(msg_destname)
                if tmpQt:
                    self._fMapQuoteOvsFUT.MapQtProc[msg_destname](tmpQt, data, msg)
        except Exception as ex:
            if isinstance(msg, int):
                self.__Fire_LogEvent(
                    f"[證][Solace_ReceiveSolaceTopic]aTopic={msg}, except={ex}")
                self._log.Add(arg1=SolLogType.Error,
                            arg2=f"[證][Solace_ReceiveSolaceTopic]aTopic={msg}, except={ex}")
            else:
                self.__Fire_LogEvent(
                    f"[證][Solace_ReceiveSolaceTopic]aTopic={msg.get_destination_name()}, aData={data}, except={ex}")
                self._log.Add(arg1=SolLogType.Error,
                            arg2=f"[證][Solace_ReceiveSolaceTopic]aTopic={msg.get_destination_name()}, aData={data}, except={ex}")

    def __Handle_RTQuote_TXSTK(self, tmpQt: TStkQuoteData, aData: str, msg: 'InboundMessage'):
        """//拆解:即時成交(一般證券) return :InboundMessage msg"""
        # self._log.Add(arg1=SolLogType.Info, arg2=f"Handle_RTQuote_TXSTK tmpQt:{tmpQt} aData:{aData}")
        try:
            with tmpQt._lock:
                # if msg.CacheRequestId.Equals(self.vRealTime):
                tmpQt.QtTX.Handle_TX(aData)  # //處理即時
                # else:
                #     tmpQt.QtTX.Handle_TXRcv(aData)#//處理回補
            self.__Fire_QtTXEventSTK(tmpQt.SolIce, tmpQt.QtTX)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_TXSTK:{ex}")

    def __Handle_RTQuote_TXFUT(self, tmpQt: TFutQuoteData, aData: str, msg: 'InboundMessage'):
        """//拆解:即時成交(一般期貨) return :InboundMessage msg"""
        try:
            with tmpQt._lock:
                # if msg.CacheRequestId.Equals(self.vRealTime):
                tmpQt.QtTX.Handle_TX(aData)  # //處理即時
                # else:
                #     tmpQt.QtTX.Handle_TXRcv(aData)#//處理回補
            self.__Fire_QtTXEventFUT(tmpQt.SolIce, tmpQt.QtTX)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_TXFUT:{ex}")

    def __Handle_RTQuote_TXOvsFUT(self, tmpQt: TOvsFutQuoteData, aData: str, msg: 'InboundMessage'):
        "拆解:即時成交(一般期貨)"
        try:
            with tmpQt._lock:
                tmpQt.QtTX.Handle_TX(aData)  # 處理即時

            self.__Fire_QtTXEventOvsFUT(tmpQt.SolIce, tmpQt.QtTX)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_TXOvsFUT:{ex}")

    def __Handle_RTQuote_5QSTK(self, tmpQt: TStkQuoteData, aData: str, msg: 'InboundMessage'):
        """//拆解:5檔行情(一般證券)"""
        try:
            with tmpQt._lock:
                tmpQt.Qt5Q.Handle_5Q(aData)
            self.__Fire_Qt5QEventSTK(tmpQt.SolIce, tmpQt.Qt5Q)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_5QSTK:{ex}")

    def __Handle_RTQuote_5QFUT(self, tmpQt: TFutQuoteData, aData: str, msg: 'InboundMessage'):
        """//拆解:5檔行情(一般期貨)"""
        try:
            with tmpQt._lock:
                tmpQt.Qt5Q.Handle_5Q(aData)
            self.__Fire_Qt5QEventFUT(tmpQt.SolIce, tmpQt.Qt5Q)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_5QFUT:{ex}")

    def __Handle_RTQuote_5QOvsFUT(self, tmpQt: TOvsFutQuoteData, aData: str, msg: 'InboundMessage'):
        try:
            with tmpQt._lock:
                tmpQt.Qt5Q.Handle_5Q(aData)
            self.__Fire_Qt5QEventOvsFUT(tmpQt.SolIce, tmpQt.Qt5Q)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_5QOvsFUT:{ex}")

    def __Handle_RTQuote_IDXSTK(self, tmpQt: TStkQuoteData, aData: str, msg: 'InboundMessage'):
        """//拆解:指數(EX:加權指數)"""
        try:
            with tmpQt._lock:
                # if msg.CacheRequestId.Equals(self.vRealTime):
                tmpQt.QtIDX.Handle_IDX(aData)  # 處理即時
                # else:
                #     tmpQt.QtIDX.Handle_IDXRcv(aData)#處理回補
            self.__Fire_QtIDXEventSTK(tmpQt.SolIce, tmpQt.QtIDX)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_IDXSTK:{ex}")

    def __Handle_RTQuote_IDXFUT(self, tmpQt: TFutQuoteData, aData: str, msg: 'InboundMessage'):
        """//拆解:指數(EX:VIX)"""
        try:
            with tmpQt._lock:
                tmpQt.QtIDX.Handle_IDX(aData)
            self.__Fire_QtIDXEventFUT(tmpQt.SolIce, tmpQt.QtIDX)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_IDXFUT:{ex}")

    def __Handle_RTQuote_5QTOTFUT(self, tmpQt: TFutQuoteData, aData: str, msg: 'InboundMessage'):
        "拆解:累計買賣委託筆數、累計買賣委託合約數 行情(一般期貨)"
        try:
            with tmpQt._lock:
                tmpQt.Qt5QTOT.Handle_5QTOT(aData)
            self.__Fire_Qt5QTOTEventFUT(tmpQt.SolIce, tmpQt.Qt5QTOT)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_5QTOT:{ex}")

    def __Handle_RTQuote_BASFUT(self, tmpQt: TFutQuoteData, aData: str, msg: 'InboundMessage'):
        "拆解:即時基本資料(I010、I011) for 換盤資訊"
        try:
            bIsChange: bool = False
            with tmpQt._lock:
                bIsChange = tmpQt.BAS.Handle_BAS_ChangeMktType(aData)  # 處理變盤
            if bIsChange:  # 變盤
                self.__Fire_ChangeMktStuEventFUT(tmpQt.SolIce, tmpQt.BAS)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"Handle_RTQuote_BAS:{ex}")
# endregion 行情解析

# region 一般商品  
    def __DoSubQuoteSTK(self, aSolICE: str, aCalcHightLowPrice: bool):
        """一般商品行情訂閱(含回補最新一筆行情); aSolICE:行情報價代碼(EX:2330), aCalcHightLowPrice:是否需要計算最高低價"""
        try:
            job = TCacheJob()
            job.prod = aSolICE
            job.TopicBAS = f"Quote/TWS/*/*/{aSolICE}/BAS"          
            job.RequestID = self.GetRequestID()
            job.HandleProc = self.__Handle_CacheJob_StkBAS
            self._fMapCacheJob[job.RequestID] = job
            self.__SolcacheReq_as_available(job.RequestID, job.TopicBAS)
            return RCode.OK
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubQuoteSTK:{ex}")
            self.__Fire_LogEvent(f"[證][DoSubQuoteSTK]{aSolICE}新增紀錄失敗!({ex})")
        
            thrd = threading.Thread(target=self.__Fire_OnQtRcv_FailEvent, args=(STKxFUT.STK, aSolICE))
            thrd.start()
            return RCode.FAIL
 
    def __DoSubQuoteByCategorySTK(self, aCat:str, aCalcHightLowPrice:bool):
        """#CAT/S一般股票, CAT/W權證類, CAT/Idx指數類"""
        try:
            job = TCacheJob()            
            job.TopicBAS = f"Quote/TWS/{aCat}/*/*/BAS"
            job.oneProd = False
            job.RequestID = self.GetRequestID()
            job.HandleProc = self.__Handle_CacheJob_StkBAS
            job.Params["Category"] = "SubQuoteByCategory_BAS"
            self._fMapCacheJob[job.RequestID] = job
            self.__SolcacheReq_as_available(job.RequestID, job.TopicBAS)
            return RCode.OK
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubQuoteByCategorySTK:{ex}")
            self.__Fire_LogEvent(f"[證][DoSubQuoteByCategorySTK]{aCat}新增紀錄失敗!({ex})")
        
        thrd = threading.Thread(
            target=self.__Fire_OnQtRcv_FailEvent, args=(STKxFUT.STK, aCat))
        thrd.start()

    def __DoSubQuoteFUT(self, aSolICE: str, aCalcHightLowPrice: bool):
        """一般商品行情訂閱(含回補最新一筆行情)
        aSolICE=行情報價代碼(EX:TXFA2)
        aCalcHightLowPrice=是否需要計算最高低價"""
        try:
            job = TCacheJob()
            job.prod = aSolICE
            job.TopicBAS = f"Quote/TWF/*/{aSolICE}/BAS"
            job.RequestID = self.GetRequestID()
            job.HandleProc = self.__Handle_CacheJob_FutBAS
            self._fMapCacheJob[job.RequestID] = job
            self.__SolcacheReq_as_available(job.RequestID, job.TopicBAS)
            return RCode.OK
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubQuoteFUT:{ex}")
            self.__Fire_LogEvent(f"[期][DoSubQuoteFUT]{aSolICE}新增紀錄失敗!({ex})")        
            thrd = threading.Thread(target=self.__Fire_OnQtRcv_FailEvent, args=(STKxFUT.FUT, aSolICE))
            thrd.start()
            return RCode.FAIL

    def __DoSubQuoteByCategoryFUT(self, aCat:str, aCalcHightLowPrice:bool):
        """#CAT/FUT期貨, CAT/OPT選擇權"""
        try:
            job = TCacheJob()            
            job.TopicBAS = f"Quote/TWF/{aCat}/*/BAS"
            job.oneProd = False
            job.RequestID = self.GetRequestID()
            job.HandleProc = self.__Handle_CacheJob_FutBAS
            job.Params["Category"] = "SubQuoteByCategory_BAS"
            self._fMapCacheJob[job.RequestID] = job
            self.__SolcacheReq_as_available(job.RequestID, job.TopicBAS)
            return RCode.OK
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubQuoteByCategoryFUT:{ex}")
            self.__Fire_LogEvent(f"[證][DoSubQuoteByCategoryFUT]{aCat}新增紀錄失敗!({ex})")

        thrd = threading.Thread(target=self.__Fire_OnQtRcv_FailEvent, args=(STKxFUT.FUT, f"[期]新增分類紀錄失敗{aCat}"))
        thrd.start() 
    
    def __DoSubQuoteOvsFUT(self, aSolICE: str, aCalcHightLowPrice: bool):
        try:
            bOK: bool = False
            # //QuoteOvs/交易所代碼/FUT or OPT/台新行情代碼/RECOVER
            sAskData = f"QuoteOvs/*/*/{aSolICE}/RECOVER"                        
            bOK, sResData = self.__SendMessage_ByRequest(self._vRcvTopic_OvsFut, sAskData, 'big5',self._vRcvTopic_OvsFut_Req)
            #region 檢核
            if bOK:
                map = json.loads(sResData)
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                         self.__Fire_LogEvent(f"[海期][DoSubQuoteOvsFUT](aSolIce={aSolICE}, aData={sResData})行情回補資料有誤!")
                         return RCode.FAIL
                    if "BAS" in map and len(map["BAS"]) == 0:
                        self.__Fire_LogEvent(f"[海期][DoSubQuoteOvsFUT](aSolIce={aSolICE}, aData={sResData})沒有BAS資料!")
                        return RCode.FAIL
            #endregion 檢核
           
                ret = self.__DoSubQuote_RTonlyOvsFUT(False, aSolICE, aCalcHightLowPrice, map)
            
                return ret
            else:                
                return RCode.FAIL
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"DoSubQuoteOvsFUT: {ex}")
            # 回補BAS失敗的Event資料 ThreadPool.QueueUserWorkItem(new WaitCallback(Fire_OnQtRcv_BAS_FailEvent), aSolICE);
            tmpRcvFail = TQtRcvEventData()
            tmpRcvFail.SetRcvBAS_Fail(aSolICE)
            self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.OVSFUT, arg2=tmpRcvFail)
            return RCode.FAIL        
    
    def __DoSubQuoteByCategoryOvsFUT(self, aCalcHightLowPrice:bool, aExchange:str = "*"):
        """一般商品行情分類訂閱(含回補最新一筆行情)
        aExchange:交易所
        aCalcHightLowPrice:是否需要計算最高低價
        """        
        try:        
            bOK:bool = False
            sAskData:str = f"QuoteOvs/{aExchange}/FUT/*/RECOVER"
            sResData:str = ""
            bOK, sResData = self.__SendMessage_ByRequest(self._vRcvTopic_OvsFut, sAskData, 'big5',self._vRcvTopic_OvsFut_Req) #要求回補最新一筆行情

            if bOK:                
                map = json.loads(sResData)
                #region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(f"[海期][DoSubQuoteByCategory](aSolIce={aExchange}, aData={sResData})行情回補資料有誤!")
                        return RCode.FAIL
                    if "BAS" in map and len(map["BAS"]) == 0:                    
                        self.__Fire_LogEvent(f"[海期][DoSubQuoteByCategory](aSolIce={aExchange}, aData={sResData})沒有BAS資料!")
                        return RCode.FAIL
                   
                #endregion 檢核

                ret = self.__DoSubQuote_RTonlyOvsFUT(False, aExchange, aCalcHightLowPrice, map)
                return ret
            else:                
                return RCode.FAIL
        except Exception as ex:
            self.__Fire_LogEvent(f"[海期][DoSubQuoteByCategoryOvsFUT] 新增分類紀錄失敗!")        
            return RCode.FAIL
    
    def __DoUnSubQuoteByCategoryOvsFUT(self, aExchange:str):
        """取消分類訂閱
        return 1.bool
                2.out string aErrMsg"""
        
        aErrMsg:str = ""
        try:
            lsTopic:list = []
            ret, lsTopic, aErrMsg = self._fMapQuoteOvsFUT.GetItem_ByExchange(aExchange)
            if ret == False:
                return False,aErrMsg
            for obj in lsTopic:
                self.__fWorkThr_SolaceUnSubTopic.Add(arg1=STKxFUT.FUT, arg2=obj)
            return True, ""
            
        except Exception as ex:
            aErrMsg = f"[海期][DoUnSubQuoteByCategory](aExchange={aExchange}){ex}"
        return False,aErrMsg
        
    def __DoSubQuote_RTonlySTK(self, aIsCat:bool, aSolICE: str, aCalcHightLowPrice:bool, mapResData, topic:str = ""):
        """一般商品即時行情訂閱; aMarket:市場別(TSE/OTC), aStkKind:證券別(S/W/Idx), aSolICE:行情報價代碼(EX:2330)"""
        try:
            mapQt:TObjStkQuoteMap = None
            sErrMsg:str=""
            ret, mapQt, sErrMsg = self._fMapQuoteSTK.AddDataBySolIce(aIsCat, aSolICE, mapResData, aCalcHightLowPrice, topic)
            if ret:
                self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.STK, arg2=mapQt)

                #回補後, 直接訂即時行情
                for key,val in mapQt.items():
                    qtData:TStkQuoteData = val
                    if topic == "":#原本的取法用HL組TX 5Q
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.STK, arg2=qtData.HL.TopicTX)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.STK, arg2=qtData.HL.Topic5Q)
                    else:
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.STK, arg2=qtData.BAS.TopicTX)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.STK, arg2=qtData.BAS.Topic5Q)
                return RCode.OK
            else:
                self.__Fire_LogEvent(f"[證][DoSubQuote_RTonlySTK]({aIsCat},{aSolICE})回補失敗!({sErrMsg})")
                return RCode.FAIL
                
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"DoSubQuote_RTonlySTK: {ex}")
            return RCode.FAIL

    def __DoSubQuote_RTonlyFUT(self, aIsCat:bool, aSolICE:str, aCalcHightLowPrice:bool, mapResData, topic:str = ""):
        """一般商品即時行情訂閱
            aMarket=市場別(FUT/OPT)
            aSolICE=行情報價代碼(EX:TXFA2)"""
        try:
            mapQt:TObjFutQuoteMap= None
            sErrMsg:str = ""
            ret, mapQt, sErrMsg = self._fMapQuoteFUT.AddDataBySolIce(aIsCat, aSolICE, mapResData, aCalcHightLowPrice, topic)
            if ret:
                self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.FUT, arg2=mapQt)

                #回補後, 直接訂即時行情
                for key,val in mapQt.items():
                    qtData:TFutQuoteData = val
                    if topic == "":
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.HL.TopicTX)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.HL.Topic5Q)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.HL.Topic5QTOT)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.HL.TopicBAS)
                    else:
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.BAS.TopicTX)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.BAS.Topic5Q)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.BAS.Topic5QTOT)
                        self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=qtData.BAS.TopicBAS)
                return RCode.OK
            else:
                self.__Fire_LogEvent(f"[期][DoSubQuote_RTonlyFUT]{aSolICE}新增紀錄失敗!({sErrMsg})")           
                return RCode.FAIL
            
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"DoSubQuote_RTonlyFUT: {ex}")
            return RCode.FAIL

    def __DoSubQuote_RTonlyOvsFUT(self, aIsCat:bool, aSolICE:str, aCalcHightLowPrice:bool, mapResData):
        """一般商品即時行情訂閱
            aSolICE:行情報價代碼(EX:TXFA2)"""
        try:
            mapQt:TMapOvsFutQuoteData = None
            sErrMsg:str = ""
            ret , mapQt, sErrMsg = self._fMapQuoteOvsFUT.AddDataBySolIce(aIsCat, aSolICE, mapResData, aCalcHightLowPrice)
            if ret:
                #回補BAS成功的Event資料
                tmpRcvSucc = TQtRcvEventData()
                tmpRcvSucc.SetRcvBAS_Succ("", mapQt)
                self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.OVSFUT, arg2=tmpRcvSucc)                

                #回補後, 直接訂即時行情
                for key,val in mapQt.items():
                    qtData:TOvsFutQuoteData = val
                    self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.OVSFUT, arg2=qtData.HL.TopicTX)
                    self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.OVSFUT, arg2=qtData.HL.Topic5Q)
                return RCode.OK
            else:
                self.__Fire_LogEvent(f"[海期][DoSubQuote_RTonlyOvsFUT]{aSolICE}新增紀錄失敗!({sErrMsg})")           
                return RCode.FAIL
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubQuote_RTonlyOvsFUT: {ex}")
            return RCode.FAIL
# endregion 一般商品

    # region 指數商品
    def __DoSubIdxQuoteSTK(self, aSolICE: str, aCalcHightLowPrice: bool):
        """指數商品即時行情訂閱
        aSolICE: 行情報價代碼(EX:加權指數IX0001)     
        aCalcHightLowPrice: 是否需要計算最高最低價"""
        try:
            bOK = False
            sAskData = f"Quote/TWS/*/*/{aSolICE}/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_Stk, sAskData, 'utf-8',self._vRcvTopic_Stk_Req)  # 要求回補最新一筆行情
            if bOK:
                map = json.loads(sResData)
            if bOK and sResData != "":
                tmpQt: TStkQuoteData = None
                sErrMsg: str
                ret, tmpQt, sErrMsg = self._fMapQuoteSTK.AddRcvData(
                    TStkProdKind.pkIndex, aSolICE, sResData, aCalcHightLowPrice)
                if ret:
                    self.__fWorkThr_HandleRcvQuote.Add(
                        arg1=STKxFUT.STK, arg2=tmpQt)
                    self.__DoSubIdxQuote_RTonlySTK(
                        tmpQt.HL.Market, tmpQt.HL.StkKind, aSolICE, map)  # 回補後, 直接訂即時行情
                    return
                else:
                    self.__Fire_LogEvent(
                        f"[證][DoSubIdxQuoteSTK]{aSolICE}新增紀錄失敗!")

        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubIdxQuoteSTK:{ex}")
        thrd = threading.Thread(
            target=self.__Fire_OnQtIdxRcv_FailEvent, args=aSolICE)
        thrd.start()

    def __DoSubIdxQuoteFUT(self, aSolICE: str, aCalcHightLowPrice: bool):
        """指數商品即時行情訂閱(EX:TAIWANVIX)
        aSolICE=行情報價代碼(EX:TAIWANVIX)
        aCalcHightLowPrice=是否需要計算最高低價"""
        try:
            # 註:指數類, 沒有回補
            sTopic: str = f"Quote/TWF/IDX/{aSolICE}/MR"
            if self._fMapQuoteFUT.AddData(TFutProdKind.pkIndex, aSolICE, aCalcHightLowPrice, sTopic, self.__Handle_RTQuote_IDXFUT):
                self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.FUT, arg2=sTopic)
            else:
                self.__Fire_LogEvent(
                    f"[期][DoSubIdxQuote_RTonly]{aSolICE}新增紀錄失敗!")
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoSubIdxQuoteFUT:{ex}")

    def __DoSubIdxQuote_RTonlySTK(self, aIsCat:bool, aSolICE:str, aCalcHightLowPrice:bool, mapResData):
        """指數商品即時行情訂閱
        aMarket: 市場別(TSE/OTC)
        aStkKind: 證券別(S/W/Idx)
        aSolICE: 行情報價代碼(EX:2330)"""
        try:
            mapQt:TObjStkQuoteMap = None
            sErrMsg:str=""
            ret, mapQt, sErrMsg = self._fMapQuoteSTK.AddIdxDataBySolIce(aIsCat, aSolICE, mapResData, aCalcHightLowPrice)
            
            if ret:
                # self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.STK, arg2=mapQt) #__fWorkThr_HandleRcvQuote.Add(mapQt);
                self.__Fire_OnQtIdxRcv_OKEvent(mapQt)

                #回補後, 直接訂即時行情

                for key,val in mapQt.items():
                    qtData:TStkQuoteData = val
                    self.__fWorkThr_SolaceSubTopic.Add(arg1=STKxFUT.STK, arg2=qtData.HL.TopicTX)                    
                return RCode.OK      
            else:
                self.__Fire_LogEvent(f"[證][HandleRecover_Idx]({aIsCat},{aSolICE})新增紀錄失敗!({sErrMsg})")
                return RCode.FAIL
        except Exception as ex:            
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"DoSubIdxQuote_RTonlySTK:{ex}")
            return RCode.FAIL
    # endregion

    def __SolcacheReq_as_available(self, RequestId ,topic:str):        
        cache_msg_sub_req = CachedMessageSubscriptionRequest.cached_only("dc01", TopicSubscription.of(topic), 60000, 1)
        self._message_receiver.request_cached(cache_msg_sub_req, RequestId, self._cacheReqOutListener)        

    def callcache(self, RequestId ,topic:str):
        self.__SolcacheReq_as_available(RequestId, topic)

    def __Handle_CacheJob_StkBAS(self, job:TCacheJob):
        """處理cache data STK BAS, HL"""
        try:    
            map:dict = {}    
            for key,val in job.CacheData.items():
                msg:'InboundMessage' = val
                msg_destname = msg.get_destination_name() 
                data = msg.get_payload_as_bytes().decode('utf-8') 
                topic:str = ""
                if msg_destname.endswith(self._vQuote_BAS):
                    map["BAS"] = [data]
                    topic = msg_destname
                elif msg_destname.endswith(self._vQuote_HL):
                    map["HL"] = [data]

            self.__DoSubQuote_RTonlySTK(False, job.prod, True, map, topic)            
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"Handle_CacheJob_StkBAS Error:{ex}")
    
    def __Handle_RTQuote_STK_HL(self, job:TCacheJob):
        #tmpQt: TStkQuoteData, aData: str, msg: 'InboundMessage'):
        try:
            msg:'InboundMessage' = job.CacheData[job.TopicHL]            
            aData = msg.get_payload_as_bytes().decode('utf-8') 
            if self._fMapQuoteSTK.get(job.TopicTX) is not None:
                aQtMap:TObjStkQuoteMap = TObjStkQuoteMap()
                tmpQt:TStkQuoteData = self._fMapQuoteSTK[job.TopicTX]                                
                tmpQt.HL.Handle_HL(aData)
                # 最高低價
                tmpQt.QtTX.HighPrice = tmpQt.HL.Get_HighPrice()
                tmpQt.QtTX.LowPrice = tmpQt.HL.Get_LowPrice()
                #五檔序號(給成交行情做判斷用, 若成交行情帶五檔的序號, 比來自HL回補的5檔序號, 還要小, 表示很久沒有成交行情, 但五檔一直在變動, 則不可使用成交行情裡的五檔資料)
                tmpQt.QtTX.HL_Sn_5Q = tmpQt.HL.Get_Sn_5Q()                
                #市場成交總額
                tmpQt.QtTX.HL_TotAmt = tmpQt.HL.Get_TotAmt2Int()
                aQtMap[job.prod]= tmpQt                

                #HL抓完再抓一次TX,如果都沒成交過HL跟TX都沒有
                jobTX = TCacheJob()
                jobTX.prod = job.prod
                jobTX.TopicBAS = job.TopicBAS
                jobTX.TopicHL = job.TopicHL
                jobTX.TopicTX = job.TopicTX
                jobTX.Topic5Q = job.Topic5Q
                jobTX.RequestID = self.GetRequestID()                
                jobTX.HandleProc = self.__Handle_RTQuote_STK_TX                                
                self._fMapCacheJob[jobTX.RequestID] = jobTX
                self.__SolcacheReq_as_available(jobTX.RequestID, jobTX.TopicTX)
            else:
                jobHL = TCacheJob()
                jobHL.prod = job.prod
                jobHL.TopicBAS = job.TopicBAS
                jobHL.TopicHL = job.TopicHL
                jobHL.TopicTX = job.TopicTX
                jobHL.Topic5Q = job.Topic5Q
                jobHL.RequestID = self.GetRequestID()
                jobHL.HandleProc = self.__Handle_RTQuote_STK_HL
                self._fMapCacheJob[jobHL.RequestID] = jobHL
                self.__SolcacheReq_as_available(jobHL.RequestID, jobHL.TopicHL)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"__Handle_RTQuote_STK_HL:{ex}")

    def __Handle_RTQuote_STK_TX(self, job:TCacheJob):
        msg:'InboundMessage' = job.CacheData[job.TopicTX]        
        aData = msg.get_payload_as_bytes().decode('utf-8') 
        if self._fMapQuoteSTK.get(job.TopicTX) is not None:
            aQtMap:TObjStkQuoteMap = TObjStkQuoteMap()
            tmpQt:TStkQuoteData = self._fMapQuoteSTK[job.TopicTX]    
            tmpQt.QtTX.Handle_TX(aData)            
            job5Q = TCacheJob()
            job5Q.prod = job.prod
            job5Q.TopicBAS = job.TopicBAS
            job5Q.TopicHL = job.TopicHL
            job5Q.TopicTX = job.TopicTX
            job5Q.Topic5Q = job.Topic5Q
            job5Q.RequestID = self.GetRequestID()                
            job5Q.HandleProc = self.__Handle_RTQuote_STK_5Q    
            self._fMapCacheJob[job5Q.RequestID] = job5Q
            self.__SolcacheReq_as_available(job5Q.RequestID, job5Q.Topic5Q)

    def __Handle_RTQuote_STK_5Q(self, job:TCacheJob):
        msg:'InboundMessage' = job.CacheData[job.Topic5Q]        
        aData = msg.get_payload_as_bytes().decode('utf-8') 
        if self._fMapQuoteSTK.get(job.TopicTX) is not None:
            aQtMap:TObjStkQuoteMap = TObjStkQuoteMap()
            tmpQt:TStkQuoteData = self._fMapQuoteSTK[job.TopicTX]
            tmpQt.Qt5Q.Handle_5Q(aData)
            tmpQt.UpdateHLTX = True          
            aQtMap[job.prod]= tmpQt        
            self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.STK, arg2=aQtMap)               

    def __Handle_CacheJob_FutBAS(self, job:TCacheJob):
        """處理cache data FUT BAS, HL"""
        try:    
            map:dict = {}    
            for key,val in job.CacheData.items():
                msg:'InboundMessage' = val
                msg_destname = msg.get_destination_name() 
                data = msg.get_payload_as_bytes().decode('utf-8') 
                topic:str = ""
                if msg_destname.endswith(self._vQuote_BAS):
                    map["BAS"] = [data]
                    topic = msg_destname
                elif msg_destname.endswith(self._vQuote_HL):
                    map["HL"] = [data]

            self.__DoSubQuote_RTonlyFUT(False, job.prod, True, map, topic)            
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"Handle_CacheJob_FutBAS Error:{ex}")

    def __Handle_RTQuote_FUT_HL(self, job:TCacheJob):
        #tmpQt: TFutQuoteData, aData: str, msg: 'InboundMessage'):
        try:
            msg:'InboundMessage' = job.CacheData[job.TopicHL]
            aData = msg.get_payload_as_bytes().decode('utf-8') 
            if self._fMapQuoteFUT.get(job.TopicTX) is not None:
                aQtMap:TObjFutQuoteMap = TObjFutQuoteMap()
                tmpQt:TFutQuoteData = self._fMapQuoteFUT[job.TopicTX]                
                tmpQt.HL.Handle_HL(aData)
                tmpQt.QtTX.HighPrice = tmpQt.HL.Get_HighPrice2Dec()
                tmpQt.QtTX.LowPrice = tmpQt.HL.Get_LowPrice2Dec()           
                aQtMap[job.prod]= tmpQt                
                
                #HL抓完再抓一次TX,如果都沒成交過HL跟TX都沒有
                jobTX = TCacheJob()
                jobTX.prod = job.prod
                jobTX.TopicBAS = job.TopicBAS
                jobTX.TopicHL = job.TopicHL
                jobTX.TopicTX = job.TopicTX
                jobTX.Topic5Q = job.Topic5Q
                jobTX.RequestID = self.GetRequestID()                
                jobTX.HandleProc = self.__Handle_RTQuote_FUT_TX                                
                self._fMapCacheJob[jobTX.RequestID] = jobTX
                self.__SolcacheReq_as_available(jobTX.RequestID, jobTX.TopicTX)
            else:
                ret,err = job.ReSet()                
                if ret:                    
                    jobHL = TCacheJob()
                    jobHL.prod = job.prod
                    jobHL.TopicBAS = job.TopicBAS
                    jobHL.TopicHL = job.TopicHL
                    jobHL.TopicTX = job.TopicTX
                    jobHL.Topic5Q = job.Topic5Q
                    jobHL.fCurCnt = job.fCurCnt
                    jobHL.RequestID = self.GetRequestID()                
                    jobHL.HandleProc = self.__Handle_RTQuote_FUT_HL                
                    self._fMapCacheJob[jobHL.RequestID] = jobHL
                    self.__SolcacheReq_as_available(jobHL.RequestID, jobHL.TopicHL)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"__Handle_RTQuote_FUT_HL:{ex}")
    
    def __Handle_RTQuote_FUT_TX(self, job:TCacheJob):
        msg:'InboundMessage' = job.CacheData[job.TopicTX]        
        aData = msg.get_payload_as_bytes().decode('utf-8') 
        if self._fMapQuoteFUT.get(job.TopicTX) is not None:
            aQtMap:TObjFutQuoteMap = TObjFutQuoteMap()
            tmpQt:TFutQuoteData = self._fMapQuoteFUT[job.TopicTX]    
            tmpQt.QtTX.Handle_TX(aData)
            job5Q = TCacheJob()
            job5Q.prod = job.prod
            job5Q.TopicBAS = job.TopicBAS
            job5Q.TopicHL = job.TopicHL
            job5Q.TopicTX = job.TopicTX
            job5Q.Topic5Q = job.Topic5Q                                
            job5Q.RequestID = self.GetRequestID()                
            job5Q.HandleProc = self.__Handle_RTQuote_FUT_5Q
            self._fMapCacheJob[job5Q.RequestID] = job5Q
            self.__SolcacheReq_as_available(job5Q.RequestID, job5Q.Topic5Q)

    def __Handle_RTQuote_FUT_5Q(self, job:TCacheJob):
        msg:'InboundMessage' = job.CacheData[job.Topic5Q]        
        aData = msg.get_payload_as_bytes().decode('utf-8') 
        if self._fMapQuoteFUT.get(job.TopicTX) is not None:
            aQtMap:TObjFutQuoteMap = TObjFutQuoteMap()
            tmpQt:TFutQuoteData = self._fMapQuoteFUT[job.TopicTX]
            tmpQt.Qt5Q.Handle_5Q(aData)

            job5QTOT = TCacheJob()
            job5QTOT.prod = job.prod
            job5QTOT.TopicBAS = job.TopicBAS
            job5QTOT.TopicHL = job.TopicHL
            job5QTOT.TopicTX = job.TopicTX
            job5QTOT.Topic5Q = job.Topic5Q
            arr = job5QTOT.Topic5Q.split("/")
            arr[len(arr)-1] = "5QTOT"
            job5QTOT.Topic5QTOT = "/".join(arr)
            job5QTOT.RequestID = self.GetRequestID()                
            job5QTOT.HandleProc = self.__Handle_RTQuote_FUT_5QTOT
            self._fMapCacheJob[job5QTOT.RequestID] = job5QTOT
            self.__SolcacheReq_as_available(job5QTOT.RequestID, job5QTOT.Topic5QTOT)
          
    def __Handle_RTQuote_FUT_5QTOT(self, job:TCacheJob):
        msg:'InboundMessage' = job.CacheData[job.Topic5QTOT]        
        aData = msg.get_payload_as_bytes().decode('utf-8') 
        if self._fMapQuoteFUT.get(job.TopicTX) is not None:
            aQtMap:TObjFutQuoteMap = TObjFutQuoteMap()
            tmpQt:TFutQuoteData = self._fMapQuoteFUT[job.TopicTX]
            tmpQt.Qt5QTOT.Handle_5QTOT(aData)

            tmpQt.UpdateHLTX = True
            aQtMap[job.prod]= tmpQt
            self.__fWorkThr_HandleRcvQuote.Add(arg1=STKxFUT.FUT, arg2=aQtMap)

    def __SolaceSubTopic(self, stk: STKxFUT, topic: str):
        try:
            with self._lock:
                self._message_receiver.add_subscription(TopicSubscription.of(topic))
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"SolaceSubTopic:{topic}, {ex}")

    def __DoUnSubTopicSTK(self, aSolICE: str):
        """取消訂閱
            reture: 1:bool
                    2:error message"""
        sErrMsg: str = ""
        try:
            lsTopic = []
            ret: bool
            ret, lsTopic, sErrMsg = self._fMapQuoteSTK.GetItem_BySolIce(
                aSolICE)
            if ret == False:
                return False, sErrMsg
            for obj in lsTopic:
                self.__fWorkThr_SolaceUnSubTopic.Add(arg1=STKxFUT.STK, arg2=obj)
            return True, ""
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoUnSubTopicSTK:{ex}")
            return False, f"[證][DoUnSubTopicSTK](aSolICE={aSolICE}){ex}"
    def __DoUnSubTopicByCategorySTK(self, aCat:str):
        """return 1.bool
                  2. aErrMsg"""
        sErrMsg:str = ""
        try:            
            lsTopic = []
            ret, lsTopic, sErrMsg = self._fMapQuoteSTK.GetItem_ByCategory(aCat)
            if ret == False:
                return RCode.FAIL, sErrMsg 
            
            for obj in lsTopic:
                self.__fWorkThr_SolaceUnSubTopic.Add(arg1=STKxFUT.STK, arg2=obj)
            return RCode.OK, ""            
        except Exception as ex:
            sErrMsg = f"[證][DoUnSubTopicByCategory](aCat={aCat}){ex}"
        return RCode.FAIL,sErrMsg
        
    def __DoUnSubTopicFUT(self, aSolICE: str):
        """取消訂閱
            reture: 1:bool
                    2:error message"""
        sErrMsg: str = ""
        try:
            lsTopic = []
            ret: bool
            ret, lsTopic, sErrMsg = self._fMapQuoteFUT.GetItem_BySolIce(
                aSolICE)
            if ret == False:
                return False, sErrMsg
            for obj in lsTopic:
                self.__fWorkThr_SolaceUnSubTopic.Add(arg1=STKxFUT.FUT, arg2=obj)
            return True, ""
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"DoUnSubTopicFUT:{ex}")
            return False, f"[期][DoUnSubTopicSTK](aSolICE={aSolICE}){ex}"

    
    def __DoUnSubTopicByCategoryFUT(self, aCat:str):
        "取消分類訂閱"        
        aErrMsg:str = ""
        try:
            lsTopic = []
            ret, lsTopic, aErrMsg = self._fMapQuoteFUT.GetItem_ByCategory(aCat)
            if ret == False:
                return RCode.FAIL, aErrMsg
            for obj in lsTopic:
                self.__fWorkThr_SolaceUnSubTopic.Add(arg1=STKxFUT.FUT, arg2=obj)            
            return RCode.OK, ""
        
        except Exception as ex:
            aErrMsg = f"[期][DoUnSubTopicByCategoryFUT](aCat={aCat}){ex}"
        return RCode.FAIL, aErrMsg
        

    def __DoUnSubTopicOvsFUT(self, aSolICE: str):
        """取消訂閱 return 1.bool
                          2.sErrMsg"""
        aErrMsg = ""
        try:
            lsTopic = []
            ret, lsTopic, sErrMsg = self._fMapQuoteOvsFUT.GetItem_BySolIce(
                aSolICE)
            if ret == False:
                return False, sErrMsg
            for obj in lsTopic:
                self.__fWorkThr_SolaceUnSubTopic.Add(
                    arg1=STKxFUT.OVSFUT, arg2=obj)
            return True, ""
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"DoUnSubTopicOvsFUT:{ex}")
            aErrMsg = f"[證][DoUnSubTopic](aSolICE={aSolICE}){ex}"
            return False, aErrMsg

    def __SolaceUnSubTopic(self, stk: STKxFUT, topic: str):
        try:
            with self._lock:
                self._message_receiver.remove_subscription(
                    TopicSubscription.of(topic))
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"SolaceUnSubTopic:{topic}, {ex}")

    def __DoRunThread(self):        
        if self.__fWorkThr_HandleQuote is None or self.__fWorkThr_HandleQuote._run == False:
            self.__fWorkThr_HandleQuote = TSolaceMessageThreadClass(
            "Trd_HandleQuote", self._log, self.__Handle_RTQuote_Main)
        
        if self.__fWorkThr_HandleRcvQuote is None or self.__fWorkThr_HandleRcvQuote._run == False:
            self.__fWorkThr_HandleRcvQuote = TMyWorkItemThreadClass(
            "Trd_HandleRcvQuote", self._log, self.__Fire_OnQtRcv_OKEvent)  # 回補行情
        
        if self.__fWorkThr_SolaceSubTopic is None or self.__fWorkThr_SolaceSubTopic._run == False:
            self.__fWorkThr_SolaceSubTopic = TMyWorkItemThreadClass(
            "Trd_SolaceSubTopic", self._log, self.__SolaceSubTopic)  # 訂閱行情
        
        if self.__fWorkThr_SolaceUnSubTopic is None or self.__fWorkThr_SolaceUnSubTopic._run == False:
            self.__fWorkThr_SolaceUnSubTopic = TMyWorkItemThreadClass(
            "Trd_SolaceUnSubTopic", self._log, self.__SolaceUnSubTopic)  # 取消訂閱行情

    def __DoCloseThread(self):
        with self._lock:
            if self.__fWorkThr_HandleQuote:
                self.__fWorkThr_HandleQuote._run = False
            if self.__fWorkThr_HandleRcvQuote:
                self.__fWorkThr_HandleRcvQuote._run = False
            if self.__fWorkThr_SolaceSubTopic:
                self.__fWorkThr_SolaceSubTopic._run = False
            if self.__fWorkThr_SolaceUnSubTopic:
                self.__fWorkThr_SolaceUnSubTopic._run = False

    # region 取商品檔
    def QryProdID_NormalStock(self):
        """取個一般上市上櫃股票商品檔(不含零股/權證)
        return  1:RCode
                2:out TQryStkProdMap mapProd"""
        mapProd = None
        try:
            bOK = False
            sAskData = "Quote/TWS/S/TSE/*/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_Stk, sAskData, 'utf-8',self._vRcvTopic_Stk_Req)
            if bOK:
                map = json.loads(sResData)
                # region 檢核
                # status = map["status"]
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[證][取個一般上市上櫃股票商品檔](aData={sResData})行情回補資料有誤!")
                        return RCode.FAIL, mapProd
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[證][取個一般上市上櫃股票商品檔](aData={sResData})沒有BAS資料!")
                    return RCode.FAIL, mapProd
                if "HL" in map and len(map["HL"]) == 0:
                    self.__Fire_LogEvent(
                        f"[證][取個一般上市上櫃股票商品檔](aData={sResData})沒有HL資料!")
                    return RCode.FAIL, mapProd
                # endregion
                # region 拆觸基本資料
                mapProd = TQryStkProdMap()
                for str in map["BAS"]:
                    try:
                        tmp = TStkQtBase()
                        tmp.Handle_BAS(str)

                        if mapProd.data.get(tmp.StkNo) is None:
                            prodRec = TQryStkProdRec()
                            prodRec.tmpBase = tmp
                            mapProd[tmp.StkNo] = prodRec
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                    arg2=f"QryProdID_NormalStock(BAS):{ex}")
                # endregion
                for str in map["HL"]:
                    try:
                        tmp = TStkQtHL()
                        tmp.Handle_HL(str)
                        # var tmpProd = mapProd.Values.Where(z => z.tmpBase.StkNo == tmp.Symbol).FirstOrDefault();
                        tmpProd: TQryStkProdRec = None
                        tmpProd = next((z for z in mapProd.values()
                                    if z.tmpBase.StkNo == tmp.Symbol), None)
                        if tmpProd is not None:
                            tmpProd.tmpHL = tmp
                            tmpProd.SetDataInit()
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                    arg2=f"QryProdID_NormalStock(HL):{ex}")

                return RCode.OK, mapProd
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"[證][QryProdID_NormalStock]取個一般上市上櫃股票商品檔失敗!({ex})")

        return RCode.FAIL, None

    def QryProdID_FutStk_FirstMth(self):
        """取個期貨商品檔(近1月)
        out TQryFutProdMap mapProd"""
        mapProd: TQryFutProdMap = None
        try:
            bOK: bool = False
            sAskData = "Quote/TWF/FUT/*/RECOVER"
            sResData = ""
            # 要求回補最新一筆行情
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_Fut, sAskData, 'utf-8',self._vRcvTopic_Fut_Req)

            if bOK and sResData != "":
                map = json.loads(sResData)
                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[期][QryProdID_FutStk_FirstMth](aData={sResData})行情回補資料有誤!")
                        return False, mapProd
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProdID_FutStk_FirstMth](aData={sResData})沒有BAS資料!")
                    return False, mapProd
                if "HL" in map and len(map["HL"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProdID_FutStk_FirstMth](aData={sResData})沒有HL資料!")
                    return False, mapProd
                # endregion

                # region 拆解基本資料
                mapProd = TQryFutProdMap()
                for str in map["BAS"]:
                    try:
                        tmp: TFutQtBase = TFutQtBase()
                        tmp.Handle_BAS(str)
                        if tmp.StkNo.isspace() == False and len(tmp.StkNo) > 0:  # 個股期商品
                            if mapProd.data.get(tmp.StkNo) is None:
                                prodRec: TQryFutProdRec = TQryFutProdRec()
                                prodRec.tmpBase = tmp
                                mapProd[tmp.ProdID] = prodRec
                            elif (int(tmp.SettleMth) < int(mapProd[tmp.ProdID].tmpBase.SettleMth)):
                                mapProd[tmp.ProdID].tmpBase = tmp
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProdID_FutStk_FirstMth(BAS):{ex}")
                # endregion
                # region 拆解最新行情
                for str in map["HL"]:
                    try:
                        tmp: TFutQtHL = TFutQtHL()
                        tmp.Handle_HL(str)
                        tmpProd: TQryStkProdRec = None
                        tmpProd = next(
                            (z for z in mapProd.values() if z.tmpBase.OrdProdID == tmp.Symbol), None)
                        if tmpProd is not None:  # 個股期商品基本資料
                            tmpProd.tmpHL = tmp  # 個股期商品最新行情(含5檔)
                            tmpProd.SetDataInit()
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProdID_FutStk_FirstMth(HL):{ex}")
                # endregion
                return True, mapProd
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"QryProdID_FutStk_FirstMth:{ex}")
            self.__Fire_LogEvent(
                f"[期][QryProdID_FutStk_FirstMth]取個期貨商品檔(近1月)失敗!({ex})")
        return False, None

    def QryProd_Fut(self, aIsNormal: bool, aIsFutStk: bool, aIsSmall: bool):
        """取期貨商品檔(不含選擇權)
            aIsNormal:取一般期貨
            aIsFutStk:取個股期
            aIsSmall:個股期是否包含小型
            return  1. RCode
                    2.out TObjBaseFutMap aMapProdBase"""
        aMapProdBase: TObjBaseFutMap = None
        try:
            sAskData = "Quote/TWF/FUT/*/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_Fut, sAskData, 'utf-8',self._vRcvTopic_Fut_Req)  # 要求回補最新一筆行情

            if bOK and sResData != "":
                map = json.loads(sResData)

                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[期][QryProdID_Fut](aData={sResData})行情回補資料有誤!")
                        return RCode.FAIL, aMapProdBase
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProdID_Fut](aData={sResData})沒有BAS資料!")
                    return RCode.FAIL, aMapProdBase
                if "HL" in map and len(map["HL"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProdID_Fut](aData={sResData})沒有HL資料!")
                    return RCode.FAIL, aMapProdBase
                # endregion

                # region 拆解基本資料
                aMapProdBase: TObjBaseFutMap = TObjBaseFutMap()
                for str in map["BAS"]:
                    try:
                        tmp: TFutQtBase = TFutQtBase()
                        tmp.Handle_BAS(str)

                        if tmp.StkNo.isspace() == False and len(tmp.StkNo)>0:  # 個股期商品
                            if aIsFutStk:
                                # 不要載入小型
                                if aIsSmall == False and tmp.FutName.startswith("小型"):
                                    pass
                                else:
                                    aMapProdBase.AddItem_ByProdID(tmp)
                        elif aIsNormal:  # 一般期貨商品
                            aMapProdBase.AddItem_ByProdID(tmp)
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProd_Fut(BAS):{ex}")

                aMapProdBase.ReAddAll()
                # endregion

                return RCode.OK, aMapProdBase
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"QryProd_Fut:{ex}")
            self.__Fire_LogEvent(f"[期][QryProdID_Fut]取期貨商品檔(不含選擇權)失敗!({ex})")
        return RCode.FAIL,aMapProdBase

    def QryProd_FutCom(self):
        "取複式期貨商品檔 out TObjFutComList aProdList"
        aProdList: TObjFutComList = None
        try:
            sAskData: str = "Quote/TWF/SPD/*/SYMBOL"
            sResData: str = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_Fut, sAskData, 'utf-8',self._vRcvTopic_Fut_Req)  # 要求回補最新一筆行情

            if bOK:
                map = json.loads(sResData)
                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[期][QryProd_FutCom](aData={sResData})行情回補資料有誤!")
                        return False, aProdList
                if "SYMBOL" in map and len(map["SYMBOL"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProd_FutCom](aData={sResData})沒有SYMBOL資料!")
                    return False, aProdList
                # endregion
                # region 拆解資料
                aProdList: TObjFutComList = TObjFutComList()
                ary = map["SYMBOL"][0].split('|')
                for sSolIce in ary:
                    aProdList.AddItem(sSolIce)
                # endregion
                return True, aProdList
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"QryProd_FutCom:{ex}")
            self.__Fire_LogEvent(f"[期][QryProd_FutCom]取複式期貨商品檔失敗!({ex})")
        return False, aProdList

    def QryProd_FutCom2(self):
        """取複式期貨商品檔
        out TObjFutComList aProdList"""
        aProdList: TObjFutComList = None
        try:
            map: TObjBaseFutMap = None
            ret, map = self.QryProd_Fut(True, True, True)
            if ret == False:
                self.__Fire_LogEvent("[QryProd_FutCom2]載入期貨單式商品失敗!")
                return RCode.FAIL, aProdList
            aProdList: TObjFutComList = TObjFutComList()
            # 月商品
            idxM, idxD = 0, 0
            # var lsNoMX = map.Keys.Where(z => z.StartsWith("MX") == false || z.Equals("MXF")).ToList();
            lsNoMX = [key for key in map.keys() if not key.startswith("MX") or key == "MXF"]

            for sProdID in lsNoMX:
                lsProd = map[sProdID]
                if len(lsProd) <= 1:
                    continue
                for idxM in range(len(lsProd)):
                    for idxD in range(idxM + 1, len(lsProd)):
                        itemM = lsProd[idxM]
                        itemD = lsProd[idxD]
                        aProdList.AddItem("{}^{}".format(
                            itemM.OrdProdID, itemD.OrdProdID[3:5]))  # CDFJ2^K2

            # 週小台對小台商品的價差商品
            lsMXF = map["MXF"]  # 小台
            lsMXn = [z for z in map.keys() if z.startswith("MX")
                     and z != "MXF"]
            for idxM in range(len(lsMXn)):
                tmpProd1 = map[lsMXn[idxM]][0]
                # region 週小台對週小台
                for idxD in range(idxM + 1, len(lsMXn)):
                    tmpProd2 = map[lsMXn[idxD]][0]
                    if tmpProd1.SettleMth == tmpProd2.SettleMth:  # 同月份==>比第幾週
                        # 值條件小於零:strA 中的子字串小於 strB 中的子字串
                        if ord(tmpProd1.OrdProdID[2]) < ord(tmpProd2.OrdProdID[2]):
                            aProdList.AddItem("{}^{}".format(
                                tmpProd1.OrdProdID, tmpProd2.OrdProdID))  # MX1J2^MX2J2
                        else:
                            # MX1J2^MX2J2(近月放在前, 遠月放在後)
                            aProdList.AddItem("{}^{}".format(
                                tmpProd2.OrdProdID, tmpProd1.OrdProdID))
                    else:  # 不同月份==>近月放在前, 遠月放在後
                        if int(tmpProd1.SettleMth) < int(tmpProd2.SettleMth):
                            aProdList.AddItem("{}^{}".format(
                                tmpProd1.OrdProdID, tmpProd2.OrdProdID))  # MX4J2^MX1K2
                        else:
                            # MX1K2^MX4J2(近月放在前, 遠月放在後)
                            aProdList.AddItem("{}^{}".format(
                                tmpProd2.OrdProdID, tmpProd1.OrdProdID))
                # endregion
                # region週小台對小台
                if tmpProd1.SettleMth == lsMXF[0].SettleMth:
                    if tmpProd1.ProdID == "MX1" or tmpProd1.ProdID == "MX2":
                        for tmpMXF in lsMXF:
                            aProdList.AddItem("{}^{}".format(
                                tmpProd1.OrdProdID, tmpMXF.OrdProdID))  # MX1J2^MXFJ2
                    else:  # MX4、MX5
                        for tmpMXF in lsMXF:
                            aProdList.AddItem("{}^{}".format(
                                tmpMXF.OrdProdID, tmpProd1.OrdProdID))  # MXFJ2^MX4J2
                else:  # 不同月份==>近月放在前, 遠月放在後(EX:第四週轉下一月的月選)
                    if int(tmpProd1.SettleMth) < int(lsMXF[0].SettleMth):
                        for tmpMXF in lsMXF:
                            aProdList.AddItem("{}^{}".format(
                                tmpProd1.OrdProdID, tmpMXF.OrdProdID))  # /MX4J2^MXFJ3
                    else:
                        for tmpMXF in lsMXF:
                            aProdList.AddItem("{}^{}".format(
                                tmpMXF.OrdProdID, tmpProd1.OrdProdID))  # MX4J2^MXFJ3
                # endregion
            return RCode.OK, aProdList
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"QryProd_FutCom2:{ex}")
            self.__Fire_LogEvent(f"[期][QryProd_FutCom2]取複式期貨商品檔失敗!({ex})")
        return RCode.FAIL, aProdList

    def QryProd_Opt(self, aIsNormal: bool, aIsOptStk: bool, aIsSmall: bool):
        """取選擇權商品檔
            aIsNormal:取一般選擇權
            aIsOptStk:取個股選
            aIsSmall:個股期是否包含小型
            out TObjBaseOptMap aMapProdBase"""
        aMapProdBase: TObjBaseOptMap = None
        try:
            sAskData = "Quote/TWF/OPT/*/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_Fut, sAskData, 'utf-8',self._vRcvTopic_Fut_Req)  # 要求回補最新一筆行情

            if bOK:
                map = json.loads(sResData)
                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[期][QryProd_Opt](aData={sResData})行情回補資料有誤!")
                        return RCode.FAIL, aMapProdBase
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProd_Opt](aData={sResData})沒有BAS資料!")
                    return RCode.FAIL, aMapProdBase
                if "HL" in map and len(map["HL"]) == 0:
                    self.__Fire_LogEvent(
                        f"[期][QryProd_Opt](aData={sResData})沒有HL資料!")
                    return RCode.FAIL, aMapProdBase
                # endregion
                # region 拆解基本資料
                aMapProdBase = TObjBaseOptMap()
                for str in map["BAS"]:
                    try:
                        tmp: TFutQtBase = TFutQtBase()
                        tmp.Handle_BAS(str)

                        if tmp.StkNo.isspace() == False and len(tmp.StkNo)>0:  # 個股選商品
                            if aIsOptStk:
                                # 不要載入小型
                                if aIsSmall == False and tmp.FutName.startswith("小型"):
                                    pass
                                else:
                                    aMapProdBase.AddItem_ByProdID(tmp)
                        elif aIsNormal:  # 一般選擇權商品
                            aMapProdBase.AddItem_ByProdID(tmp)
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProd_Opt:{ex}")
                # endregion

                return RCode.OK, aMapProdBase
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"QryProd_Opt:{ex}")
            self.__Fire_LogEvent(f"[期][QryProd_Opt]取個選擇權商品檔失敗!({ex})")
        return RCode.FAIL, aMapProdBase

    def QryProd_OvsFut(self):
        """out  1. bool
                2.TObjOvsFutProdMthMap aMapBase
        取期貨商品檔(不含選擇權)"""
        aMapBase: TObjOvsFutProdMthMap = None
        try:
            bOK = False
            sAskData = "QuoteOvs/*/FUT/*/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_OvsFut, sAskData, 'big5',self._vRcvTopic_OvsFut_Req)  # 要求回補最新一筆行情
            if bOK:
                map = json.loads(sResData)
                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[海期][QryProd_OvsFut](aData={sResData})行情回補資料有誤!")
                        return False, aMapBase
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[海期][QryProd_OvsFut](aData={sResData})沒有BAS資料!")
                    return False, aMapBase
                # endregion
                # region 拆解基本資料
                aMapBase = TObjOvsFutProdMthMap("", "")
                for str in map["BAS"]:
                    try:
                        tmp = TOvsFutQtBase()
                        tmp.Handle_BAS(str)

                        aMapBase.AddItem(tmp)
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProd_OvsFut: {ex}")
                # endregion
                return True, aMapBase
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"QryProd_OvsFut:{ex}")
            self.__Fire_LogEvent(f"[海期][QryProd_OvsFut]取期貨商品檔(不含選擇權)失敗!({ex})")
        return False, aMapBase

    def QryProd_OvsOpt(self):
        """取選擇權商品檔
            return: out TObjOvsFutProdMthMap aMapBase"""
        aMapBase: None
        try:
            bOK: bool = False
            sAskData = "QuoteOvs/*/OPT/*/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_OvsFut, sAskData, 'big5',self._vRcvTopic_OvsFut_Req)  # 要求回補最新一筆行情
            if bOK:
                map = json.loads(sResData)
                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[海期][QryProd_OvsOpt](aData={sResData})行情回補資料有誤!")
                        return False, aMapBase
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[海期][QryProd_OvsOpt](aData={sResData})沒有BAS資料!")
                    return False, aMapBase
                # endregion
                # region 拆解基本資料
                aMapBase = TObjOvsFutProdMthMap("", "")
                for str in map["BAS"]:
                    try:
                        tmp = TOvsFutQtBase()
                        tmp.Handle_BAS(str)
                        aMapBase.AddItem(tmp)
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProd_OvsOpt: {ex}")
                # endregion
                return True, aMapBase
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"QryProd_OvsOpt:{ex}")
            self.__Fire_LogEvent(f"[海期][QryProd_OptOvs]取選擇權商品檔失敗!({ex})")
        return False, aMapBase

    def QryProd_Fut_ByExchangeTree(self, aCanTxOnly: bool):
        """取期貨商品檔(交易所樹狀)
        aCanTxOnly:是否只載入可交易的商品(False:表示載入所有商品)
        return  TObjBaseOvsFutExchageTree aExchangeTree"""
        aExchangeTree: TObjBaseOvsFutExchageTree = None
        try:
            bOK: bool = False
            sAskData = "QuoteOvs/*/FUT/*/RECOVER"
            sResData = ""
            bOK, sResData = self.__SendMessage_ByRequest(
                self._vRcvTopic_OvsFut, sAskData, 'big5',self._vRcvTopic_OvsFut_Req)  # 要求回補最新一筆行情
            if bOK:
                map = json.loads(sResData)
                # region 檢核
                if "status" in map and len(map["status"]) > 0:
                    if map["status"][0] == "error":
                        self.__Fire_LogEvent(
                            f"[海期][QryProd_OvsFut](aData={sResData})行情回補資料有誤!")
                        return False, aExchangeTree
                if "BAS" in map and len(map["BAS"]) == 0:
                    self.__Fire_LogEvent(
                        f"[海期][QryProd_OvsFut](aData={sResData})沒有BAS資料!")
                    return False, aExchangeTree
                # endregion
                # region 拆解基本資料
                aExchangeTree = TObjBaseOvsFutExchageTree()
                for str in map["BAS"]:
                    try:
                        tmp = TOvsFutQtBase()
                        tmp.Handle_BAS(str)
                        if tmp.Market == "4":
                            # 是否只載入可交易的商品
                            if aCanTxOnly == False or (aCanTxOnly and tmp.Display == "Y"):
                                aExchangeTree.AddItem(tmp)
                    except Exception as ex:
                        self._log.Add(arg1=SolLogType.Error,
                                      arg2=f"QryProd_Fut_ByExchangeTree: {ex}")
                aExchangeTree.SetInit()
                # endregion

                return True, aExchangeTree
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"QryProd_Fut_ByExchangeTree:{ex}")
            self.__Fire_LogEvent(f"[海期][QryProdID_Fut]取期貨商品檔(不含選擇權)失敗!({ex})")
        return False, aExchangeTree
    # endregion 取商品檔

    # region Topic發送
    def __SendMessage(self, aTopic: str, aBody: str):
        try:
            with self._lock:
                pub_start = self._direct_publish_service.start_async()                
                pub_start.result()
                encoding = 'utf-8'
                payloadByte = bytearray(f'{aBody}', encoding)
                message: OutboundMessage = self._message_service.message_builder().build(payloadByte)
                self._direct_publish_service.publish(aTopic, message)

        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"SendMessage:{ex}")
        # finally:
        #         self._direct_publish_service.terminate()

    def __SendMessage_ByRequest(self, aTopic: str, aBody: str, encoding:str, aReqTopic: str):
        """指定收到的Reply Topic
            return  1: bool
                    2: out string aResData"""
        aResData = ""
        # if aBody.startswith(self._vQuote_OvsFUT):
        #     encoding = 'big5'
        # else:
        #     encoding = 'utf-8'

        payloadByte = bytearray(f'{aBody}', encoding)
        message: OutboundMessage = self._message_service.message_builder().build(payload=payloadByte)
        # log.info(f'start send request: topic={topic}, msg={msg}')
        try:
            with self._lock:                                
                reply = self._message_requester.publish_await_response(request_message=message,
                                                                       request_destination=Topic.of(
                                                                           aTopic),
                                                                       reply_timeout=self._reply_timeout)
                payload_str = reply.get_payload_as_bytes().decode(encoding)                
                return True, payload_str
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,
                          arg2=f"send_request exception! topic={aTopic}, msg={aBody}, exception={ex}")
            payload_str = ""

        return False, payload_str
    # endregion Topic發送

    #region new method
    def Subscribe(self, exchange:str, symbol:str)->RCode:
        """單一商品訂閱
            exchange:交易所(TWF/TWS)
            symbol:商品代碼"""
        self._log.Add(arg1=SolLogType.Info, arg2=f"[Subscribe]exchange={exchange}, symbol={symbol}")

        #期貨
        if EXCHANGE.TWF == exchange:            
            ret = self.__DoSubQuoteFUT(symbol, True)
        #證券
        elif EXCHANGE.TWS == exchange:            
            ret = self.__DoSubQuoteSTK(symbol, True)
            
        return ret
    def OvsSubscribe(self, aSymbol:str):
        """海期單一商品訂閱"""        
        return self.__DoSubQuoteOvsFUT(aSymbol, True)
    
    def OvsSubscribeWithCategory(self, aMrt:str = "FUT", aExchange:str = "*"):
        """海期訂閱分類商品"""
        if aMrt == "FUT":
            return self.__DoSubQuoteByCategoryOvsFUT(True, aExchange)
        else:
            self._log.Add(arg1=SolLogType.Error, arg2=f"OvsSubscribeWithCategory aMrt:{aMrt}")
            return RCode.FAIL
    
    def Unsubscribe(self, exchange:str, symbol:str)->RCode:
        """單一商品取消訂閱
        exchange:交易所(TWF/TWS)
        symbol:商品代碼"""
        self._log.Add(arg1=SolLogType.Info, arg2=f"[Unsubscribe]exchange={exchange}, symbol={symbol}")

        sErrMsg:str = ""
        #期貨
        if EXCHANGE.TWF == exchange:
            ret, sErrMsg = self.__DoUnSubTopicFUT(symbol)
            if ret == False:#EX:TXFC2
                sysevt = SystemEvent(RCode.SUBSCRIPTION_FAIL,sErrMsg)
                self.__mdm.Fire_OnSystemEvent(sysevt)
                return RCode.FAIL
        #證券
        elif EXCHANGE.TWS == exchange:        
            ret , sErrMsg = self.__DoUnSubTopicSTK(symbol)
            if ret == False:
                sysevt = SystemEvent(RCode.SUBSCRIPTION_FAIL,sErrMsg)
                self.__mdm.Fire_OnSystemEvent(sysevt)
                return RCode.FAIL

        return RCode.OK    
    def OvsUnSubscribe(self, aSymbol:str)->bool:
        "海期單一商品取消訂閱"
            
        sErrMsg:str = ""
        ret, sErrMsg = self.__DoUnSubTopicOvsFUT(aSymbol)
        if ret:
            self._log.Add(arg1=SolLogType.Info, arg2=f"[OvsUnSubscribe]aSymbol={aSymbol}")
            return RCode.OK
        else:
            self._log.Add(arg1=SolLogType.Info, arg2=f"[OvsUnSubscribe]aSymbol={aSymbol}, sErrMsg={sErrMsg}")
            return RCode.FAIL     
    def SubscribeWithCategory(self, exchange:str, subscriptionCategory:str)->RCode:
        self._log.Add(arg1=SolLogType.Info, arg2=f"[SubscribeWithCategory]exchange={exchange}, subscriptionCategory={subscriptionCategory}")
        # 期貨
        if EXCHANGE.TWF == exchange:            
            # new Task(() => fSolQuoteFutAPI.DoSubQuoteByCategory(subscriptionCategory, true)).Start();\
            thrd = threading.Thread(target=self.__DoSubQuoteByCategoryFUT, args=(subscriptionCategory, True))
            thrd.start()
        #證券
        elif EXCHANGE.TWS == exchange:
            # new Task(() => fSolQuoteStkAPI.DoSubQuoteByCategory(subscriptionCategory, true)).Start();   
            thrd = threading.Thread(target=self.__DoSubQuoteByCategorySTK, args=(subscriptionCategory, True))
            thrd.start()
        return RCode.OK
    
    def UnsubscribeWithCategory(self, exchange:str, subscriptionCategory:str)->RCode:
        """return   1.bool
                    2.errorMsg"""
        errorMsg:str=""
        #期貨
        if EXCHANGE.TWF == exchange:
            ret, errorMsg = self.__DoUnSubTopicByCategoryFUT(subscriptionCategory)
            if ret == RCode.FAIL:
                return RCode.FAIL,errorMsg        
        #證券
        elif EXCHANGE.TWS == exchange:
            ret, errorMsg = self.__DoUnSubTopicByCategorySTK(subscriptionCategory)
            if ret == RCode.FAIL:
                return RCode.FAIL,errorMsg
        return RCode.OK,errorMsg         
    def OvsUnSubscribeWithCategory(self, aMrt:str = "FUT", aExchange:str = "*"):        
        errMsg:str=""
        if aMrt == "FUT":
            ret, errMsg =self.__DoUnSubQuoteByCategoryOvsFUT(aExchange)
            if ret:
                return RCode.OK , ""
            else:
                return RCode.FAIL, errMsg
        else:
            return RCode.FAIL, "Mart is not 'FUT'"
        
    #region STK event
    def __SolQuoteStkAPI_OnQtRcvEvent(self, aMsg:str, aIsOK:bool, aMapQt:TObjStkQuoteMap):
        "行情回補"        
        if  aIsOK == False :
            self._log.Add(arg1=SolLogType.Info, arg2=f"[證券行情回補]回補失敗!({aMsg})")
            return
        try:
            for key, val in aMapQt.items():
                tmpQt:TStkQuoteData = val
                sSolIce = tmpQt.BAS.StkNo
                if self._fPrdSnapshotMap.NewItemStk(sSolIce, tmpQt):
                    # if self.__fRcvUseList == False:
                    prd:ProductSnapshot = self._fPrdSnapshotMap[sSolIce]
                    if tmpQt.UpdateBAS:
                        self.__mdm.Fire_OnUpdateBasic(prd.BasicData)
                        tmpQt.UpdateBAS = False
                    if tmpQt.UpdateHLTX:                            
                        prd.TickData = ProductTick_Stk(tmpQt)
                        prd.TickData.Upt_TX(tmpQt.QtTX)
                        prd.TickData.Upt_5Q(tmpQt.Qt5Q)
                        self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[sSolIce])                        
                        tmpQt.UpdateHLTX = False
            # if self.__fRcvUseList:
            #     if len(self._fPrdSnapshotMap) > 0:                
            #         ls = list(self._fPrdSnapshotMap.values())
            #         self.__mdm.Fire_OnUpdateProductBasicList(ls)
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteStkAPI_OnQtRcvEvent]aMsg={aMsg}, aIsOK={aIsOK}, ex:{ex}")

    def __SolQuoteStkAPI_OnQtIdxRcvEvent(self, aMsg:str, aIsOK:str, aMapQt:TObjStkQuoteMap):
        "回補(指數)"        
        if aIsOK == False:
            self._log.Add(arg1=SolLogType.Info, arg2=f"[證券行情回補(指數)]{aMsg}回補失敗!") 
            return
        try:
            for key, val in aMapQt.items():
                tmpQt:TStkQuoteData = val
                sSolIce = tmpQt.BAS.StkNo
                if self._fPrdSnapshotMap.NewItemStk(sSolIce, tmpQt):
                    if self.__fRcvUseList == False:
                        prd:ProductSnapshot = self._fPrdSnapshotMap[sSolIce]
                        self.__mdm.Fire_OnUpdateBasic(prd.BasicData)
                        self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[sSolIce])
            if self.__fRcvUseList:
                if len(self._fPrdSnapshotMap) > 0:                
                    ls = list(self._fPrdSnapshotMap.values())
                    self.__mdm.Fire_OnUpdateProductBasicList(ls)           
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error,arg2=f"[SolQuoteStkAPI_OnQtIdxRcvEvent]aMsg={aMsg}, aIsOK={aIsOK}, ex:{ex}")
        
    def __SolQuoteStkAPI_OnQtTXEvent(self, aSolIce:str, tmpQtTx:TStkQtTX):
        "即時成交(一般證券)"
        try:
            tmpPrd:ProductSnapshot = None

            ret, tmpPrd = self._fPrdSnapshotMap.GetItem(aSolIce)
            # self._log.Add(arg1=SolLogType.Info, arg2=f"SolQuoteStkAPI_OnQtTXEvent1 ret:{ret} aSolIce:{aSolIce} tmpQtTx:{tmpQtTx}")
            if ret:
                tmpTick:ProductTick_Stk = tmpPrd.TickData
                ret,sErr = tmpTick.Upt_TX(tmpQtTx)                
                if ret:
                    self.__mdm.Fire_OnMatch(self._fPrdSnapshotMap[aSolIce].TickData)
                    # self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[aSolIce])
                else:
                    self._log.Add(arg1=SolLogType.Error, arg2=f"STK_TXEvent Error:{sErr} aSolIce:{aSolIce} tmpQtTx:{tmpQtTx}")
        except Exception as ex:            
            self._log.Add(arg1=SolLogType.Error, arg2=f"[STK_TXEvent]ProdID={aSolIce}, ex:{ex}")
    def __SolQuoteStkAPI_OnQt5QEvent(self, aSolIce:str, tmpQt5Q:TStkQt5Q):
        "5檔行情(一般證券)"        
        try:
            tmpPrd:ProductSnapshot = None
            ret, tmpPrd = self._fPrdSnapshotMap.GetItem(aSolIce)            
            if ret:
                tmpTick:ProductTick_Stk = tmpPrd.TickData

                ret,sErr = tmpTick.Upt_5Q(tmpQt5Q)
                if ret:
                    self.__mdm.Fire_OnOrderBook(self._fPrdSnapshotMap[aSolIce].TickData)
                    # self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[aSolIce])                
                else:
                    self._log.Add(arg1=SolLogType.Error, arg2=f"STK_5QEvent Error:{sErr} aSolIce={aSolIce} tmpQt5Q:{tmpQt5Q}")
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[STK_5QEvent]ProdID={aSolIce}, ex:{ex}")                
    def __SolQuoteStkAPI_OnQtIDXEvent(self, aSolIce:str, tmpQtIDX:TStkQtIDX):
        "指數行情(EX:VIX)"
        try:
            tmpPrd:ProductSnapshot = None

            ret,tmpPrd = self._fPrdSnapshotMap.GetItem(aSolIce)
            if ret:
                tmpTick:ProductTick_Stk = tmpPrd.TickData

                ret, sErr = tmpTick.Upt_IDX(tmpQtIDX)
                if ret:
                    self.__mdm.Fire_OnMatch(self._fPrdSnapshotMap[aSolIce].TickData)
                    # self.__mdm.Fire_OnUpdateLastSnapshot(self._fPrdSnapshotMap[aSolIce])
                else:
                    self._log.Add(arg1=SolLogType.Error, arg2=f"STK_IDXEvent Error:{sErr} aSolIce:{aSolIce} tmpQtIDX:{tmpQtIDX}")
        except Exception as ex:
            self._log.Add(arg1=SolLogType.Error, arg2=f"[SolQuoteStkAPI_OnQtIDXEvent]ProdID={aSolIce}, ex:{ex}")
        

    #endregion STK event
    #endregion new method

class SolAPIHH(SolAPI):
    def __init__(self, __mdm: MarketDataMart,pypath:str,loglv = logging.INFO, conlv = logging.INFO):
        super().__init__(__mdm, pypath, False, loglv, conlv)

    def Logon(self, host:str, username:str, password:str, aCompressLevel:int = 5)->RCode:
        """return RCode
        HH使用者登入
        host:連線主機HOST
        username:使用者帳號
        password:使用者密碼
        """
        if aCompressLevel < 1:
            return RCode.FAIL
      
        return self.Connect(host + ":55003", "api", username, password, aCompressLevel)

        
#-------------------------------------------------------Thread class receive----------------------------------------------#


class TSolaceMessageThreadClass(MessageHandler):
    """create thread get receive to list and then call UI mesage"""
    # def __init__(self, log: logging.Logger, MsgHdr_fromUI: MessageHandler):

    def __init__(self, name: str, log: logging.Logger, MsgHdr_proc):
        self._name = name
        self._msgHandler = MsgHdr_proc
        self._lock = Lock()
        self._log = log
        self._list = []
        self._run = True
        self.thrd = threading.Thread(target=self.OnThread, name=self._name)
        self.thrd.start()

    def OnThread(self):
        list_date = []
        iCnt_Now, iCnt_Last, i = 0, 0, 0
        while self._run:
            # print("loop(0.001)...",end='')
            try:
                with self._lock:
                    list_date = self._list.copy()                    
                    iCnt_Now = len(list_date)
                    if(len(self._list) > 3000) and iCnt_Now == iCnt_Last:
                        self._list = []
                        
                for i in range(iCnt_Last, iCnt_Now):
                    self._msgHandler(list_date[i])                    
                    # self._msgHandler.on_message(da)#call the message
                iCnt_Last = iCnt_Now
            except Exception as ex:
                self._log.Add(
                    arg1=SolLogType.Error, arg2=f"TSolaceMessageThreadClass __Handle_RTQuote_Main exception! exception={ex}")
            finally:
                sleep(0.001)

    def Add(self, message):
        with self._lock:
            self._list.append(message)

    def on_message(self, message):
        """ Message receive callback """
        self.Add(message)

#-------------------------------------------------------Thread class sub unsub----------------------------------------------#


class TMyWorkItemThreadClass:
    def __init__(self, name: str, log: logging.Logger, MsgHdr_proc):
        self._name = name
        self._msgHandler = MsgHdr_proc
        self._lock = Lock()
        self._log = log
        self._run = True
        self._queue = queue.Queue()
        thrd = threading.Thread(target=self.OnThread, name=self._name)
        thrd.start()

    def OnThread(self):
        while self._run:
            # print("loop(0.001)...",end='')
            try:
                with self._lock:
                    while not self._queue.empty():
                        para = self._queue.get()
                        # self._log.Add(arg1=SolLogType.Info, arg2=f"Thrd: {self._name} arg1:{para['arg1']} arg2:{para['arg2']} proc:{self._msgHandler}")
                        self._msgHandler(para["arg1"], para["arg2"])

            except Exception as ex:
                self._log.Add(arg1=SolLogType.Error, arg2=f"TMyWorkItemThreadClass send_msg exception! exception={ex}")
            finally:
                sleep(0.001)

    def Add(self, **para):
        with self._lock:
            self._queue.put(para)

class CacheReqOutListener(CacheRequestOutcomeListener):
    def __init__(self,solapi, thrdMsg:TSolaceMessageThreadClass, log:SolaceLog) -> None:
        self._solapi = solapi
        self._thrdMag:TSolaceMessageThreadClass = thrdMsg
        self._log:SolaceLog = log
    def on_completion(self, result: CacheRequestOutcome, correlation_id: int, e: Exception):        
        # print(f"\n*******CacheRequestOutcomeListenerHandler:{result}, cache_request_id:{correlation_id} exception:{e}")        
        if result == CacheRequestOutcome.FAILED:
            self._log.Add(arg1=SolLogType.Error, arg2=f"cache completion fail: result:{result} id:{correlation_id} exception:{e}")
            job: TCacheJob = self._solapi._fMapCacheJob[correlation_id]            
            # print(f"cache completion fail: result:{result} id:{correlation_id} exception:{e} jobHL:{job.TopicHL} TX:{job.TopicTX}")            

        elif result == CacheRequestOutcome.OK:
            self._log.Add(arg1=SolLogType.Debug, arg2=f"cache completion OK: result:{result} id:{correlation_id} exception:{e}")
            if self._solapi._fMapCacheJob.get(correlation_id):
                job: TCacheJob = self._solapi._fMapCacheJob[correlation_id]
                Category = job.Params.get("Category")            

                # print(f"cache completion OK: result:{result} id:{correlation_id} exception:{e} jobHL:{job.TopicHL} TX:{job.TopicTX} Category:{Category}")
                if(Category =="SubQuoteByCategory_BAS"):
                    #  if job.TopicHL == "":#訂閱category HL
                    job_HL = TCacheJob()
                    arr = job.TopicBAS.split("/")
                    if job.TopicBAS.startswith("Quote/TWS/"):
                        arr[len(arr)-1] = "HL"
                        arr[len(arr)-2] = "*"
                        arr[len(arr)-3] = "*"
                        job_HL.TopicHL = "/".join(arr)#Quote/TWS/S/*/*/HL
                    elif job.TopicBAS.startswith("Quote/TWF/"):
                        arr[len(arr)-1] = "HL"
                        arr[len(arr)-2] = "*"                        
                        job_HL.TopicHL = "/".join(arr)#Quote/TWF/FUT/*/HL
                    job_HL.oneProd = False
                    job_HL.RequestID = self._solapi.GetRequestID()
                    job_HL.Params["Category"] = "SubQuoteByCategory_HL"
                    self._solapi._fMapCacheJob[job_HL.RequestID] = job_HL
                
                    self._solapi.callcache(job_HL.RequestID, job_HL.TopicHL) 
                
                  


            
