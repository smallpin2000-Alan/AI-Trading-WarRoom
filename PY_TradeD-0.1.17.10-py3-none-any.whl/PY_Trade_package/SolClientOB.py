import datetime #line:1
from threading import Lock #line:2
from PY_Trade_package .SolLog import *#line:3
from PY_Trade_package .SolPYAPI_Model import *#line:4
from PY_Trade_package .Helper import MQCSHelper #line:5
from solace .messaging .messaging_service import MessagingService #line:7
from solace .messaging .publisher .outbound_message import OutboundMessage #line:8
from solace .messaging .resources .topic import Topic #line:9
from solace .messaging .resources .topic_subscription import TopicSubscription #line:10
from enum import Enum #line:11
from solace .messaging .resources .cached_message_subscription_request import CachedMessageSubscriptionRequest #line:12
from solace .messaging .utils .cache_request_outcome_listener import CacheRequestOutcomeListener #line:13
from solace .messaging .utils .cache_request_outcome import CacheRequestOutcome #line:14
class Stats_Rx (Enum ):#line:17
    DirectBytes =0 #line:18
    "Direct data bytes received"#line:19
    Bytes =1 #line:20
    "Direct data bytes received"#line:21
    DirectMsgs =2 #line:22
    "Direct data messages received"#line:23
    Msgs =3 #line:24
    "Direct data messages received"#line:25
    NonEmptyReads =4 #line:26
    "non-empty reads"#line:27
    DiscardMsgIndication =5 #line:28
    "Messages with discard indication"#line:29
    DiscardSMFUnknownElement =6 #line:30
    "Invalid messages (SMF parser Error)"#line:31
    DiscardMsgTooBig =7 #line:32
    "Receive message too large"#line:33
    AcksSent =8 #line:34
    "Guaranteed Delivery Acknowledgements sent"#line:35
    DiscardsDuplicate =9 #line:36
    "Duplicate Guaranteed Delivery messages received"#line:37
    DiscardsNoMatchingFlow =10 #line:38
    "Guaranteed Delivery messages with unknown flow"#line:39
    DiscardsOutOfOrder =11 #line:40
    "Out of order Guaranteed Delivery messages received"#line:41
    PersistentBytes =12 #line:42
    "Guaranteed Delivery (Persistent) bytes received"#line:43
    PersistentMsgs =13 #line:44
    "Guaranteed Delivery (Persistent) messages received"#line:45
    NonPersitentBytes =14 #line:46
    "Guaranteed Delivery (Non-Persistent) bytes received"#line:47
    NonPersistentMsgs =15 #line:48
    "Guaranteed Delivery (Non-Persistent) messages received"#line:49
    ControlMsgs =16 #line:50
    "Control (non-data) messages received"#line:51
    ControlBytes =17 #line:52
    "Control (non-data) bytes received"#line:53
    TotalDataBytes =18 #line:54
    "Data bytes received"#line:55
    TotalDataMsgs =19 #line:56
    "Data messages received"#line:57
    CompressedBytes =20 #line:58
    "Bytes received before decompression"#line:59
    ReplyMsg =21 #line:60
    "Reply messages received"#line:61
    ReplyMsgDiscard =22 #line:62
    "Reply messages discarded due to no outstanding request"#line:63
    CacheRequestOkResponse =23 #line:64
    "Cache Requests completed ok"#line:65
    CacheRequestFulfillData =24 #line:66
    "Cache Requests fulfilled by live data"#line:67
    CacheRequestErrorResponse =25 #line:68
    "Cache Requests failed due to solCache error response"#line:69
    CacheRequestDiscardResponse =26 #line:70
    "Cached Request Response discarded due to errors in response format"#line:71
    CacheMsg =27 #line:72
    "Cached messages delivered to application"#line:73
    FoundCutThroughSync =28 #line:74
    "On a cut-through Flow, the number of times the Flow entered cut-through delivery mode."#line:75
    LostCutThroughSync =29 #line:76
    "On a cut-through Flow, the number of times the Flow left cut-through delivery mode to resynchronize with the Guaranteed message storage on the appliance."#line:77
    LostCutThroughSyncGM =30 #line:78
    "On a cut-through Flow, the number of times the Flow left cut-through delivery mode to resynchronize with the Guaranteed message storage due to receiving a Guaranteed message that was not previously received as Direct."#line:79
    OverflowCutThroughSyncBuffer =31 #line:80
    "On a cut-through Flow, the number of times the synchronization buffer overflowed, delaying synchronization."#line:81
    AlreadyCutThrough =32 #line:82
    "On a cut-through Flow, the number of Guaranteed messages discarded because they had already been received on the cut-through Flow."#line:83
    DiscardFromCutThroughSync =33 #line:84
    "On a cut-through Flow, the number of messages discarded from the synchronization list other than those discarded due to overflow."#line:85
    DiscardMessageFlowUnboundPending =34 #line:86
    "On a transacted flow, the number of messages discarded because the flow is in a UNBOUND pending state."#line:87
    DiscardMessageTransactionRollback =35 #line:88
    "On a transacted flow, the number of messages discarded after a transaction rollback and becomes a message comes in with prevMsgId=0."#line:89
    DiscardTransactionResponse =36 #line:90
    "On a transacted session, the number of transaction responses discarded due to reconnection."#line:91
class SolClient :#line:93
    host =''#line:95
    vpn =''#line:96
    username =''#line:97
    password =''#line:98
    cacheName ='dc01'#line:99
    clientName =''#line:100
    cacheRequestTimeoutInMsecs =50000 #line:101
    requestTimeoutInMsecs =50000 #line:102
    session =None #line:103
    context =None #line:104
    Jan1st1970 =datetime .datetime (1970 ,1 ,1 ,0 ,0 ,0 ,tzinfo =datetime .timezone .utc )#line:106
    def __init__ (OO0OO0O000O0OO0O0 ,O0OOO00000000000O :str ,O00OOO0000OOOOO0O :str ,O0OO0O0O00O0OOO0O :str ,OO0O000OO00O00OOO :str ,OO0O00O00OOOOO000 :SolaceLog ,clientName :str =""):#line:107
        ""#line:108
        OO0OO0O000O0OO0O0 .host =O0OOO00000000000O #line:109
        OO0OO0O000O0OO0O0 .vpn =O00OOO0000OOOOO0O #line:110
        OO0OO0O000O0OO0O0 .username =O0OO0O0O00O0OOO0O #line:111
        OO0OO0O000O0OO0O0 .password =OO0O000OO00O00OOO #line:112
        if clientName =="":#line:113
            O000OO0O0O0OOO0OO =int ((datetime .datetime .now (datetime .timezone .utc )-OO0OO0O000O0OO0O0 .Jan1st1970 ).total_seconds ()*1000 )#line:114
            O0O00000OOOOO000O =MQCSHelper .extractIp ()#line:115
            OO0OO0O000O0OO0O0 .clientName =f"MQCS:{O0OO0O0O00O0OOO0O}:{O0O00000OOOOO000O}:{O000OO0O0O0OOO0OO}"#line:116
        else :#line:117
            OO0OO0O000O0OO0O0 .clientName =clientName #line:118
        OO0OO0O000O0OO0O0 .lockObj =Lock ()#line:119
        OO0OO0O000O0OO0O0 .lock_RequestID =Lock ()#line:120
        OO0OO0O000O0OO0O0 ._fLast_RequestID =0 #line:121
        OO0OO0O000O0OO0O0 ._log =OO0O00O00OOOOO000 #line:122
        OO0OO0O000O0OO0O0 ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"init SolClient: host={OO0OO0O000O0OO0O0.host}, vpn={OO0OO0O000O0OO0O0.vpn}, username={OO0OO0O000O0OO0O0.username}, password={OO0OO0O000O0OO0O0.password}, clientName={OO0OO0O000O0OO0O0.clientName}")#line:123
        OO0OO0O000O0OO0O0 ._is_connected =False #line:124
    def PrintRxStats (O00OOOOO0OOO0OO00 ):#line:126
        ""#line:127
        OOO000O00OO000O00 =""#line:129
        OO000O0O00OO000O0 =list (Stats_Rx )#line:130
        OOO000O00OO000O00 =OOO000O00OO000O00 +"Session Rx stats: "#line:131
        for O0O0OOOO00OO0OO0O in range (len (OO000O0O00OO000O0 )):#line:132
            try :#line:133
                OOO000O00OO000O00 =OOO000O00OO000O00 +f"\n\t{O0O0OOOO00OO0OO0O} {OO000O0O00OO000O0[O0O0OOOO00OO0OO0O]}"#line:134
            except Exception as OO0000OO0OOO0O00O :#line:135
                O00OOOOO0OOO0OO00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"PrintRxStats exception!{O0O0OOOO00OO0OO0O}")#line:136
    def SendRequestSync (OOO00O0OOO00O00OO ,O00000O000OOOOO0O :str ,OO0O0O000O0OO0OO0 :str ,Ecoding :str ="utf-8")->str :#line:145
        ""#line:147
        return OOO00O0OOO00O00OO .SendRequestSyncX (O00000O000OOOOO0O ,OO0O0O000O0OO0OO0 ,OOO00O0OOO00O00OO .requestTimeoutInMsecs ,Ecoding );#line:148
    def SendRequestSyncX (O0OO0000OOO000O0O ,O0OOO0OOO00OO0OO0 :str ,OO0O00000O0O00O00 :str ,OOOOO0OOO0OO0OO00 :int ,OO0OO0O0000O00O00 :str )->str :#line:150
        ""#line:152
        O0OO0000OOO000O0O ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"request topic={O0OOO0OOO00OO0OO0}, message={OO0O00000O0O00O00}, timeout={OOOOO0OOO0OO0OO00}")#line:153
        OOOOO00OOO0OOOOOO =""#line:154
        if O0OOO0OOO00OO0OO0 .startswith ("QuoteOvs/"):#line:155
            OO0OO0O0000O00O00 ='big5'#line:156
        O00O00OOOO0O000O0 =bytearray (f'{OO0O00000O0O00O00}',OO0OO0O0000O00O00 )#line:158
        OOO0O0O0000000O00 :OutboundMessage =O0OO0000OOO000O0O ._message_service .message_builder ().build (payload =O00O00OOOO0O000O0 )#line:159
        try :#line:160
            with O0OO0000OOO000O0O .lockObj :#line:161
                OOOOO00OOO0OOOOOO =O0OO0000OOO000O0O ._message_requester .publish_await_response (request_message =OOO0O0O0000000O00 ,request_destination =Topic .of (O0OOO0OOO00OO0OO0 ),reply_timeout =OOOOO0OOO0OO0OO00 )#line:165
                OO0OOOO0OOOO0OOO0 =OOOOO00OOO0OOOOOO .get_payload_as_bytes ().decode (OO0OO0O0000O00O00 )#line:166
            return OO0OOOO0OOOO0OOO0 #line:167
        except Exception as O00OO0OOO0OO00OOO :#line:168
            O0OO0000OOO000O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SendRequestSyncX Request failed, return code{O00OO0OOO0OO00OOO}")#line:169
        return ""#line:170
    def createConnection (O0O00OOOO0O00OOO0 ,O0OOO0OO0O0OOOO00 )->RCode :#line:172
        O0O00OOOO0O00OOO0 ._log .Add (arg1 =SolLogType .Info ,arg2 ="Start Create Connection")#line:173
        O0OO0OOO0OO0OOO0O :RCode =RCode .FAIL #line:175
        O00OOO0OOOO00O00O :dict ={}#line:177
        O00OOO0OOOO00O00O ["solace.messaging.transport.host"]=O0O00OOOO0O00OOO0 .host #line:178
        O00OOO0OOOO00O00O ["solace.messaging.service.vpn-name"]=O0O00OOOO0O00OOO0 .vpn #line:179
        O00OOO0OOOO00O00O ["solace.messaging.authentication.basic.username"]=O0O00OOOO0O00OOO0 .username #line:180
        O00OOO0OOOO00O00O ["solace.messaging.authentication.basic.password"]=O0O00OOOO0O00OOO0 .password #line:181
        O00OOO0OOOO00O00O ['solace.messaging.transport.reconnection-attempts']=5 #line:182
        if O0O00OOOO0O00OOO0 .clientName !="":#line:183
            O00OOO0OOOO00O00O ["solace.messaging.client.name"]=O0O00OOOO0O00OOO0 .clientName #line:184
        try :#line:185
            with O0O00OOOO0O00OOO0 .lockObj :#line:186
                O0O00OOOO0O00OOO0 ._message_service =MessagingService .builder ().from_properties (O00OOO0OOOO00O00O ).build ()#line:187
                O0O00OOOO0O00OOO0 ._message_service .connect ()#line:188
                O0O00OOOO0O00OOO0 ._message_receiver =O0O00OOOO0O00OOO0 ._message_service .create_direct_message_receiver_builder ().build ()#line:190
                O0O00OOOO0O00OOO0 ._message_receiver .start ()#line:191
                O0O00OOOO0O00OOO0 ._message_receiver .receive_async (O0OOO0OO0O0OOOO00 )#line:193
                O0O00OOOO0O00OOO0 ._direct_publish_service =O0O00OOOO0O00OOO0 ._message_service .create_direct_message_publisher_builder ().build ()#line:195
                O0O00OOOO0O00OOO0 ._message_requester =O0O00OOOO0O00OOO0 ._message_service .request_reply ().create_request_reply_message_publisher_builder ().build ().start ()#line:196
                O0O00OOOO0O00OOO0 ._is_connected =O0O00OOOO0O00OOO0 ._message_service .is_connected #line:197
                if O0O00OOOO0O00OOO0 ._is_connected :#line:198
                    O0OO0OOO0OO0OOO0O =RCode .OK #line:199
                else :#line:200
                    O0OO0OOO0OO0OOO0O =RCode .FAIL #line:201
        except Exception as O0OOO0O00O0OOO0OO :#line:203
            O0O00OOOO0O00OOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Create Connection Fail. {O0OOO0O00O0OOO0OO}")#line:204
        O0O00OOOO0O00OOO0 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"End of Create Connection: rc={O0OO0OOO0OO0OOO0O}")#line:206
        return O0OO0OOO0OO0OOO0O #line:207
    def AddSubscription (O00OOOO0O00O00O0O ,O0000O00OOOO0O00O :str )->RCode :#line:210
        return O00OOOO0O00O00O0O .AddSubscriptionX (O0000O00OOOO0O00O ,False )#line:211
    def AddSubscriptionX (O00O0OOO0OOO00O0O ,O0000OOO00O0OOOOO :str ,O00O00OOO00O0OOO0 :bool ):#line:213
        O00O0OOO0OOO00O0O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"AddSubscription: topic={O0000OOO00O0OOOOO}, withCache={O00O00OOO00O0OOO0}")#line:214
        OOOOO00OOO00OO000 :RCode =RCode .FAIL #line:215
        if O00O0OOO0OOO00O0O ._is_connected :#line:216
            try :#line:217
                with O00O0OOO0OOO00O0O .lockObj :#line:218
                    O00O0OOO0OOO00O0O ._message_receiver .add_subscription (TopicSubscription .of (O0000OOO00O0OOOOO ))#line:219
                OOOOO00OOO00OO000 =RCode .OK #line:220
                return OOOOO00OOO00OO000 #line:221
            except Exception as OO0OOOO0O00OO0O0O :#line:222
                O00O0OOO0OOO00O0O ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Session subscribe: topic={O0000OOO00O0OOOOO} {OO0OOOO0O00OO0O0O}")#line:223
        return OOOOO00OOO00OO000 #line:224
    def AddSubscriptionXUid (OOO00OO0OO00O0O00 ,OOO000OOO0O000O0O :str ,O000OOO000O00OOOO :str ,O0OO0OO00OO0OO0O0 :bool ):#line:226
        O0O0O0OO0OOO00000 =OOO000OOO0O000O0O +"/"+O000OOO000O00OOOO [:-6 ]+"******"#line:227
        OOO000OOO0O000O0O =OOO000OOO0O000O0O +"/"+O000OOO000O00OOOO #line:228
        OOO00OO0OO00O0O00 ._log .Add (arg1 =SolLogType .Info ,arg2 =f"AddSubscription: topic={O0O0O0OO0OOO00000}, withCache={O0OO0OO00OO0OO0O0}")#line:229
        OO000O000O000O0OO :RCode =RCode .FAIL #line:230
        if OOO00OO0OO00O0O00 ._is_connected :#line:231
            try :#line:232
                with OOO00OO0OO00O0O00 .lockObj :#line:233
                    OOO00OO0OO00O0O00 ._message_receiver .add_subscription (TopicSubscription .of (OOO000OOO0O000O0O ))#line:234
                OO000O000O000O0OO =RCode .OK #line:235
                return OO000O000O000O0OO #line:236
            except Exception as OO00OO0OO0O0O00O0 :#line:237
                OOO00OO0OO00O0O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Session subscribe: topic={OOO000OOO0O000O0O} {OO00OO0OO0O0O00O0}")#line:238
        return OO000O000O000O0OO #line:239
    def AddSubscriptionlist (OO0O000000000O00O ,O00O0000O0O000000 :list ,O0000OO0OO00000O0 :bool ):#line:241
        OO0O000000000O00O ._log .Add (arg1 =SolLogType .Info ,arg2 =f"AddSubscriptionlist: topic={O00O0000O0O000000}, withCache={O0000OO0OO00000O0}")#line:242
        O0OO0O0000O000OOO :RCode #line:243
        for OOO000O00O00000OO in O00O0000O0O000000 :#line:244
            O0OO0O0000O000OOO =OO0O000000000O00O .AddSubscriptionX (OOO000O00O00000OO ,O0000OO0OO00000O0 )#line:245
            if O0OO0O0000O000OOO !=RCode .OK :#line:246
                OO0O000000000O00O .RemoveSubscriptionlist (O00O0000O0O000000 )#line:247
                return RCode .FAIL #line:248
        return RCode .OK #line:250
    def RemoveSubscriptionlist (OO0O000O0O0OO0OOO ,OO0OOO0OO00000O0O :list ):#line:253
        for O0OOOO0OOO00OOO00 in OO0OOO0OO00000O0O :#line:254
            OO0O000000OO00O0O =OO0O000O0O0OO0OOO .RemoveSubscription (O0OOOO0OOO00OOO00 )#line:255
            if OO0O000000OO00O0O !=RCode .OK :#line:256
                OO0O000O0O0OO0OOO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"RemoveSubscription: rc={OO0O000000OO00O0O}")#line:257
        return RCode .OK #line:258
    def RemoveSubscription (OO0OOOO0O0O000O00 ,OO0000O00OO0O0OO0 :str ):#line:260
        OOOO0OO000000O00O :RCode =RCode .FAIL #line:261
        try :#line:262
            with OO0OOOO0O0O000O00 .lockObj :#line:263
                OO0OOOO0O0O000O00 ._message_receiver .remove_subscription (TopicSubscription .of (OO0000O00OO0O0OO0 ))#line:264
            OOOO0OO000000O00O =RCode .OK #line:265
            return OOOO0OO000000O00O #line:266
        except Exception as OO000O000O00000OO :#line:267
            OO0OOOO0O0O000O00 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Session Unsubscribe: topic={OO0000O00OO0O0OO0} {OO000O000O00000OO}")#line:268
        return OOOO0OO000000O00O #line:270
    def DisConnect (O0OO0OO0O0O0O0000 ):#line:272
        O0OOOOO0O0O000OOO =RCode .OK #line:273
        if O0OO0OO0O0O0O0000 ._is_connected :#line:274
            O0OOOOO0O0O000OOO :RCode =RCode .FAIL #line:275
            try :#line:276
                with O0OO0OO0O0O0O0000 .lockObj :#line:277
                    O0OO0OO0O0O0O0000 ._message_receiver .terminate ()#line:278
                    O0OO0OO0O0O0O0000 ._message_requester .terminate ()#line:279
                    O0OO0OO0O0O0O0000 ._message_service .disconnect ()#line:280
                O0OOOOO0O0O000OOO =RCode .OK #line:281
            except Exception as OOO0OO0000OOO0O0O :#line:282
                O0OO0OO0O0O0O0000 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"DisConnect:{OOO0OO0000OOO0O0O}")#line:283
                O0OOOOO0O0O000OOO =RCode .FAIL #line:284
            finally :#line:285
                pass #line:286
        return O0OOOOO0O0O000OOO #line:288
    def request_cached_only (O000OO00000OOOOO0 ,OO0O0O000O0000000 :str ,O0000OOO00O00OO0O :str ,OO0000O00O0O0OOO0 :int ,OOOO00O00O0000O00 :int ):#line:290
        try :#line:291
            with O000OO00000OOOOO0 .lockObj :#line:292
                O0OOOOOO0OOO000O0 =CachedMessageSubscriptionRequest .cached_only (OO0O0O000O0000000 ,TopicSubscription .of (O0000OOO00O00OO0O ),OO0000O00O0O0OOO0 )#line:293
                O00O000O00OO00O0O =MyCacheRequestOutcomeListener (O000OO00000OOOOO0 )#line:294
                O000OO00000OOOOO0 ._message_receiver .request_cached (O0OOOOOO0OOO000O0 ,OOOO00O00O0000O00 ,O00O000O00OO00O0O )#line:296
        except Exception as OOOO000O0OO0OOO00 :#line:297
            O000OO00000OOOOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Error request_cached_only:{OOOO000O0OO0OOO00}")#line:298
    def GetRequestID (OO00OOO0O0O0O00OO ):#line:300
        try :#line:301
            with OO00OOO0O0O0O00OO .lock_RequestID :#line:302
                O0O00000O00O000O0 =int (datetime .datetime .now ().strftime ("%y%m%d%H%M%S%f"))#line:303
                if O0O00000O00O000O0 <OO00OOO0O0O0O00OO ._fLast_RequestID :#line:304
                    O0O00000O00O000O0 =OO00OOO0O0O0O00OO ._fLast_RequestID +1 #line:305
                OO00OOO0O0O0O00OO ._fLast_RequestID =O0O00000O00O000O0 #line:306
                return O0O00000O00O000O0 #line:307
        except Exception as O0O00O0O00O0OOOO0 :#line:308
            OO00OOO0O0O0O00OO ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Error GetRequestID:{O0O00O0O00O0OOOO0}")#line:309
class MyCacheRequestOutcomeListener (CacheRequestOutcomeListener ):#line:311
    def __init__ (OO0O000OOO0OOO0OO ,OOOOO00O00000OOO0 )->None :#line:312
        OO0O000OOO0OOO0OO ._log :SolaceLog =OOOOO00O00000OOO0 #line:313
    def on_completion (O0OO0O00000OOOOO0 ,O00O000O0O0O0O0OO :CacheRequestOutcome ,OOO00OOO0OO00OOO0 :int ,OO00OOOOOO00000OO :Exception ):#line:315
        if O00O000O0O0O0O0OO ==CacheRequestOutcome .FAILED :#line:316
            O0OO0O00000OOOOO0 ._log .Add (arg1 =SolLogType .Error ,arg2 =f"Mycache completion fail: result:{O00O000O0O0O0O0OO} id:{OOO00OOO0OO00OOO0} exception:{OO00OOOOOO00000OO}")#line:317
