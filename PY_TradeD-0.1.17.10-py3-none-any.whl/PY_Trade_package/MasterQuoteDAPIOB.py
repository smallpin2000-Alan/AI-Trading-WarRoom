import json #line:1

import logging #line:2

import os #line:3

import pathlib #line:4

import re #line:5

import socket #line:6

from threading import Lock #line:7

import threading #line:8

from time import sleep #line:9

from PY_Trade_package .Helper import IniFile #line:10

from PY_Trade_package .Product import *#line:11

from PY_Trade_package .SolClientOB import SolClient #line:12

from PY_Trade_package .SolPYAPI import *#line:13

from PY_Trade_package .MarketDataMart import MarketDataMart ,SystemEvent #line:14

from solace .messaging .receiver .message_receiver import MessageHandler ,InboundMessage #line:15

import hashlib #line:16

class TMarketKind (Enum ):#line:18

    ALL =0 #line:19

    FUT =1 #line:20

    STK =2 #line:21

    OVS =3 #line:22

class TVerifyResult ():#line:23

    MarketKind :TMarketKind #line:24

    IsSucc :bool #line:25

    Msg :str #line:26

    def __init__ (self ,argIsSucc :bool ,argMarketKind :TMarketKind ,argMsg :str )->None :#line:27

        self .IsSucc =argIsSucc #line:28

        self .MarketKind =argMarketKind #line:29

        self .Msg =argMsg #line:30

class Constants :#line:32

    "TOPIC"#line:33

    AuthTopic ="DAPI/REQ/TW/AUTH/NEW"#line:35

    CheckTopicTX_TWSE ="DAPI/Quote/TWS/S/TSE/*/TX"#line:36

    CheckTopicBAS_TWSE ="DAPI/Quote/TWS/S/TSE/*/BAS"#line:37

    CheckTopicTX_TAIFEX ="DAPI/Quote/TWF/FUT/*/TX"#line:38

    CheckTopicBAS_TAIFEX ="DAPI/Quote/TWF/FUT/*/BAS"#line:39

    Topic_TWSE_SYSANNOUNCEMENT ="DAPI/Quote/TWS/ANN"#line:41

    Topic_TAIFEX_SYSANNOUNCEMENT ="DAPI/Quote/TWF/ANN"#line:42

    def __setattr__ (self ,*_O0O0000OOOOO00OOO ):#line:44

        raise Exception ("Tried to change the value of a constant")#line:45

class MasterQuoteDAPI :#line:48

    _api :SolAPI =None #line:49

    _client :SolClient =None #line:50

    _client_RevAnn :SolClient =None #line:51

    _Username :str #line:52

    _Password :str #line:53

    _IsSIM :bool #line:54

    def __init__ (self ,aMdm :MarketDataMart ,pypath :str ,loglv =logging .INFO ,conlv =logging .INFO ):#line:56

        self ._api =SolAPI (aMdm ,pypath ,False ,loglv ,conlv )#line:57

    def Set_OnLogEvent (self ,func :callable ):#line:59

        self ._api .Set_OnLogEvent (func )#line:60

    def Set_OnInterruptEvent (self ,func :callable ):#line:62

        self ._api .Set_OnInterruptEvent (func )#line:63

    def __O0OO000000OO00000 (self ,msg :'InboundMessage'):#line:65

        if msg .get_payload_as_bytes ()==None :#line:66

            self ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"QuoteHandler.OnMessage Exception Null Data, topic:{msg.get_destination_name()}")#line:67

            OOO0O0000OO0O0O00 =SystemEvent (RCode .FAIL ,f"QuoteHandler.OnMessage Exception: Null Data, topic:{msg.get_destination_name()}")#line:68

            self .Fire_OnSystemEvent_DAPI (OOO0O0000OO0O0O00 )#line:69

            return #line:70

        O0OO0O0000000O00O :str =msg .get_payload_as_bytes ().decode ('utf-8')#line:72

        O00000000OO0O00O0 :str =msg .get_destination_name ()#line:73

        O00OOO0OOO0OO0OOO =re .match (r"^DAPI/Quote/TWS/(S|W|Idx|Z|\*)/(TSE|OTC|\*)/(.+)/TX/[A-Z0-9]+$",O00000000OO0O00O0 )#line:74

        OOO0OOO00O0OO00O0 =re .match (r"^DAPI/Quote/TWF/(FUT|OPT|\*)/(.+)/TX/[A-Z0-9]+$",O00000000OO0O00O0 )#line:75

        OOOOOO00000O0OO00 =re .match (r"^DAPI/Quote/TWS/(S|W|Idx|Z|\*)/(TSE|OTC|\*)/(.+)/BAS/[A-Z0-9]+$",O00000000OO0O00O0 )#line:76

        O0OOOOOOO0OO000OO =re .match (r"^DAPI/Quote/TWF/(FUT|OPT|\*)/(.+)/BAS/[A-Z0-9]+$",O00000000OO0O00O0 )#line:77

        O00O0O0O0O0O00OOO =re .match (r"DAPI/Quote/TWS/ANN",O00000000OO0O00O0 )#line:78

        O0O0O00OO00OOOO0O =re .match (r"DAPI/Quote/TWF/ANN",O00000000OO0O00O0 )#line:79

        if OOOOOO00000O0OO00 :#line:81

            O0000OO00OO0O000O :TStkQtBase =TStkQtBase ()#line:82

            O0000OO00OO0O000O .Handle_BAS (O0OO0O0000000O00O )#line:83

            OO0OO0O0O0OOOOOO0 :TStkQuoteData =TStkQuoteData (TStkProdKind .pkNone ,O0000OO00OO0O000O .StkNo ,False )#line:84

            OO0OO0O0O0OOOOOO0 .HL =TStkQtHL ()#line:85

            OO0OO0O0O0OOOOOO0 .BAS =O0000OO00OO0O000O #line:86

            OOO0O0O0O00O00O0O :ProductBasic_Stk =ProductBasic_Stk (OO0OO0O0O0OOOOOO0 )#line:87

            self .Fire_OnUpdateBasic_DAPI (OOO0O0O0O00O00O0O )#line:88

        elif O0OOOOOOO0OO000OO :#line:89

            O0O00O0000O0O0000 :TFutQtBase =TFutQtBase ()#line:90

            O0O00O0000O0O0000 .Handle_BAS (O0OO0O0000000O00O )#line:91

            OO0OO0O0O0OOOOOO0 :TFutQuoteData =TFutQuoteData (TFutProdKind .pkNone ,O0O00O0000O0O0000 .OrdProdID ,False )#line:92

            OO0OO0O0O0OOOOOO0 .HL =TFutQtHL ()#line:93

            OO0OO0O0O0OOOOOO0 .BAS =O0O00O0000O0O0000 #line:94

            OOO0O0O0O00O00O0O :ProductBasic_Fut =ProductBasic_Fut (OO0OO0O0O0OOOOOO0 )#line:96

            self .Fire_OnUpdateBasic_DAPI (OOO0O0O0O00O00O0O )#line:98

        elif O00OOO0OOO0OO0OOO :#line:99

            O00OOOO00O00OOO00 :TStkQtTX =TStkQtTX (False )#line:100

            O00OOOO00O00OOO00 .Handle_TX (O0OO0O0000000O00O )#line:101

            OO0O00OOO0OOO00OO :ProductTick_Stk =ProductTick_Stk (None )#line:102

            OO0O00OOO0OOO00OO .Upt_TX (O00OOOO00O00OOO00 )#line:103

            OO0O00OOO0OOO00OO .Symbol =O00OOOO00O00OOO00 .fTX [0 ]#line:104

            self .Fire_OnMatch_DAPI (OO0O00OOO0OOO00OO )#line:106

        elif OOO0OOO00O0OO00O0 :#line:107

            O000OO0O0OOO000O0 :TFutQtTX =TFutQtTX (False )#line:108

            O000OO0O0OOO000O0 .Handle_TX (O0OO0O0000000O00O )#line:109

            OO0O00OOO0OOO00OO :ProductTick_Fut =ProductTick_Fut (None )#line:110

            OO0O00OOO0OOO00OO .Upt_TX (O000OO0O0OOO000O0 )#line:111

            self .Fire_OnMatch_DAPI (OO0O00OOO0OOO00OO )#line:113

        elif O00O0O0O0O0O00OOO or O0O0O00OO00OOOO0O :#line:114

            self .Fire_OnAnnouncementEvent_DAPI (O0OO0O0000000O00O )#line:115

    def DoQuoteConn (self ,exchange :str ):#line:120

        "執行報價主機連線"#line:121

        OO0OO0OOOOOO0O0O0 =self .Connect (exchange )#line:123

        return OO0OO0OOOOOO0O0O0 #line:124

    def DisConnect (self )->RCode :#line:130

        self ._client .DisConnect ()#line:131

        self .__O000OO0O0OO0O000O ._run =False #line:132

        self ._client_RevAnn .DisConnect ()#line:133

        self .__O000OOO0OOO00000O ._run =False #line:134

        return self ._api .DisConnect ()#line:136

    def Login (self ,aUsername :str ,aPassword :str ,exchange :str ,aIsSIM :bool =False )->RCode :#line:141

        """DAPI使用者登入"""#line:142

        self ._Username =aUsername #line:143

        self ._Password =self .MD5Pwd (aPassword )#line:144

        self ._IsSIM =aIsSIM #line:145

        O0000O0O0OOO00000 :RCode =RCode .FAIL #line:147

        try :#line:149

            O000OO00OOO0O0OO0 :str =os .path .join (pathlib .Path (self ._api ._pypath ).parent .absolute (),'Configs')#line:151

            O0OO0O0O0O0OOO00O :str =os .path .join (O000OO00OOO0O0OO0 ,"SYS_SOLACE.ini")#line:152

            O000O000O00000OOO :IniFile =IniFile (O0OO0O0O0O0OOO00O )#line:153

            OOO0O0000OO0O00OO :str =O000O000O00000OOO .GetString ("Solace","Host","")#line:155

            O0OOOOOO0O0OOOO00 :str =O000O000O00000OOO .GetString ("Solace","Vpn","")#line:156

            OOOOO0OO0OO000O0O :str =O000O000O00000OOO .GetString ("Solace","Username","")#line:157

            OOO0OO00O0OO0O00O :str =O000O000O00000OOO .GetString ("Solace","Password","")#line:158

            self ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"API Login: Host={OOO0O0000OO0O00OO},Vpn={O0OOOOOO0O0OOOO00},_Username={aUsername},Password={aPassword}")#line:160

            if self ._client ==None :#line:163

                self ._client =SolClient (OOO0O0000OO0O00OO ,O0OOOOOO0O0OOOO00 ,OOOOO0OO0OO000O0O ,OOO0OO00O0OO0O00O ,self ._api ._log )#line:164

                self ._client_RevAnn =SolClient (OOO0O0000OO0O00OO ,O0OOOOOO0O0OOOO00 ,"Recover_ANN",OOO0OO00O0OO0O00O ,self ._api ._log )#line:165

            self ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"Start Auth: solace host={OOO0O0000OO0O00OO}")#line:167

            if hasattr (self ,'_MasterQuoteDAPI__fWorkThr_HandleQuote'):#line:168

                self .__O000OO0O0OO0O000O ._run =True #line:169

            else :#line:170

                self .__O000OO0O0OO0O000O =TSolMsgThrdClass_DAPI ("Trd_HandleQuote_DAPI",self ._api ._log ,self .__O0OO000000OO00000 )#line:171

            if hasattr (self ,'_MasterQuoteDAPI__fWorkThr_HandleQuote_RevAnn'):#line:173

                self .__O000OOO0OOO00000O ._run =True #line:174

            else :#line:175

                self .__O000OOO0OOO00000O =TSolMsgThrdClass_DAPI ("Trd_HandleQuote_DAPI_RevAnn",self ._api ._log ,self .__O0OO000000OO00000 )#line:176

            if self ._client ._is_connected ==False :#line:178

                O0000O0O0OOO00000 =self ._client .createConnection (self .__O000OO0O0OO0O000O )#line:179

                if O0000O0O0OOO00000 !=RCode .OK :#line:180

                    self ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"Create Auth Connection Fail: rc={O0000O0O0OOO00000}")#line:181

                    O0000O0O0OOO00000 =RCode .FAIL #line:182

                    self .Fire_OnLoginResultEvent_DAPI (False ,"[Login]驗證主機(Sol)連線失敗!")#line:183

                    return O0000O0O0OOO00000 #line:184

                else :#line:185

                    self .SubSysAnnouncement ()#line:187

            O00O00O0O0OOOO0O0 =self .DoQuoteConn (exchange )#line:189

            return O00O00O0O0OOOO0O0 #line:190

        except Exception as O00000OO000O0O000 :#line:191

            self .Fire_OnLoginResultEvent_DAPI (False ,f"[Login]Failed: error={O00000OO000O0O000}")#line:192

            return RCode .FAIL #line:193

    def MD5Pwd (self ,aPwd ):#line:195

        try :#line:196

            OO0000OOO00OOO000 =hashlib .md5 (aPwd .encode ()).hexdigest ()#line:197

            return OO0000OOO00OOO000 #line:198

        except Exception as O0O000OO0O0OO0O0O :#line:199

            self .Fire_OnLoginResultEvent_DAPI (False ,f"[Login]MD5Pwd Failed: error={O0O000OO0O0OO0O0O}")#line:200

        return ""#line:201

    def Auth_TWSE (self ,userLoginReply :UserLoginReply )->RCode :#line:203

        "證券驗證報價"#line:204

        O00O00O0O0O00OOO0 :RCode =RCode .FAIL #line:205

        O00O00O0O0O00OOO0 =self ._client .AddSubscriptionXUid (Constants .CheckTopicBAS_TWSE ,userLoginReply .uid ,False )#line:206

        if O00O00O0O0O00OOO0 ==RCode .OK :#line:207

            O00O00O0O0O00OOO0 =self ._client .AddSubscriptionXUid (Constants .CheckTopicTX_TWSE ,userLoginReply .uid ,False )#line:208

            if O00O00O0O0O00OOO0 ==RCode .OK :#line:209

                OO0OOOOOO00O0OOO0 =SystemEvent (O00O00O0O0O00OOO0 ,"[Auth_TWSE] Sub Verified TWSE OK")#line:210

                self .Fire_OnSystemEvent_DAPI (OO0OOOOOO00O0OOO0 )#line:211

            else :#line:212

                O00O00O0O0O00OOO0 =RCode .SUBSCRIPTION_FAIL #line:213

                OO0OOOOOO00O0OOO0 =SystemEvent (O00O00O0O0O00OOO0 ,"[Auth_TWSE] Sub Verified TWSE Subscription for Failed(TX)")#line:214

                self .Fire_OnSystemEvent_DAPI (OO0OOOOOO00O0OOO0 )#line:215

        else :#line:217

            O00O00O0O0O00OOO0 =RCode .SUBSCRIPTION_FAIL #line:218

            OO0OOOOOO00O0OOO0 =SystemEvent (O00O00O0O0O00OOO0 ,"[Auth_TWSE] Sub Verified TWSE Subscription for Failed(BAS)")#line:219

            self .Fire_OnSystemEvent_DAPI (OO0OOOOOO00O0OOO0 )#line:220

        return O00O00O0O0O00OOO0 #line:222

    def Auth_TAIFEX (self ,userLoginReply :UserLoginReply )->RCode :#line:226

        """期貨驗證報價"""#line:227

        OO0OOOOO0000O0O00 :RCode =RCode .FAIL #line:229

        OO0OOOOO0000O0O00 =self ._client .AddSubscriptionXUid (Constants .CheckTopicBAS_TAIFEX ,userLoginReply .uid ,False )#line:231

        if OO0OOOOO0000O0O00 ==RCode .OK :#line:232

            OO0OOOOO0000O0O00 =self ._client .AddSubscriptionXUid (Constants .CheckTopicTX_TAIFEX ,userLoginReply .uid ,False )#line:233

            if OO0OOOOO0000O0O00 ==RCode .OK :#line:234

                O00O0OO0O00O00OOO =SystemEvent (OO0OOOOO0000O0O00 ,"[Auth_TAIFEX] Sub Verified TAIFEX OK")#line:235

                self .Fire_OnSystemEvent_DAPI (O00O0OO0O00O00OOO )#line:236

            else :#line:237

                OO0OOOOO0000O0O00 =RCode .SUBSCRIPTION_FAIL #line:238

                O00O0OO0O00O00OOO =SystemEvent (OO0OOOOO0000O0O00 ,"[Auth_TAIFEX] Sub Verified TAIFEX Subscription for Failed(TX)")#line:239

                self .Fire_OnSystemEvent_DAPI (O00O0OO0O00O00OOO )#line:240

        else :#line:241

            OO0OOOOO0000O0O00 =RCode .SUBSCRIPTION_FAIL #line:242

            O00O0OO0O00O00OOO =SystemEvent (OO0OOOOO0000O0O00 ,"[Auth_TAIFEX] Sub Verified TAIFEX Subscription for  Failed(BAS)")#line:243

            self .Fire_OnSystemEvent_DAPI (O00O0OO0O00O00OOO )#line:244

            return OO0OOOOO0000O0O00 #line:245

        return OO0OOOOO0000O0O00 #line:246

    def Connect (self ,exchange :str )->RCode :#line:250

        "取得驗證並執行報價主機連線"#line:251

        try :#line:252

            O0OOO00O00OOOOOO0 :RCode =RCode .OK #line:253

            OO0OOO0O00O0O0000 :UserLogin =UserLogin (self ._Username ,self ._Password ,"MQCS",RequestType .QuoteAPI .value ,self .ExtractIp (),self ._IsSIM )#line:256

            OO00O0O0OO000OOO0 :str =f'{{"uid":"{OO0OOO0O00O0O0000.uid}", "pass":"{OO0OOO0O00O0O0000.password}", "source":"{OO0OOO0O00O0O0000.source}", "requestType":{OO0OOO0O00O0O0000.requestType}, "ip":"{OO0OOO0O00O0O0000.ip}" , "isSIM":{"true" if OO0OOO0O00O0O0000.isSIM else "false"}}}'#line:260

            self ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"Start Auth: solace content={OO0OOO0O00O0O0000}")#line:262

            O0OO0O00000O000OO :str =self ._client .SendRequestSync (Constants .AuthTopic ,OO00O0O0OO000OOO0 ,"utf-8")#line:265

            if O0OO0O00000O000OO .isspace ()or O0OO0O00000O000OO ==None or len (O0OO0O00000O000OO )==0 :#line:267

                O0OOO00O00OOOOOO0 =RCode .FAIL #line:268

                self .Fire_OnLoginResultEvent_DAPI (False ,"[登入回覆.失敗]error=No Response")#line:269

                self ._api ._log .Add (arg1 =SolLogType .Info ,arg2 ="[Login]Failed: error=No Response")#line:270

                return O0OOO00O00OOOOOO0 #line:271

            self ._api ._log .Add (arg1 =SolLogType .Debug ,arg2 =f"End Auth: response={O0OO0O00000O000OO}")#line:273

            O0OOO000OO00OOO0O =json .loads (O0OO0O00000O000OO )#line:277

            OO0OO00OOOOOOOO00 =UserLoginReply ()#line:279

            if 'result'in O0OO0O00000O000OO :#line:280

                OO0OO00OOOOOOOO00 .result =O0OOO000OO00OOO0O ['result']#line:281

            if 'uid'in O0OO0O00000O000OO :#line:282

                OO0OO00OOOOOOOO00 .uid =O0OOO000OO00OOO0O ['uid']#line:283

            if 'accountStatus'in O0OO0O00000O000OO :#line:284

                OO0OO00OOOOOOOO00 .accountStatus =O0OOO000OO00OOO0O ['accountStatus']#line:285

            if 'requestType'in O0OO0O00000O000OO :#line:286

                OO0OO00OOOOOOOO00 .requestType =O0OOO000OO00OOO0O ['requestType']#line:287

            if 'typeName'in O0OO0O00000O000OO :#line:288

                OO0OO00OOOOOOOO00 .typeName =O0OOO000OO00OOO0O ['typeName']#line:289

            if 'hostName'in O0OO0O00000O000OO :#line:290

                OO0OO00OOOOOOOO00 .hostName =O0OOO000OO00OOO0O ['hostName']#line:291

            if 'vpnName'in O0OO0O00000O000OO :#line:292

                OO0OO00OOOOOOOO00 .vpnName =O0OOO000OO00OOO0O ['vpnName']#line:293

            if 'userName'in O0OO0O00000O000OO :#line:294

                OO0OO00OOOOOOOO00 .userName =O0OOO000OO00OOO0O ['userName']#line:295

            if 'password'in O0OO0O00000O000OO :#line:296

                OO0OO00OOOOOOOO00 .password =O0OOO000OO00OOO0O ['password']#line:297

            if 'message'in O0OO0O00000O000OO :#line:298

                OO0OO00OOOOOOOO00 .message =O0OOO000OO00OOO0O ['message']#line:299

            if 'announcement'in O0OO0O00000O000OO :#line:300

                OO0OO00OOOOOOOO00 .announcement =O0OOO000OO00OOO0O ['announcement']#line:301

            if 'compressLevel'in O0OO0O00000O000OO :#line:302

                OO0OO00OOOOOOOO00 .compressLevel =O0OOO000OO00OOO0O ['compressLevel']#line:303

            if 'twsPsaStatus'in O0OO0O00000O000OO :#line:304

                OO0OO00OOOOOOOO00 .twsPsaStatus =O0OOO000OO00OOO0O ['twsPsaStatus']#line:305

            if 'twfPsaStatus'in O0OO0O00000O000OO :#line:306

                OO0OO00OOOOOOOO00 .twfPsaStatus =O0OOO000OO00OOO0O ['twfPsaStatus']#line:307

            if not (OO0OO00OOOOOOOO00 .announcement ==None or OO0OO00OOOOOOOO00 .announcement .isspace ()or len (OO0OO00OOOOOOOO00 .announcement )==0 ):#line:309

                self .Fire_OnAnnouncementEvent_DAPI (OO0OO00OOOOOOOO00 .announcement )#line:310

            self ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"UserLoginReply.Result: {OO0OO00OOOOOOOO00.result}")#line:313

            if OO0OO00OOOOOOOO00 .result ==True :#line:315

                if OO0OO00OOOOOOOO00 .twsPsaStatus !=2 and OO0OO00OOOOOOOO00 .twfPsaStatus !=2 :#line:317

                    O0OOO00O00OOOOOO0 =RCode .USER_NOT_VERIFIED #line:318

                    self .Fire_OnLoginResultEvent_DAPI (False ,"公告尚未驗證，請至台新證券官網>電子平台>數位API專區，進行驗證")#line:319

                    return O0OOO00O00OOOOOO0 #line:320

                elif exchange =="TWS"and OO0OO00OOOOOOOO00 .twsPsaStatus !=2 :#line:321

                    O0OOO00O00OOOOOO0 =RCode .USER_NOT_VERIFIED #line:322

                    self .Fire_OnLoginResultEvent_DAPI (False ,"公告尚未驗證，請至台新證券官網>電子平台>數位API專區，進行驗證")#line:323

                    return O0OOO00O00OOOOOO0 #line:324

                elif exchange =="TWF"and OO0OO00OOOOOOOO00 .twfPsaStatus !=2 :#line:325

                    O0OOO00O00OOOOOO0 =RCode .USER_NOT_VERIFIED #line:326

                    self .Fire_OnLoginResultEvent_DAPI (False ,"公告尚未驗證，請至台新證券官網>電子平台>數位API專區，進行驗證")#line:327

                    return O0OOO00O00OOOOOO0 #line:328

                self ._client_RevAnn .createConnection (self .__O000OOO0OOO00000O )#line:331

                self ._client_RevAnn .request_cached_only ("dc01",Constants .Topic_TWSE_SYSANNOUNCEMENT ,60000 ,self ._client_RevAnn .GetRequestID ())#line:332

                if OO0OO00OOOOOOOO00 .accountStatus [0 ]==AccountStatus .NotApplied .value and OO0OO00OOOOOOOO00 .accountStatus [1 ]==AccountStatus .NotApplied .value :#line:335

                    O0OOO00O00OOOOOO0 =RCode .USER_NOT_APPLIED #line:336

                    self .Fire_OnVerifiedEvent_DAPI (TVerifyResult (False ,TMarketKind .ALL ,"尚未提出API申請，\n請至台新證券官網>電子平台>數位API專區提出申請"))#line:337

                    return O0OOO00O00OOOOOO0 #line:338

                else :#line:340

                    OOOO0OO0OO0000O0O :RCode =RCode .FAIL #line:343

                    OOO0OO0O0OO0OO0OO :RCode =RCode .FAIL #line:344

                    OOOO0OO0OO0000O0O =self .Auth_TWSE (OO0OO00OOOOOOOO00 )#line:346

                    OOO0OO0O0OO0OO0OO =self .Auth_TAIFEX (OO0OO00OOOOOOOO00 )#line:348

                    if OO0OO00OOOOOOOO00 .accountStatus [0 ]==AccountStatus .NotVerified .value and OO0OO00OOOOOOOO00 .accountStatus [1 ]==AccountStatus .NotVerified .value :#line:351

                        O0OOO00O00OOOOOO0 =RCode .USER_NOT_VERIFIED_TWSE_TAIFEX #line:353

                        self .Fire_OnSystemEvent_DAPI (SystemEvent (O0OOO00O00OOOOOO0 ,"[驗證失敗]行情尚未開通，請至台新證券官網>電子平台>數位API專區，進行驗證"))#line:354

                        self .Fire_OnVerifiedEvent_DAPI (TVerifyResult (False ,TMarketKind .ALL ,"行情尚未開通，請至台新證券官網>電子平台>數位API專區，進行驗證"))#line:355

                        return O0OOO00O00OOOOOO0 #line:356

                    else :#line:357

                        if OO0OO00OOOOOOOO00 .accountStatus [0 ]==AccountStatus .Verified .value or OO0OO00OOOOOOOO00 .accountStatus [1 ]==AccountStatus .Verified .value :#line:358

                            if exchange =="TWS"and OO0OO00OOOOOOOO00 .accountStatus [0 ]==AccountStatus .NotVerified .value :#line:359

                                self .Fire_OnVerifiedEvent_DAPI (TVerifyResult (False ,TMarketKind .STK ,"行情尚未開通，請至台新證券官網>電子平台>數位API專區，進行驗證"))#line:361

                                O0OOO00O00OOOOOO0 =RCode .USER_NOT_VERIFIED_TWSE #line:362

                                return O0OOO00O00OOOOOO0 #line:364

                            elif exchange =="TWF"and OO0OO00OOOOOOOO00 .accountStatus [1 ]==AccountStatus .NotVerified .value :#line:365

                                O0OOO00O00OOOOOO0 =RCode .USER_NOT_VERIFIED_TAIFEX #line:367

                                self .Fire_OnVerifiedEvent_DAPI (SystemEvent (False ,"行情尚未開通，請至台新證券官網>電子平台>數位API專區，進行驗證"))#line:368

                                return O0OOO00O00OOOOOO0 #line:370

                    self ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"Quote Srv Connect rc={O0OOO00O00OOOOOO0}, rc_TWSE={OOO0OO0O0OO0OO0OO}, rc_TAIFEX={OOOO0OO0OO0000O0O}")#line:373

                    if OO0OO00OOOOOOOO00 .accountStatus [0 ]==AccountStatus .Verified .value or OO0OO00OOOOOOOO00 .accountStatus [1 ]==AccountStatus .Verified .value :#line:376

                        self .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .OK ,"準備行情連線..."))#line:377

                        O0OOO00O00OOOOOO0 =self ._api .Connect (OO0OO00OOOOOOOO00 .hostName ,OO0OO00OOOOOOOO00 .vpnName ,OO0OO00OOOOOOOO00 .userName ,OO0OO00OOOOOOOO00 .password ,OO0OO00OOOOOOOO00 .compressLevel )#line:379

                        if O0OOO00O00OOOOOO0 !=RCode .OK :#line:381

                            self ._api ._log .Add (arg1 =SolLogType .Info ,arg2 =f"Quote Srv Connect Fail: rc={O0OOO00O00OOOOOO0}")#line:382

                            return RCode .FAIL #line:383

                    else :#line:384

                        self .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .FAIL ,"行情尚未驗證成功, 無法執行情連線!"))#line:385

            else :#line:386

                O0OOO00O00OOOOOO0 =RCode .USER_VERIFICATION_FAIL #line:387

                self .Fire_OnLoginResultEvent_DAPI (False ,f"[登入回覆.失敗]{OO0OO00OOOOOOOO00.message}")#line:388

                self ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[Login]Failed: error={OO0OO00OOOOOOOO00.message} rc={O0OOO00O00OOOOOO0}")#line:389

                return O0OOO00O00OOOOOO0 #line:390

            return O0OOO00O00OOOOOO0 #line:391

        except Exception as OOO0OO0O0O00O0O0O :#line:392

            self .Fire_OnLoginResultEvent_DAPI (False ,f"[登入回覆.失敗]{OOO0OO0O0O00O0O0O}")#line:393

            self ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"[Login Reply]Failed: error={OOO0OO0O0O00O0O0O}")#line:394

            return RCode .FAIL #line:395

    def IsConnect (self )->bool :#line:397

        return self ._api .IsConnect ()#line:398

    def Subscribe (self ,aExchange :str ,aSymbol :str )->RCode :#line:403

        """(國內)單一商品訂閱

            aExchange:TWF/TWS

            aSymbol:證:2330; 期:TXFA3"""#line:406

        return self ._api .Subscribe (aExchange ,aSymbol )#line:407

    def Unsubscribe (self ,aExchange :str ,aSymbol :str )->RCode :#line:408

        """(國內)單一商品取消訂閱

            aExchange:TWF/TWS

            aSymbol:證:2330; 期:TXFA3"""#line:411

        return self ._api .Unsubscribe (aExchange ,aSymbol )#line:412

    def OvsSubscribe (self ,aSymbol :str ):#line:414

        """(海外)單一商品訂閱

            aSymbol:EX:NQ.202303"""#line:416

        self ._api .OvsSubscribe (aSymbol )#line:417

    def OvsUnSubscribe (self ,aSymbol :str ):#line:418

        """(海外)單一商品訂閱

        aSymbol :EX:NQ.202303"""#line:420

        self ._api .OvsUnSubscribe (aSymbol )#line:421

    def QryProdID_NormalStock (self )->RCode :#line:426

        "out TQryStkProdMap mapProd"#line:427

        OOO00OO0O0000OOO0 ,OOO00OO0O000OO0OO =self ._api .QryProdID_NormalStock ()#line:428

        return OOO00OO0O0000OOO0 ,OOO00OO0O000OO0OO #line:429

    def QryProd_FutCom2 (self )->RCode :#line:430

        "out TObjFutComList aProdList"#line:431

        O000O00000O0OOOOO ,O00O0000O0OO0OOO0 =self ._api .QryProd_FutCom2 ()#line:432

        return O000O00000O0OOOOO ,O00O0000O0OO0OOO0 #line:433

    def QryProd_Fut (self ,aIsNormal :bool ,aIsFutStk :bool ,aIsSmall :bool )->RCode :#line:435

        """ out TObjBaseFutMap aMapProdBase"""#line:436

        O0O0O0O0OO0OO0OOO ,O0O00OO0OO00O0OOO =self ._api .QryProd_Fut (aIsNormal ,aIsFutStk ,aIsSmall )#line:437

        return O0O0O0O0OO0OO0OOO ,O0O00OO0OO00O0OOO #line:438

    def QryProd_Opt (self ,aIsNormal :bool ,aIsOptStk :bool ,aIsSmall :bool )->RCode :#line:440

        "out TObjBaseOptMap aMapProdBase"#line:441

        OO00O00O0O00O0OO0 ,O0O00000O0OOOOOO0 =self ._api .QryProd_Opt (aIsNormal ,aIsOptStk ,aIsSmall )#line:442

        return OO00O00O0O00O0OO0 ,O0O00000O0OOOOOO0 #line:443

    def QryProd_OvsFut (self )->bool :#line:445

        "out TObjOvsFutProdMthMap aMapBase"#line:446

        OOOOO000000OOOO00 ,O00OO000000O0OOO0 =self ._api .QryProd_OvsFut ()#line:447

        return OOOOO000000OOOO00 ,O00OO000000O0OOO0 #line:448

    def QryProd_OvsOpt (self )->bool :#line:449

        "out TObjOvsFutProdMthMap aMapBase"#line:450

        OOOO0O0OO000O000O ,O00O000OO0OOOOOOO =self ._api .QryProd_OvsOpt ()#line:451

        return OOOO0O0OO000O000O ,O00O000OO0OOOOOOO #line:452

    def SubSysAnnouncement (self ):#line:457

        "訂閱系統公告"#line:458

        try :#line:459

            OO00OO00OOO000OO0 :RCode =RCode .FAIL #line:460

            OO00OO00OOO000OO0 =self ._client .AddSubscription (Constants .Topic_TWSE_SYSANNOUNCEMENT )#line:461

            if OO00OO00OOO000OO0 !=RCode .OK :#line:462

                self .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .SUBSCRIPTION_FAIL ,f"[SubSysAnnouncement]Subscription for TWS_SysAnnouncement Failed, rc={OO00OO00OOO000OO0}"))#line:463

        except Exception as OO000O0OOO00OO00O :#line:464

            self ._api ._log .Add (arg1 =SolLogType .Error ,arg2 =f"SubSysMsg fail, error={OO000O0OOO00OO00O}")#line:465

            self .Fire_OnSystemEvent_DAPI (SystemEvent (RCode .FAIL ,f"[SubSysMsg]Failed: error={OO000O0OOO00OO00O}"))#line:466

    def ExtractIp (self )->str :#line:468

        "取得本機IP"#line:469

        OO0O0O0O0OOO00OO0 =""#line:470

        with socket .socket (socket .AF_INET ,socket .SOCK_DGRAM )as OO00O0O0OO00000O0 :#line:471

            OO00O0O0OO00000O0 .connect (('10.255.255.255',1 ))#line:472

            OO0O0O0O0OOO00OO0 =OO00O0O0OO00000O0 .getsockname ()[0 ]#line:473

        return OO0O0O0O0OOO00OO0 #line:474

    OnLoginResultEvent_DAPI :callable =None #line:478

    def Fire_OnLoginResultEvent_DAPI (self ,aIsSucc :bool ,aMsg :str ):#line:479

        if self .OnLoginResultEvent_DAPI ==None :#line:480

            return #line:481

        if self .OnLoginResultEvent_DAPI !=None :#line:482

            self .OnLoginResultEvent_DAPI (aIsSucc ,aMsg )#line:483

    OnSystemEvent_DAPI :callable =None #line:487

    def Fire_OnSystemEvent_DAPI (self ,data :SystemEvent ):#line:488

        if self .OnSystemEvent_DAPI ==None :#line:489

            return #line:490

        if self .OnSystemEvent_DAPI !=None :#line:491

            self .OnSystemEvent_DAPI (data )#line:492

    OnAnnouncementEvent_DAPI :callable =None #line:495

    def Fire_OnAnnouncementEvent_DAPI (self ,data :str ):#line:496

        if self .OnAnnouncementEvent_DAPI ==None :#line:497

            return #line:498

        if self .OnAnnouncementEvent_DAPI !=None :#line:499

            self .OnAnnouncementEvent_DAPI (data )#line:500

    OnVerifiedEvent_DAPI :callable =None #line:503

    def Fire_OnVerifiedEvent_DAPI (self ,data :TVerifyResult ):#line:504

        if self .OnVerifiedEvent_DAPI ==None :#line:505

            return #line:506

        if self .OnVerifiedEvent_DAPI !=None :#line:508

            self .OnVerifiedEvent_DAPI (data )#line:509

    OnMatch_DAPI :callable =None #line:512

    def Fire_OnMatch_DAPI (self ,data :ProductTick ):#line:513

        if self .OnMatch_DAPI ==None :#line:514

            return #line:515

        if self .OnMatch_DAPI !=None :#line:516

            self .OnMatch_DAPI (data )#line:517

    OnUpdateBasic_DAPI :callable =None #line:521

    def Fire_OnUpdateBasic_DAPI (self ,data :ProductBasic ):#line:522

        if self .OnUpdateBasic_DAPI ==None :#line:523

            return #line:524

        if self .OnUpdateBasic_DAPI !=None :#line:525

            self .OnUpdateBasic_DAPI (data )#line:526

        else :#line:527

            pass #line:528

class TSolMsgThrdClass_DAPI (MessageHandler ):#line:535

    """create thread get receive to list and then call UI mesage"""#line:536

    def __init__ (self ,name :str ,log :logging .Logger ,MsgHdr_proc ):#line:539

        self ._name =name #line:540

        self ._msgHandler =MsgHdr_proc #line:541

        self ._lock =Lock ()#line:542

        self ._log =log #line:543

        self ._list =[]#line:544

        self ._run =True #line:545

        self .thrd =threading .Thread (target =self .OnThread ,name =self ._name )#line:546

        self .thrd .start ()#line:547

    def OnThread (self ):#line:549

        O0O00OOO0O000OOOO =[]#line:550

        OOOO00OOOO0O000OO ,OO0OO00O0O00OOO00 ,OO0O0OOO0O00O0O00 =0 ,0 ,0 #line:551

        while self ._run :#line:552

            try :#line:554

                with self ._lock :#line:555

                    O0O00OOO0O000OOOO =self ._list .copy ()#line:556

                    OOOO00OOOO0O000OO =len (O0O00OOO0O000OOOO )#line:557

                    if (len (self ._list )>2000 )and OOOO00OOOO0O000OO ==OO0OO00O0O00OOO00 :#line:558

                        self ._list =[]#line:559

                for OO0O0OOO0O00O0O00 in range (OO0OO00O0O00OOO00 ,OOOO00OOOO0O000OO ):#line:561

                    self ._msgHandler (O0O00OOO0O000OOOO [OO0O0OOO0O00O0O00 ])#line:562

                OO0OO00O0O00OOO00 =OOOO00OOOO0O000OO #line:564

            except Exception as OOOOO00O0O0OOO0O0 :#line:565

                self ._log .Add (arg1 =SolLogType .Error ,arg2 =f"TSolMsgThrdClass_DAPI send_request exception! exception={OOOOO00O0O0OOO0O0}")#line:567

            finally :#line:568

                sleep (0.001 )#line:569

    def Add (self ,message :'InboundMessage'):#line:571

        with self ._lock :#line:572

            self ._list .append (message )#line:573

    def on_message (self ,message :'InboundMessage'):#line:575

        """ Message receive callback """#line:576

        self .Add (message )#line:577

